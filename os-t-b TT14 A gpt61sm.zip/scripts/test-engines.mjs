#!/usr/bin/env node
/** Nonvisual agent test: compile REAL engine source to a temporary CommonJS tree, run acceptance
 * checks and remove the tree. Does not start Next, touch DB data, or rewrite import specifiers.
 * Exit code is nonzero on compiler or acceptance failure. JSON output is an execution log, not
 * ledger evidence (the live server suite separately records fingerprint-bound acceptance results).
 */
import { spawnSync } from "node:child_process";
import { mkdtempSync, rmSync, mkdirSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";
import { createRequire } from "node:module";
const root = dirname(dirname(fileURLToPath(import.meta.url)));
const require = createRequire(import.meta.url);
const build = mkdtempSync(join(tmpdir(), "fusion-engine-checks-"));
let status = 1;
try {
  const compile = spawnSync(process.execPath, [join(root, "node_modules/typescript/bin/tsc"),
    "src/lib/verification/tt14.ts", "--rootDir", "src/lib", "--outDir", build,
    "--module", "commonjs", "--target", "es2022", "--moduleResolution", "node", "--strict", "--skipLibCheck"],
    { cwd: root, encoding: "utf8", timeout: 120000 });
  if (compile.status !== 0) throw new Error(`Engine compilation failed:\n${compile.stdout}\n${compile.stderr}`);
  const { runTT14Checks } = require(join(build, "verification/tt14.js"));
  const cases = runTT14Checks();
  for (const c of cases) console.log(`${c.pass ? "PASS" : "FAIL"} ${c.id} — ${c.detail}`);
  const passed = cases.every((c) => c.pass);
  console.log(`ENGINE SUMMARY ${cases.filter((c) => c.pass).length}/${cases.length}`);
  mkdirSync(join(root, "verification"), { recursive: true });
  writeFileSync(join(root, "verification/engine-execution.json"), JSON.stringify({ suite: "pure-engine-acceptance", runAt: new Date().toISOString(), passed, cases }, null, 2));
  status = passed ? 0 : 1;
} catch (e) { console.error(String(e)); }
finally { rmSync(build, { recursive: true, force: true }); }
process.exitCode = status;
