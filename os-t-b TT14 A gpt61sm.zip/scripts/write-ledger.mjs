// Run after recording the four verification suites. This file is a derived artifact, never a hand-count.
// APP_URL=https://... node scripts/write-ledger.mjs
import { mkdirSync, writeFileSync } from "node:fs";
const base = process.env.APP_URL;
if (!base) throw new Error("APP_URL required");
const response = await fetch(`${base}/api/ledger`, { cache: "no-store" });
if (!response.ok) throw new Error(`ledger HTTP ${response.status}`);
const d = await response.json();
const c = d.counts;
if (c.total !== c.fullBuild + c.partialBuild + c.notBuilt + c.blocked || c.total !== c.fullTest + c.partialTest + c.untested + c.notApplicable) throw new Error("ledger totals do not partition the register");
const suites = d.evidence.acceptedSuites;
if (suites.length !== 4 || d.evidence.staleSuites.length) throw new Error(`evidence incomplete/stale: ${JSON.stringify(d.evidence)}`);
const byBuild = grade => d.rows.filter(r => r.buildGrade === grade).map(r => r.id);
const byTest = grade => d.rows.filter(r => r.testGrade === grade).map(r => r.id);
const lines = [
  "# Fusion Shell build & verification ledger",
  "",
  `Generated from live \`/api/ledger\` at ${new Date().toISOString()} (source fingerprint \`${d.fingerprint}\`).`,
  "",
  "## Counting contract",
  "",
  `The unit is one feature row in \`src/lib/registry.ts\` (${c.total} rows). The original Android-only rows that were never ported into the web register are *outside this denominator*. Button callbacks and test cases are not double-counted as features.`,
  "",
  "Build and test are independent axes. A source comment, compiler pass, mock page or test name is not a passed acceptance test.",
  "",
  "| Build | Count | Test | Count |",
  "|---|---:|---|---:|",
  `| Fully built (audited scoped web contract) | **${c.fullBuild}** | Fully tested (all declared direct cases passed, Chromium/server scope) | **${c.fullTest}** |`,
  `| Partially built | **${c.partialBuild}** | Partially tested (at least one direct pass, not all gates/contract) | **${c.partialTest}** |`,
  `| Not built (skeleton/spec) | ${c.notBuilt} | Untested | ${c.untested} |`,
  `| Blocked / not applicable on web | ${c.blocked} | Tests not applicable | ${c.notApplicable} |`,
  "",
  `Build partition: ${c.fullBuild}+${c.partialBuild}+${c.notBuilt}+${c.blocked}=${c.total}. Test partition: ${c.fullTest}+${c.partialTest}+${c.untested}+${c.notApplicable}=${c.total}.`,
  "",
  "**Fully built IDs:** " + (byBuild("full").join(", ") || "none"),
  "",
  "**Fully tested IDs:** " + (byTest("full").join(", ") || "none"),
  "",
  "**Partially built IDs:** " + (byBuild("partial").join(", ") || "none"),
  "",
  "**Partially tested IDs:** " + (byTest("partial").join(", ") || "none"),
  "",
  "## Accepted, matching-fingerprint evidence",
  "",
  ...suites.map(s => `- ${s}`),
  "",
  "## Verification boundary",
  "",
  "'Fully tested' here means *only* the explicitly declared test cases passed in this Node/Chromium sandbox, with no claims about Firefox, Safari, Android hardware, receiver devices or long-soak performance. The preceding legacy suite includes real HTTPS Matrix and Wikipedia calls; WebRTC was verified between two Chromium contexts with fake camera devices on one host. PSD fixtures are generated in-repo and not independent Photoshop files. No actual Apple TV, HomePod, Chromecast, two-device LAN, BlueBubbles server, billing provider, legal reviewer or accessibility expert was available.",
  "",
  "TT14 adds a bounded spill calculator (20,000 generated cells / 8 passes), alpha-aware image layers and masks, versioned layer projects, vector affine tools, and actual Canvas-oracle comparisons. See docs/TT14-CONTRACT.md for limits. Passing the declared cases is not a production or all-feature certification.",
  "",
  "Nonvisual runner: APP_URL=https://your-preview PW_PATH=playwright node scripts/verify-preview.mjs. Pure engine checks: node scripts/test-engines.mjs. Screenshots are saved under verification/screenshots; capture is not the same as visual inspection.",
  "",
  "Highest-information next tests: independent XLSX/DOCX/PSD corpora, real receiver/mobile browsers, multi-device NAT traversal, and an independent keyboard/screen-reader audit. Do not promote a partial row before its gates.",
  "",
];
mkdirSync("docs", { recursive: true });
writeFileSync("docs/LEDGER.md", lines.join("\n"));
console.log(`WROTE docs/LEDGER.md: build full=${c.fullBuild} partial=${c.partialBuild}; test full=${c.fullTest} partial=${c.partialTest}; total=${c.total}`);
