#!/usr/bin/env node
/** Independent exported-XLSX check using Python stdlib zipfile (incl. CRC) and ElementTree XML,
 * NOT Fusion's own parser. It checks the real workbook downloaded by TT14's browser test.
 * This is package/value validation, NOT proof of Excel/LibreOffice application interoperability.
 */
import { spawnSync } from "node:child_process";
import { mkdirSync, writeFileSync } from "node:fs";
const file = process.argv[2] ?? "verification/spill-values-snapshot.xlsx";
const program = String.raw`
import json,sys,zipfile,xml.etree.ElementTree as ET
p=sys.argv[1]
ns={'s':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
with zipfile.ZipFile(p) as z:
    assert z.testzip() is None, 'CRC failure in XLSX package'
    assert '[Content_Types].xml' in z.namelist(), 'missing content types'
    root=ET.fromstring(z.read('xl/worksheets/sheet1.xml'))
    values={}
    for c in root.findall('.//s:c',ns):
        assert c.find('s:f',ns) is None, 'values snapshot still contains a formula'
        if c.get('t')=='inlineStr':
            values[c.get('r')]=''.join((t.text or '') for t in c.findall('.//s:t',ns))
        else:
            v=c.find('s:v',ns)
            values[c.get('r')]=v.text if v is not None else ''
    expected={'A1':'50','E1':'10','F1':'15','E2':'20','F2':'25'}
    for ref,value in expected.items():
        assert values.get(ref)==value, f'{ref}: expected {value}, got {values.get(ref)}'
    print(json.dumps({'pass':True,'parser':'Python stdlib zipfile+ElementTree','crc':'valid','expectedCells':expected,'scope':'package and values, not independent Office application test'}))
`;
const r = spawnSync("python3", ["-c", program, file], { encoding: "utf8", timeout: 30000 });
if (r.status !== 0) { console.error(r.stderr || r.error || r.stdout); process.exit(r.status ?? 1); }
const data = JSON.parse(r.stdout);
mkdirSync("verification", { recursive: true });
writeFileSync("verification/independent-xlsx-check.json", JSON.stringify({ ...data, at: new Date().toISOString(), file }, null, 2));
console.log("INDEPENDENT XLSX PASS: CRC valid, no formulas, all five expected source/generated cells preserved");
