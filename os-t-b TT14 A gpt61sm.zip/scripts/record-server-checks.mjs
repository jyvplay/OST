// Records actual /api/selftest output. No claim is promoted by source text or a fabricated fixture.
// Run after build_and_start: APP_URL=https://... node scripts/record-server-checks.mjs
import { mkdirSync, writeFileSync } from "node:fs";
const base = process.env.APP_URL;
if (!base) throw new Error("APP_URL required");
const [ledgerRes, testRes] = await Promise.all([fetch(`${base}/api/ledger`, { cache: "no-store" }), fetch(`${base}/api/selftest`, { cache: "no-store" })]);
if (!ledgerRes.ok || !testRes.ok) throw new Error(`status ledger=${ledgerRes.status}, selftest=${testRes.status}`);
const ledger = await ledgerRes.json();
const test = await testRes.json();
const artifact = {
  fingerprint: ledger.fingerprint,
  runAt: new Date().toISOString(),
  suite: "server-selftest",
  passed: test.ok && test.pass === test.total,
  cases: test.checks.map(c => ({ id: c.id, pass: c.pass, detail: c.detail })),
};
mkdirSync("verification", { recursive: true });
writeFileSync("verification/server.json", JSON.stringify(artifact, null, 2));
console.log(`SERVER ${test.pass}/${test.total} fingerprint=${artifact.fingerprint}`);
if (!artifact.passed) {
  for (const c of artifact.cases.filter(x => !x.pass)) console.error(`FAIL ${c.id}: ${c.detail}`);
  process.exit(1);
}
