#!/usr/bin/env node
/** Fail-fast, nonvisual verification orchestrator. Requires a running platform-managed preview.
 * Does NOT launch next dev/start. Uses actual exit codes, not grep through a pipeline.
 * Compiler/build gates remain separate (see developer instructions and docs/TT14-CONTRACT.md).
 * APP_URL=https://... PW_PATH=/tmp/fusion-e2e/node_modules/playwright node scripts/verify-preview.mjs
 */
import { spawnSync } from "node:child_process";
const base = process.env.APP_URL;
if (!base) throw new Error("Set APP_URL to the running preview URL");
const health = await fetch(`${base}/api/health`);
if (!health.ok || !(await health.json()).ok) throw new Error("Preview/database health failed");
const before = await (await fetch(`${base}/api/ledger`)).json();
const steps = ["scripts/test-engines.mjs", "scripts/record-server-checks.mjs", "tests/e2e/fusion.e2e.mjs", "tests/e2e/fusion-extended.mjs", "tests/e2e/tt14.mjs", "scripts/write-ledger.mjs"];
for (const script of steps) {
  console.log(`\n=== ${script} ===`);
  const run = spawnSync(process.execPath, [script], { stdio: "inherit", env: process.env, timeout: 540000 });
  if (run.status !== 0) { console.error(`FAILED ${script}: exit=${run.status}, signal=${run.signal}, error=${run.error ?? "none"}`); process.exit(run.status ?? 1); }
}
const after = await (await fetch(`${base}/api/ledger`)).json();
if (before.fingerprint !== after.fingerprint) throw new Error("Source changed during verification; evidence must be rerun");
if (after.evidence.staleSuites.length) throw new Error(`Evidence stale/missing: ${after.evidence.staleSuites.join(", ")}`);
console.log("\nVERIFICATION PASSED", after.fingerprint, after.counts);
console.log("Screenshots captured by TT14 require inspection; this script does not call them visually reviewed.");
