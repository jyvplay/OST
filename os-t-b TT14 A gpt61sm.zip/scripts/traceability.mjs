// Implements: spec §10 traceability gate.
// 1) Every row the server reports as "implemented" must be cited by ID in source (outside the registry).
// 2) Every ID cited in source must exist in the registry (unknown citations are reported).
// 3) Reports which implemented rows are exercised by the browser e2e suite (tests/e2e) vs. code-only.
// Usage: APP_URL=https://... node scripts/traceability.mjs
import { readFileSync, readdirSync, statSync } from "node:fs";
import path from "node:path";

const APP = process.env.APP_URL ?? "http://localhost:3000";
const reg = await (await fetch(`${APP}/api/registry`)).json();
const rows = reg.features;

const files = [];
const walk = (d) => {
  for (const f of readdirSync(d)) {
    const p = path.join(d, f);
    if (statSync(p).isDirectory()) walk(p);
    else if (/\.(ts|tsx|mjs|js)$/.test(f) && p !== path.join("src", "lib", "registry.ts")) files.push(p);
  }
};
walk("src");
walk("scripts");
const e2ePath = path.join("tests", "e2e", "fusion.e2e.mjs");
const e2e = readFileSync(e2ePath, "utf8");
const corpus = files.map((f) => readFileSync(f, "utf8")).join("\n");

const idRe = /(?<![A-Za-z0-9])([A-Z]{2}-\d{2}[a-z]?)(?![0-9a-z])/g;
const cited = new Set([...corpus.matchAll(idRe)].map((m) => m[1]));
const known = new Set(rows.map((r) => r.id));
const implemented = rows.filter((r) => r.status === "implemented");

const missingCitation = implemented.filter((r) => !cited.has(r.id)).map((r) => r.id);
const unknownCitations = [...cited].filter((id) => !known.has(id));
const e2eIds = new Set([...e2e.matchAll(idRe)].map((m) => m[1]));
const verifiedE2e = implemented.filter((r) => e2eIds.has(r.id)).map((r) => r.id);
const codeOnly = implemented.filter((r) => !e2eIds.has(r.id)).map((r) => r.id);

const byStatus = {};
for (const r of rows) byStatus[r.status] = (byStatus[r.status] ?? 0) + 1;

console.log(`registry rows: ${rows.length}  statuses: ${JSON.stringify(byStatus)}`);
console.log(`implemented: ${implemented.length}  cited in code: ${implemented.length - missingCitation.length}  exercised by e2e: ${verifiedE2e.length}  code-only: ${codeOnly.length}`);
if (missingCitation.length) console.log(`FAIL uncited implemented rows: ${missingCitation.join(", ")}`);
else console.log("PASS every implemented row is cited in source");
if (unknownCitations.length) console.log(`WARN cited IDs not in registry: ${unknownCitations.join(", ")}`);
console.log(`code-only (implemented, not e2e-exercised): ${codeOnly.join(", ")}`);
process.exit(missingCitation.length ? 1 : 0);
