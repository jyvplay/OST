# Fusion Shell build & verification ledger

Generated from live `/api/ledger` at 2026-10-16T00:57:17.115Z (source fingerprint `a804e68168944613de3d`).

## Counting contract

The unit is one feature row in `src/lib/registry.ts` (189 rows). The original Android-only rows that were never ported into the web register are *outside this denominator*. Button callbacks and test cases are not double-counted as features.

Build and test are independent axes. A source comment, compiler pass, mock page or test name is not a passed acceptance test.

| Build | Count | Test | Count |
|---|---:|---|---:|
| Fully built (audited scoped web contract) | **25** | Fully tested (all declared direct cases passed, Chromium/server scope) | **25** |
| Partially built | **112** | Partially tested (at least one direct pass, not all gates/contract) | **31** |
| Not built (skeleton/spec) | 39 | Untested | 120 |
| Blocked / not applicable on web | 13 | Tests not applicable | 13 |

Build partition: 25+112+39+13=189. Test partition: 25+31+120+13=189.

**Fully built IDs:** WM-06, SR-04, SR-05, FM-16, ST-03, ST-08, PR-05, PR-06, PR-07c, PR-07d, PR-07e, PR-07f, PR-07o, PR-07q, PR-07r, PR-11, PR-12, FF-01, FF-02, FF-05, FF-09, FF-11, FF-17, MD-03, CT-02

**Fully tested IDs:** WM-06, SR-04, SR-05, FM-16, ST-03, ST-08, PR-05, PR-06, PR-07c, PR-07d, PR-07e, PR-07f, PR-07o, PR-07q, PR-07r, PR-11, PR-12, FF-01, FF-02, FF-05, FF-09, FF-11, FF-17, MD-03, CT-02

**Partially built IDs:** SH-01, SH-02, SH-03, SH-04, SH-05, SH-06, SH-07, SH-08, SH-09, SH-10, SH-11, SH-12, WM-01, WM-02, WM-03, WM-04, WM-05, WM-07, WM-09, WM-10, WM-11, WM-13, SR-01, SR-02, SR-03, SR-06, SR-08, FM-01, FM-02, FM-03, FM-10, FM-11, FM-15, FM-17, FM-18, NC-01, NC-02, NC-03, NC-04, NC-05, ST-01, ST-02, ST-04, ST-05, ST-06, ST-07, ST-09, AP-05, TD-01, TD-02, PR-01, PR-02, PR-03, PR-04, PR-07a, PR-07b, PR-07g, PR-08, PR-09, FF-03, FF-06, FF-08, FF-12, FF-15, MD-01, MD-02, MD-04, MD-06, MD-07, SC-01, SC-03, SC-05, SC-08, BK-01, BK-03, BK-05, BK-06, CT-01, CT-06, CA-01, CA-02, CA-05, CA-08, CA-11, CA-14, LN-01, LN-04, LN-13, LN-15, LN-20, LN-23, MS-06, AX-01, AX-02, AX-03, AX-04, AU-01, AU-02, AU-05, RG-01, RG-04, RG-06, RG-07, RG-08, BL-02, BL-04, BL-05, PR-10, VR-01, VR-02, VR-03, VR-04

**Partially tested IDs:** SH-01, SH-05, SH-06, SH-09, SH-11, SH-12, WM-01, WM-09, SR-01, FM-18, NC-02, NC-04, ST-06, ST-09, PR-03, PR-04, FF-03, FF-08, FF-12, MD-04, MD-07, SC-03, LN-20, MS-06, AU-01, AU-02, AU-05, VR-01, VR-02, VR-03, VR-04

## Accepted, matching-fingerprint evidence

- server-selftest@2026-10-16T00:56:10.952Z pass
- legacy-browser-chromium@2026-10-16T00:56:42.732Z pass
- extended-browser-chromium@2026-10-16T00:57:12.467Z pass
- tt14-browser-chromium@2026-10-16T00:57:16.996Z pass

## Verification boundary

'Fully tested' here means *only* the explicitly declared test cases passed in this Node/Chromium sandbox, with no claims about Firefox, Safari, Android hardware, receiver devices or long-soak performance. The preceding legacy suite includes real HTTPS Matrix and Wikipedia calls; WebRTC was verified between two Chromium contexts with fake camera devices on one host. PSD fixtures are generated in-repo and not independent Photoshop files. No actual Apple TV, HomePod, Chromecast, two-device LAN, BlueBubbles server, billing provider, legal reviewer or accessibility expert was available.

TT14 adds a bounded spill calculator (20,000 generated cells / 8 passes), alpha-aware image layers and masks, versioned layer projects, vector affine tools, and actual Canvas-oracle comparisons. See docs/TT14-CONTRACT.md for limits. Passing the declared cases is not a production or all-feature certification.

Nonvisual runner: APP_URL=https://your-preview PW_PATH=playwright node scripts/verify-preview.mjs. Pure engine checks: node scripts/test-engines.mjs. Screenshots are saved under verification/screenshots; capture is not the same as visual inspection.

Highest-information next tests: independent XLSX/DOCX/PSD corpora, real receiver/mobile browsers, multi-device NAT traversal, and an independent keyboard/screen-reader audit. Do not promote a partial row before its gates.
