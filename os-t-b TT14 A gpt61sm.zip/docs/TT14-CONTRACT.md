# TT14 engineering contract

This is a bounded implementation expansion, not completion of the original Android specification and not a claim of parity with LibreOffice, Excel, Photoshop, or Illustrator. The ledger counts **189 web register rows**, not every original Android row or individual callback.

## Runtime honesty

Available during this turn: repository/file tools, bash/Node 22, TypeScript 5.9, Next.js, PostgreSQL through Drizzle, npm dependency audit, web search/fetch, and Playwright. The test scripts install/use a real Chromium binary; generated screenshots are saved for inspection. There are no independent agents, theorem provers, real Apple TV/HomePod/Chromecast devices, Excel/LibreOffice installations, or physical mobile devices in this environment. Tests generated in-repo prove only their declared subset. Browser Canvas is an independent implementation used as a pixel-compositing oracle, not proof of Photoshop compatibility.

Do not treat a source citation, screenshot capture, test name, total function count, or compiler pass as independent feature verification. Current execution results belong in `verification/*.json` and `docs/LEDGER.md`.

## A. Model, access and resources

Admissible objects:

* A workbook model with source cells/formulas and separate calculated values/spill metadata. A values-only export is a different, explicitly lossy object.
* A layer document with bottom-to-top RGBA8 rasters, integer pixel translations, visibility, opacity, separable blend mode, and optional alpha masks. Project export preserves layers; PNG export flattens them.
* A vector document with shapes/groups and supported affine transforms. Text/glyph and path bounds are estimates.

Access: browser APIs act only within the origin and user grants. Office and Layers operate on local decoded files until an explicit API/save action. Next/Node handlers compute on the server; Files writes go through the existing Drizzle-backed VFS. There is no root access, arbitrary OS cursor injection, raw protocol socket, virtual camera registration, or third-party browser renderer control.

Counted resources:

| Engine | Regime and hard boundary |
|---|---|
| Spill calculation | At most 20,000 generated cells; at most 8 recalculation passes; Excel row/column coordinate bounds. API input: 1–8 sheets, 1,000 source cells, 4,096 characters/formula, 2 MB JSON cap. |
| Layers | At most 4 million pixels/canvas and per layer, 16 million total source pixels, 12 layers. Projects: version 1 and 32 MB cap. Compositing API: 2 MB input cap. Undo: 16 states sharing unchanged immutable buffers. |
| Vector geometry | Numeric matrix/translate/scale/rotate only. Unsupported transform commands produce an error, not silent flattening. Path/text bounds are approximate. |
| UI grid | At most 100 visible rows × 26 columns; snapshots include all supported generated output, not only visible cells. |

Spill allocation uses deterministic sheet/row/column order. One occupied source cell or reserved child blocks the entire array, yielding `#SPILL!`; a blank styled cell does not block, but an actual formula returning an empty string does. Generated children are read-only. Scalar references to children are recomputed with bounded fixed-point passes. Failure to stabilise reports `#CALC!` rather than looping indefinitely. Tables/merged cells, `A1#` references, external workbooks and Excel dynamic-array package metadata are outside this implementation.

Pixel units: straight (not premultiplied) sRGB bytes 0–255; alpha mask bytes 0–255; opacity 0–1. Pure-engine assertions use exact byte values; the independent Canvas comparison allows at most **2 byte values** per RGBA channel because implementations quantise premultiplication differently. No linear-light or wide-gamut colour-management claim.

Success quantifiers: **for every preregistered acceptance case**, execute its real engine/UI/API path on the current source fingerprint, and require its predicate plus the compiler, production build, preview health and required evidence gates to pass. This does **not** mean for every possible Office/PSD/SVG file or every browser/device. On any mandatory gate failure, the patch inherits no trust and affected gates are rerun. A changed source fingerprint invalidates old evidence.

Adjacent tasks not substituted: top-left scalar evaluation is not spilling; a PNG is not an editable layer project; an SVG bounding box is not exact glyph geometry; a values snapshot is not formula-preserving export; file round-trip through our own reader is not Excel/LibreOffice interoperability; an iframe is not a full browser engine; same-host WebRTC is not tested NAT traversal.

## B. Outcome space and evidence threshold

* **H+**: the declared bounded subsets work. Threshold: actual server and browser acceptance cases with matching source fingerprint and successful required build/runtime gates.
* **H−**: a normal web page cannot register a camera for native apps, become the host OS, read private data across arbitrary origins, or bypass framing policies. A different architecture/privileged companion is needed; no fake capability UI should be shipped.
* **H∂**: full Office file fidelity, independent application interoperability, mobile performance, receiver hardware, accessibility certification and multi-device networking change with additional conditions. No evidence in this turn closes those interfaces.

## C. Primary-source frontier used this turn

1. Microsoft, **Dynamic array formulas and spilled array behavior**: arrays occupy neighbouring cells; only the anchor is editable; obstructions cause `#SPILL!`. Applies to dynamic-array-capable Excel. Tables/merged-cell and external workbook restrictions are described but are not implemented here.
   https://support.microsoft.com/en-us/excel/dynamic-array-formulas-and-spilled-array-behavior
2. W3C, **Compositing and Blending Level 1**: source-over alpha and separable normal/multiply/screen formulae. Applied here to encoded sRGB byte inputs, not a claim about every colour-managed editor.
   https://www.w3.org/TR/compositing-1/
3. Apple, **Annotate an image in Preview on Mac**: selections and Instant Alpha operate on image regions; saved raster annotations cannot subsequently be edited/moved/deleted. This motivates keeping an explicit editable project distinct from a flattened PNG, not claiming Preview's exact algorithms.
   https://support.apple.com/guide/preview/annotate-an-image-prvw1501/mac
4. Playwright, **Screenshots**: actual `page.screenshot` API used by the acceptance runner. Capturing a screenshot is not the same as inspecting it.
   https://playwright.dev/docs/screenshots

5. MDN, **Permissions Policy embedded-frame syntax**: the iframe attribute is `allow="camera 'none'; microphone 'none'"`, not HTTP-header syntax `camera=()`. TT14 adds a real Chromium policy-object check after fixing the inherited grammar error.
   https://developer.mozilla.org/en-US/docs/Web/HTTP/Guides/Permissions_Policy

Security audit during this turn identified critical advisories on the old Next runtime. Targeted update: Next 16.4.2. Test-tool update: Playwright 1.56.1 (avoids the browser-download certificate-verification advisory on <1.55.1). An audit snapshot is diagnostic evidence, not penetration testing; residual advisories are not silently dismissed.

## D. Six distinct mechanisms, artifacts and attackers

| Mechanism | Artifact and established portion | Strongest structure-specific attack / cheapest falsification | Unresolved interface |
|---|---|---|---|
| Deterministic spill reservation + bounded fixed point | `src/lib/workbook.ts`, direct engine cases plus Calc/API checks | Occupied output, blank-looking formulas, different source insertion order, dependent child reference, overlapping anchors, grid edge, huge generator | Full Excel dependency graph, Tables/merged cells and package interoperability; local to the bounded scope but large outside it |
| API input/shape admission | `/api/office/calculate`, 400 refusals for bad refs/model structure | Malformed cells, duplicate sheet names, huge formulas and oversized request; API test must see refusal, not just a UI guard | Cooperative limits are not preemptive process isolation or multi-tenant security certification |
| Alpha-aware separable compositing | `src/lib/layers.ts`, analytic byte assertions and independent Canvas oracle | Transparent backdrop, hidden RGB under alpha 0, partial opacity/mask, multiply/screen against transparent pixels | Wide gamut, linear-light compositing, PSD semantics and artistic blend modes not implemented |
| Versioned editable project + immutable history | Project parser/serializer and `src/lib/history.ts`, real download/reimport/VFS save tests | Corrupt base64, mismatched lengths, unknown version, duplicate ids, huge dimensions before decode, undo branch followed by new edit | History is in-tab; persistent crash recovery and PSD write-back remain open |
| Affine geometry commands | `src/lib/vectorGeometry.ts`, analytic transforms, real pointer drag and export | Reverse transform order, nested groups, rotation pivot, unsupported skew, quote-bearing ids, hit-test order | Exact path extrema, text metrics, boolean path operations and complete SVG editing remain open |
| Source-fingerprinted verification pipeline | `scripts/test-engines.mjs`, `scripts/verify-preview.mjs`, live ledger | Change any helper/dependency after tests; missing/failing suite must stop promotion; pipeline must honour exit codes | No independent expert audit, fuzzing campaign or all-browser/device matrix |

## E. Negative space (reject these 17 apparent solutions)

1. A dynamic-array function which returns only its first value.
2. A spill that overwrites a user's source cell.
3. A partial spill published before collision checking completes.
4. An array generator that silently truncates oversized requests.
5. A never-ending recalculation loop hidden as a spinner.
6. A generated child editable independently of its anchor.
7. A values-only export labelled formula-preserving.
8. RGB averaging presented as alpha compositing.
9. Multiply/screen tested only on opaque pixels.
10. A mask which destructively changes original source pixels.
11. A flattened PNG called an editable layer project or PSD export.
12. An undo operation that mutated the stored prior state's buffers.
13. An exported SVG whose quote-bearing id or fill can escape its attribute.
14. Silently ignoring unsupported imported transforms.
15. Exact hit-testing claims based on approximate path/text boxes.
16. Capturing screenshots and calling them visually reviewed without inspection.
17. Promoting a register row merely because new function names were added.

Modal shortcut: testing only the top-left result of an array can make a scalar-only engine look complete. Detector: assert all six `SEQUENCE(2,3)` cells, their ownership, obstruction refusal/recovery, and an independent formula referencing a generated child. These are actual cases in `runTT14Checks` and `tests/e2e/tt14.mjs`.

## F. Reproduction and stopping

* `node scripts/test-engines.mjs` compiles the real TypeScript sources to an isolated temporary CommonJS tree, executes the deterministic engine cases, writes an execution log, removes the tree, and exits nonzero on failure.
* After a platform-managed preview is up: `APP_URL=https://your-preview node scripts/verify-preview.mjs` runs unit, server, both existing browser suites, TT14 browser suite, then the ledger writer. `PW_PATH` may point at a separate Playwright install; the project dependency works by default.
* Compiler/build gates are additionally required: `npx next typegen`, `npm exec tsc -- --noEmit --pretty false`, `npm run build`, then `build_and_start`.
* TT14 screenshots: `verification/screenshots/tt14-office.png`, `tt14-layers.png`, `tt14-vector.png`. Inspect them with the image-reading tool; test automation alone cannot declare visual review.
* Highest-information next tests remain an independent Excel/LibreOffice/PSD corpus, real mobile/browser/receiver devices, process-level parser isolation, adversarial resource-exhaustion testing and an expert accessibility/security audit.

Stop on the strongest verified bounded artifact. Do not call all original features complete, do not call every registered function correct, and do not call this application production-ready solely because the current tests pass.
