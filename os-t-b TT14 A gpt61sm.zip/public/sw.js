/* Fusion Shell service worker.
   Nuance: an OS shell must never serve a stale *state* response. We cache the app
   shell with stale-while-revalidate and explicitly never cache /api/*, so an offline
   session degrades visibly (DP-10) instead of showing yesterday's filesystem. */
const SHELL = "fusion-shell-v3";
const ASSETS = ["/", "/manifest.webmanifest", "/icon.svg", "/offline"];

self.addEventListener("install", (e) => {
  e.waitUntil(caches.open(SHELL).then((c) => c.addAll(ASSETS)).then(() => self.skipWaiting()));
});

self.addEventListener("activate", (e) => {
  e.waitUntil(
    caches.keys().then((keys) => Promise.all(keys.filter((k) => k !== SHELL).map((k) => caches.delete(k)))).then(() => self.clients.claim()),
  );
});

self.addEventListener("fetch", (event) => {
  const url = new URL(event.request.url);
  if (event.request.method !== "GET" || url.origin !== location.origin) return;
  if (url.pathname.startsWith("/api/")) {
    event.respondWith(
      fetch(event.request).catch(() =>
        new Response(JSON.stringify({ error: "offline", offline: true }), { status: 503, headers: { "content-type": "application/json" } })),
    );
    return;
  }
  event.respondWith(
    caches.match(event.request).then((hit) => {
      const net = fetch(event.request)
        .then((res) => { const copy = res.clone(); caches.open(SHELL).then((c) => c.put(event.request, copy)); return res; })
        .catch(() => hit || caches.match("/offline"));
      return hit || net;
    }),
  );
});
