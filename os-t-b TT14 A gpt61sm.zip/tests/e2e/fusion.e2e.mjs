// Browser end-to-end suite for Fusion Shell. Drives a real headless Chromium against APP_URL.
// Live external calls: Matrix homeserver (matrix.org), Wikipedia OpenSearch (SR-04).
// Run:  APP_URL=https://... PW_PATH=/path/to/node_modules/playwright node tests/e2e/fusion.e2e.mjs
// Notes: the side-button test dispatches a synthetic PointerEvent (button=3); a physical mouse
// side button is not exercised. WebRTC uses host candidates only (no STUN/TURN).
import { createRequire } from "node:module";
import { readFileSync, writeFileSync, mkdirSync } from "node:fs";

const require = createRequire(import.meta.url);
const { chromium } = require(process.env.PW_PATH ?? "playwright");
const APP = process.env.APP_URL;
if (!APP) throw new Error("APP_URL is required");

const results = [];
const check = async (id, name, fn) => {
  try {
    const detail = await fn();
    results.push({ id, name, pass: true });
    console.log(`PASS ${id} ${name}${detail ? ` — ${detail}` : ""}`);
  } catch (e) {
    const msg = String(e?.message ?? e).split("\n")[0].slice(0, 300);
    results.push({ id, name, pass: false });
    console.log(`FAIL ${id} ${name} — ${msg}`);
  }
};
const expect = (cond, msg) => { if (!cond) throw new Error(msg); };

const browser = await chromium.launch({
  args: [
    "--no-sandbox",
    "--use-fake-ui-for-media-stream",
    "--use-fake-device-for-media-stream",
    "--disable-features=WebRtcHideLocalIpsWithMdns",
  ],
});
const ctx = await browser.newContext({ viewport: { width: 1440, height: 900 } });
const page = await ctx.newPage();
const pageErrors = [];
page.on("pageerror", (e) => pageErrors.push(e.message));
page.on("console", (m) => {
  if (m.type() === "error" && !/Failed to load resource|403|502/.test(m.text())) pageErrors.push(m.text());
});
const api = (p, init) => ctx.request.fetch(`${APP}${p}`, init);
const apiJson = async (p, init) => (await api(p, init)).json();
const ledgerFingerprint = (await apiJson("/api/ledger")).fingerprint;
const put = (key, value) => api("/api/kvstore", { method: "PUT", data: { key, value } });

const openApp = async (label) => {
  await page.keyboard.press("Control+k");
  await page.locator('input[aria-label="Command palette"]').waitFor();
  await page.locator('input[aria-label="Command palette"]').fill(`Open ${label}`);
  await page.locator("button", { hasText: `Open ${label}` }).first().click();
  await page.waitForTimeout(300);
};
const windowNamed = (name) => page.locator(`section[role="dialog"][aria-label="${name} window"]`);
const closeAll = async () => {
  await page.keyboard.press("Control+k");
  await page.locator('input[aria-label="Command palette"]').fill("Close all");
  await page.locator("button", { hasText: "Close all windows" }).first().click();
  await page.waitForTimeout(200);
};

/* ── boot and layout ── */
await check("SH-01", "Boot: desktop renders with at least one window and no page errors on load", async () => {
  await page.goto(APP, { waitUntil: "networkidle" });
  await page.waitForSelector('section[role="dialog"]', { timeout: 30000 });
  expect((await page.locator('section[role="dialog"]').count()) >= 1, "no windows");
  return `${await page.locator('section[role="dialog"]').count()} window(s)`;
});

await check("WM-01", "Dragging a window header moves it and the position survives a reload (SH-08)", async () => {
  await closeAll();
  await openApp("Calculator");
  const win = windowNamed("Calculator");
  const hdr = win.locator("header").first();
  const b = await hdr.boundingBox();
  await page.mouse.move(b.x + 40, b.y + 10);
  await page.mouse.down();
  await page.mouse.move(b.x + 160, b.y + 10, { steps: 8 });
  await page.mouse.up();
  await page.waitForTimeout(900);
  const after = await win.boundingBox();
  expect(Math.abs(after.x - (b.x + 120)) < 10, `moved ${after.x - b.x}px, expected ~120`);
  await page.reload({ waitUntil: "networkidle" });
  await page.waitForSelector('section[role="dialog"]');
  const again = await windowNamed("Calculator").boundingBox();
  expect(Math.abs(again.x - after.x) < 10, `after reload x=${again.x}, expected ${after.x}`);
  return `moved ${Math.round(after.x - b.x)}px; restored after reload`;
});

await check("WM-09", "Meta+ArrowLeft tiles the focused window to the left half", async () => {
  const win = windowNamed("Calculator");
  await win.locator("header").first().click();
  await page.keyboard.press("Meta+ArrowLeft");
  await page.waitForTimeout(200);
  const b = await win.boundingBox();
  expect(Math.abs(b.width - 720) < 6, `width ${b.width}, expected ~720`);
  return `width ${Math.round(b.width)} px`;
});

await check("SR-01", "Command palette (Ctrl+K) lists and opens an app by name", async () => {
  await openApp("Notes");
  expect((await windowNamed("Notes").count()) === 1, "Notes window not created");
});

await check("SH-06", "Hot corner dwell (350 ms) opens Overview", async () => {
  await page.mouse.move(700, 450);
  await page.mouse.move(1, 1, { steps: 3 });
  await page.waitForTimeout(700);
  const visible = await page.locator('[data-testid="overview"]').isVisible();
  expect(visible, "overview not visible");
  await page.locator('[data-testid="overview"]').click({ position: { x: 700, y: 820 } });
  return "overview opened and dismissed";
});

await check("SH-09", "Side-button (button 3) routes a nav event that climbs the Files folder", async () => {
  await closeAll();
  await openApp("Files");
  const files = windowNamed("Files");
  const crumbs = files.locator('nav[aria-label="Breadcrumbs"]');
  expect((await crumbs.innerText()).includes("Documents"), "start folder not Documents");
  await files.locator("header").first().dispatchEvent("pointerdown", { button: 3, buttons: 8, bubbles: true });
  await page.waitForTimeout(300);
  const t = await crumbs.innerText();
  expect(!t.includes("Documents"), `still in: ${t}`);
  return "synthetic PointerEvent button=3 (physical side button not exercised)";
});

await check("SH-11", "Touchpad drag moves the most recent other window (2× sensitivity)", async () => {
  await closeAll();
  await openApp("Calculator");
  const calc = windowNamed("Calculator");
  const before = await calc.boundingBox();
  await openApp("Touchpad");
  const pad = page.locator('[data-testid="touchpad-pad"]');
  const pb = await pad.boundingBox();
  await page.mouse.move(pb.x + 30, pb.y + 30);
  await page.mouse.down();
  await page.mouse.move(pb.x + 70, pb.y + 50, { steps: 6 });
  await page.mouse.up();
  await page.waitForTimeout(300);
  const after = await calc.boundingBox();
  const dx = Math.round(after.x - before.x);
  expect(Math.abs(dx - 80) < 8, `calculator moved ${dx}px, expected ~80`);
  return `calculator moved ${dx}px`;
});

await check("SH-05", "Widget crash is isolated: crashed widget shows a message, shell keeps working", async () => {
  await put("app.widgets", ["clock", "governor", "fault"]);
  await page.reload({ waitUntil: "networkidle" });
  await page.waitForSelector('[data-testid="widget-crashed-fault"]', { timeout: 15000 });
  await page.keyboard.press("Control+k");
  expect(await page.locator('input[aria-label="Command palette"]').isVisible(), "palette dead after crash");
  await page.keyboard.press("Escape");
  await put("app.widgets", ["clock", "governor"]);
  return "fault widget isolated; palette still responds";
});

await check("NC-02", "Do-not-disturb holds a toast into Alerts instead of showing it", async () => {
  await api("/api/settings", { method: "PATCH", data: { key: "focus.dnd", value: true } });
  await put("app.routines", [{ id: "dnd1", name: "dnd-probe", enabled: true, mode: "live", trigger: { type: "manual" }, action: { type: "notify", text: "dnd-probe-held" } }]);
  await page.reload({ waitUntil: "networkidle" });
  await openApp("Routines");
  await page.locator("button", { hasText: "Run now" }).first().click();
  await page.waitForTimeout(800);
  const held = await apiJson("/api/alerts");
  const dndVisible = await page.locator('[data-testid="dnd-indicator"]').isVisible();
  await api("/api/settings", { method: "PATCH", data: { key: "focus.dnd", value: false } });
  expect(held.alerts.some((a) => a.app === "Held (DND)" && a.title === "dnd-probe-held"), "no held alert row");
  expect(dndVisible, "DND indicator not shown");
  return "held alert stored; indicator visible";
});

await check("AU-01", "Dry-run routine: firing writes an audit row and shows the plan, does not act", async () => {
  await put("app.routines", [{ id: "dry1", name: "calc-dry", enabled: true, mode: "dry-run", trigger: { type: "app-open", module: "calc" }, action: { type: "notify", text: "should-not-appear-live" } }]);
  await page.reload({ waitUntil: "networkidle" });
  await openApp("Calculator");
  await page.waitForSelector('[data-testid="toast"]:has-text("[dry-run]")', { timeout: 5000 });
  const audit = await apiJson("/api/audit");
  expect(audit.entries.some((e) => e.action === "routine.dry-run"), "no routine.dry-run audit row");
  await put("app.routines", []);
  return "plan toast + audit row";
});

await check("PR-03", "Timer (3 s) fires an alert row while the tab is open", async () => {
  await openApp("Tasks & timers");
  await page.locator('input[aria-label="Task title"]').fill("timer-e2e");
  await page.locator('input[aria-label="Minutes until due"]').fill("0.05");
  await page.locator('select[aria-label="Kind"]').selectOption("timer");
  await page.locator("button", { hasText: /^Add$/ }).first().click();
  const deadline = Date.now() + 15000;
  while (Date.now() < deadline) {
    const alerts = await apiJson("/api/alerts");
    if (alerts.alerts.some((a) => a.title === "timer-e2e")) return "alert row written";
    await page.waitForTimeout(500);
  }
  throw new Error("timer did not fire within 15 s");
});

await check("PR-04", "Calendar: add event, export .ics, import .ics with commas (round trip)", async () => {
  await openApp("Calendar");
  const app = page.locator('[data-testid="calendar-app"]');
  await app.locator('input[aria-label="Event title"]').fill("E2E meeting");
  await app.locator('input[aria-label="Start"]').fill("2026-03-01T09:30");
  await app.locator('input[aria-label="End"]').fill("2026-03-01T10:00");
  await app.locator("button", { hasText: /^Add$/ }).first().click();
  await page.waitForTimeout(400);
  const dl = page.waitForEvent("download");
  await app.locator("button", { hasText: "Export .ics" }).click();
  const text = readFileSync(await (await dl).path(), "utf8");
  expect(text.includes("BEGIN:VCALENDAR") && text.includes("SUMMARY:E2E meeting"), "export missing event");
  writeFileSync("/tmp/fusion-import.ics", "BEGIN:VCALENDAR\r\nBEGIN:VEVENT\r\nUID:imp-e2e-1@test\r\nDTSTART:20260302T100000\r\nDTEND:20260302T110000\r\nSUMMARY:Imported\\, with comma\r\nEND:VEVENT\r\nEND:VCALENDAR\r\n");
  await app.locator('input[aria-label="Import ICS"]').setInputFiles("/tmp/fusion-import.ics");
  await page.waitForTimeout(800);
  const listText = await app.locator('[data-testid="calendar-events"]').innerText();
  expect(listText.includes("Imported, with comma"), `import lost the comma: ${listText.slice(0, 120)}`);
  return "export has VCALENDAR; import unescapes commas";
});

await check("SC-03", "Privacy app lists browser permissions and server data categories", async () => {
  await openApp("Privacy");
  await page.waitForSelector('[data-testid="privacy-counts"] >> text=files:', { timeout: 10000 });
  const rows = await page.locator('[data-testid="privacy-list"] li').count();
  expect(rows >= 8, `only ${rows} permission rows`);
  return `${rows} permission rows, counts shown`;
});

await check("ST-09", "Crossing 1600 px switches density profile with a visible, revertible banner", async () => {
  await page.setViewportSize({ width: 1440, height: 900 });
  await page.waitForTimeout(300);
  await page.setViewportSize({ width: 1920, height: 1000 });
  await page.waitForSelector('[data-testid="profile-banner"]', { timeout: 5000 });
  const txt = await page.locator('[data-testid="profile-banner"]').innerText();
  expect(txt.includes("desk"), `banner: ${txt}`);
  const s = await apiJson("/api/settings");
  expect(s.settings["appearance.density"] === "compact", `density=${s.settings["appearance.density"]}`);
  await page.locator('[data-testid="profile-banner"] button', { hasText: "Revert" }).click();
  await page.setViewportSize({ width: 1440, height: 900 });
  return "banner shown; density compact; revert available";
});

await check("ST-08", "Managed policy blocks a locked setting with HTTP 409", async () => {
  const pol = await apiJson("/api/policy");
  expect(pol.locked["privacy.telemetry"] === false, "policy not loaded");
  const r = await api("/api/settings", { method: "PATCH", data: { key: "privacy.telemetry", value: true } });
  expect(r.status() === 409, `status ${r.status()}`);
  return "409 for privacy.telemetry";
});

await check("SR-04", "Web results: refused while off (403), live Wikipedia results when on", async () => {
  await api("/api/settings", { method: "PATCH", data: { key: "find.webResults", value: false } });
  const off = await api("/api/websearch?q=fusion");
  expect(off.status() === 403, `off status ${off.status()}`);
  await api("/api/settings", { method: "PATCH", data: { key: "find.webResults", value: true } });
  const on = await apiJson("/api/websearch?q=Linux");
  await api("/api/settings", { method: "PATCH", data: { key: "find.webResults", value: false } });
  expect(Array.isArray(on.results) && on.results.length > 0, `on: ${JSON.stringify(on).slice(0, 160)}`);
  return `${on.results.length} live results from ${on.provider}`;
});

await check("MS-06", "Matrix homeserver check reads public versions and login flows (live matrix.org)", async () => {
  const m = await apiJson("/api/matrix?server=https://matrix.org");
  expect(Array.isArray(m.versions) && m.versions.length > 0, `error: ${JSON.stringify(m).slice(0, 160)}`);
  expect(m.status.versions === 200, `status ${m.status.versions}`);
  return `${m.versions.length} client-server versions, flows: ${m.loginFlows.join(",") || "none"}`;
});

await check("AU-05", "Automation API: no token → 401; scoped token → note created", async () => {
  const no = await api("/api/command", { method: "POST", data: { cmd: "status" } });
  expect(no.status() === 401, `no-token status ${no.status()}`);
  const tok = (await apiJson("/api/command/token")).token;
  const ok = await api("/api/command", { method: "POST", headers: { authorization: `Bearer ${tok}` }, data: { cmd: "note", title: "cmd-e2e", body: "via token" } });
  expect(ok.status() === 200, `token status ${ok.status()}`);
  const notes = await apiJson("/api/notes");
  expect(notes.notes.some((n) => n.title === "cmd-e2e"), "note not persisted");
  return "401 without token; note persisted with token";
});

await check("AU-02", "Presets: save the current layout and find it in the store", async () => {
  await openApp("Presets");
  await page.locator('input[aria-label="Preset name"]').fill("e2e-layout");
  await page.locator("button", { hasText: /^Save$/ }).first().click();
  await page.waitForTimeout(400);
  const p = await apiJson("/api/kvstore?key=app.presets");
  expect(Array.isArray(p.value) && p.value.some((x) => x.name === "e2e-layout"), "preset not stored");
  return "stored in app.presets";
});

await check("SH-12", "Shell governor reports a measured state with its evidence (read back in Monitor)", async () => {
  await openApp("Monitor");
  await page.waitForSelector('[data-testid="governor-state"]', { timeout: 10000 });
  await page.waitForTimeout(1500);
  const state = (await page.locator('[data-testid="governor-state"]').innerText()).trim();
  expect(["COOL", "WARM", "HOT", "THROTTLED", "CRITICAL"].includes(state), `state was "${state}"`);
  const ev = await page.locator('[data-testid="monitor-app"]').innerText();
  expect(ev.includes("mean frame") && ev.includes("ms over 60 frames"), "no evidence string");
  return `state ${state} with frame evidence`;
});

await check("MD-04", "Voice recorder: record, meter reads input, stop yields a clip", async () => {
  await openApp("Capture");
  await page.locator("button", { hasText: "Record voice" }).click();
  await page.waitForSelector('[data-testid="capture-state"]:has-text("recording")');
  await page.waitForTimeout(1200);
  await page.locator("button", { hasText: /^Stop$/ }).click();
  await page.waitForSelector('[data-testid="voice-clip"]', { timeout: 5000 });
  return "clip produced with fake microphone";
});

await check("FF-08", "PSD: fixture uploads to Forge, parses 3 layers, returns a composite PNG", async () => {
  const bytes = await (await api("/api/fixtures/psd")).body();
  const r = await api("/api/forge", { method: "POST", multipart: { file: { name: "fixture.psd", mimeType: "image/vnd.adobe.photoshop", buffer: bytes } } });
  const j = await r.json();
  expect(j.format === "Photoshop PSD", `format ${j.format} ${j.error ?? ""}`);
  expect(j.layers.length === 3, `layers ${j.layers?.length}`);
  expect(typeof j.previewPng === "string" && j.previewPng.startsWith("iVBORw0KGgo"), "no PNG preview");
  return `3 layers, grade ${j.grade}`;
});

await check("FF-03", "PDF: Forge lab accepts a PDF and shows a browser viewer frame", async () => {
  await openApp("Forge");
  const pdf = Buffer.from("%PDF-1.4\n1 0 obj<<>>endobj\ntrailer<<>>\n%%EOF\n");
  await page.locator('input[aria-label="Document to parse"]').setInputFiles({ name: "probe.pdf", mimeType: "application/pdf", buffer: pdf });
  await page.waitForSelector('[data-testid="pdf-preview"]', { timeout: 5000 });
  return "viewer frame mounted (not a rendering-fidelity test)";
});

await check("MD-07", "Colour picker path is visible and probes EyeDropper support", async () => {
  await openApp("Capture");
  const supported = await page.evaluate(() => "EyeDropper" in window);
  expect(await page.locator("button", { hasText: "Pick a colour" }).count() >= 1, "no picker button");
  return `EyeDropper supported: ${supported}`;
});

await check("LN-20", "Fusion Meet: two browser contexts receive each other's live video track", async () => {
  const room = `e2e-${Date.now().toString(36)}`;
  const ctxA = await browser.newContext({ viewport: { width: 1200, height: 800 } });
  const ctxB = await browser.newContext({ viewport: { width: 1200, height: 800 } });
  const pa = await ctxA.newPage(), pb = await ctxB.newPage();
  const errs = [];
  for (const p of [pa, pb]) p.on("pageerror", e => errs.push(e.message));
  try {
    for (const p of [pa, pb]) {
      await p.goto(APP, { waitUntil: "networkidle" });
      await p.waitForSelector('section[role="dialog"]', { timeout: 30000 });
      await p.keyboard.press("Control+k");
      await p.locator('input[aria-label="Command palette"]').fill("Close all");
      await p.locator("button", { hasText: "Close all windows" }).first().click();
      await p.waitForTimeout(300);
      await p.keyboard.press("Control+k");
      await p.locator('input[aria-label="Command palette"]').fill("Open Meet");
      await p.locator("button", { hasText: "Open Meet" }).first().click();
      await p.locator('input[aria-label="Room code"]').first().fill(room);
      await p.locator("button", { hasText: /^Join$/ }).first().click();
    }
    const deadline = Date.now() + 60000;
    let connected = false;
    while (Date.now() < deadline) {
      const a = await pa.locator('[data-testid="meet-peer"]').innerText();
      const b = await pb.locator('[data-testid="meet-peer"]').innerText();
      if (a === "connected" && b === "connected") { connected = true; break; }
      await pa.waitForTimeout(500);
    }
    expect(connected, `peer states: A=${await pa.locator('[data-testid="meet-peer"]').innerText()} B=${await pb.locator('[data-testid="meet-peer"]').innerText()}`);
    await pa.waitForTimeout(2500);
    const remoteOk = async p => p.evaluate(() => {
      const v = document.querySelector('[data-testid="remote-video"]');
      return !!v && v.videoWidth > 0 && v.srcObject && v.srcObject.getVideoTracks().some(t => t.readyState === "live");
    });
    expect(await remoteOk(pa) && await remoteOk(pb), "remote video not flowing both ways");
    expect(errs.length === 0, `page errors: ${errs.join("; ").slice(0, 200)}`);
    return `room ${room}: both peers connected; video track live on both`;
  } finally { await ctxA.close(); await ctxB.close(); }
});

await check("NC-04", "Alerts diagnostics show permission and service-worker state", async () => {
  await openApp("Alerts");
  const text = await page.locator('[data-testid="alerts-app"]').innerText();
  expect(text.includes("OS notification permission") && text.includes("Service worker"), "diagnostics missing");
});

await check("VR-01", "Server self-test passes every check", async () => {
  const j = await apiJson("/api/selftest");
  expect(j.ok, `failed: ${j.checks.filter(c => !c.pass).map(c => c.id).join(", ")}`);
  return `${j.pass}/${j.total}`;
});

await check("RUN", "No unexpected uncaught page errors", async () => {
  const expected = pageErrors.filter(e => e.includes("intentional fault injected by the Widgets test"));
  const unexpected = pageErrors.filter(e => !expected.includes(e));
  expect(unexpected.length === 0, `unexpected: ${unexpected.slice(0, 3).join(" | ").slice(0, 250)}`);
  return `0 unexpected, ${expected.length} expected fault-injector error(s)`;
});

await browser.close();
const pass = results.filter(r => r.pass).length;
mkdirSync("verification", { recursive: true });
writeFileSync("verification/legacy-browser.json", JSON.stringify({
  fingerprint: ledgerFingerprint, runAt: new Date().toISOString(), suite: "legacy-browser-chromium",
  passed: pass === results.length, cases: results.map(r => ({ id: r.id, pass: r.pass })),
}, null, 2));
console.log(`\nE2E SUMMARY: ${pass}/${results.length} passed`);
console.log(JSON.stringify(results.map(r => ({ id: r.id, pass: r.pass }))));
process.exit(pass === results.length ? 0 : 1);