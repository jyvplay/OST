// TT14 nonvisual acceptance suite with screenshot artifacts. Real live Next/PG endpoints, real Chromium.
// Generated images/workbooks are explicitly labelled test inputs; no routes are mocked.
// APP_URL=https://... PW_PATH=/tmp/fusion-e2e/node_modules/playwright node tests/e2e/tt14.mjs
import { createRequire } from "node:module";
import { spawnSync } from "node:child_process";
import { mkdirSync, readFileSync, writeFileSync } from "node:fs";
const require = createRequire(import.meta.url);
const { chromium } = require(process.env.PW_PATH ?? "playwright");
const APP = process.env.APP_URL;
if (!APP) throw new Error("APP_URL required");
const browser = await chromium.launch({ args: ["--no-sandbox"] });
const ctx = await browser.newContext({ viewport: { width: 1440, height: 960 } });
const page = await ctx.newPage();
page.setDefaultTimeout(10000);
const api = (p, opts) => ctx.request.fetch(`${APP}${p}`, opts);
const get = async (p) => (await api(p)).json();
const fingerprint = (await get("/api/ledger")).fingerprint;
const cases = [], errors = [];
const assert = (v, reason) => { if (!v) throw new Error(reason); };
const check = async (id, name, fn) => {
  try { const detail = await fn(); cases.push({ id, pass: true, detail: detail ?? "All assertions passed" }); console.log(`PASS ${id} ${name} — ${detail ?? ""}`); }
  catch (e) { const detail = String(e?.message ?? e).slice(0, 2000); cases.push({ id, pass: false, detail }); console.error(`FAIL ${id} ${name}\n${detail}`); }
};
page.on("pageerror", (e) => errors.push(e.message));
mkdirSync("verification/screenshots", { recursive: true });
await page.goto(APP, { waitUntil: "networkidle" });
await page.waitForSelector('section[role="dialog"]', { timeout: 30000 });
const palette = async (text) => {
  await page.keyboard.press("Control+k");
  await page.locator('input[aria-label="Command palette"]').fill(text);
};
const closeAll = async () => { await palette("Close all"); await page.getByRole("button", { name: /Close all windows/ }).first().click(); };
const open = async (name) => {
  await palette(`Open ${name}`);
  await page.locator('[data-testid="palette"] button, [role="dialog"] button').filter({ hasText: `Open ${name}` }).first().click().catch(async () => {
    await page.locator("button").filter({ hasText: `Open ${name}` }).first().click();
  });
};
const pngFixture = async (w, h, color) => Buffer.from(await page.evaluate(async ({ w, h, color }) => {
  const c = document.createElement("canvas"); c.width = w; c.height = h;
  const x = c.getContext("2d"); x.fillStyle = color; x.fillRect(0, 0, w, h);
  const blob = await new Promise((res) => c.toBlob(res, "image/png"));
  return Array.from(new Uint8Array(await blob.arrayBuffer()));
}, { w, h, color }));
const canvasPixel = async (testid, x = 0, y = 0) => page.locator(`[data-testid="${testid}"]`).evaluate((cv, p) => Array.from(cv.getContext("2d").getImageData(p.x, p.y, 1, 1).data), { x, y });
const setRange = async (locator, value) => {
  await locator.focus(); await locator.press("Home");
  for (let i = 0; i < value; i++) await locator.press("ArrowRight");
};

await check("FF-02.spill.ui", "Calc publishes six cells, generated children are read-only, blockers recover", async () => {
  await closeAll(); await open("Office");
  const app = page.locator('[data-testid="office-app"]');
  await app.getByRole("button", { name: "New workbook", exact: true }).click();
  await app.getByTestId("cell-F2").fill("occupied");
  await app.getByTestId("cell-E1").fill("=SEQUENCE(2,2,10,5)");
  await page.waitForFunction(() => document.querySelector('[data-testid="computed-E1"]')?.textContent === "#SPILL!");
  assert((await app.getByTestId("office-spill-errors").innerText()).includes("F2"), "No blocker diagnostic");
  assert((await app.getByTestId("cell-F2").inputValue()) === "occupied", "Blocker overwritten");
  await app.getByTestId("cell-F2").fill("");
  await page.waitForFunction(() => document.querySelector('[data-testid="computed-F2"]')?.textContent === "25");
  assert(!await app.getByTestId("cell-F2").isEditable(), "Generated child remains editable");
  assert((await app.getByTestId("cell-F2").getAttribute("data-spill-owner")) === "Sheet1!E1", "Wrong owner");
  await app.getByTestId("cell-A1").fill("=F2*2");
  assert((await app.getByTestId("computed-A1").innerText()) === "50", "Dependent scalar not recomputed");
  await app.getByTestId("office-server-calc").click();
  await page.waitForFunction(() => document.querySelector('[data-testid="office-calc-status"]')?.textContent?.includes("Server calculated"));
  const pending = page.waitForEvent("download");
  await app.getByTestId("office-values-export").click();
  const dl = await pending;
  const bytes = readFileSync(await dl.path());
  assert(dl.suggestedFilename() === "values-snapshot.xlsx" && bytes[0] === 0x50 && bytes[1] === 0x4b, "No XLSX snapshot");
  writeFileSync("verification/spill-values-snapshot.xlsx", bytes);
  await page.screenshot({ path: "verification/screenshots/tt14-office.png" });
  return "#SPILL! -> recovered E1:F2; child F2=25 read-only; A1=50; server calculated; snapshot downloaded";
});

await check("FF-02.spill.independent-xlsx", "Independent ZIP/XML parser checks the actual downloaded values snapshot", async () => {
  const run = spawnSync(process.execPath, ["scripts/check-snapshot.mjs"], { encoding: "utf8", timeout: 40000 });
  assert(run.status === 0, run.stderr || run.error || run.stdout);
  return run.stdout.trim();
});

await check("FF-02.spill.api", "Headless calculation exposes full results, bounds and refusals", async () => {
  const model = { sheets: [{ name: "S", cells: { A1: { ref: "A1", raw: "", formula: "SEQUENCE(2,3)" }, D1: { ref: "D1", raw: "", formula: "C2*2" } } }], unsupported: [] };
  const r = await api("/api/office/calculate", { method: "POST", data: { model } });
  assert(r.ok(), `calculate status ${r.status()}`);
  const j = await r.json();
  assert(j.values["S!C2"] === 6 && j.values["S!D1"] === 12 && j.owners["S!C2"] === "S!A1", "API lost spill/dependency");
  const bad = await api("/api/office/calculate", { method: "POST", data: { model: { sheets: [{ name: "S", cells: { A0: { ref: "A0", raw: "x" } } }] } } });
  assert(bad.status() === 400, "Bad reference accepted by API");
  return "C2=6, D1=12, child ownership returned; A0 -> 400";
});

await check("FF-05.layers.ui", "Layer opacity, masks and undo/redo change actual pixels", async () => {
  await closeAll(); await open("Layers");
  const app = page.getByTestId("layers-app");
  await app.getByLabel("Open base image").setInputFiles({ name: "generated-red.png", mimeType: "image/png", buffer: await pngFixture(4, 2, "#ff0000") });
  await page.waitForFunction(() => document.querySelector('[data-testid="layers-canvas"]')?.width === 4);
  await app.getByLabel("Fill layer colour").fill("#0000ff");
  await app.getByTestId("layers-add-fill").click();
  await setRange(app.getByLabel("Layer opacity"), 50);
  await app.getByRole("button", { name: "Keep left half", exact: true }).click();
  let left = await canvasPixel("layers-canvas", 0, 0), right = await canvasPixel("layers-canvas", 1, 0);
  assert(Math.abs(left[0] - 128) <= 1 && Math.abs(left[2] - 128) <= 1 && left[3] === 255, `Alpha blend ${left}`);
  assert(right.join() === "255,0,0,255", `Mask did not hide right pixel ${right}`);
  await app.getByTestId("layers-undo").click();
  right = await canvasPixel("layers-canvas", 1, 0);
  assert(right[2] >= 127, "Undo did not remove mask");
  await app.getByTestId("layers-redo").click();
  assert((await canvasPixel("layers-canvas", 1, 0)).join() === "255,0,0,255", "Redo did not restore mask");
  return "Red/blue 50% blend ≈128/128; mask clips right pixel; undo/redo verified on canvas bytes";
});

await check("FF-05.layers.project-ui", "Save/open project preserves two layers and mask; original pixels remain intact", async () => {
  const app = page.getByTestId("layers-app");
  const pending = page.waitForEvent("download");
  await app.getByRole("button", { name: "Save project", exact: true }).click();
  const dl = await pending, data = readFileSync(await dl.path());
  const j = JSON.parse(data.toString());
  assert(j.version === 1 && j.layers.length === 2 && j.layers[1].mask, "Project omitted layer/mask");
  assert(Buffer.from(j.layers[0].pixels, "base64").subarray(0, 4).toString("hex") === "ff0000ff", "Original pixels changed");
  await app.getByRole("button", { name: "Delete layer", exact: true }).click();
  await app.getByLabel("Open layer project").setInputFiles({ name: "restore.json", mimeType: "application/json", buffer: data });
  await page.waitForFunction(() => document.querySelectorAll('[data-testid="layers-list"] li').length === 2);
  assert((await canvasPixel("layers-canvas", 1, 0)).join() === "255,0,0,255", "Project restore lost mask");
  return "Project decoded; original RGBA unchanged; two layers/mask restored";
});

await check("FF-05.layers.files", "Explicit save commits the composite as a PNG in the PostgreSQL VFS", async () => {
  const app = page.getByTestId("layers-app");
  await app.getByRole("button", { name: "Save PNG to Files", exact: true }).click();
  await page.waitForFunction(() => document.querySelector('[data-testid="layers-message"]')?.textContent?.startsWith("Saved /Home/Pictures/"));
  const files = await get("/api/fs?op=list&path=/Home/Pictures");
  assert(files.entries.some((f) => f.mime === "image/png" && f.content.startsWith("data:image/png;base64,")), "PNG not committed to VFS");
  await page.screenshot({ path: "verification/screenshots/tt14-layers.png" });
  return "PNG bytes committed to /Home/Pictures, source files not overwritten";
});

await check("FF-05.layers.canvas-oracle", "Independent Chromium Canvas and server compositor agree for normal/multiply/screen with transparency", async () => {
  const compared = await page.evaluate(async () => {
    const cases = [
      { bg: [120, 80, 220, 255], fg: [200, 50, 90, 128], opacity: 0.6, mask: 255 },
      { bg: [120, 80, 220, 100], fg: [40, 200, 10, 180], opacity: 0.75, mask: 255 },
      { bg: [255, 0, 0, 0], fg: [0, 0, 255, 128], opacity: 1, mask: 255 },
    ];
    let maxError = 0, checks = 0;
    for (const c of cases) for (const mode of ["normal", "multiply", "screen"]) {
      const enc = (bytes) => btoa(String.fromCharCode(...bytes));
      const project = { kind: "fusion-layers", version: 1, width: 1, height: 1, layers: [
        { id: "a", name: "background", width: 1, height: 1, pixels: enc(c.bg), x: 0, y: 0, visible: true, opacity: 1, blend: "normal" },
        { id: "b", name: "source", width: 1, height: 1, pixels: enc(c.fg), mask: enc([c.mask]), x: 0, y: 0, visible: true, opacity: c.opacity, blend: mode },
      ] };
      const r = await fetch("/api/studio/composite", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(project) });
      if (!r.ok) throw new Error(`Compositor API HTTP ${r.status}: ${await r.text()}`);
      const img = await createImageBitmap(await r.blob());
      const a = document.createElement("canvas"), b = document.createElement("canvas"); a.width = b.width = 1; a.height = b.height = 1;
      const ax = a.getContext("2d"), bx = b.getContext("2d"); ax.drawImage(img, 0, 0); img.close();
      const rgba = (v) => `rgba(${v[0]},${v[1]},${v[2]},${v[3] / 255})`;
      bx.fillStyle = rgba(c.bg); bx.fillRect(0, 0, 1, 1);
      bx.globalCompositeOperation = mode === "normal" ? "source-over" : mode;
      bx.globalAlpha = c.opacity * c.mask / 255;
      bx.fillStyle = rgba(c.fg); bx.fillRect(0, 0, 1, 1);
      const got = ax.getImageData(0, 0, 1, 1).data, ref = bx.getImageData(0, 0, 1, 1).data;
      for (let i = 0; i < 4; i++) maxError = Math.max(maxError, Math.abs(got[i] - ref[i]));
      checks++;
    }
    return { checks, maxError };
  });
  // Browser Canvas premultiplication and unpremultiplication can differ by up to 2 RGBA byte values.
  assert(compared.maxError <= 2, `Canvas disagreement ${JSON.stringify(compared)}`);
  return `${compared.checks} independent Canvas comparisons, maximum RGBA-byte error ${compared.maxError} (tolerance 2)`;
});

await check("FF-09.geometry.ui", "Vector move/align/drag commands and undo/redo preserve export geometry", async () => {
  await closeAll(); await open("Vector");
  const app = page.getByTestId("vector-app");
  const svg = '<svg xmlns="http://www.w3.org/2000/svg" width="200" height="120"><rect id="box" x="10" y="20" width="30" height="40" fill="#38bdf8"/></svg>';
  await app.getByLabel("Import SVG").setInputFiles({ name: "box.svg", mimeType: "image/svg+xml", buffer: Buffer.from(svg) });
  await app.getByTestId("vector-list").locator("li button").first().click();
  await app.getByTestId("vector-nudge").click();
  assert((await app.getByTestId("vector-bounds").innerText()).includes("x=20.0"), "Nudge wrong");
  await app.getByTestId("vector-undo").click();
  assert((await app.getByTestId("vector-bounds").innerText()).includes("x=10.0"), "Undo wrong");
  await app.getByTestId("vector-align-right").click();
  assert((await app.getByTestId("vector-bounds").innerText()).includes("x=170.0"), "Canvas alignment wrong");
  const view = app.getByTestId("vector-canvas").locator("svg");
  const box = await view.boundingBox();
  await page.mouse.move(box.x + 185, box.y + 40); await page.mouse.down();
  await page.mouse.move(box.x + 175, box.y + 50, { steps: 5 }); await page.mouse.up();
  const bounds = await app.getByTestId("vector-bounds").innerText();
  assert(bounds.includes("x=160.0") && bounds.includes("y=30.0"), `Drag result ${bounds}`);
  const pending = page.waitForEvent("download"); await app.getByRole("button", { name: "Export SVG", exact: true }).click();
  const dl = await pending, saved = readFileSync(await dl.path(), "utf8");
  assert(saved.includes("matrix("), "Transform not saved");
  await page.screenshot({ path: "verification/screenshots/tt14-vector.png" });
  return "Nudge/undo/align/real pointer drag and SVG transform export verified";
});

await check("WM-06.policy-browser", "Chromium confirms iframe camera and microphone denial using the actual policy object", async () => {
  await closeAll(); await open("Browser");
  const frame = page.locator('section[aria-label="Browser window"] iframe').first();
  await frame.waitFor();
  const p = await frame.evaluate((el) => {
    const policy = el.featurePolicy ?? el.permissionsPolicy;
    return { attribute: el.getAttribute("allow"), supported: !!policy, camera: policy?.allowsFeature("camera"), microphone: policy?.allowsFeature("microphone") };
  });
  assert(p.attribute.includes("camera 'none'") && !p.attribute.includes("camera="), `Wrong iframe grammar ${p.attribute}`);
  assert(p.supported && p.camera === false && p.microphone === false, `Policy not enforced: ${JSON.stringify(p)}`);
  return "Actual Chromium policy reports camera=false and microphone=false; no permission prompts requested";
});

await check("VR-04.tt14-errors", "No unexpected uncaught browser exceptions during TT14 acceptance", async () => {
  assert(errors.length === 0, errors.join(" | "));
  return "0 uncaught page errors; screenshots written for human/model inspection";
});
await browser.close();
const passed = cases.every((c) => c.pass);
writeFileSync("verification/tt14-browser.json", JSON.stringify({ fingerprint, runAt: new Date().toISOString(), suite: "tt14-browser-chromium", passed, cases }, null, 2));
console.log(`TT14 SUMMARY ${cases.filter((c) => c.pass).length}/${cases.length} fingerprint=${fingerprint}`);
process.exitCode = passed ? 0 : 1;
