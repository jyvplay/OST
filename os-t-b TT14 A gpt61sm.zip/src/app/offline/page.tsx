export default function Offline() {
  return (
    <main className="flex h-dvh flex-col items-center justify-center gap-2 bg-[#0b1120] p-8 text-center text-slate-200">
      <h1 className="text-xl font-semibold">Fusion Shell is offline</h1>
      <p className="max-w-md text-xs text-slate-400">
        The shell is cached, but the file engine, search and registry live in Postgres and are intentionally never served
        from cache — a stale filesystem would be worse than an honest outage.
      </p>
    </main>
  );
}
