"use client";

import { useEffect, useState } from "react";

/** CA-08: the Presentation API receiver page. It lives on this origin, so no Cast
 *  developer-console app id and no proprietary SDK are involved. */
export default function Receiver() {
  const [msgs, setMsgs] = useState<string[]>(["Fusion Beam receiver ready."]);
  useEffect(() => {
    type Conn = { addEventListener: (t: string, cb: (e: { data: string }) => void) => void };
    type Rec = { connectionList: Promise<{ connections: Conn[]; addEventListener: (t: string, cb: (e: { connection: Conn }) => void) => void }> };
    const r = (navigator as Navigator & { presentation?: { receiver?: Rec } }).presentation?.receiver;
    if (!r) { setMsgs((m) => [...m, "No presentation receiver context — open this page from Beam to use it as a display."]); return; }
    r.connectionList.then((list) => {
      const wire = (c: Conn) => c.addEventListener("message", (e) => setMsgs((m) => [...m, String(e.data)]));
      list.connections.forEach(wire);
      list.addEventListener("connectionavailable", (e) => wire(e.connection));
    });
  }, []);
  return (
    <main className="flex h-dvh flex-col items-center justify-center gap-3 bg-[#0b1120] p-8 text-slate-100">
      <h1 className="text-2xl font-semibold text-teal-300">Fusion Beam — receiver</h1>
      <ul className="text-xs text-slate-400">{msgs.map((m, i) => <li key={i}>{m}</li>)}</ul>
    </main>
  );
}
