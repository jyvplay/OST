import { NextResponse } from "next/server";
import { calculateWorkbook, validateWorkbookInput } from "@/lib/workbook";

export const dynamic = "force-dynamic";

/** FF-02: same spill engine as the browser, no eval, shell execution, external fetch or macros.
 * The body and source-cell counts are capped before calculation; output and pass limits are in the engine.
 * This route calculates only. Persistence is an explicit separate Files action. */
export async function POST(req: Request) {
  try {
    const text = await req.text();
    if (text.length > 2_000_000) return NextResponse.json({ error: "Workbook JSON exceeds 2 MB" }, { status: 413 });
    const input = JSON.parse(text) as { model?: unknown };
    const model = validateWorkbookInput(input.model);
    const calc = calculateWorkbook(model);
    return NextResponse.json({
      values: Object.fromEntries(calc.values), owners: Object.fromEntries(calc.owners),
      spills: Object.fromEntries(calc.spills), issues: Object.fromEntries(calc.issues),
      passes: calc.passes, stable: calc.stable,
      limits: { inputCells: 1000, generatedCells: 20000, passes: 8 },
      scope: "Bounded spill-aware web engine; not Excel calc-chain or file interoperability certification",
    });
  } catch (e) {
    return NextResponse.json({ error: e instanceof Error ? e.message : "Invalid workbook" }, { status: 400 });
  }
}
