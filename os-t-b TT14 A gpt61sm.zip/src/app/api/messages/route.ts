import { NextResponse } from "next/server";
import { asc } from "drizzle-orm";
import { db } from "@/db";
import { messages } from "@/db/schema";
import { ensureSeed } from "@/lib/server/seed";

export const dynamic = "force-dynamic";

export async function GET() {
  await ensureSeed();
  const rows = await db.select().from(messages).orderBy(asc(messages.createdAt));
  const threads: Record<string, typeof rows> = {};
  for (const m of rows) (threads[m.thread] ??= []).push(m);
  return NextResponse.json({
    threads,
    capabilities: {
      local: "available",
      sms: "unavailable — the web platform has no SMS send API (MS-05)",
      rcs: "unavailable — no third-party RCS API exists (MS-04)",
      imessage: "requires a BlueBubbles-shaped server you host on your own Mac (MS-01); no bridge configured",
      matrix: "configure a homeserver URL in Settings to enable (MS-06)",
    },
  });
}

export async function POST(req: Request) {
  await ensureSeed();
  const b = (await req.json()) as { thread: string; body: string; author?: string; channel?: string };
  if ((b.channel ?? "local") !== "local")
    return NextResponse.json({ error: `channel ${b.channel} is not connected; we do not simulate it` }, { status: 409 });
  const [row] = await db.insert(messages).values({ thread: b.thread, body: b.body, author: b.author ?? "me", channel: "local" }).returning();
  return NextResponse.json({ message: row });
}
