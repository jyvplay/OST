import { NextResponse } from "next/server";
import { sql } from "drizzle-orm";
import { db } from "@/db";
import { ensureSeed } from "@/lib/server/seed";
import { childrenOf, createNode, ensureDir, folderStats, nodeById, pathOf, resolvePath, runFileOp, trash, writeFile } from "@/lib/server/vfs";

export const dynamic = "force-dynamic";

/** TD-02: a real interpreter over the Postgres VFS. No canned transcript. */
export async function POST(req: Request) {
  await ensureSeed();
  const { cwd, line } = (await req.json()) as { cwd: string; line: string };
  const argv = line.trim().match(/"[^"]*"|\S+/g)?.map((a) => a.replace(/^"|"$/g, "")) ?? [];
  const cmd = argv[0] ?? "";
  const args = argv.slice(1);
  const out: string[] = [];
  let nextCwd = cwd || "/";

  const abs = (p: string) => (p?.startsWith("/") ? p : `${nextCwd === "/" ? "" : nextCwd}/${p ?? ""}`).replace(/\/+/g, "/").replace(/\/$/, "") || "/";

  try {
    switch (cmd) {
      case "": break;
      case "help":
        out.push("ls cd pwd cat tree mkdir touch write append rm mv cp find grep du stat versions ops json clear help");
        break;
      case "pwd": out.push(nextCwd); break;
      case "ls": {
        const target = abs(args[0] ?? ".") === "/." ? "/" : abs(args[0] ?? "");
        const node = target === "/" ? null : await resolvePath(target);
        if (target !== "/" && !node) { out.push(`ls: ${target}: no such path`); break; }
        for (const c of await childrenOf(node?.id ?? null))
          out.push(`${c.kind === "dir" ? "d" : "-"} ${String(c.size).padStart(7)}  v${c.version}  ${c.name}${c.kind === "dir" ? "/" : ""}`);
        break;
      }
      case "cd": {
        const target = args[0] === ".." ? nextCwd.split("/").slice(0, -1).join("/") || "/" : abs(args[0] ?? "/");
        if (target !== "/" && !(await resolvePath(target))) { out.push(`cd: ${target}: no such directory`); break; }
        nextCwd = target || "/";
        break;
      }
      case "cat": {
        const n = await resolvePath(abs(args[0] ?? ""));
        if (!n) { out.push(`cat: ${args[0]}: not found`); break; }
        out.push(...n.content.split("\n"));
        break;
      }
      case "tree": {
        const root = abs(args[0] ?? "");
        const base = root === "/" ? null : await resolvePath(root);
        const walk = async (id: number | null, depth: number) => {
          for (const c of await childrenOf(id)) {
            out.push(`${"  ".repeat(depth)}${c.kind === "dir" ? "📁" : "📄"} ${c.name}`);
            if (c.kind === "dir" && depth < 4) await walk(c.id, depth + 1);
          }
        };
        await walk(base?.id ?? null, 0);
        break;
      }
      case "mkdir": { const d = await ensureDir(abs(args[0] ?? "")); out.push(`created ${await pathOf(d.id)}`); break; }
      case "touch": case "write": case "append": {
        const p = abs(args[0] ?? "");
        const parentPath = p.split("/").slice(0, -1).join("/") || "/";
        const name = p.split("/").pop()!;
        const parent = parentPath === "/" ? null : await ensureDir(parentPath);
        const existing = await resolvePath(p);
        const payload = args.slice(1).join(" ");
        if (existing) {
          const content = cmd === "append" ? `${existing.content}\n${payload}` : cmd === "touch" ? existing.content : payload;
          const n = await writeFile(existing.id, content);
          out.push(`wrote ${p} (v${n.version}, ${n.size} bytes)`);
        } else {
          const n = await createNode(parent?.id ?? null, name, "file", "text/plain", cmd === "touch" ? "" : payload);
          out.push(`created ${p} (${n.size} bytes)`);
        }
        break;
      }
      case "rm": {
        const n = await resolvePath(abs(args[0] ?? ""));
        if (!n) { out.push("rm: not found"); break; }
        await trash([n.id]);
        out.push(`moved to Trash: ${n.name} (reversible — FM-11)`);
        break;
      }
      case "cp": case "mv": {
        const src = await resolvePath(abs(args[0] ?? ""));
        const destPath = abs(args[1] ?? "");
        const dest = destPath === "/" ? null : await resolvePath(destPath);
        if (!src) { out.push(`${cmd}: source not found`); break; }
        const interruptFlag = args.find((a) => a.startsWith("--interrupt"));
        const interrupt = interruptFlag ? (args[args.indexOf(interruptFlag) + 1] as "before_publish" | "after_publish") : undefined;
        const r = await runFileOp({ kind: cmd === "cp" ? "copy" : "move", srcIds: [src.id], destParentId: dest?.id ?? null, interrupt });
        out.push(`op #${r.op} ${r.state}${r.outcome ? ` (${r.outcome})` : ""}`);
        out.push(...r.journal.map((j) => `  ${j.state.padEnd(16)} ${j.note}`));
        break;
      }
      case "find": {
        const q = (args[0] ?? "").toLowerCase();
        const res = await db.execute<{ name: string; id: number }>(sql`select id, name from fs_nodes where trashed = false and lower(name) like ${"%" + q + "%"} limit 50`);
        for (const r of res.rows) out.push(`${await pathOf(Number(r.id))}`);
        break;
      }
      case "grep": {
        const q = (args[0] ?? "").toLowerCase();
        const res = await db.execute<{ id: number; name: string; content: string }>(sql`select id, name, content from fs_nodes where kind='file' and trashed=false and lower(content) like ${"%" + q + "%"} limit 50`);
        for (const r of res.rows)
          for (const [i, lineText] of String(r.content).split("\n").entries())
            if (lineText.toLowerCase().includes(q)) out.push(`${await pathOf(Number(r.id))}:${i + 1}: ${lineText.trim()}`);
        break;
      }
      case "du": {
        const p = abs(args[0] ?? "");
        const n = p === "/" ? null : await resolvePath(p);
        const st = await folderStats(n?.id ?? null);
        out.push(`${st.files} files, ${st.dirs} dirs, ${st.bytes} bytes`);
        break;
      }
      case "stat": {
        const n = await resolvePath(abs(args[0] ?? ""));
        if (!n) { out.push("stat: not found"); break; }
        out.push(JSON.stringify({ id: n.id, kind: n.kind, mime: n.mime, size: n.size, version: n.version, updatedAt: n.updatedAt }, null, 2));
        break;
      }
      case "versions": {
        const n = await resolvePath(abs(args[0] ?? ""));
        if (!n) { out.push("versions: not found"); break; }
        const res = await db.execute<{ version: number; created_at: string; length: number }>(sql`select version, created_at, length(content) as length from fs_versions where node_id = ${n.id} order by version desc`);
        for (const r of res.rows) out.push(`v${r.version}  ${r.created_at}  ${r.length} bytes`);
        break;
      }
      case "ops": {
        const res = await db.execute<{ id: number; kind: string; state: string }>(sql`select id, kind, state from file_ops order by id desc limit 15`);
        for (const r of res.rows) out.push(`#${r.id} ${r.kind} ${r.state}`);
        break;
      }
      case "json": {
        const n = await nodeById(Number(args[0]));
        out.push(JSON.stringify(n, null, 2));
        break;
      }
      default: out.push(`${cmd}: command not found (try: help)`);
    }
  } catch (e) {
    out.push(`error: ${String(e)}`);
  }
  return NextResponse.json({ cwd: nextCwd, out });
}
