import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { kv } from "@/db/schema";
import { ensureSeed } from "@/lib/server/seed";
import { normalize, type DesktopState } from "@/lib/windowEngine";

export const dynamic = "force-dynamic";
const KEY = "desktop.state";

export async function GET() {
  await ensureSeed();
  const [row] = await db.select().from(kv).where(eq(kv.key, KEY)).limit(1);
  if (!row) return NextResponse.json({ state: null });
  // SH-08: a persisted layout is normalised before it can ever be rendered.
  return NextResponse.json({ state: normalize(row.value as DesktopState), savedAt: row.updatedAt });
}

export async function PUT(req: Request) {
  await ensureSeed();
  const body = (await req.json()) as { state: DesktopState };
  const state = normalize(body.state);
  await db
    .insert(kv)
    .values({ key: KEY, scope: "shell", value: state })
    .onConflictDoUpdate({ target: kv.key, set: { value: state, updatedAt: new Date() } });
  return NextResponse.json({ ok: true, windows: state.windows.length });
}
