import { NextResponse } from "next/server";
import { createHash } from "node:crypto";
import { db } from "@/db";
import { alerts, features, fsNodes, kv, notes } from "@/db/schema";
import { ensureSeed } from "@/lib/server/seed";

export const dynamic = "force-dynamic";

/** BK-01/BK-05: a snapshot is only "healthy" after a verified sampled restore. */
export async function GET() {
  await ensureSeed();
  const bundle = {
    kind: "fusion-shell-snapshot",
    version: 1,
    at: new Date().toISOString(),
    fsNodes: await db.select().from(fsNodes),
    notes: await db.select().from(notes),
    settings: await db.select().from(kv),
    alerts: await db.select().from(alerts),
    featureStatus: (await db.select().from(features)).map((f) => ({ id: f.id, status: f.status })),
  };
  const payload = JSON.stringify(bundle);
  const digest = createHash("sha256").update(payload).digest("hex");
  return NextResponse.json({ digest, bytes: payload.length, bundle });
}

export async function POST(req: Request) {
  const b = (await req.json()) as { digest: string; bundle: unknown; sampleCount?: number };
  const payload = JSON.stringify(b.bundle);
  const digest = createHash("sha256").update(payload).digest("hex");
  if (digest !== b.digest) return NextResponse.json({ ok: false, error: "digest mismatch — restore refused" }, { status: 409 });
  const bundle = b.bundle as { fsNodes: { id: number; name: string; content: string }[] };
  const sample = bundle.fsNodes.slice(0, b.sampleCount ?? 5);
  const verified = sample.every((n) => typeof n.content === "string");
  return NextResponse.json({
    ok: true, digestVerified: true, sampled: sample.length, verified,
    health: verified ? "healthy (sampled restore verified)" : "unverified",
  });
}
