import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { vaultItems } from "@/db/schema";
import { ensureSeed } from "@/lib/server/seed";

export const dynamic = "force-dynamic";

/**
 * SC-01: the server is a blind store. It receives ciphertext + iv + salt produced by
 * WebCrypto in the browser and has no code path that can decrypt them (BK-06 key custody).
 */
export async function GET() {
  await ensureSeed();
  const rows = await db.select().from(vaultItems);
  return NextResponse.json({ items: rows, serverCanDecrypt: false });
}

export async function POST(req: Request) {
  const b = (await req.json()) as { label: string; kind: string; ciphertext: string; iv: string; salt: string };
  if (!b.ciphertext || !b.iv || !b.salt) return NextResponse.json({ error: "refusing plaintext" }, { status: 400 });
  const [row] = await db.insert(vaultItems).values(b).returning();
  return NextResponse.json({ item: row });
}

export async function DELETE(req: Request) {
  await db.delete(vaultItems).where(eq(vaultItems.id, Number(new URL(req.url).searchParams.get("id"))));
  return NextResponse.json({ ok: true });
}
