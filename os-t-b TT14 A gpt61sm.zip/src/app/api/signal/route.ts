import { NextResponse } from "next/server";
import { and, asc, eq, gt, max, sql } from "drizzle-orm";
import { db } from "@/db";
import { signals } from "@/db/schema";
import { ensureSeed } from "@/lib/server/seed";

// Implements: LN-20 Fusion Meet signalling. Append-only log per room; peers poll with ?after=<id>.
// Retention: rows older than 15 minutes are deleted on each POST. Authentication: none (LAN/demo trust model).
export const dynamic = "force-dynamic";

const KINDS = new Set(["hello", "offer", "answer", "ice", "bye"]);

export async function GET(req: Request) {
  await ensureSeed();
  const sp = new URL(req.url).searchParams;
  const room = sp.get("room") ?? "";
  const after = Number(sp.get("after") ?? 0);
  if (!/^[a-z0-9-]{3,40}$/i.test(room)) return NextResponse.json({ error: "bad room" }, { status: 400 });
  const rows = await db
    .select()
    .from(signals)
    .where(and(eq(signals.room, room), gt(signals.id, after)))
    .orderBy(asc(signals.id))
    .limit(200);
  const [m] = await db.select({ m: max(signals.id) }).from(signals).where(eq(signals.room, room));
  return NextResponse.json({
    messages: rows.map((r) => ({ id: r.id, from: r.fromPeer, kind: r.kind, payload: r.payload, createdAt: r.createdAt })),
    maxId: Number(m?.m ?? 0),
  });
}

export async function POST(req: Request) {
  await ensureSeed();
  const b = (await req.json()) as { room: string; from: string; kind: string; payload?: unknown };
  if (!/^[a-z0-9-]{3,40}$/i.test(b.room ?? "")) return NextResponse.json({ error: "bad room" }, { status: 400 });
  if (!/^p[a-z0-9]{6,12}$/.test(b.from ?? "")) return NextResponse.json({ error: "bad peer id" }, { status: 400 });
  if (!KINDS.has(b.kind)) return NextResponse.json({ error: "bad kind" }, { status: 400 });
  const payload = (b.payload ?? {}) as object;
  if (JSON.stringify(payload).length > 65_536) return NextResponse.json({ error: "payload over 64 KB" }, { status: 413 });
  const [row] = await db
    .insert(signals)
    .values({ room: b.room, fromPeer: b.from, kind: b.kind, payload })
    .returning();
  await db.execute(sql`delete from signals where created_at < now() - interval '15 minutes'`);
  return NextResponse.json({ id: row.id });
}
