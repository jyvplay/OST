import { NextResponse } from "next/server";
import { createHmac, timingSafeEqual } from "node:crypto";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { kv } from "@/db/schema";
import { ensureSeed } from "@/lib/server/seed";

export const dynamic = "force-dynamic";

const SECRET = process.env.FUSION_LICENSE_SECRET ?? "dev-only-local-secret";

function sign(payload: object) {
  const body = Buffer.from(JSON.stringify(payload)).toString("base64url");
  const mac = createHmac("sha256", SECRET).update(body).digest("base64url");
  return `${body}.${mac}`;
}
function verify(token: string) {
  const [body, mac] = token.split(".");
  if (!body || !mac) return null;
  const expected = createHmac("sha256", SECRET).update(body).digest("base64url");
  const a = Buffer.from(mac), b = Buffer.from(expected);
  if (a.length !== b.length || !timingSafeEqual(a, b)) return null;
  return JSON.parse(Buffer.from(body, "base64url").toString()) as Record<string, unknown>;
}

/** BL-02/BL-04: signed, offline-tolerant entitlement. Expiry never deletes data (BL-05). */
export async function GET() {
  await ensureSeed();
  const [row] = await db.select().from(kv).where(eq(kv.key, "entitlement")).limit(1);
  const ent = (row?.value as { plan: string; startedAt: string; days: number }) ?? { plan: "trial", startedAt: new Date().toISOString(), days: 14 };
  const elapsed = (Date.now() - new Date(ent.startedAt).getTime()) / 864e5;
  const daysLeft = Math.max(0, Math.ceil(ent.days - elapsed));
  const state = ent.plan === "pro" ? "pro" : daysLeft > 0 ? "trial" : "expired";
  return NextResponse.json({
    plan: ent.plan, state, daysLeft,
    graceDays: 7,
    degradedCapabilities: state === "expired" ? ["files:read-only", "find:read-only"] : [],
    token: sign({ plan: ent.plan, state, exp: Date.now() + 7 * 864e5 }),
  });
}

export async function POST(req: Request) {
  await ensureSeed();
  const b = (await req.json()) as { plan: "trial" | "pro" | "expired" };
  const value = b.plan === "expired"
    ? { plan: "trial", startedAt: new Date(Date.now() - 30 * 864e5).toISOString(), days: 14 }
    : { plan: b.plan, startedAt: new Date().toISOString(), days: 14 };
  await db.insert(kv).values({ key: "entitlement", scope: "commerce", value })
    .onConflictDoUpdate({ target: kv.key, set: { value, updatedAt: new Date() } });
  return NextResponse.json({ ok: true, value });
}
