import { NextResponse } from "next/server";
import { desc, eq, inArray } from "drizzle-orm";
import { db } from "@/db";
import { alerts } from "@/db/schema";
import { ensureSeed } from "@/lib/server/seed";

export const dynamic = "force-dynamic";

export async function GET() {
  await ensureSeed();
  const rows = await db.select().from(alerts).orderBy(desc(alerts.createdAt));
  const ttl = Date.now() - 7 * 864e5; // NC-01: 7-day TTL applied on read, never silently persisted longer
  const live = rows.filter((r) => r.pinned || new Date(r.createdAt).getTime() > ttl);
  const groups: Record<string, typeof live> = {};
  for (const a of live) (groups[a.app] ??= []).push(a);
  return NextResponse.json({ alerts: live, groups, expired: rows.length - live.length });
}

export async function POST(req: Request) {
  await ensureSeed();
  const b = (await req.json()) as { app: string; title: string; body?: string; priority?: string };
  const [row] = await db.insert(alerts).values({ app: b.app, title: b.title, body: b.body ?? "", priority: b.priority ?? "normal" }).returning();
  return NextResponse.json({ alert: row });
}

export async function PATCH(req: Request) {
  const b = (await req.json()) as { ids: number[]; read?: boolean; pinned?: boolean; snoozeMinutes?: number };
  await db.update(alerts).set({
    ...(b.read !== undefined ? { read: b.read } : {}),
    ...(b.pinned !== undefined ? { pinned: b.pinned } : {}),
    ...(b.snoozeMinutes ? { snoozedUntil: new Date(Date.now() + b.snoozeMinutes * 60000) } : {}),
  }).where(inArray(alerts.id, b.ids));
  return NextResponse.json({ ok: true });
}

export async function DELETE(req: Request) {
  const url = new URL(req.url);
  if (url.searchParams.get("all")) { await db.delete(alerts).where(eq(alerts.pinned, false)); return NextResponse.json({ ok: true }); }
  await db.delete(alerts).where(eq(alerts.id, Number(url.searchParams.get("id"))));
  return NextResponse.json({ ok: true });
}
