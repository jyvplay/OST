import { NextResponse } from "next/server";
import { computeLedger, ledgerFingerprint, readEvidence } from "@/lib/server/ledger";

export const dynamic = "force-dynamic";
/** Read-only audited ledger. No client can write a build or test grade via this route. */
export async function GET() {
  const fingerprint = ledgerFingerprint();
  const ev = readEvidence(fingerprint);
  const directCases = ev.cases.filter(c => c.id !== "RUN");
  const { rows, counts } = computeLedger(directCases, []);
  return NextResponse.json({
    fingerprint, rows, counts,
    evidence: { acceptedSuites: ev.acceptedSuites, staleSuites: ev.staleSuites },
    policy: "Fully tested means all declared acceptance cases passed on the current source fingerprint in Chromium/server scope only; it does not certify Safari, Firefox or physical receivers. A source citation is not test evidence.",
  });
}
