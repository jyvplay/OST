import { NextResponse } from "next/server";
import { compositeLayers, parseLayerProject } from "@/lib/layers";
import { encodePng } from "@/lib/server/png";
export const dynamic = "force-dynamic";

/** FF-05: headless project -> flattened PNG. Same core as the browser; no external URLs or decoder
 * libraries. API input is capped at 2 MB (downloadable project format itself allows up to 32 MB).
 * This cooperative budget is NOT OS process isolation or a multi-tenant security certification. */
export async function POST(req: Request) {
  try {
    const text = await req.text();
    if (text.length > 2_000_000) return NextResponse.json({ error: "API project body exceeds 2 MB" }, { status: 413 });
    const doc = parseLayerProject(text);
    const raster = compositeLayers(doc);
    const png = encodePng(raster.width, raster.height, new Uint8Array(raster.data.buffer));
    return new Response(new Uint8Array(png), { headers: {
      "content-type": "image/png", "content-disposition": 'inline; filename="composite.png"', "cache-control": "no-store",
    } });
  } catch (e) {
    return NextResponse.json({ error: e instanceof Error ? e.message : "Invalid layer project" }, { status: 400 });
  }
}
