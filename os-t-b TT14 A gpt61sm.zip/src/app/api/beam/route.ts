import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { castTargets } from "@/db/schema";
import { ensureSeed } from "@/lib/server/seed";

export const dynamic = "force-dynamic";

export async function GET() {
  await ensureSeed();
  const rows = await db.select().from(castTargets);
  return NextResponse.json({
    targets: rows,
    protocolMatrix: {
      "remote-playback": "browser-owned; the OS picker may include AirPlay / Cast (CA-01, CA-02)",
      presentation: "Presentation API: second display or Cast receiver page on this origin (CA-08)",
      "webrtc-together": "peer sync room, media stays local to each peer (CA-11)",
    },
    impossible: {
      "airplay-mirroring": "no web API and no FairPlay client (CA-04)",
      dlna: "no SSDP/multicast from a browser (CA-10)",
      miracast: "no API on any platform (CA-12)",
    },
  });
}

/** CA-14: trust memory. A target is only remembered after the user confirms it once. */
export async function POST(req: Request) {
  const b = (await req.json()) as { name: string; protocol: string; fingerprint?: string; trusted?: boolean };
  const [row] = await db.insert(castTargets)
    .values({ name: b.name, protocol: b.protocol, fingerprint: b.fingerprint ?? "", trusted: b.trusted ?? false })
    .returning();
  return NextResponse.json({ target: row });
}

export async function PATCH(req: Request) {
  const b = (await req.json()) as { id: number; trusted: boolean };
  const [row] = await db.update(castTargets).set({ trusted: b.trusted, lastSeen: new Date() }).where(eq(castTargets.id, b.id)).returning();
  return NextResponse.json({ target: row });
}
