import { NextResponse } from "next/server";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { notes } from "@/db/schema";
import { ensureSeed } from "@/lib/server/seed";

export const dynamic = "force-dynamic";

export async function GET() {
  await ensureSeed();
  const rows = await db.select().from(notes).orderBy(desc(notes.updatedAt));
  // PR-02 backlinks: resolved server-side in one pass over the corpus.
  const backlinks: Record<number, number[]> = {};
  for (const n of rows) {
    backlinks[n.id] = rows.filter((o) => o.id !== n.id && o.body.toLowerCase().includes(`[[${n.title.toLowerCase()}]]`)).map((o) => o.id);
  }
  return NextResponse.json({ notes: rows, backlinks });
}

export async function POST(req: Request) {
  await ensureSeed();
  const b = (await req.json()) as { title?: string; body?: string; tags?: string };
  const [row] = await db.insert(notes).values({ title: b.title ?? "Untitled", body: b.body ?? "", tags: b.tags ?? "" }).returning();
  return NextResponse.json({ note: row });
}

export async function PATCH(req: Request) {
  const b = (await req.json()) as { id: number; title?: string; body?: string; tags?: string };
  const [row] = await db.update(notes)
    .set({ ...(b.title !== undefined ? { title: b.title } : {}), ...(b.body !== undefined ? { body: b.body } : {}), ...(b.tags !== undefined ? { tags: b.tags } : {}), updatedAt: new Date() })
    .where(eq(notes.id, b.id)).returning();
  return NextResponse.json({ note: row });
}

export async function DELETE(req: Request) {
  const id = Number(new URL(req.url).searchParams.get("id"));
  await db.delete(notes).where(eq(notes.id, id));
  return NextResponse.json({ ok: true });
}
