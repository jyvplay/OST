import { NextResponse } from "next/server";
import { count, desc, ilike } from "drizzle-orm";
import { db } from "@/db";
import { alerts, auditLog, fsNodes, notes } from "@/db/schema";
import { verifyScoped } from "@/lib/server/auth";

// Implements: AU-05 automation API. Same command surface as the palette; bearer token required.
export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  const auth = req.headers.get("authorization") ?? "";
  const token = auth.startsWith("Bearer ") ? auth.slice(7) : null;
  if (!verifyScoped(token, "cmd")) {
    return NextResponse.json({ error: "missing, invalid, or expired token" }, { status: 401 });
  }
  const b = (await req.json()) as { cmd: string; title?: string; body?: string; q?: string };
  switch (b.cmd) {
    case "note": {
      const [row] = await db
        .insert(notes)
        .values({ title: (b.title ?? "Untitled").slice(0, 200), body: (b.body ?? "").slice(0, 100_000) })
        .returning();
      await db.insert(auditLog).values({ action: "command.note", detail: { id: row.id } });
      return NextResponse.json({ ok: true, note: row });
    }
    case "search": {
      const q = (b.q ?? "").slice(0, 200);
      const rows = await db.select({ id: notes.id, title: notes.title }).from(notes).where(ilike(notes.title, `%${q}%`)).limit(20);
      return NextResponse.json({ ok: true, results: rows });
    }
    case "status": {
      const [n] = await db.select({ c: count() }).from(notes);
      const [f] = await db.select({ c: count() }).from(fsNodes);
      const [a] = await db.select({ c: count() }).from(alerts);
      const recent = await db.select().from(auditLog).orderBy(desc(auditLog.id)).limit(3);
      return NextResponse.json({ ok: true, notes: Number(n.c), files: Number(f.c), alerts: Number(a.c), recent });
    }
    default:
      return NextResponse.json({ error: `unknown cmd ${b.cmd}` }, { status: 400 });
  }
}
