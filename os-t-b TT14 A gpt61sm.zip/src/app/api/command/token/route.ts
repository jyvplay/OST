import { NextResponse } from "next/server";
import { signScoped } from "@/lib/server/auth";

// Implements: AU-05 token issuance. Refuses requests browsers mark cross-site (Sec-Fetch-Site).
export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const site = req.headers.get("sec-fetch-site");
  if (site && site !== "same-origin" && site !== "none") {
    return NextResponse.json({ error: "cross-site token requests are refused" }, { status: 403 });
  }
  return NextResponse.json({ token: signScoped("cmd", 3_600_000), ttlSeconds: 3600 });
}
