import { NextResponse } from "next/server";
import { forgeParse } from "@/lib/server/forge";

// Implements: FF-02 headless parse endpoint, FF-12 sandbox (40 MB cap, 10 s watchdog).
export const dynamic = "force-dynamic";
export const maxDuration = 30;

export async function POST(req: Request) {
  const form = await req.formData();
  const file = form.get("file");
  if (!(file instanceof File)) return NextResponse.json({ error: "no file" }, { status: 400 });
  if (file.size > 40 * 1024 * 1024) return NextResponse.json({ error: "file over 40 MB guard" }, { status: 413 });
  const buf = Buffer.from(await file.arrayBuffer());
  const started = Date.now();
  if (file.name.toLowerCase().endsWith(".pdf")) {
    return NextResponse.json({
      format: "PDF",
      grade: "B",
      engine: "browser-native viewer (FF-03)",
      text: "Rendered by the browser's built-in PDF viewer below; no server-side parsing.",
      entries: [],
      warnings: [],
      lossReport: [],
      name: file.name,
      bytes: file.size,
      tookMs: Date.now() - started,
    });
  }
  try {
    const result = await Promise.race([
      Promise.resolve().then(() => forgeParse(file.name, buf)),
      new Promise<never>((_, rej) => setTimeout(() => rej(new Error("watchdog: parse exceeded 10 s")), 10_000)),
    ]);
    return NextResponse.json({ ...result, name: file.name, bytes: file.size, tookMs: Date.now() - started });
  } catch (e) {
    return NextResponse.json({ error: String(e), name: file.name, bytes: file.size }, { status: 422 });
  }
}
