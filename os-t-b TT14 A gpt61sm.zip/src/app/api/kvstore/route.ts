import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { kv } from "@/db/schema";
import { ensureSeed } from "@/lib/server/seed";

// Implements: storage for app state (tasks, calendar, routines, presets, widgets, matrix, websearch).
// Allow-listed keys only; each value is capped at 512 KB of JSON. Last-writer-wins per key (declared).
export const dynamic = "force-dynamic";

const ALLOWED = /^app\.(tasks|calendar|routines|presets|widgets|touchpad|matrix|websearch|contacts|clipboard|sticky|browserSessions|browserProfiles|browserHistory\.[\w.\- ]{1,60})$/;

export async function GET(req: Request) {
  await ensureSeed();
  const key = new URL(req.url).searchParams.get("key") ?? "";
  if (!ALLOWED.test(key)) return NextResponse.json({ error: "key not allowed" }, { status: 400 });
  const [row] = await db.select().from(kv).where(eq(kv.key, key)).limit(1);
  return NextResponse.json({ key, value: row?.value ?? null, updatedAt: row?.updatedAt ?? null });
}

export async function PUT(req: Request) {
  await ensureSeed();
  const b = (await req.json()) as { key: string; value: unknown };
  if (!ALLOWED.test(b.key ?? "")) return NextResponse.json({ error: "key not allowed" }, { status: 400 });
  const bytes = JSON.stringify(b.value ?? null).length;
  if (bytes > 512_000) return NextResponse.json({ error: "value over 512 KB" }, { status: 413 });
  await db
    .insert(kv)
    .values({ key: b.key, scope: "app", value: b.value })
    .onConflictDoUpdate({ target: kv.key, set: { value: b.value, updatedAt: new Date() } });
  return NextResponse.json({ ok: true, bytes });
}
