import { NextResponse } from "next/server";
import { safePublicFetch, safePublicUrl } from "@/lib/server/safeFetch";

// MS-06: read-only Matrix capabilities probe; no credentials. User-supplied HTTPS origin is DNS-vetted
// and pinned to a public IP for the TLS request (no redirect, no cookie forwarding).
export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const raw = (new URL(req.url).searchParams.get("server") ?? "").trim().replace(/\/+$/, "");
  const u = safePublicUrl(raw);
  if (!u) return NextResponse.json({ error: "HTTPS public hostname required (no IP, localhost, custom port or credentials)" }, { status: 400 });
  const t0 = Date.now();
  try {
    const [v, f] = await Promise.all([
      safePublicFetch(`${u.origin}/_matrix/client/versions`),
      safePublicFetch(`${u.origin}/_matrix/client/v3/login`),
    ]);
    const versions = v.status === 200 ? JSON.parse(v.body) as { versions?: string[]; unstable_features?: Record<string, boolean> } : null;
    const login = f.status === 200 ? JSON.parse(f.body) as { flows?: { type: string }[] } : null;
    return NextResponse.json({
      server: u.origin, latencyMs: Date.now() - t0,
      versions: versions?.versions ?? [], unstableFeatures: Object.keys(versions?.unstable_features ?? {}).length,
      loginFlows: (login?.flows ?? []).map(x => x.type), status: { versions: v.status, login: f.status },
    });
  } catch (e) {
    return NextResponse.json({ error: `homeserver probe refused or unreachable: ${String(e)}` }, { status: 502 });
  }
}
