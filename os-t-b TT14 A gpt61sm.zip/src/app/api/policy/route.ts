import { NextResponse } from "next/server";
import { loadPolicy } from "@/lib/server/policy";

// Implements: ST-08 managed configuration (read side).
export const dynamic = "force-dynamic";

export async function GET() {
  return NextResponse.json(loadPolicy());
}
