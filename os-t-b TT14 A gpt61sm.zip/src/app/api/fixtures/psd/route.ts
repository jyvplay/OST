import { buildPsd, makeFixtureSpec } from "@/lib/psdWriter";

// TEST FIXTURE endpoint: returns a generated layered PSD (see psdWriter.ts). Not a user feature.
export const dynamic = "force-dynamic";

export async function GET() {
  const bytes = buildPsd(makeFixtureSpec());
  return new Response(new Uint8Array(bytes), {
    headers: {
      "content-type": "image/vnd.adobe.photoshop",
      "content-disposition": 'attachment; filename="fixture-layers.psd"',
    },
  });
}
