import { NextResponse } from "next/server";
import { safePublicFetch, safePublicUrl } from "@/lib/server/safeFetch";

export const dynamic = "force-dynamic";
/** WM-06: a HEAD preflight is advisory only, never a security guarantee. Arbitrary user URLs are
 *  opened by the browser iframe (with a real-browser fallback), NOT fetched by our server.
 *  This allowlist prevents /api/embed from becoming an SSRF/proxy endpoint. */
const ALLOWED = new Set(["example.com", "www.wikipedia.org", "wikipedia.org", "developer.mozilla.org"]);
export async function GET(req: Request) {
  const target = new URL(req.url).searchParams.get("url") ?? "";
  const u = safePublicUrl(target);
  if (!u || !ALLOWED.has(u.hostname)) {
    return NextResponse.json({ embeddable: null, reason: "server preflight restricted to a few public reference hosts; iframe may still work" });
  }
  try {
    const res = await safePublicFetch(u.href, "HEAD");
    const xfo = (res.headers["x-frame-options"] ?? "").toLowerCase();
    const csp = (res.headers["content-security-policy"] ?? "").toLowerCase();
    const blocked = xfo.includes("deny") || xfo.includes("sameorigin") || /frame-ancestors\s+('none'|'self')/.test(csp);
    return NextResponse.json({ embeddable: !blocked, status: res.status, xfo, frameAncestors: /frame-ancestors[^;]*/.exec(csp)?.[0] ?? null });
  } catch (e) {
    return NextResponse.json({ embeddable: null, reason: String(e) });
  }
}
