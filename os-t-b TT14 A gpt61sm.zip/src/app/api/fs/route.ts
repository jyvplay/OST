import { NextResponse } from "next/server";
import { and, eq, inArray } from "drizzle-orm";
import { db } from "@/db";
import { fsNodes, fsVersions, fileOps } from "@/db/schema";
import { ensureSeed } from "@/lib/server/seed";
import {
  childrenOf, createNode, folderStats, nodeById, pathOf, purge, resolvePath,
  restore, runFileOp, trash, uniqueName, writeFile, ensureDir, VersionConflictError,
} from "@/lib/server/vfs";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  await ensureSeed();
  const url = new URL(req.url);
  const op = url.searchParams.get("op") ?? "list";
  if (op === "list") {
    const path = url.searchParams.get("path") ?? "/";
    const node = path === "/" ? null : await resolvePath(path);
    if (path !== "/" && !node) return NextResponse.json({ error: "not found", path }, { status: 404 });
    const parentId = node?.id ?? null;
    return NextResponse.json({
      path,
      id: parentId,
      entries: await childrenOf(parentId),
      stats: await folderStats(parentId),
    });
  }
  if (op === "read") {
    const id = Number(url.searchParams.get("id"));
    const node = await nodeById(id);
    if (!node) return NextResponse.json({ error: "not found" }, { status: 404 });
    return NextResponse.json({ node, path: await pathOf(id) });
  }
  if (op === "versions") {
    const id = Number(url.searchParams.get("id"));
    const rows = await db.select().from(fsVersions).where(eq(fsVersions.nodeId, id));
    return NextResponse.json({ versions: rows.sort((a, b) => b.version - a.version) });
  }
  if (op === "trash") {
    const rows = await db.select().from(fsNodes).where(eq(fsNodes.trashed, true));
    return NextResponse.json({ entries: rows });
  }
  if (op === "ops") {
    const rows = await db.select().from(fileOps);
    return NextResponse.json({ ops: rows.sort((a, b) => b.id - a.id).slice(0, 50) });
  }
  if (op === "tree") {
    const rows = await db.select().from(fsNodes).where(and(eq(fsNodes.kind, "dir"), eq(fsNodes.trashed, false)));
    return NextResponse.json({ dirs: rows });
  }
  return NextResponse.json({ error: "unknown op" }, { status: 400 });
}

export async function POST(req: Request) {
  await ensureSeed();
  const body = (await req.json()) as Record<string, unknown>;
  const op = String(body.op ?? "");
  switch (op) {
    case "create": {
      const node = await createNode(
        (body.parentId as number | null) ?? null,
        String(body.name ?? "untitled"),
        (body.kind as "dir" | "file") ?? "file",
        String(body.mime ?? "text/plain"),
        String(body.content ?? ""),
      );
      return NextResponse.json({ node });
    }
    case "write": {
      // FM-18 optimistic concurrency: fail closed on stale edits, leaving the caller's draft untouched.
      try {
        const expected = body.expectedVersion === undefined ? undefined : Number(body.expectedVersion);
        if (expected !== undefined && (!Number.isSafeInteger(expected) || expected < 1))
          return NextResponse.json({ error: "invalid expectedVersion" }, { status: 400 });
        return NextResponse.json({ node: await writeFile(Number(body.id), String(body.content ?? ""), expected) });
      } catch (e) {
        if (e instanceof VersionConflictError)
          return NextResponse.json({ error: e.message, code: "VERSION_CONFLICT", expected: e.expected, actual: e.actual }, { status: 409 });
        return NextResponse.json({ error: String(e) }, { status: 400 });
      }
    }
    case "rename": {
      const id = Number(body.id);
      const node = await nodeById(id);
      if (!node) return NextResponse.json({ error: "not found" }, { status: 404 });
      const name = await uniqueName(node.parentId, String(body.name));
      const [row] = await db.update(fsNodes).set({ name, updatedAt: new Date() }).where(eq(fsNodes.id, id)).returning();
      return NextResponse.json({ node: row });
    }
    case "batchRename": {
      const ids = (body.ids as number[]) ?? [];
      const pattern = String(body.pattern ?? "{name}");
      const preview: { id: number; from: string; to: string }[] = [];
      let i = Number(body.start ?? 1);
      for (const id of ids) {
        const n = await nodeById(id);
        if (!n) continue;
        const dot = n.name.lastIndexOf(".");
        const base = dot > 0 ? n.name.slice(0, dot) : n.name;
        const ext = dot > 0 ? n.name.slice(dot + 1) : "";
        const to = pattern
          .replace(/\{name\}/g, base)
          .replace(/\{ext\}/g, ext ? "." + ext : "")
          .replace(/\{n(?::(\d+))?\}/g, (_m, pad) => String(i).padStart(Number(pad ?? 1), "0"));
        preview.push({ id, from: n.name, to });
        i++;
      }
      if (!body.apply) return NextResponse.json({ preview, applied: false });
      for (const p of preview) {
        const n = await nodeById(p.id);
        if (!n) continue;
        const name = await uniqueName(n.parentId, p.to);
        await db.update(fsNodes).set({ name }).where(eq(fsNodes.id, p.id));
      }
      return NextResponse.json({ preview, applied: true });
    }
    case "copy":
    case "move":
      return NextResponse.json(
        await runFileOp({
          kind: op,
          srcIds: (body.ids as number[]) ?? [],
          destParentId: (body.destParentId as number | null) ?? null,
          interrupt: body.interrupt as "before_publish" | "after_publish" | undefined,
        }),
      );
    case "ensureDir": {
      // FM-18/FM-13: idempotent folder creation (used by file handlers and share targets).
      const node = await ensureDir(String(body.path ?? "/"));
      return NextResponse.json({ node });
    }
    case "trash":
      await trash((body.ids as number[]) ?? []);
      return NextResponse.json({ ok: true });
    case "restore":
      await restore((body.ids as number[]) ?? []);
      return NextResponse.json({ ok: true });
    case "purge":
      await purge((body.ids as number[]) ?? []);
      return NextResponse.json({ ok: true });
    case "revert": {
      const [v] = await db.select().from(fsVersions).where(eq(fsVersions.id, Number(body.versionId))).limit(1);
      if (!v) return NextResponse.json({ error: "no version" }, { status: 404 });
      return NextResponse.json({ node: await writeFile(v.nodeId, v.content) });
    }
    case "tag": {
      await db.update(fsNodes).set({ tags: String(body.tags ?? "") }).where(inArray(fsNodes.id, (body.ids as number[]) ?? []));
      return NextResponse.json({ ok: true });
    }
    default:
      return NextResponse.json({ error: "unknown op" }, { status: 400 });
  }
}
