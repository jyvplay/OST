import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { kv } from "@/db/schema";
import { ensureSeed } from "@/lib/server/seed";

// Implements: SR-04 opt-in web results. Off by default (403 unless find.webResults is true).
// Provider nuance: Wikipedia OpenSearch, i.e. encyclopaedic results, NOT general web search.
export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  await ensureSeed();
  const [row] = await db.select().from(kv).where(eq(kv.key, "settings.root")).limit(1);
  const enabled = (row?.value as Record<string, unknown> | undefined)?.["find.webResults"] === true;
  if (!enabled) {
    return NextResponse.json({ error: "web results are off (SR-04 default); enable them in Settings" }, { status: 403 });
  }
  const q = (new URL(req.url).searchParams.get("q") ?? "").trim().slice(0, 200);
  if (!q) return NextResponse.json({ provider: "Wikipedia OpenSearch", query: q, results: [] });
  const url = `https://en.wikipedia.org/w/api.php?action=opensearch&search=${encodeURIComponent(q)}&limit=6&namespace=0&format=json`;
  try {
    const r = await fetch(url, {
      headers: { "user-agent": "FusionShell/2.2 (self-hosted PWA; opt-in search)" },
      signal: AbortSignal.timeout(6000),
    });
    if (!r.ok) return NextResponse.json({ error: `provider HTTP ${r.status}` }, { status: 502 });
    const j = (await r.json()) as [string, string[], string[], string[]];
    return NextResponse.json({
      provider: "Wikipedia OpenSearch (not general web)",
      query: q,
      results: j[1].map((title, i) => ({ title, url: j[3][i], snippet: j[2][i] ?? "" })),
    });
  } catch (e) {
    return NextResponse.json({ error: `provider unreachable: ${String(e)}` }, { status: 502 });
  }
}
