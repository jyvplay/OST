import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { auditLog, kv } from "@/db/schema";
import { defaultSettings, ensureSeed } from "@/lib/server/seed";
import { loadPolicy } from "@/lib/server/policy";

// Implements: ST-01 settings graph (typed keys, history, undo) and ST-08 policy locks (409 on locked keys).
export const dynamic = "force-dynamic";
const KEY = "settings.root";

async function read() {
  const [row] = await db.select().from(kv).where(eq(kv.key, KEY)).limit(1);
  return { ...defaultSettings, ...((row?.value as Record<string, unknown>) ?? {}) };
}

export async function GET() {
  await ensureSeed();
  const [hist] = await db.select().from(kv).where(eq(kv.key, "settings.history")).limit(1);
  const policy = loadPolicy();
  return NextResponse.json({
    settings: await read(),
    defaults: defaultSettings,
    history: (hist?.value as unknown[]) ?? [],
    locked: policy.locked,
    policy: { name: policy.name, source: policy.source },
  });
}

export async function PATCH(req: Request) {
  await ensureSeed();
  const { key, value } = (await req.json()) as { key: string; value: unknown };
  const policy = loadPolicy();
  if (key in policy.locked) {
    await db.insert(auditLog).values({ action: "setting.refused-by-policy", detail: { key } });
    return NextResponse.json({ error: `“${key}” is locked by ${policy.name}`, locked: true }, { status: 409 });
  }
  const current = await read();
  const prev = current[key];
  const next = { ...current, [key]: value };
  await db
    .insert(kv)
    .values({ key: KEY, scope: "settings", value: next })
    .onConflictDoUpdate({ target: kv.key, set: { value: next, updatedAt: new Date() } });
  const [h] = await db.select().from(kv).where(eq(kv.key, "settings.history")).limit(1);
  const history = [
    { key, from: prev ?? null, to: value, at: new Date().toISOString() },
    ...((h?.value as unknown[]) ?? []),
  ].slice(0, 50);
  await db
    .insert(kv)
    .values({ key: "settings.history", scope: "settings", value: history })
    .onConflictDoUpdate({ target: kv.key, set: { value: history, updatedAt: new Date() } });
  await db.insert(auditLog).values({ action: "setting.change", detail: { key, from: prev ?? null, to: value } });
  return NextResponse.json({ settings: next, undo: { key, value: prev ?? null } });
}
