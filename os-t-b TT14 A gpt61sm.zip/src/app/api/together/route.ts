import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { togetherRooms } from "@/db/schema";
import { ensureSeed } from "@/lib/server/seed";

export const dynamic = "force-dynamic";

/**
 * CA-11 Together: the server holds only a clock and a playback intent.
 * Media never passes through it — each participant plays their own copy.
 */
export async function GET(req: Request) {
  await ensureSeed();
  const code = new URL(req.url).searchParams.get("code") ?? "";
  const [row] = await db.select().from(togetherRooms).where(eq(togetherRooms.code, code)).limit(1);
  const serverNow = Date.now();
  if (!row) return NextResponse.json({ room: null, serverNow });
  const st = row.state as { playing: boolean; positionMs: number; rate: number; title: string };
  const projected = st.playing ? st.positionMs + (serverNow - row.epochMs) * st.rate : st.positionMs;
  return NextResponse.json({ room: { code, ...st, projectedMs: Math.round(projected) }, serverNow });
}

export async function PUT(req: Request) {
  await ensureSeed();
  const b = (await req.json()) as { code: string; playing: boolean; positionMs: number; rate?: number; title?: string };
  const state = { playing: b.playing, positionMs: b.positionMs, rate: b.rate ?? 1, title: b.title ?? "" };
  await db.insert(togetherRooms).values({ code: b.code, state, epochMs: Date.now() })
    .onConflictDoUpdate({ target: togetherRooms.code, set: { state, epochMs: Date.now(), updatedAt: new Date() } });
  return NextResponse.json({ ok: true, serverNow: Date.now() });
}
