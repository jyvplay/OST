/** CA-02: a Range-capable media endpoint, because a cast receiver must be able to seek. */
const WAV = (() => {
  const sr = 8000, secs = 3, n = sr * secs;
  const buf = Buffer.alloc(44 + n * 2);
  buf.write("RIFF", 0); buf.writeUInt32LE(36 + n * 2, 4); buf.write("WAVEfmt ", 8);
  buf.writeUInt32LE(16, 16); buf.writeUInt16LE(1, 20); buf.writeUInt16LE(1, 22);
  buf.writeUInt32LE(sr, 24); buf.writeUInt32LE(sr * 2, 28); buf.writeUInt16LE(2, 32); buf.writeUInt16LE(16, 34);
  buf.write("data", 36); buf.writeUInt32LE(n * 2, 40);
  for (let i = 0; i < n; i++) buf.writeInt16LE(Math.round(6000 * Math.sin((2 * Math.PI * 220 * i) / sr) * (1 - i / n)), 44 + i * 2);
  return buf;
})();

export async function GET(req: Request) {
  const range = req.headers.get("range");
  const total = WAV.length;
  if (range) {
    const m = /bytes=(\d+)-(\d*)/.exec(range);
    const start = Number(m?.[1] ?? 0);
    const end = m?.[2] ? Number(m[2]) : total - 1;
    const slice = WAV.subarray(start, end + 1);
    return new Response(new Uint8Array(slice), {
      status: 206,
      headers: {
        "content-type": "audio/wav",
        "content-range": `bytes ${start}-${end}/${total}`,
        "accept-ranges": "bytes",
        "content-length": String(slice.length),
      },
    });
  }
  return new Response(new Uint8Array(WAV), {
    headers: { "content-type": "audio/wav", "accept-ranges": "bytes", "content-length": String(total) },
  });
}
