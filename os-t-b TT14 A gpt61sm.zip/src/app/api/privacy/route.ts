import { NextResponse } from "next/server";
import { count, inArray } from "drizzle-orm";
import { db } from "@/db";
import { alerts, auditLog, castTargets, fsNodes, kv, messages, notes, signals, vaultItems } from "@/db/schema";
import { ensureSeed } from "@/lib/server/seed";

// Implements: SC-05 privacy dashboard. Row counts per data category and every configured outbound endpoint.
// SC-08: reports that no telemetry endpoint exists in this build.
export const dynamic = "force-dynamic";

export async function GET() {
  await ensureSeed();
  const [files, nts, al, msg, vault, cast, sig, audit, kvRows] = await Promise.all([
    db.select({ c: count() }).from(fsNodes),
    db.select({ c: count() }).from(notes),
    db.select({ c: count() }).from(alerts),
    db.select({ c: count() }).from(messages),
    db.select({ c: count() }).from(vaultItems),
    db.select({ c: count() }).from(castTargets),
    db.select({ c: count() }).from(signals),
    db.select({ c: count() }).from(auditLog),
    db.select().from(kv).where(inArray(kv.key, ["app.matrix", "app.websearch"])),
  ]);
  const counts = {
    files: Number(files[0].c),
    notes: Number(nts[0].c),
    alerts: Number(al[0].c),
    messages: Number(msg[0].c),
    vaultCiphertexts: Number(vault[0].c),
    castTargets: Number(cast[0].c),
    meetSignals: Number(sig[0].c),
    auditEntries: Number(audit[0].c),
  };
  const destinations = ["this origin (your Postgres, on this server)"];
  for (const r of kvRows) {
    const v = r.value as { server?: string } | null;
    if (r.key === "app.matrix" && v?.server) destinations.push(`Matrix homeserver ${v.server} (only when you press Check)`);
    if (r.key === "app.websearch") destinations.push("Wikipedia OpenSearch (only when “web results” is on)");
  }
  return NextResponse.json({ counts, destinations, telemetry: "none — no analytics or crash endpoints exist in this build" });
}
