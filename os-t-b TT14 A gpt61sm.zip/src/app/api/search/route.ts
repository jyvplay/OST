import { NextResponse } from "next/server";
import { sql } from "drizzle-orm";
import { db } from "@/db";
import { ensureSeed } from "@/lib/server/seed";
import { resolvePath } from "@/lib/server/vfs";

export const dynamic = "force-dynamic";
/** SR-05: scoped search uses a descendant CTE. A missing/trashed/non-folder scope never falls back
 * to a global search. SR-08 diagnostics say whether a name is outside scope or in Trash. */
export async function GET(req: Request) {
  await ensureSeed();
  const p = new URL(req.url).searchParams;
  const q = (p.get("q") ?? "").trim().slice(0, 120);
  const scope = p.get("scope")?.trim() || "";
  const op = p.get("op") ?? "search";
  let scopeId: number | null = null;
  if (scope && scope !== "/") {
    const node = await resolvePath(scope);
    if (!node || node.kind !== "dir" || node.trashed)
      return NextResponse.json({ error: `scope not found or not a folder: ${scope}`, code: "INVALID_SCOPE" }, { status: 404 });
    scopeId = node.id;
  }
  if (!q) return NextResponse.json({ q, scope: scope || "/", results: [], tookMs: 0 });
  const t0 = performance.now();
  // `position()` searches literal substrings. LIKE/ILIKE would let '%' and '_' escape the scope contract.
  const allowedFiles = scopeId === null ? sql`true` : sql`f.id in (
    with recursive descendants(id) as (
      select id from fs_nodes where id = ${scopeId} and kind = 'dir' and trashed = false
      union all
      select child.id from fs_nodes child join descendants d on child.parent_id = d.id where child.trashed = false
    ) select id from descendants)`;
  if (op === "diagnose") {
    const stats = await db.execute<{ in_scope: number; outside_scope: number; trashed: number }>(sql`
      select
        count(*) filter (where f.trashed = false and ${allowedFiles})::int as in_scope,
        count(*) filter (where f.trashed = false and not (${allowedFiles}))::int as outside_scope,
        count(*) filter (where f.trashed = true)::int as trashed
      from fs_nodes f where position(lower(${q}) in lower(f.name)) > 0`);
    const s = stats.rows[0];
    return NextResponse.json({ query: q, scope: scope || "/", inScope: Number(s?.in_scope ?? 0), outsideScope: Number(s?.outside_scope ?? 0), inTrash: Number(s?.trashed ?? 0),
      explanation: Number(s?.in_scope ?? 0) > 0 ? "Some names match here; content matches may also appear."
        : Number(s?.outside_scope ?? 0) > 0 ? "Matching names exist, but outside this folder scope."
        : Number(s?.trashed ?? 0) > 0 ? "Matching names are in Trash and excluded by default."
        : "No literal name matches in the indexed VFS. Text may appear in notes or unindexed sources." });
  }
  if (scope) {
    const res = await db.execute<{ source: string; id: string; title: string; subtitle: string; rank: number }>(sql`
      select 'file' as source, f.id::text as id, f.name as title, left(f.content, 120) as subtitle,
        (case when lower(f.name) = lower(${q}) then 100 when position(lower(${q}) in lower(f.name)) > 0 then 60 else 20 end)::float as rank
      from fs_nodes f where f.trashed = false and ${allowedFiles}
        and (position(lower(${q}) in lower(f.name)) > 0 or position(lower(${q}) in lower(f.content)) > 0)
      order by rank desc, f.name asc limit 60`);
    return NextResponse.json({ q, scope, results: res.rows, tookMs: Math.round(performance.now() - t0) });
  }
  const res = await db.execute<{ source: string; id: string; title: string; subtitle: string; rank: number }>(sql`
    select 'file' as source, id::text, name as title, left(content, 120) as subtitle,
      (case when lower(name) = lower(${q}) then 100 when position(lower(${q}) in lower(name)) > 0 then 60 else 20 end)::float as rank
      from fs_nodes where trashed = false and (position(lower(${q}) in lower(name)) > 0 or position(lower(${q}) in lower(content)) > 0)
    union all select 'note', id::text, title, left(body, 120), 50::float from notes
      where position(lower(${q}) in lower(title)) > 0 or position(lower(${q}) in lower(body)) > 0
    union all select 'feature', id, id || ' — ' || title, web_nuance, 35::float from features
      where position(lower(${q}) in lower(id)) > 0 or position(lower(${q}) in lower(title)) > 0
    union all select 'setting', key, key, value::text, 30::float from kv where scope = 'settings' and position(lower(${q}) in lower(key)) > 0
    union all select 'alert', id::text, title, body, 22::float from alerts where position(lower(${q}) in lower(title)) > 0
    union all select 'message', id::text, thread || ': ' || left(body, 60), channel, 20::float from messages where position(lower(${q}) in lower(body)) > 0
    order by rank desc limit 60`);
  return NextResponse.json({ q, scope: "/", results: res.rows, tookMs: Math.round(performance.now() - t0) });
}
