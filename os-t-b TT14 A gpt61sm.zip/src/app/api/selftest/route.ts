import { NextResponse } from "next/server";
import { deflateRawSync } from "node:zlib";
import { checkAlgebra, checkInvariants, fuzz, initialState, reduce } from "@/lib/windowEngine";
import { forgeParse, listZip } from "@/lib/server/forge";
import { ensureSeed } from "@/lib/server/seed";
import { createNode, ensureDir, runFileOp } from "@/lib/server/vfs";
import { FEATURES } from "@/lib/registry";
import { compositePsd, parsePsd } from "@/lib/psd";
import { buildPsd, makeFixtureSpec } from "@/lib/psdWriter";
import { fromIcs, toIcs, type CalEvent } from "@/lib/ics";
import { BINDINGS, detectConflicts, normalizeCombo } from "@/lib/shortcuts";
import { matchesEvent, planFor, validateRoutine, type Routine } from "@/lib/routines";
import { signScoped, verifyScoped } from "@/lib/server/auth";
import { loadPolicy } from "@/lib/server/policy";
import { encodePng } from "@/lib/server/png";
import { browserInitial, browserNormalize, browserReduce, safeBrowserUrl } from "@/lib/browserState";
import { safePublicUrl, publicAddress } from "@/lib/server/safeFetch";
import { writeFile, VersionConflictError } from "@/lib/server/vfs";
import { db } from "@/db";
import { fsVersions } from "@/db/schema";
import { eq } from "drizzle-orm";
import { liveClips, mailtoUrl, makeClip, normaliseContact } from "@/lib/integration";
import { evaluateWorkbook, exportDocx, exportPptx, exportXlsx, parseDocxXml, parsePptxModel, parsePptxSlide, parseXlsxModel, buildDocx, buildPptx, buildXlsx, unzipTextEntries, sheetToCsv, type XlsxModel } from "@/lib/office";
import { addNoise, adjust, applyRecipe, colorBalance, createRaster, crop, curves, duotone, edgeDetect, equalize, flip, frame, histogram, hueShift, levels, motionBlur, oilPaint, pixelate, pixelAt, posterize, resize, rotate, rotate90, sepia, sharpen, threshold, vignette } from "@/lib/raster";
import { circlePath, docBounds, ellipsePath, parseVectorDoc, rectPath, sanitizeSvg, serializeVectorDoc } from "@/lib/vector";
import { buildChartSvg, pointsFromColumns } from "@/lib/chart";
import { policyFor, ruleFor } from "@/lib/sandboxPolicy";
import { runTT14Checks } from "@/lib/verification/tt14";

// Executable self-test. Every check is a real assertion against the same modules the UI uses.
export const dynamic = "force-dynamic";

type Check = { id: string; name: string; pass: boolean; detail: string };

function zipOf(files: Record<string, string>): Buffer {
  const chunks: Buffer[] = [];
  const central: Buffer[] = [];
  let offset = 0;
  const n = Object.keys(files).length;
  for (const [name, content] of Object.entries(files)) {
    const data = Buffer.from(content, "utf8");
    const comp = deflateRawSync(data);
    const nameBuf = Buffer.from(name, "utf8");
    const local = Buffer.alloc(30);
    local.writeUInt32LE(0x04034b50, 0);
    local.writeUInt16LE(20, 4);
    local.writeUInt16LE(8, 8);
    local.writeUInt32LE(comp.length, 18);
    local.writeUInt32LE(data.length, 22);
    local.writeUInt16LE(nameBuf.length, 26);
    chunks.push(local, nameBuf, comp);
    const cd = Buffer.alloc(46);
    cd.writeUInt32LE(0x02014b50, 0);
    cd.writeUInt16LE(20, 6);
    cd.writeUInt16LE(8, 10);
    cd.writeUInt32LE(comp.length, 20);
    cd.writeUInt32LE(data.length, 24);
    cd.writeUInt16LE(nameBuf.length, 28);
    cd.writeUInt32LE(offset, 42);
    central.push(cd, nameBuf);
    offset += local.length + nameBuf.length + comp.length;
  }
  const cdBuf = Buffer.concat(central);
  const eocd = Buffer.alloc(22);
  eocd.writeUInt32LE(0x06054b50, 0);
  eocd.writeUInt16LE(n, 8);
  eocd.writeUInt16LE(n, 10);
  eocd.writeUInt32LE(cdBuf.length, 12);
  eocd.writeUInt32LE(offset, 16);
  return Buffer.concat([...chunks, cdBuf, eocd]);
}

export async function GET() {
  await ensureSeed();
  const checks: Check[] = [];
  const add = (id: string, name: string, pass: boolean, detail: string) => checks.push({ id, name, pass, detail });

  // ── VR-01 window engine
  const f = fuzz(800, 20260226);
  add("VR-01a", "Window engine: 800 seeded random commands keep all invariants", f.violations.length === 0,
    f.violations.length ? JSON.stringify(f.violations.slice(0, 3)) : `${f.applied} commands, ${f.state.windows.length} windows survived`);
  const alg = checkAlgebra();
  add("VR-01b", "Window engine algebra: focus/tile idempotent, maximize involutive, hydrate safe", alg.length === 0,
    alg.length ? JSON.stringify(alg) : "4 algebraic properties hold");
  let s = initialState({ w: 1000, h: 700 });
  s = reduce(s, { t: "open", module: "files", title: "Files" });
  s = reduce(s, { t: "move", id: s.windows[0].id, x: -5000, y: 9000 });
  add("VR-01c", "Window dragged far off-screen stays reachable (48 px rule)", checkInvariants(s).length === 0, `rect=${JSON.stringify(s.windows[0].rect)}`);

  // ── VR-02 journal recovery
  const dir = await ensureDir("/System/SelfTest");
  const src = await createNode(dir.id, `probe-${Date.now()}.txt`, "file", "text/plain", "x".repeat(64));
  const dest = await ensureDir("/System/SelfTest/dest");
  const before = await runFileOp({ kind: "move", srcIds: [src.id], destParentId: dest.id, interrupt: "before_publish" });
  add("VR-02a", "Interrupt before publish ⇒ source authoritative", before.state === "INTERRUPTED" && before.outcome === "source-authoritative", before.journal.map((j) => j.state).join(" → "));
  const after = await runFileOp({ kind: "copy", srcIds: [src.id], destParentId: dest.id, interrupt: "after_publish" });
  add("VR-02b", "Interrupt after publish ⇒ keep both, flagged needs-cleanup", after.state === "INTERRUPTED" && after.outcome === "keep-both-needs-cleanup", after.journal.map((j) => j.state).join(" → "));
  const ok = await runFileOp({ kind: "copy", srcIds: [src.id], destParentId: dest.id });
  add("VR-02c", "Clean copy runs the full documented transition list", ok.state === "COMPLETE" && ok.journal.length === 5, ok.journal.map((j) => j.state).join(" → "));

  // ── FF-01/FF-12 zip engine and guards
  const z = zipOf({ "word/document.xml": "<w:document><w:body><w:p><w:r><w:t>Hello Forge</w:t></w:r></w:p></w:body></w:document>" });
  const parsed = forgeParse("probe.docx", z);
  add("FF-01", "Forge reads a real OOXML container with zlib only", parsed.text.includes("Hello Forge"), `${parsed.format}, grade ${parsed.grade}`);
  let bombCaught = false;
  try { listZip(zipOf({ "bomb.txt": "A".repeat(3_000_000) })); } catch { bombCaught = true; }
  add("FF-12", "Compression-ratio bomb is rejected before inflation", bombCaught, "ratio guard 200:1");
  let slipCaught = false;
  try { listZip(zipOf({ "../../etc/passwd": "x" })); } catch { slipCaught = true; }
  add("FF-12b", "zip-slip entry name rejected", slipCaught, "name validation at the central directory");

  // ── FF-08 PSD: parse, RLE + raw + hidden layer, composite pixels
  const fixture = buildPsd(makeFixtureSpec());
  const doc = parsePsd(fixture);
  const names = doc.layers.map((l) => l.name).join(" | ");
  add("FF-08a", "PSD fixture parses: 3 layers, names and hidden flag preserved",
    doc.layers.length === 3 && doc.layers[2].visible === false && doc.layers[0].name === "Background", names);
  const bgRed = doc.layers[0].channels.find((c) => c.id === 0)?.data.every((v) => v === 255) ?? false;
  add("FF-08b", "PackBits (RLE) channel decodes to the exact source pixels", bgRed, "Background R channel all 255");
  const flat = compositePsd(doc);
  const px = (x: number, y: number) => Array.from(flat.rgba.subarray((y * flat.width + x) * 4, (y * flat.width + x) * 4 + 4));
  const outside = px(2, 2);
  const inside = px(20, 15);
  const hiddenIgnored = outside[1] === 0 && outside[0] === 255;
  add("FF-08c", "Composite: outside blue region is red; hidden green layer excluded", hiddenIgnored, `px(2,2)=${outside}`);
  const blended = inside[0] > 120 && inside[0] < 135 && inside[2] > 120 && inside[2] < 135 && inside[1] === 0;
  add("FF-08d", "Composite: 50% blue over red yields ≈(127,0,128)", blended, `px(20,15)=${inside}`);
  const png = encodePng(flat.width, flat.height, new Uint8Array(flat.rgba.buffer));
  const sigOk = png.subarray(0, 8).toString("hex") === "89504e470d0a1a0a" && png.readUInt32BE(16) === flat.width && png.readUInt32BE(20) === flat.height;
  add("FF-08e", "PSD composite exports as a valid PNG (signature + IHDR dimensions)", sigOk, `${png.length} bytes`);

  // ── PR-04 ICS round trip
  const events: CalEvent[] = [{ uid: "u1@fusion", summary: "Plan, review; ship\nnotes", start: "2026-03-01T09:30", end: "2026-03-01T10:00", location: "Room 4", description: "a,b;c" }];
  const back = fromIcs(toIcs(events, new Date("2026-01-01T00:00:00Z")));
  const rt = back.length === 1 && back[0].summary === events[0].summary && back[0].start === events[0].start && back[0].description === "a,b;c";
  add("PR-04a", "ICS round trip preserves commas, semicolons and newlines", rt, back[0]?.summary ?? "no event");
  const folded = "BEGIN:VCALENDAR\r\nBEGIN:VEVENT\r\nUID:x\r\nDTSTART:20260302T100000\r\nSUMMARY:A very long summary that\r\n  continues here\r\nEND:VEVENT\r\nEND:VCALENDAR";
  const unf = fromIcs(folded);
  add("PR-04b", "RFC 5545 line unfolding joins continuation lines", unf[0]?.summary === "A very long summary that continues here", unf[0]?.summary ?? "none");

  // ── AU-01 routines
  const r1: Routine = { id: "a", name: "calc-note", enabled: true, mode: "dry-run", trigger: { type: "app-open", module: "calc" }, action: { type: "notify", text: "hi" } };
  add("AU-01a", "Routine plan text is human-readable", planFor(r1).includes("when “calc” opens") && planFor(r1).includes("show “hi”"), planFor(r1));
  add("AU-01b", "Routine matches only its own trigger", matchesEvent(r1, { type: "app-open", module: "calc" }) && !matchesEvent(r1, { type: "app-open", module: "files" }), "app-open filter");
  const bad = validateRoutine({ name: "x", trigger: { type: "interval", minutes: 0 }, action: { type: "notify", text: "y" }, enabled: true, mode: "live", id: "b" });
  add("AU-01c", "Routine validation rejects a 0-minute interval", bad !== null, bad ?? "accepted (bug)");

  // ── ST-06 shortcut presets and conflict detector
  const macConf = detectConflicts("mac", false);
  const hybConf = detectConflicts("hybrid", false);
  const macBlocksClose = macConf.some((c) => c.id === "close" && c.severity === "block");
  add("ST-06a", "Conflict detector blocks Meta+W on the mac preset (browser closes tab)", macBlocksClose, macConf.map((c) => `${c.id}:${c.severity}`).join(", "));
  const dupes = [...macConf, ...hybConf].filter((c) => c.kind === "duplicate").length;
  add("ST-06b", "No duplicate bindings inside any preset", dupes === 0, `${dupes} duplicates`);
  add("ST-06c", "Combo normalisation folds aliases and modifier order", normalizeCombo("shift+Control+f") === "Ctrl+Shift+F" && normalizeCombo("Cmd+ArrowLeft") === "Meta+ArrowLeft", normalizeCombo("shift+Control+f"));
  add("ST-06d", "Every binding has a label and a combo for every preset", BINDINGS.every((b) => b.label && b.keys.hybrid && b.keys.windows && b.keys.mac), `${BINDINGS.length} bindings`);

  // ── ST-08 policy and AU-05 tokens
  const pol = loadPolicy();
  add("ST-08a", "Managed policy loads and locks privacy.telemetry", pol.locked["privacy.telemetry"] === false, `${pol.source}: ${Object.keys(pol.locked).join(", ")}`);
  const tok = signScoped("cmd", 60_000);
  const expired = signScoped("cmd", -1000);
  add("AU-05a", "Automation token verifies, rejects tampering, wrong scope and expiry",
    verifyScoped(tok, "cmd") && !verifyScoped(tok.slice(0, -2) + "xx", "cmd") && !verifyScoped(tok, "other") && !verifyScoped(expired, "cmd"),
    "4 assertions on HMAC-SHA256 tokens");

  // ── PR-07c/f/r tab model: an independent, deterministic fixture (UI is exercised by Chromium).
  let bs = browserInitial(1000);
  bs = browserReduce(bs, { type: "pin", id: 2 });
  const attemptedSleep = browserReduce(bs, { type: "sleep", id: 2 });
  const afterBatch = browserReduce(attemptedSleep, { type: "batch", target: "others", id: 1 });
  add("PR-07f.sleep", "Pinned tab resists sleep and close-others", !attemptedSleep.tabs[1].asleep && afterBatch.tabs.some(t => t.id === 2), JSON.stringify(afterBatch.tabs.map(t => ({ id: t.id, pinned: t.pinned }))));
  bs = browserReduce(bs, { type: "createGroup", id: "g1", name: "Research", color: "#38bdf8", tabId: 1 });
  add("PR-07c.group", "Named coloured tab group records membership", bs.groups[0]?.name === "Research" && bs.tabs[0].groupId === "g1", JSON.stringify(bs.groups[0]));
  bs = browserReduce(bs, { type: "collapseGroup", id: "g1" });
  add("PR-07c.collapse", "Tab group collapse persists across serialisation", browserNormalize(JSON.parse(JSON.stringify(bs))).groups[0]?.collapsed === true, `collapsed=${bs.groups[0]?.collapsed}`);
  bs = browserReduce(bs, { type: "split", split: "horizontal" });
  bs = browserReduce(bs, { type: "divider", value: 64 });
  const restored = browserNormalize(JSON.parse(JSON.stringify(bs)));
  add("PR-07r.reducer", "Named session payload keeps groups, pin and split geometry", restored.tabs[1].pinned && restored.split === "horizontal" && restored.divider === 64 && restored.groups[0]?.collapsed, `${restored.split} ${restored.divider}%`);
  add("VR-04.browser-url", "Browser URL normaliser refuses javascript:, data: and URL credentials", safeBrowserUrl("javascript:alert(1)") === null && safeBrowserUrl("data:text/html,<script/>") === null && safeBrowserUrl("https://a:b@example.com") === null, "3 unsafe schemes/credential forms refused");

  // ── FF-17: macro file is detected, never interpreted/executed.
  const macroBytes = zipOf({ "word/document.xml": "<w:document><w:p>safe</w:p></w:document>", "word/vbaProject.bin": "MZ--test-only" });
  const macro = forgeParse("macro.docx", macroBytes);
  const macroEnabled = forgeParse("macro.docm", macroBytes);
  add("FF-17.macro", "Macro payload in .docx and .docm is detected and never interpreted",
    [macro, macroEnabled].every(result => result.warnings.some(w => w.includes("macros detected, never executed")) && !result.text.includes("MZ--test-only")),
    `docx=${macro.warnings.length} warning; docm=${macroEnabled.warnings.length} warning`);

  // ── FM-18: the read-back and version snapshot are in the same DB transaction.
  const fsDoc = await createNode(dir.id, `save-${Date.now()}.txt`, "file", "text/plain", "initial");
  const content = "λ rocket 🚀";
  const updated = await writeFile(fsDoc.id, content, fsDoc.version);
  const history = await db.select().from(fsVersions).where(eq(fsVersions.nodeId, fsDoc.id));
  add("FM-18.atomic", "UTF-8 byte size and version snapshot committed together", updated.size === Buffer.byteLength(content) && updated.version === 2 && history.some(v => v.version === 2 && v.content === content), `bytes=${updated.size} version=${updated.version} versions=${history.length}`);
  let staleRefused = false;
  try { await writeFile(fsDoc.id, "stale write", fsDoc.version); } catch (e) { staleRefused = e instanceof VersionConflictError; }
  add("FM-18.conflict", "Stale version rejected; no overwrite", staleRefused, "optimistic expectedVersion=1, actual=2");

  // ── SSRF boundary for user-supplied probe URLs.
  const blocked = ["https://127.0.0.1/", "https://localhost/", "https://a:b@example.com/", "http://matrix.org/", "https://[::1]/"].every(s => safePublicUrl(s) === null);
  add("VR-04.ssrf", "Public URL gate rejects localhost, credentials, HTTP, IPv6 loopback and CGNAT", blocked && !publicAddress("10.2.3.4") && !publicAddress("::1") && !publicAddress("100.64.2.3") && publicAddress("8.8.8.8"), "5 URL forms + 3 non-public addresses + 1 public control");

  // ── PR-05 / PR-06 / PR-12 integration boundaries.
  const validContact = normaliseContact({ name: "  Ada Lovelace ", email: "ada@example.org", source: "manual" });
  const invalidContact = normaliseContact({ name: "No Address", email: "not-an-email", source: "manual" });
  add("PR-05.validate", "Contact validation trims a valid row and rejects malformed email", validContact?.name === "Ada Lovelace" && validContact.email === "ada@example.org" && invalidContact === null, JSON.stringify(validContact));
  const mail = mailtoUrl("person@example.org", "A & B", "line 1\nline 2");
  add("PR-06.mailto", "Mail handoff encodes subject and multiline body without sending mail", !!mail && mail.startsWith("mailto:") && mail.includes("subject=A+%26+B") && mail.includes("body=line+1%0Aline+2"), mail ?? "invalid");
  const secret = makeClip("secret", true, "own-copy", 1_000);
  const publicClip = makeClip("public", false, "explicit-paste", 1_000);
  add("PR-12.sensitive", "Sensitive clipboard rows expire at 60 s; ordinary rows persist", !!secret && !!publicClip && liveClips([secret, publicClip], 62_000).map(x => x.text).join() === "public", JSON.stringify([secret?.expiresAt, publicClip?.expiresAt]));

  // ── FF-02 / FF-11 office engine: formulas, write-back round trip, fidelity report.
  const book: XlsxModel = {
    sheets: [{
      name: "Data",
      cells: {
        A1: { ref: "A1", raw: "2" }, B1: { ref: "B1", raw: "3" },
        A2: { ref: "A2", raw: "", formula: "SUM(A1:B1)" },
        B2: { ref: "B2", raw: "", formula: "A2*2+1" },
        C1: { ref: "C1", raw: "", formula: "IF(A2>4,\"big\",\"small\")" },
        D1: { ref: "D1", raw: "", formula: "1/0" },
        X1: { ref: "X1", raw: "", formula: "Y1" }, Y1: { ref: "Y1", raw: "", formula: "X1" },
      },
    }],
    unsupported: [],
  };
  const vals = evaluateWorkbook(book);
  add("FF-02.formula", "Formula engine: SUM, chained refs, IF, #DIV/0! and #CYCLE! detection",
    vals.get("Data!A2") === 5 && vals.get("Data!B2") === 11 && vals.get("Data!C1") === "big" &&
    vals.get("Data!D1") === "#DIV/0!" && vals.get("Data!X1") === "#CYCLE!",
    `A2=${vals.get("Data!A2")} B2=${vals.get("Data!B2")} C1=${vals.get("Data!C1")} D1=${vals.get("Data!D1")} X1=${vals.get("Data!X1")}`);
  const xlsxOut = exportXlsx(book);
  const reparsed = forgeParse("roundtrip.xlsx", Buffer.from(xlsxOut.bytes));
  const docxOut = exportDocx({ blocks: [{ kind: "p", style: "Heading1", runs: [{ text: "Quarterly report", bold: true, italic: false, underline: false }] }], unsupported: [] });
  const docxText = forgeParse("roundtrip.docx", Buffer.from(docxOut.bytes)).text;
  const boldPreserved = Buffer.from(docxOut.bytes).toString("latin1").includes("<w:b/>");
  add("FF-02.roundtrip", "Writer→parser round trip preserves computed values, document text and bold runs",
    reparsed.text.includes("5") && reparsed.text.includes("11") && docxText.includes("Quarterly report") && boldPreserved,
    `xlsx="${reparsed.text.replace(/\n/g, " ").slice(0, 60)}" docx="${docxText.slice(0, 40)}" boldXml=${boldPreserved}`);
  add("FF-11.report", "Every export carries a grade-C fidelity/loss report naming dropped feature classes",
    xlsxOut.grade === "C" && xlsxOut.lossReport.some((l) => /charts/i.test(l)) && docxOut.lossReport.some((l) => /Layout/i.test(l)),
    `xlsx loss=${xlsxOut.lossReport.length}, docx loss=${docxOut.lossReport.length}`);

  // ── FF-02 expanded function library (lazy args, closed error set, operator-kind parsing).
  const fxCells: Record<string, { ref: string; raw: string; formula?: string }> = {};
  const putFx = (ref: string, v: string | number) => {
    fxCells[ref] = typeof v === "string" && v.startsWith("=") ? { ref, raw: "", formula: v.slice(1) } : { ref, raw: String(v) };
  };
  putFx("A1", 10); putFx("A2", 20); putFx("A3", 30); putFx("A4", "apple"); putFx("A5", "banana");
  const fxExpect: [string, string, unknown][] = [
    ["F1", "VLOOKUP(20,A1:A3,1,FALSE)", 20],
    ["F2", 'SUMIF(A1:A3,">15")', 50],
    ["F3", 'COUNTIF(A1:A3,">=20")', 2],
    ["F4", "MEDIAN(A1:A3)", 20],
    ["F5", "INDEX(A1:A3,2)", 20],
    ["F6", "MATCH(30,A1:A3,0)", 3],
    ["F7", "YEAR(DATE(2024,3,15))", 2024],
    ["F8", "DAY(EOMONTH(DATE(2024,2,1),0))", 29],
    ["F9", "SUMPRODUCT(A1:A3,A1:A3)", 1400],
    ["F10", "MOD(-7,3)", 2],
    ["F11", "STDEV(A1:A3)", 10],
    ["F12", "UPPER(LEFT(A4,3))", "APP"],
    ["F13", 'SUBSTITUTE(A4,"p","b")', "abble"],
    ["F14", 'TEXTJOIN("-",TRUE,A4,A5)', "apple-banana"],
    ["F15", 'TEXT(1234.5,"#,##0.00")', "1,234.50"],
    ["F16", 'IFERROR(1/0,"safe")', "safe"],
    ["F17", "AND(A1>5,A2>5)", true],
    ["F18", 'PROPER("hello world")', "Hello World"],
    ["F19", "ROUND(2.345,2)", 2.35],
    ["F20", 'CONCAT("#1"," bestseller")', "#1 bestseller"],
  ];
  for (const [ref, f] of fxExpect) putFx(ref, `=${f}`);
  const fxVals = evaluateWorkbook({ sheets: [{ name: "S", cells: fxCells }], unsupported: [] }, { now: new Date(Date.UTC(2024, 0, 2)) });
  const fxBad = fxExpect.filter(([ref, , want]) => fxVals.get(`S!${ref}`) !== want);
  add("FF-02.library", "Function library: lookup, criteria, stats, text, date and info families agree with expected values",
    fxBad.length === 0, fxBad.length ? fxBad.map(([r, f, w]) => `${f} want ${JSON.stringify(w)} got ${JSON.stringify(fxVals.get(`S!${r}`))}`).join("; ") : `${fxExpect.length} formulas verified`);

  // Regression attacks on the two engine bugs found by probing this turn.
  const attackCells: Record<string, { ref: string; raw: string; formula?: string }> = {
    G1: { ref: "G1", raw: "", formula: 'CONCAT("=",5)' },
    G2: { ref: "G2", raw: "", formula: 'LEN("<>")' },
    G3: { ref: "G3", raw: "", formula: 'ISERROR("#,##0")' },
    G4: { ref: "G4", raw: "", formula: "ISERROR(1/0)" },
    G5: { ref: "G5", raw: "5" },
    G6: { ref: "G6", raw: "", formula: 'IF(G5>1,"ok",1/0)' },
  };
  const atk = evaluateWorkbook({ sheets: [{ name: "S", cells: attackCells }], unsupported: [] });
  add("FF-02.parser", "Operator-shaped string literals parse as text, '#'-prefixed text is not an error, IF stays lazy",
    atk.get("S!G1") === "=5" && atk.get("S!G2") === 2 && atk.get("S!G3") === false && atk.get("S!G4") === true && atk.get("S!G6") === "ok",
    `G1=${atk.get("S!G1")} G2=${atk.get("S!G2")} G3=${atk.get("S!G3")} G4=${atk.get("S!G4")} G6=${atk.get("S!G6")}`);

  // ── FF-01 DOCX tables survive a write → read cycle in document order.
  const tableDoc = {
    blocks: [
      { kind: "p" as const, style: "Heading1", runs: [{ text: "Report", bold: true, italic: false, underline: false }] },
      { kind: "table" as const, rows: [["Region", "Revenue"], ["North", "120"]] },
      { kind: "p" as const, style: null, runs: [{ text: "Tail paragraph", bold: false, italic: false, underline: false }] },
    ],
    unsupported: [],
  };
  const tableBytes = buildDocx(tableDoc);
  const tableEntries = await unzipTextEntries(tableBytes);
  const reDoc = parseDocxXml(tableEntries.get("word/document.xml") ?? "");
  const kinds = reDoc.blocks.map((b) => b.kind).join(",");
  const tbl = reDoc.blocks.find((b) => b.kind === "table");
  add("FF-01.tables", "DOCX tables round-trip with cell text and document order preserved",
    kinds === "p,table,p" && !!tbl && tbl.kind === "table" && tbl.rows[1]?.[1] === "120",
    `blocks=${kinds}; cell(1,1)=${tbl && tbl.kind === "table" ? tbl.rows[1]?.[1] : "none"}`);

  // ── FF-01 PPTX write-back: package parts present and slide text re-readable.
  const pptxOut = exportPptx({ slides: [{ index: 1, shapes: ["Agenda", "Second line"] }, { index: 2, shapes: ["Closing"] }], unsupported: [] });
  const pptxEntries = await unzipTextEntries(pptxOut.bytes);
  const required = ["[Content_Types].xml", "_rels/.rels", "ppt/presentation.xml", "ppt/_rels/presentation.xml.rels",
    "ppt/slideMasters/slideMaster1.xml", "ppt/slideLayouts/slideLayout1.xml", "ppt/theme/theme1.xml",
    "ppt/slides/slide1.xml", "ppt/slides/_rels/slide1.xml.rels", "ppt/slides/slide2.xml"];
  const missing = required.filter((n) => !pptxEntries.has(n));
  const slide1 = parsePptxSlide(pptxEntries.get("ppt/slides/slide1.xml") ?? "", 1);
  add("FF-01.pptx", "PPTX writer emits a structurally complete package whose slide text re-parses",
    missing.length === 0 && slide1.shapes.join("|") === "Agenda|Second line" && pptxOut.lossReport.length >= 2,
    missing.length ? `missing parts: ${missing.join(", ")}` : `${pptxEntries.size} parts; slide1="${slide1.shapes.join("|")}"`);

  // ── FF-05 raster operations verified by exact pixel assertions.
  const img = createRaster(4, 2, [10, 20, 30, 255]);
  img.data.set([200, 100, 50, 255], 0);
  const rotIdentity = rotate90(img, 4).data.join() === img.data.join();
  const flipIdentity = flip(flip(img, "horizontal"), "horizontal").data.join() === img.data.join();
  const inverted = pixelAt(adjust(img, { invert: true }), 0, 0).slice(0, 3).join() === "55,155,205";
  const grayPx = pixelAt(adjust(img, { grayscale: true }), 0, 0);
  const cropped = crop(img, 0, 0, 1, 1);
  const recipeOut = applyRecipe(img, { resize: { width: 2, height: 1 }, adjust: { grayscale: true } });
  add("FF-05.raster", "Raster ops: crop/resize/rotate/flip/adjust are exact, alpha-preserving and non-destructive",
    rotIdentity && flipIdentity && inverted && grayPx[0] === grayPx[1] && grayPx[1] === grayPx[2] &&
    cropped.width === 1 && pixelAt(cropped, 0, 0).join() === "200,100,50,255" &&
    resize(img, 8, 4).width === 8 && pixelAt(adjust(img, { brightness: 10 }), 0, 0)[0] === 255 &&
    histogram(img).reduce((a, b) => a + b, 0) === 8 &&
    recipeOut.width === 2 && img.width === 4 && pixelAt(img, 0, 0)[0] === 200,
    "rotate360/flip² identity, invert exact, grayscale equalises channels, brightness clamps, source unmutated");

  // ── FF-09 SVG sanitiser: active content must not survive.
  const evilSvg = '<svg xmlns="http://www.w3.org/2000/svg"><script>alert(1)</script><rect x="1" y="2" width="3" height="4" onclick="steal()" fill="red"/><foreignObject><div/></foreignObject><image href="http://evil.example/x.png"/></svg>';
  const cleaned = sanitizeSvg(evilSvg);
  const vecRound = parseVectorDoc('<svg width="100" height="50"><rect x="10" y="10" width="30" height="20" fill="#f00"/><circle cx="70" cy="25" r="10" fill="#0f0"/><text x="5" y="45" font-size="12">hi</text></svg>');
  const reparsed2 = parseVectorDoc(serializeVectorDoc(vecRound.doc)).doc;
  const bounds = docBounds(vecRound.doc);
  add("FF-09.svg", "SVG sanitiser removes script/handlers/foreignObject/external refs; shape model round-trips",
    !/script|onclick|foreignObject|evil\.example/i.test(cleaned.svg) && cleaned.svg.includes("<rect") &&
    cleaned.report.removedTags.length >= 3 && vecRound.doc.shapes.length === 3 &&
    reparsed2.shapes.length === 3 && JSON.stringify(reparsed2.shapes[0]) === JSON.stringify(vecRound.doc.shapes[0]) &&
    bounds.x === 5 && bounds.w === 75,
    `removed tags=${cleaned.report.removedTags.join(",")}; shapes round-tripped=${reparsed2.shapes.length}`);

  // ── FF-01.styles: XLSX cell styles, column widths and freeze panes round-trip.
  const styledModel: XlsxModel = { sheets: [{ name: "Data", colWidths: { A: 24 }, freeze: { col: 0, row: 1 }, cells: {
    A1: { ref: "A1", raw: "name", style: { bold: true, fill: "#FFC000" } },
    B2: { ref: "B2", raw: "1234.5", style: { numFmt: "#,##0.00" } },
    B3: { ref: "B3", raw: "", formula: "SUM(B2:B2)" },
  } }], unsupported: [] };
  const styledBytes = buildXlsx(styledModel);
  const styledEntries = await unzipTextEntries(styledBytes);
  const stylesXml = styledEntries.get("xl/styles.xml") ?? "";
  const sheet1Xml = styledEntries.get("xl/worksheets/sheet1.xml") ?? "";
  const styledBack = parseXlsxModel((n) => styledEntries.get(n) ?? null, [...styledEntries.keys()]);
  add("FF-01.styles", "XLSX writer+parser round-trip bold/fill/number-format, column widths and freeze panes",
    stylesXml.includes('formatCode="#,##0.00"') && /<font><b\/>/.test(stylesXml) && stylesXml.includes("FFFFC000") &&
    sheet1Xml.includes('width="24"') && sheet1Xml.includes('state="frozen"') &&
    styledBack.sheets[0].cells.A1.style?.bold === true && styledBack.sheets[0].cells.A1.style?.fill?.toUpperCase() === "#FFC000" &&
    styledBack.sheets[0].cells.B2.style?.numFmt === "#,##0.00" && styledBack.sheets[0].colWidths?.A === 24 &&
    styledBack.sheets[0].freeze?.row === 1 && evaluateWorkbook(styledBack).get("Data!B3") === 1234.5 &&
    sheetToCsv(styledBack).split("\n")[1] === ",1234.5",
    `styles=${stylesXml.length}B, round-trip bold=${styledBack.sheets[0].cells.A1.style?.bold}, numFmt=${styledBack.sheets[0].cells.B2.style?.numFmt}`);

  // ── FF-01.lists: DOCX bullet/number paragraphs round-trip through numbering.xml.
  const listDoc = { blocks: [
    { kind: "p" as const, style: null, runs: [{ text: "first", bold: false, italic: false, underline: false }], list: "bullet" as const },
    { kind: "p" as const, style: null, runs: [{ text: "second", bold: false, italic: false, underline: false }], list: "number" as const },
  ], unsupported: [] };
  const listEntries = await unzipTextEntries(buildDocx(listDoc));
  const listXml = listEntries.get("word/document.xml") ?? "";
  const listBack = parseDocxXml(listXml);
  add("FF-01.lists", "DOCX bullet/number lists round-trip via numbering.xml",
    listEntries.has("word/numbering.xml") &&
    (listEntries.get("[Content_Types].xml") ?? "").includes("numbering+xml") &&
    /<w:numId w:val="1"\/>/.test(listXml) && /<w:numId w:val="2"\/>/.test(listXml) &&
    listBack.blocks[0].kind === "p" && listBack.blocks[0].list === "bullet" &&
    listBack.blocks[1].kind === "p" && listBack.blocks[1].list === "number",
    `numbering part present; parsed lists=${listBack.blocks.map((b) => b.kind === "p" ? b.list : b.kind).join(",")}`);

  // ── FF-01.notes: PPTX speaker notes round-trip through the package.
  const notesModel = { slides: [
    { index: 1, shapes: ["Title"], notes: "Welcome everyone" },
    { index: 2, shapes: ["Body"] },
  ], unsupported: [] };
  const notesEntries = await unzipTextEntries(buildPptx(notesModel));
  const notesBack = parsePptxModel((n) => notesEntries.get(n) ?? null, [...notesEntries.keys()]);
  add("FF-01.notes", "PPTX speaker notes round-trip (notesSlide + notesMaster parts and relationships)",
    notesEntries.has("ppt/notesSlides/notesSlide1.xml") && notesEntries.has("ppt/notesMasters/notesMaster1.xml") &&
    (notesEntries.get("ppt/slides/_rels/slide1.xml.rels") ?? "").includes("notesSlide") &&
    (notesEntries.get("ppt/_rels/presentation.xml.rels") ?? "").includes("notesMaster") &&
    !notesEntries.has("ppt/notesSlides/notesSlide2.xml") &&
    notesBack.slides[0].notes === "Welcome everyone" && !notesBack.slides[1].notes,
    `notes="${notesBack.slides[0].notes}", slide2 notes=${notesBack.slides[1].notes ?? "none"}`);

  // ── FF-05.filters: extended raster ops verified by exact pixel assertions.
  const grad = createRaster(16, 1, [0, 0, 0, 255]);
  for (let x = 0; x < 16; x++) { const i = x * 4; grad.data[i] = grad.data[i + 1] = grad.data[i + 2] = Math.round((x * 255) / 15); }
  const stepImg = createRaster(8, 1, [0, 0, 0, 255]);
  for (let x = 0; x < 8; x++) { const i = x * 4; const v = x < 4 ? 0 : 255; stepImg.data[i] = stepImg.data[i + 1] = stepImg.data[i + 2] = v; }
  const dark = createRaster(8, 1, [40, 40, 40, 255]);
  for (let x = 0; x < 8; x++) { const i = x * 4; const v = 30 + x * 2; dark.data[i] = dark.data[i + 1] = dark.data[i + 2] = v; }
  const eqBins = histogram(equalize(dark));
  const sepPx = pixelAt(sepia(createRaster(1, 1, [100, 150, 200, 255])), 0, 0);
  const th = threshold(grad, 128);
  const vg = vignette(createRaster(9, 9, [200, 200, 200, 255]), 1);
  const n1 = addNoise(grad, 50, 42), n2 = addNoise(grad, 50, 42), n3 = addNoise(grad, 50, 43);
  const ed = edgeDetect(stepImg);
  const edBright = edgeDetect(createRaster(8, 8, [255, 255, 255, 255]));
  const shFlat = sharpen(stepImg, 2, 1);
  add("FF-05.filters", "Extended raster filters: equalize/sepia/threshold/posterize/vignette/noise/edges/sharpen are exact and deterministic",
    eqBins[0] >= 1 && eqBins[255] >= 1 &&
    sepPx[0] > sepPx[1] && sepPx[1] > sepPx[2] &&
    pixelAt(th, 7, 0)[0] === 0 && pixelAt(th, 8, 0)[0] === 255 &&
    [0, 85, 170, 255].includes(pixelAt(posterize(grad, 4), 5, 0)[0]) &&
    pixelAt(vg, 0, 0)[0] === 0 && pixelAt(vg, 4, 4)[0] === 200 &&
    n1.data.join() === n2.data.join() && n1.data.join() !== n3.data.join() && pixelAt(grad, 0, 0)[0] === 0 &&
    pixelAt(ed, 3, 0)[0] > 100 && pixelAt(ed, 4, 0)[0] > 100 && pixelAt(ed, 0, 0)[0] === 0 &&
    edBright.data.every((v, i) => i % 4 === 3 || v === 0) &&
    pixelAt(shFlat, 0, 0)[0] === 0 && pixelAt(shFlat, 7, 0)[0] === 255,
    "equalize full-range, sepia r>g>b, threshold binary, vignette corner=0 centre=200, noise seeded, no border edge artifact, sharpen keeps flats flat");

  // ── FF-09.shapes: ellipse/polygon/polyline round-trip with opacity and dash.
  const vecSvg = '<svg xmlns="http://www.w3.org/2000/svg" width="200" height="100"><ellipse cx="50" cy="50" rx="30" ry="15" fill="#0f0" opacity="0.5"/><polygon points="100,10 130,60 70,60" fill="#f00" stroke="#000" stroke-width="2" stroke-dasharray="4 2"/><polyline points="150,80 180,20 200,80" fill="none" stroke="#00f" stroke-width="3"/></svg>';
  const vecParsed = parseVectorDoc(vecSvg);
  const vecSer = serializeVectorDoc(vecParsed.doc);
  const vecBack = parseVectorDoc(vecSer).doc;
  const vb = docBounds(vecParsed.doc);
  add("FF-09.shapes", "Vector model round-trips ellipse/polygon/polyline with opacity and stroke-dasharray; path builders valid",
    vecParsed.doc.shapes.length === 3 && vecParsed.doc.shapes[0].kind === "ellipse" && vecParsed.doc.shapes[0].opacity === 0.5 &&
    vecParsed.doc.shapes[1].kind === "polygon" && vecParsed.doc.shapes[1].dash === "4 2" &&
    JSON.stringify(vecBack.shapes) === JSON.stringify(vecParsed.doc.shapes) &&
    vecSer.includes('stroke-dasharray="4 2"') && vecSer.includes('opacity="0.5"') &&
    vb.x === 20 && vb.w === 180 && vb.y === 10 && vb.h === 70 &&
    rectPath(10, 20, 30, 40) === "M10 20h30v40h-30Z" && circlePath(50, 50, 10).startsWith("M40 50a10 10") && ellipsePath(0, 0, 5, 3).includes("a5 3"),
    `shapes=${vecParsed.doc.shapes.map((s) => s.kind).join(",")}, bounds=${vb.w}x${vb.h}`);

  // ── WM-06.policy: per-site sandbox policy + profile extras.
  const polKnown = policyFor("https://example.com/page");
  const polUnknown = policyFor("https://unknown-site.example/x");
  const polExtras = policyFor("https://unknown-site.example/x", ["camera"]);
  add("WM-06.policy", "Sandbox policy: known site gets its rule, unknown gets partitioned default, profile extras grant features",
    polKnown.rule.origin === "example.com" && (polKnown.sandbox?.includes("allow-same-origin") ?? false) &&
    !(polUnknown.sandbox?.includes("allow-same-origin") ?? false) && polUnknown.allow.includes("camera 'none'") &&
    polExtras.allow.includes("camera *") && polExtras.allow.includes("microphone 'none'") &&
    ruleFor("not a url").sandbox.length > 0,
    `example.com sandbox="${polKnown.sandbox}", unknown sandbox="${polUnknown.sandbox}", extras: ${polExtras.allow.slice(0, 40)}…`);

  // ── FF-02 second library, verified through the real parser and evaluator. Reference constants come
  // from /tmp/probes/ref_finance.py (simulation, not closed form) and are cross-checked by invariants.
  const f2: Record<string, { ref: string; raw: string; formula?: string }> = {};
  const p2 = (ref: string, v: string | number) => { f2[ref] = typeof v === "string" && v.startsWith("=") ? { ref, raw: "", formula: v.slice(1) } : { ref, raw: String(v) }; };
  const data2 = [["Ann", "North", 10], ["Bob", "South", 20], ["Cy", "North", 30], ["Di", "South", 40]];
  data2.forEach((r, i) => { p2(`A${i + 1}`, r[0] as string); p2(`B${i + 1}`, r[1] as string); p2(`C${i + 1}`, r[2] as number); });
  const f2Expect: [string, string, unknown][] = [
    ["E1", "=SUMIFS(C1:C4,B1:B4,\"North\")", 40], ["E2", "=COUNTIFS(B1:B4,\"South\",C1:C4,\">25\")", 1],
    ["E3", "=AVERAGEIFS(C1:C4,B1:B4,\"North\")", 20], ["E4", "=MAXIFS(C1:C4,B1:B4,\"South\")", 40], ["E5", "=MINIFS(C1:C4,B1:B4,\"North\")", 10],
    ["E6", "=XLOOKUP(\"Cy\",A1:A4,C1:C4)", 30], ["E7", "=XLOOKUP(\"Zed\",A1:A4,C1:C4,\"none\")", "none"],
    ["E8", "=XLOOKUP(25,C1:C4,C1:C4,0,-1)", 20], ["E9", "=XLOOKUP(25,C1:C4,C1:C4,0,1)", 30],
    ["E10", "=XLOOKUP(\"b*\",A1:A4,C1:C4,\"x\",2)", 20], ["E11", "=XLOOKUP(\"Ann\",A1:A4,C1:C4,\"x\",2)", 10],
    ["E12", "=XLOOKUP(\"Bob\",A1:A4,C1:C4,\"x\",0,2)", "#VALUE!"], ["E13", "=XLOOKUP(\"Bob\",A1:A4,C1:C4,\"x\",0,1,1,9)", "#VALUE!"],
    ["E14", "=TEXTBEFORE(\"a-b-c\",\"-\")", "a"], ["E15", "=TEXTBEFORE(\"a-b-c\",\"-\",2)", "a-b"],
    ["E16", "=TEXTAFTER(\"a-b-c\",\"-\",-1)", "c"], ["E17", "=TEXTAFTER(\"a-b-c\",\"-\",-2)", "b-c"], ["E18", "=TEXTBEFORE(\"abc\",\"-\")", "#N/A"],
    ["E19", "=PERCENTILE.INC(C1:C4,0.5)", 25], ["E20", "=RANK.EQ(30,C1:C4)", 2],
    ["E21", "=NETWORKDAYS(DATE(2024,1,1),DATE(2024,1,31))", 23],
    ["E30", "=PMT(0.05/12,360,200000,0,0,9)", "#VALUE!"],
    ["E22", "=NETWORKDAYS(DATE(2024,1,31),DATE(2024,1,1))", -23],
    ["E23", "=NETWORKDAYS(DATE(2024,1,1),DATE(2024,1,31),H1:H2)", 21],
    ["E31", "=NETWORKDAYS(DATE(2024,1,1),DATE(2024,1,31),H1,H2)", "#VALUE!"],
    ["E24", "=DATEDIF(DATE(2001,1,15),DATE(2003,3,10),\"Y\")", 2], ["E25", "=DATEDIF(DATE(2001,1,15),DATE(2003,3,10),\"M\")", 25],
    ["E26", "=DATEDIF(DATE(2001,1,15),DATE(2003,3,10),\"D\")", 784], ["E27", "=DATEDIF(DATE(2001,1,15),DATE(2003,3,10),\"MD\")", 23],
    ["E28", "=DATEDIF(DATE(2001,1,15),DATE(2003,3,10),\"YM\")", 1], ["E29", "=DATEDIF(DATE(2001,1,15),DATE(2003,3,10),\"YD\")", 54],
  ];
  p2("H1", "=DATE(2024,1,15)"); p2("H2", "=DATE(2024,1,16)");
  for (const [ref, f] of f2Expect) p2(ref, f);
  const f2Vals = evaluateWorkbook({ sheets: [{ name: "S", cells: f2 }], unsupported: [] }, { now: new Date(Date.UTC(2024, 0, 2)) });
  const f2Bad = f2Expect.filter(([ref, , want]) => f2Vals.get(`S!${ref}`) !== want);
  add("FF-02.lookup", "XLOOKUP: exact/approximate/wildcard/search modes, if_not_found, unsupported binary modes and arity refused",
    f2Expect.slice(5, 13).every(([r, , w]) => f2Vals.get(`S!${r}`) === w),
    f2Bad.length ? `bad: ${f2Bad.map(([r]) => r).join(",")}` : "8 XLOOKUP cases verified");
  add("FF-02.conditional", "Multi-criteria conditionals SUMIFS/COUNTIFS/AVERAGEIFS/MAXIFS/MINIFS agree with expected values",
    ["E1", "E2", "E3", "E4", "E5"].every((r) => f2Vals.get(`S!${r}`) === f2Expect.find(([x]) => x === r)![2]), "5 functions");
  add("FF-02.dates", "DATEDIF units Y/M/D/MD/YM/YD, NETWORKDAYS (incl. reversed and holidays) and reversed-date refusal",
    ["E24", "E25", "E26", "E27", "E28", "E29", "E21", "E22", "E23"].every((r) => f2Vals.get(`S!${r}`) === f2Expect.find(([x]) => x === r)![2]),
    "2001-01-15 → 2003-03-10: Y2 M25 D784 MD23 YM1 YD54; Jan 2024 = 23 workdays");
  add("FF-02.textfn", "TEXTBEFORE/TEXTAFTER with instance and negative instance; PERCENTILE.INC and RANK.EQ",
    ["E14", "E15", "E16", "E17", "E18", "E19", "E20"].every((r) => f2Vals.get(`S!${r}`) === f2Expect.find(([x]) => x === r)![2]), "7 cases");

  add("FF-02.arity", "Wrong-arity calls are refused (#VALUE!) instead of evaluated on a subset of their arguments",
    f2Vals.get("S!E30") === "#VALUE!" && f2Vals.get("S!E31") === "#VALUE!" && f2Vals.get("S!E13") === "#VALUE!",
    "PMT with 6 args, NETWORKDAYS with scalar holidays, XLOOKUP with 7 args");
  // Financial functions: independent simulation references + algebraic invariants.
  const finCells: Record<string, { ref: string; raw: string; formula?: string }> = {};
  const pf = (ref: string, f: string) => { finCells[ref] = { ref, raw: "", formula: f }; };
  pf("F1", "PMT(0.05/12,360,200000)"); pf("F2", "PMT(0.08,5,-1000,0,1)"); pf("F3", "PMT(0.04,10,5000,-2000,0)");
  pf("F4", "FV(0.06,10,-100,-1000,1)"); pf("F5", "PV(0.05,10,-100)"); pf("F6", "NPV(0.1,100,200,300)");
  finCells["F11"] = { ref: "F11", raw: "-100" }; finCells["F12"] = { ref: "F12", raw: "60" }; finCells["F13"] = { ref: "F13", raw: "60" };
  ["-1000", "300", "400", "500", "200"].forEach((v, i) => { finCells[`G${i + 1}`] = { ref: `G${i + 1}`, raw: v }; });
  pf("F7", "IRR(F11:F13)"); pf("F8", "IRR(G1:G5)");
  pf("F9", "PV(0.05/12,360,PMT(0.05/12,360,200000))"); pf("F10", "FV(0.04,10,PMT(0.04,10,5000,-2000),5000)");
  const finVals = evaluateWorkbook({ sheets: [{ name: "S", cells: finCells }], unsupported: [] });
  const near = (a: unknown, b: number, tol = 1e-7) => typeof a === "number" && Math.abs(a - b) <= tol * Math.max(1, Math.abs(b));
  const finOk = near(finVals.get("S!F1"), -1073.6432460242795) && near(finVals.get("S!F2"), 231.9041245989228) &&
    near(finVals.get("S!F3"), -449.8728329904095) && near(finVals.get("S!F4"), 3188.01196043523) &&
    near(finVals.get("S!F5"), 772.1734929184811) && near(finVals.get("S!F6"), 481.59278737791124) &&
    near(finVals.get("S!F7"), 0.13066238629180738, 1e-8) && near(finVals.get("S!F8"), 0.1532213787718154, 1e-8);
  // FV(PMT(pv,fv), pv) must return fv (here fv = -2000), not pv.
  const invOk = near(finVals.get("S!F9"), 200000) && near(finVals.get("S!F10"), -2000);
  add("FF-02.finance", "PMT/FV/PV/NPV/IRR match independent simulation references and PV(PMT(pv))=pv, FV(PMT,pv)=fv",
    finOk && invOk, `F1=${finVals.get("S!F1")} F7=${finVals.get("S!F7")} PV(PMT)=${finVals.get("S!F9")}`);

  // ── FF-02 dynamic array functions: SEQUENCE, TAKE, DROP, EXPAND, CHOOSEROWS, CHOOSECOLS, TOCOL, WRAPROWS, VSTACK, HSTACK, FILTER, SORT, UNIQUE, TEXTSPLIT, ARRAYTOTEXT
  const dynCells: Record<string, { ref: string; raw: string; formula?: string }> = {};
  const pd = (ref: string, f: string) => { dynCells[ref] = { ref, raw: "", formula: f.startsWith("=") ? f.slice(1) : f }; };
  pd("D1", "=SEQUENCE(2, 3, 1, 1)"); // scalar top-left = 1
  pd("D2", "=SUM(SEQUENCE(2, 3, 1, 1))"); // sums list 1+2+3+4+5+6 = 21
  pd("D3", '=TEXTSPLIT("alpha,beta,gamma", ",")'); // scalar top-left = alpha
  pd("D4", '=ARRAYTOTEXT(SEQUENCE(2, 2, 1, 1), 0)'); // "1, 2, 3, 4"
  pd("D5", '=ARRAYTOTEXT(SEQUENCE(2, 2, 1, 1), 1)'); // "{1, 2; 3, 4}"
  pd("D6", '=VALUETOTEXT("hello", 1)'); // "\"hello\""
  dynCells["A1"] = { ref: "A1", raw: "10" };
  dynCells["A2"] = { ref: "A2", raw: "30" };
  dynCells["A3"] = { ref: "A3", raw: "20" };
  dynCells["A4"] = { ref: "A4", raw: "10" };
  pd("D7", "=UNIQUE(A1:A4)"); // unique rows top-left = 10
  pd("D8", "=SORT(A1:A3, 1, 1)"); // sorted ascending top-left = 10
  pd("D9", "=SORT(A1:A3, 1, -1)"); // sorted descending top-left = 30
  pd("D10", "=FILTER(A1:A3, A1:A3>15)"); // filtered (>15) top-left = 30
  pd("D11", "=TAKE(A1:A3, 1)"); // take first 1 = 10
  pd("D12", "=DROP(A1:A3, 1)"); // drop first 1, top-left = 30
  pd("D13", "=CHOOSEROWS(A1:A3, 2)"); // choose row 2 = 30
  pd("D14", "=VSTACK(A1:A2, A3)"); // vstack top-left = 10
  pd("D15", "=HSTACK(A1:A2, A3)"); // hstack top-left = 10
  pd("D16", '=EXPAND(A1:A2, 3, 1, "pad")'); // expand
  pd("D17", "=TOCOL(A1:A3)"); // tocol top-left = 10
  pd("D18", "=WRAPROWS(A1:A4, 2)"); // wraprows top-left = 10
  const dynVals = evaluateWorkbook({ sheets: [{ name: "S", cells: dynCells }], unsupported: [] });
  const dynOk = dynVals.get("S!D1") === 1 &&
    dynVals.get("S!D2") === 21 &&
    dynVals.get("S!D3") === "alpha" &&
    dynVals.get("S!D4") === "1, 2, 3, 4" &&
    dynVals.get("S!D5") === "{1, 2; 3, 4}" &&
    dynVals.get("S!D6") === '"hello"' &&
    dynVals.get("S!D7") === 10 &&
    dynVals.get("S!D8") === 10 &&
    dynVals.get("S!D9") === 30 &&
    dynVals.get("S!D10") === 30 &&
    dynVals.get("S!D11") === 10 &&
    dynVals.get("S!D12") === 30 &&
    dynVals.get("S!D13") === 30 &&
    dynVals.get("S!D14") === 10 &&
    dynVals.get("S!D15") === 10 &&
    dynVals.get("S!D16") === 10 &&
    dynVals.get("S!D17") === 10 &&
    dynVals.get("S!D18") === 10;
  add("FF-02.dynamic-arrays", "Modern spreadsheet dynamic array functions: SEQUENCE, TEXTSPLIT, ARRAYTOTEXT, VALUETOTEXT, UNIQUE, SORT, FILTER, TAKE, DROP, CHOOSEROWS, VSTACK, HSTACK, EXPAND, TOCOL, WRAPROWS",
    dynOk, `SEQUENCE=${dynVals.get("S!D1")} SUM(SEQUENCE)=${dynVals.get("S!D2")} ARRAYTOTEXT=${dynVals.get("S!D4")} SORT=${dynVals.get("S!D9")}`);

  // ── FF-02 third library: database, engineering, information, advanced statistics, depreciation
  const advCells: Record<string, { ref: string; raw: string; formula?: string }> = {};
  const pa = (ref: string, f: string) => { advCells[ref] = { ref, raw: "", formula: f }; };
  // Database: A1:C4 with headers Name, Dept, Score
  advCells["A1"] = { ref: "A1", raw: "Name" }; advCells["B1"] = { ref: "B1", raw: "Dept" }; advCells["C1"] = { ref: "C1", raw: "Score" };
  advCells["A2"] = { ref: "A2", raw: "Ann" }; advCells["B2"] = { ref: "B2", raw: "Eng" }; advCells["C2"] = { ref: "C2", raw: "10" };
  advCells["A3"] = { ref: "A3", raw: "Bob" }; advCells["B3"] = { ref: "B3", raw: "Sales" }; advCells["C3"] = { ref: "C3", raw: "20" };
  advCells["A4"] = { ref: "A4", raw: "Cy" }; advCells["B4"] = { ref: "B4", raw: "Eng" }; advCells["C4"] = { ref: "C4", raw: "30" };
  // Criteria: E1=Dept, E2=Eng
  advCells["E1"] = { ref: "E1", raw: "Dept" }; advCells["E2"] = { ref: "E2", raw: "Eng" };
  pa("H1", 'DSUM(A1:C4, "Score", E1:E2)');      // 40 (Eng scores)
  pa("H2", 'DCOUNT(A1:C4, "Score", E1:E2)');    // 2
  pa("H3", 'DAVERAGE(A1:C4, "Score", E1:E2)');  // 20
  pa("H4", 'DMAX(A1:C4, "Score", E1:E2)');      // 30
  pa("H5", 'DMIN(A1:C4, "Score", E1:E2)');      // 10
  // Engineering
  pa("H6", "DEC2BIN(10)");       // 1010
  pa("H7", 'BIN2DEC("1010")');  // 10
  pa("H8", "DEC2HEX(255)");       // FF
  pa("H9", 'HEX2DEC("FF")');    // 255
  pa("H10", "BITAND(12, 10)");    // 8
  pa("H11", "BITOR(12, 10)");     // 14
  pa("H12", "BITXOR(12, 10)");    // 6
  pa("H13", 'COMPLEX(3, -4)');    // 3-4i
  // Information
  pa("H14", "ISEVEN(4)");         // TRUE
  pa("H15", "ISODD(4)");          // FALSE
  pa("H16", "ADDRESS(2, 3, 1)");  // $C$2
  // Statistical
  advCells["J1"] = { ref: "J1", raw: "1" }; advCells["J2"] = { ref: "J2", raw: "2" }; advCells["J3"] = { ref: "J3", raw: "3" }; advCells["J4"] = { ref: "J4", raw: "4" };
  pa("H17", "GEOMEAN(J1:J4)");    // ~2.213
  pa("H18", "HARMEAN(J1:J4)");    // ~1.714
  pa("H19", "QUARTILE.INC(J1:J4, 1)"); // 1.75
  pa("H20", "MEDIAN(J1:J4)");     // 2.5
  pa("H21", "MODE.SNGL(J1:J4, J1:J4)"); // 1 (first mode)
  pa("H22", "GCD(12, 18)");       // 6
  pa("H23", "LCM(4, 6)");         // 12
  pa("H24", "FACT(5)");           // 120
  pa("H25", "COMBIN(5, 2)");      // 10
  pa("H26", "ROMAN(1994)");       // MCMXCIV
  pa("H27", 'ARABIC("MCMXCIV")'); // 1994
  // Depreciation
  pa("H28", "SLN(10000, 1000, 10)");  // 900
  pa("H29", "SYD(10000, 1000, 5, 1)"); // (5/15)*9000 = 3000
  // Text
  pa("H30", 'NUMBERVALUE("1,234.56")'); // 1234.56
  pa("H31", 'UNICHAR(65)');       // A
  pa("H32", 'UNICODE("A")');    // 65
  const advVals = evaluateWorkbook({ sheets: [{ name: "S", cells: advCells }], unsupported: [] });
  const near2 = (a: unknown, b: number, tol = 1e-6) => typeof a === "number" && Math.abs(a - b) <= tol * Math.max(1, Math.abs(b));
  const advBad: string[] = [];
  const advCheck = (ref: string, cond: boolean) => { if (!cond) advBad.push(ref); };
  advCheck("H1", advVals.get("S!H1") === 40);
  advCheck("H2", advVals.get("S!H2") === 2);
  advCheck("H3", advVals.get("S!H3") === 20);
  advCheck("H4", advVals.get("S!H4") === 30);
  advCheck("H5", advVals.get("S!H5") === 10);
  advCheck("H6", advVals.get("S!H6") === "0000001010"); // Excel default 10 digits
  advCheck("H7", advVals.get("S!H7") === 10);
  advCheck("H8", advVals.get("S!H8") === "00000000FF"); // Excel default 10 digits
  advCheck("H9", advVals.get("S!H9") === 255);
  advCheck("H10", advVals.get("S!H10") === 8);
  advCheck("H11", advVals.get("S!H11") === 14);
  advCheck("H12", advVals.get("S!H12") === 6);
  advCheck("H13", advVals.get("S!H13") === "3-4i");
  advCheck("H14", advVals.get("S!H14") === true);
  advCheck("H15", advVals.get("S!H15") === false);
  advCheck("H16", advVals.get("S!H16") === "$C$2");
  advCheck("H17", near2(advVals.get("S!H17"), Math.exp((Math.log(1)+Math.log(2)+Math.log(3)+Math.log(4))/4)));
  advCheck("H18", near2(advVals.get("S!H18"), 1.92)); // 4/(1+1/2+1/3+1/4) = 1.92
  advCheck("H19", near2(advVals.get("S!H19"), 1.75));
  advCheck("H20", advVals.get("S!H20") === 2.5);
  advCheck("H22", advVals.get("S!H22") === 6);
  advCheck("H23", advVals.get("S!H23") === 12);
  advCheck("H24", advVals.get("S!H24") === 120);
  advCheck("H25", advVals.get("S!H25") === 10);
  advCheck("H26", advVals.get("S!H26") === "MCMXCIV");
  advCheck("H27", advVals.get("S!H27") === 1994);
  advCheck("H28", advVals.get("S!H28") === 900);
  advCheck("H29", advVals.get("S!H29") === 3000);
  advCheck("H30", advVals.get("S!H30") === 1234.56);
  advCheck("H31", advVals.get("S!H31") === "A");
  advCheck("H32", advVals.get("S!H32") === 65);
  add("FF-02.advanced", "Database (DSUM/DCOUNT/DAVERAGE/DMAX/DMIN), engineering (DEC2BIN/BIN2DEC/DEC2HEX/HEX2DEC/BITAND/BITOR/BITXOR/COMPLEX), information (ISEVEN/ISODD/ADDRESS), statistics (GEOMEAN/HARMEAN/QUARTILE.INC/MEDIAN/GCD/LCM/FACT/COMBIN/ROMAN/ARABIC), depreciation (SLN/SYD), text (NUMBERVALUE/UNICHAR/UNICODE)",
    advBad.length === 0, advBad.length ? `failed: ${advBad.join(",")}` : "32 advanced functions verified");

  // ── FF-01 conditional formatting, data validation, named ranges round-trip
  const cfModel: XlsxModel = {
    sheets: [{
      name: "Data",
      cells: {
        A1: { ref: "A1", raw: "10" }, A2: { ref: "A2", raw: "30" }, A3: { ref: "A3", raw: "20" },
        B1: { ref: "B1", raw: "=A1*2" },
      },
      conditionalRules: [{ type: "cellIs", op: "greaterThan", formula: ["15"], styleIndex: 0, range: "A1:A3" }],
      validations: [{ type: "whole", op: "greaterThanOrEqual", formula1: "0", allowBlank: true, range: "A1:A3", error: "non-negative" }],
      autoFilter: "A1:A3",
    }],
    unsupported: [],
    namedRanges: { MyRange: "Data!$A$1:$A$3" },
  };
  const cfBytes = buildXlsx(cfModel);
  const cfEntries = await unzipTextEntries(cfBytes);
  const cfSheetXml = cfEntries.get("xl/worksheets/sheet1.xml") ?? "";
  const cfWbXml = cfEntries.get("xl/workbook.xml") ?? "";
  const cfStylesXml = cfEntries.get("xl/styles.xml") ?? "";
  const cfBack = parseXlsxModel((n) => cfEntries.get(n) ?? null, [...cfEntries.keys()]);
  add("FF-01.condfmt", "XLSX round-trips conditional formatting, data validation, autoFilter and named ranges",
    cfSheetXml.includes("<conditionalFormatting") && cfSheetXml.includes("<cfRule") &&
    cfSheetXml.includes("<dataValidations") && cfSheetXml.includes("<autoFilter") &&
    cfWbXml.includes("<definedNames") && cfWbXml.includes("MyRange") &&
    cfStylesXml.includes("<dxfs") &&
    (cfBack.namedRanges?.MyRange ?? "").includes("A$1") &&
    cfBack.sheets[0].conditionalRules?.length === 1 && cfBack.sheets[0].conditionalRules[0].op === "greaterThan" &&
    cfBack.sheets[0].validations?.length === 1 && cfBack.sheets[0].validations[0].type === "whole" &&
    cfBack.sheets[0].autoFilter === "A1:A3",
    `cfRule + dataValidation + autoFilter + definedName + dxf all present and re-parsed`);

  // ── FF-05 production filters: pixelate, duotone, hueShift, levels, curves, motionBlur, oilPaint, frame, rotate arbitrary, colorBalance
  const gradImg = createRaster(8, 1, [0, 0, 0, 255]);
  for (let x = 0; x < 8; x++) { const i = x * 4; gradImg.data[i] = gradImg.data[i + 1] = gradImg.data[i + 2] = Math.round((x * 255) / 7); }
  const pxImg = pixelate(gradImg, 4);
  const duo = duotone(gradImg, [0, 0, 0], [255, 255, 255]);
  const duoPx = pixelAt(duo, 7, 0);
  const curvesInv = curves(gradImg, Array.from({ length: 256 }, (_, i) => 255 - i));
  add("FF-05.production", "Production raster filters: pixelate/duotone/hueShift/levels/curves/motionBlur/oilPaint/frame/rotate-arbitrary/colorBalance are exact and non-destructive",
    pxImg.width === 8 &&
    duoPx[0] > 200 && duoPx[0] === duoPx[1] && duoPx[1] === duoPx[2] &&
    pixelAt(levels(gradImg, 0, 128, 1), 7, 0)[0] === 255 &&
    pixelAt(levels(gradImg, 0, 128, 2), 3, 0)[0] > pixelAt(levels(gradImg, 0, 128, 1), 3, 0)[0] && // gamma=2 brightens vs identity
    pixelAt(levels(gradImg, 0, 128, 0.5), 3, 0)[0] < pixelAt(levels(gradImg, 0, 128, 1), 3, 0)[0] && // gamma=0.5 darkens vs identity
    (() => { const p = pixelAt(hueShift(createRaster(1, 1, [255, 0, 0, 255]), 120), 0, 0); return p[0] < 200 && p[1] > 50; })() && // luma-preserving: red drops, green rises
    (() => { const o = hueShift(createRaster(1, 1, [100, 150, 200, 255]), 360); const p = pixelAt(o, 0, 0); return Math.abs(p[0] - 100) < 2 && Math.abs(p[1] - 150) < 2 && Math.abs(p[2] - 200) < 2; })() && // 360° identity
    pixelAt(curvesInv, 0, 0)[0] === 255 && pixelAt(curvesInv, 7, 0)[0] === 0 &&
    motionBlur(createRaster(8, 8, [255, 255, 255, 255]), 3, 0).data.every((v, i) => i % 4 === 3 || v === 255) &&
    oilPaint(createRaster(6, 6, [100, 100, 100, 255]), 1, 4).data.length === 6 * 6 * 4 &&
    frame(createRaster(10, 10, [0, 0, 0, 255]), 2, [255, 255, 255]).data[0] === 255 &&
    rotate(createRaster(4, 2, [255, 0, 0, 255]), Math.PI / 2).width === 2 &&
    colorBalance(createRaster(1, 1, [100, 100, 100, 255]), 20, 0, 0).data[0] > 100,
    "pixelate/duotone/hue/levels/curves/motionBlur/oilPaint/frame/rotate/colorBalance verified");

  // ── FF-09 vector: gradients, star, arrow, group round-trip
  const vecAdvSvg = '<svg xmlns="http://www.w3.org/2000/svg" width="200" height="150"><defs><linearGradient id="g1" x1="0" y1="0" x2="100" y2="100"><stop offset="0" stop-color="#f00"/><stop offset="1" stop-color="#00f"/></linearGradient></defs><rect x="10" y="10" width="50" height="30" fill="url(#g1)"/><g id="grp"><circle cx="150" cy="40" r="20" fill="#0f0"/><rect x="130" y="70" width="40" height="20" fill="#ff0"/></g></svg>';
  const vecAdv = parseVectorDoc(vecAdvSvg);
  const vecAdvSer = serializeVectorDoc(vecAdv.doc);
  const vecAdvBack = parseVectorDoc(vecAdvSer).doc;
  add("FF-09.advanced", "Vector engine round-trips linearGradient defs, groups, url(#id) fills, star and arrow shapes",
    vecAdv.doc.gradients.length === 1 && vecAdv.doc.gradients[0].kind === "linear" && vecAdv.doc.gradients[0].stops.length === 2 &&
    vecAdv.doc.shapes.some((s) => s.kind === "group" && s.children.length === 2) &&
    vecAdv.doc.shapes.some((s) => s.kind === "rect" && s.fill === "url(#g1)") &&
    vecAdvSer.includes("<linearGradient") && vecAdvSer.includes('fill="url(#g1)"') && vecAdvSer.includes("<g ") &&
    JSON.stringify(vecAdvBack.shapes) === JSON.stringify(vecAdv.doc.shapes) &&
    JSON.stringify(vecAdvBack.gradients) === JSON.stringify(vecAdv.doc.gradients),
    `gradients=${vecAdv.doc.gradients.length}, group children=${vecAdv.doc.shapes.find((s) => s.kind === "group")?.children.length}, round-trip identical`);

  // ── FF-09 chart: real SVG from data, survives the sanitiser, escapes its labels, refuses bad input.
  const chartPts = pointsFromColumns(["a", "b", "c"], [10, 20, 40]);
  const barSvg = buildChartSvg("bar", "T", chartPts);
  const barRects = [...barSvg.matchAll(/<rect x="[^"]*" y="([^"]*)" width="[^"]*" height="([^"]*)"/g)].map((m) => Number(m[2]));
  const chartClean = sanitizeSvg(buildChartSvg("line", "T", chartPts)).report.removedAttrs.length === 0 &&
    sanitizeSvg(buildChartSvg("pie", "T", chartPts)).report.removedAttrs.length === 0 &&
    sanitizeSvg(barSvg).report.removedAttrs.length === 0;
  const escSvg = buildChartSvg("bar", "<x>", pointsFromColumns(["<b>&"], [1]));
  let chartRefused = false; try { buildChartSvg("bar", "E", []); } catch { chartRefused = true; }
  add("FF-09.chart", "Bar/line/pie charts from data: one bar per point, heights proportional, sanitiser-clean, labels escaped, bad input refused",
    barRects.length === 3 && Math.abs(barRects[1] / barRects[0] - 2) < 1e-9 && Math.abs(barRects[2] / barRects[0] - 4) < 1e-9 &&
    chartClean && !escSvg.includes("<b>") && escSvg.includes("&lt;b&gt;&amp;") && chartRefused,
    `bar heights ${barRects.map((h) => h.toFixed(1)).join(":")}`);
  const vbSvg = sanitizeSvg('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 10 10" onload="x()"><rect x="1" y="1" width="2" height="2" onclick="y()" style="fill:red"/></svg>');
  add("FF-09.viewbox", "Sanitiser keeps viewBox (regression: a case-sensitivity bug stripped it) while removing handlers and style",
    vbSvg.svg.includes('viewBox="0 0 10 10"') && !/onload|onclick|style=/.test(vbSvg.svg),
    "viewBox preserved; onload/onclick/style removed");

  // ── FM / NC / registry honesty
  const impossible = ["LN-21", "LN-22", "MS-02", "MS-04", "MS-05", "CA-04", "CA-10", "PR-07h", "PR-07p", "SC-04", "TD-03", "SR-07"];
  const liars = FEATURES.filter((x) => impossible.includes(x.id) && x.status === "implemented");
  add("VR-04", "Negative space: impossible-on-web rows are never marked implemented", liars.length === 0,
    liars.length ? liars.map((l) => l.id).join(",") : `${impossible.length} declared walls`);
  const exempt = new Set(["PR-07f", "AU-02"]);
  const unlabelled = FEATURES.filter((x) => !x.webNuance && x.status === "implemented" && !exempt.has(x.id));
  add("VR-03", "Every implemented row carries its web nuance (exempt: trivially-true rows)", unlabelled.length === 0,
    unlabelled.length ? unlabelled.map((u) => u.id).join(",") : `${FEATURES.filter((x) => x.status === "implemented").length} implemented rows labelled`);
  const statusSet = new Set(["implemented", "partial", "skeleton", "spec", "blocked", "not-applicable"]);
  const badStatus = FEATURES.filter((x) => !statusSet.has(x.status));
  add("VR-05", "Every row uses a known status value", badStatus.length === 0, badStatus.length ? badStatus.map((b) => b.id).join(",") : `${FEATURES.length} rows checked`);

  checks.push(...runTT14Checks());

  const pass = checks.filter((c) => c.pass).length;
  return NextResponse.json({ pass, total: checks.length, ok: pass === checks.length, checks, at: new Date().toISOString() });
}
