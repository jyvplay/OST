import { NextResponse } from "next/server";
import { FEATURES } from "@/lib/registry";

export const dynamic = "force-dynamic";
/** The checked-in feature register is authoritative. Runtime clients cannot mark their own code implemented. */
export async function GET() {
  const rows = [...FEATURES].sort((a, b) => a.id.localeCompare(b.id));
  const byStatus: Record<string, number> = {};
  const byTier: Record<string, number> = {};
  for (const r of rows) { byStatus[r.status] = (byStatus[r.status] ?? 0) + 1; byTier[r.tier] = (byTier[r.tier] ?? 0) + 1; }
  return NextResponse.json({ features: rows, total: rows.length, byStatus, byTier, source: "src/lib/registry.ts (read-only)" });
}
