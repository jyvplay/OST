import { NextResponse } from "next/server";
import { desc } from "drizzle-orm";
import { db } from "@/db";
import { auditLog } from "@/db/schema";

// Implements: AU-01 audit trail (every routine dry-run and run is recorded here), DP-14 observability.
export const dynamic = "force-dynamic";

export async function GET() {
  const rows = await db.select().from(auditLog).orderBy(desc(auditLog.id)).limit(100);
  return NextResponse.json({ entries: rows });
}

export async function POST(req: Request) {
  const b = (await req.json()) as { action: string; detail?: unknown };
  const [row] = await db
    .insert(auditLog)
    .values({ action: String(b.action ?? "event").slice(0, 80), detail: (b.detail ?? {}) as object })
    .returning();
  return NextResponse.json({ entry: row });
}
