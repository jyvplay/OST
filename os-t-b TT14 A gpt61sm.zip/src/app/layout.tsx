import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Fusion Shell — desktop environment PWA",
  description:
    "A web port of the Fusion Shell desktop-environment specification: window compositor, journaled file engine, terminal, format engine, casting hub, camera studio and a live feature register.",
  manifest: "/manifest.webmanifest",
  appleWebApp: { capable: true, title: "Fusion Shell", statusBarStyle: "black-translucent" },
  icons: { icon: "/icon.svg", apple: "/icon.svg" },
};

export const viewport: Viewport = {
  themeColor: "#0b1120",
  width: "device-width",
  initialScale: 1,
  viewportFit: "cover",
  userScalable: true,
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-[#0b1120] text-slate-100 antialiased">{children}</body>
    </html>
  );
}
