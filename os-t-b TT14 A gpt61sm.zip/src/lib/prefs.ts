// Implements: ST-05 (appearance), ST-07 (text scale), AX-03 (reduce motion honoured via CSS).
// Applies stored settings to the document. Scope nuance: only the dark theme exists; font scale changes
// rem-based text and controls, while window geometry stays in CSS pixels.

export function applyAppearance(s: Record<string, unknown>): void {
  if (typeof document === "undefined") return;
  const root = document.documentElement;
  const motion = String(s["appearance.motion"] ?? "system");
  const systemReduce = typeof matchMedia === "function" && matchMedia("(prefers-reduced-motion: reduce)").matches;
  root.dataset.motion = motion === "reduce" || (motion === "system" && systemReduce) ? "reduce" : "full";
  const scale = Math.min(140, Math.max(85, Number(s["appearance.fontScale"] ?? 100)));
  root.style.fontSize = `${scale}%`;
  root.style.setProperty("--accent", String(s["appearance.accent"] ?? "#5eead4"));
}
