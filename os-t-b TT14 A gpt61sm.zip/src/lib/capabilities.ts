"use client";

/**
 * §5.5 Capability Probe — the web edition.
 *
 * Nuance: this never sniffs the user agent. Every row is a *feature test* with a
 * recorded evidence string, and features ask the probe instead of assuming. Rows
 * that cannot exist on the web at all are reported as `impossible`, not `missing`,
 * so the UI can tell the difference between "grant this" and "this will never work".
 */

export type Cap = {
  id: string;
  label: string;
  state: "available" | "needs-permission" | "unavailable" | "impossible";
  evidence: string;
  featureIds: string[];
};

export type Probe = {
  at: string;
  caps: Cap[];
  env: Record<string, string | number | boolean>;
  frameBudgetMs: number | null;
};

const has = (o: unknown, k: string) => !!o && k in (o as object);

export async function runProbe(): Promise<Probe> {
  const n = navigator as Navigator & {
    deviceMemory?: number;
    connection?: { downlink?: number; effectiveType?: string; saveData?: boolean };
    getBattery?: () => Promise<{ level: number; charging: boolean }>;
    userAgentData?: { platform?: string; mobile?: boolean };
    hid?: unknown; usb?: unknown; serial?: unknown; bluetooth?: unknown;
    windowControlsOverlay?: { visible: boolean };
    wakeLock?: unknown;
  };
  const caps: Cap[] = [];
  const add = (id: string, label: string, state: Cap["state"], evidence: string, featureIds: string[]) =>
    caps.push({ id, label, state, evidence, featureIds });

  const secure = window.isSecureContext;
  add("secure-context", "Secure context", secure ? "available" : "unavailable", `isSecureContext=${secure}`, ["SH-07"]);
  add("service-worker", "Service worker / offline", "serviceWorker" in navigator ? "available" : "unavailable", `navigator.serviceWorker=${"serviceWorker" in navigator}`, ["SH-07", "RG-06"]);
  add("installed", "Installed (standalone) display mode", matchMedia("(display-mode: standalone)").matches || matchMedia("(display-mode: window-controls-overlay)").matches ? "available" : "unavailable", `display-mode=${matchMedia("(display-mode: standalone)").matches ? "standalone" : "browser"}`, ["SH-01", "ST-06"]);
  add("wco", "Window controls overlay", n.windowControlsOverlay ? (n.windowControlsOverlay.visible ? "available" : "needs-permission") : "unavailable", `wco=${!!n.windowControlsOverlay}`, ["SH-03"]);

  add("window-management", "Multi-screen placement (Window Management API)", has(window, "getScreenDetails") ? "needs-permission" : "unavailable", `getScreenDetails=${has(window, "getScreenDetails")}; screen.isExtended=${(screen as Screen & { isExtended?: boolean }).isExtended ?? "n/a"}`, ["SH-10", "WM-07", "ST-09"]);
  add("fullscreen", "Fullscreen on a chosen screen", document.fullscreenEnabled ? "available" : "unavailable", `fullscreenEnabled=${document.fullscreenEnabled}`, ["SH-10"]);
  add("wake-lock", "Screen wake lock", n.wakeLock ? "needs-permission" : "unavailable", `navigator.wakeLock=${!!n.wakeLock}`, ["SH-10"]);

  add("fs-access", "Real disk access (File System Access API)", has(window, "showDirectoryPicker") ? "needs-permission" : "unavailable", `showDirectoryPicker=${has(window, "showDirectoryPicker")}`, ["FM-01", "FM-08", "FM-18"]);
  add("opfs", "Origin private file system", has(navigator.storage ?? {}, "getDirectory") ? "available" : "unavailable", `storage.getDirectory=${has(navigator.storage ?? {}, "getDirectory")}`, ["FM-08"]);
  const est = navigator.storage?.estimate ? await navigator.storage.estimate() : null;
  add("storage-quota", "Storage quota", est ? "available" : "unavailable", est ? `${Math.round((est.usage ?? 0) / 1e6)} MB of ${Math.round((est.quota ?? 0) / 1e6)} MB` : "estimate() unavailable", ["FM-07", "RG-04"]);

  add("display-capture", "Screen capture (getDisplayMedia)", navigator.mediaDevices && "getDisplayMedia" in navigator.mediaDevices ? "needs-permission" : "unavailable", `getDisplayMedia=${!!navigator.mediaDevices && "getDisplayMedia" in navigator.mediaDevices}`, ["MD-01", "LN-13", "WM-15"]);
  add("camera", "Camera / microphone", navigator.mediaDevices && "getUserMedia" in navigator.mediaDevices ? "needs-permission" : "unavailable", `getUserMedia=${!!navigator.mediaDevices && "getUserMedia" in navigator.mediaDevices}`, ["LN-01", "MD-04"]);
  add("media-recorder", "MediaRecorder", typeof MediaRecorder !== "undefined" ? "available" : "unavailable", typeof MediaRecorder !== "undefined" ? `webm/vp9=${MediaRecorder.isTypeSupported("video/webm;codecs=vp9")}` : "absent", ["MD-01", "LN-23"]);
  add("webcodecs", "WebCodecs", has(window, "VideoEncoder") ? "available" : "unavailable", `VideoEncoder=${has(window, "VideoEncoder")}`, ["MD-08", "CA-13"]);
  add("webgpu", "WebGPU", has(navigator, "gpu") ? "available" : "unavailable", `navigator.gpu=${has(navigator, "gpu")}`, ["SR-03", "LN-01"]);

  add("remote-playback", "Remote Playback (AirPlay/Cast via the OS picker)", has(window, "RemotePlayback") || has(HTMLMediaElement.prototype, "remote") ? "available" : "unavailable", `HTMLMediaElement.remote=${has(HTMLMediaElement.prototype, "remote")}`, ["CA-01", "CA-02", "CA-05"]);
  add("presentation", "Presentation API (second screen / Cast receiver)", has(window, "PresentationRequest") ? "available" : "unavailable", `PresentationRequest=${has(window, "PresentationRequest")}`, ["CA-08", "CA-05"]);
  add("pip", "Picture-in-picture", document.pictureInPictureEnabled ? "available" : "unavailable", `pictureInPictureEnabled=${document.pictureInPictureEnabled}`, ["MD-02", "WM-11"]);
  add("doc-pip", "Document picture-in-picture", has(window, "documentPictureInPicture") ? "available" : "unavailable", `documentPictureInPicture=${has(window, "documentPictureInPicture")}`, ["WM-11", "CA-05"]);
  add("media-session", "Media Session", has(navigator, "mediaSession") ? "available" : "unavailable", `mediaSession=${has(navigator, "mediaSession")}`, ["MD-02"]);

  add("webauthn", "Passkeys (WebAuthn)", has(window, "PublicKeyCredential") ? "needs-permission" : "unavailable", `PublicKeyCredential=${has(window, "PublicKeyCredential")}`, ["SC-01"]);
  add("webcrypto", "WebCrypto (AES-GCM, PBKDF2)", crypto?.subtle ? "available" : "unavailable", `crypto.subtle=${!!crypto?.subtle}`, ["SC-01", "BK-06"]);
  add("notifications", "Notifications", typeof Notification !== "undefined" ? (Notification.permission === "granted" ? "available" : "needs-permission") : "unavailable", typeof Notification !== "undefined" ? `permission=${Notification.permission}` : "absent", ["NC-01", "NC-05"]);
  add("clipboard-read", "Clipboard read", navigator.clipboard && "readText" in navigator.clipboard ? "needs-permission" : "unavailable", `clipboard.readText=${!!navigator.clipboard && "readText" in navigator.clipboard}`, ["PR-12"]);
  add("eyedropper", "EyeDropper", has(window, "EyeDropper") ? "available" : "unavailable", `EyeDropper=${has(window, "EyeDropper")}`, ["MD-07"]);
  add("contact-picker", "Contact picker", has(navigator, "contacts") ? "needs-permission" : "unavailable", `navigator.contacts=${has(navigator, "contacts")}`, ["PR-05"]);
  add("share", "Web Share", !!navigator.share ? "available" : "unavailable", `navigator.share=${!!navigator.share}`, ["CT-01"]);
  add("hid", "WebHID", n.hid ? "needs-permission" : "unavailable", `navigator.hid=${!!n.hid}`, ["CT-06"]);
  add("usb", "WebUSB", n.usb ? "needs-permission" : "unavailable", `navigator.usb=${!!n.usb}`, ["CT-06"]);
  add("serial", "Web Serial", n.serial ? "needs-permission" : "unavailable", `navigator.serial=${!!n.serial}`, ["CT-06", "TD-03"]);
  add("bluetooth", "Web Bluetooth", n.bluetooth ? "needs-permission" : "unavailable", `navigator.bluetooth=${!!n.bluetooth}`, ["CT-06"]);
  add("battery", "Battery status", n.getBattery ? "available" : "unavailable", `navigator.getBattery=${!!n.getBattery}`, ["RG-06", "NC-03"]);
  add("net-info", "Network information", n.connection ? "available" : "unavailable", n.connection ? `downlink=${n.connection.downlink} effectiveType=${n.connection.effectiveType} saveData=${n.connection.saveData}` : "absent", ["CA-13", "RG-06"]);
  add("avif", "AVIF decode", await canDecode("image/avif") ? "available" : "unavailable", "1-pixel decode test", ["FF-06"]);
  add("heic", "HEIC decode", await canDecode("image/heic") ? "available" : "unavailable", "1-pixel decode test (expected to fail outside Safari)", ["FF-06", "FF-07"]);

  // Hard walls — declared, never faked (DP-10, VR-04).
  add("virtual-camera", "Virtual camera for other applications", "impossible", "no web API can register a capture device for other origins or native apps", ["LN-21", "LN-22"]);
  add("rcs", "RCS messaging", "impossible", "no third-party RCS API exists on any platform", ["MS-04"]);
  add("sms", "SMS send", "impossible", "the web exposes OTP reception only, never send", ["MS-05"]);
  add("dlna", "DLNA / SSDP discovery", "impossible", "no multicast sockets in a browser", ["CA-10"]);
  add("airplay-mirror", "AirPlay screen mirroring", "impossible", "no API; FairPlay client auth is unavailable to any web page", ["CA-04"]);
  add("iframe-ua", "User-agent override inside a cross-origin frame", "impossible", "the embedder cannot alter a third-party document's UA", ["PR-07h"]);
  add("request-filter", "Request filtering for third-party frames", "impossible", "service workers only see same-scope requests", ["PR-07p"]);
  add("raw-sockets", "Raw TCP/SSH", "impossible", "browsers expose no raw sockets; a user-hosted WS bridge is the only path", ["TD-03", "FM-08"]);

  const env: Record<string, string | number | boolean> = {
    cores: navigator.hardwareConcurrency ?? 0,
    deviceMemoryGB: n.deviceMemory ?? 0,
    dpr: window.devicePixelRatio,
    viewport: `${innerWidth}×${innerHeight}`,
    screen: `${screen.width}×${screen.height}`,
    colorDepth: screen.colorDepth,
    reducedMotion: matchMedia("(prefers-reduced-motion: reduce)").matches,
    contrast: matchMedia("(prefers-contrast: more)").matches,
    pointerFine: matchMedia("(pointer: fine)").matches,
    languages: navigator.languages.join(","),
    timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone,
    crossOriginIsolated: window.crossOriginIsolated,
  };

  return { at: new Date().toISOString(), caps, env, frameBudgetMs: await measureFrameBudget() };
}

async function canDecode(mime: string): Promise<boolean> {
  const data: Record<string, string> = {
    "image/avif": "data:image/avif;base64,AAAAIGZ0eXBhdmlmAAAAAGF2aWZtaWYxbWlhZk1BMUIAAADybWV0YQAAAAAAAAAoaGRscgAAAAAAAAAAcGljdAAAAAAAAAAAAAAAAGxpYmF2aWYAAAAADnBpdG0AAAAAAAEAAAAeaWxvYwAAAABEAAABAAEAAAABAAABGgAAAB0AAAAoaWluZgAAAAAAAQAAABppbmZlAgAAAAABAABhdjAxQ29sb3IAAAAAamlwcnAAAABLaXBjbwAAABRpc3BlAAAAAAAAAAEAAAABAAAAEHBpeGkAAAAAAwgICAAAAAxhdjFDgQAMAAAAABNjb2xybmNseAACAAIABoAAAAAXaXBtYQAAAAAAAAABAAEEAQKDBAAAACVtZGF0EgAKCBgABogQEDQgMgkQAAAAB8dSLfI=",
    "image/heic": "data:image/heic;base64,AAAAGGZ0eXBoZWljAAAAAG1pZjFoZWlj",
  };
  return new Promise((res) => {
    const img = new Image();
    img.onload = () => res(img.width > 0);
    img.onerror = () => res(false);
    img.src = data[mime];
    setTimeout(() => res(false), 600);
  });
}

/** SH-12: measure, do not guess. Returns the mean frame interval over ~20 frames. */
export function measureFrameBudget(): Promise<number | null> {
  return new Promise((resolve) => {
    const times: number[] = [];
    let last = performance.now();
    let n = 0;
    const tick = (t: number) => {
      times.push(t - last);
      last = t;
      if (++n < 20) requestAnimationFrame(tick);
      else resolve(Math.round((times.slice(2).reduce((a, b) => a + b, 0) / (times.length - 2)) * 100) / 100);
    };
    requestAnimationFrame(tick);
    setTimeout(() => resolve(null), 2000);
  });
}
