/**
 * FF-09 vector (SVG) engine: parse → sanitise → model → serialise.
 *
 * Security is the point of this module, not an afterthought: SVG is an active document format, so
 * anything inlined into our DOM must first lose script, event handlers, external references and
 * foreignObject. The sanitiser is pure and therefore testable without a browser.
 */
import { parseXml, serializeXml, escapeXml, escapeAttr, findAll, elChildren, type XNode } from "./office";

export const ALLOWED_TAGS = new Set([
  "svg", "g", "defs", "title", "desc", "rect", "circle", "ellipse", "line", "polyline", "polygon",
  "path", "text", "tspan", "linearGradient", "radialGradient", "stop", "clipPath", "use",
  "marker", "pattern", "mask", "symbol",
]);
export const ALLOWED_ATTRS = new Set([
  "id", "class", "d", "x", "y", "x1", "y1", "x2", "y2", "cx", "cy", "r", "rx", "ry", "width", "height",
  "points", "fill", "fill-opacity", "fill-rule", "stroke", "stroke-width", "stroke-opacity", "stroke-linecap",
  "stroke-linejoin", "stroke-dasharray", "opacity", "transform", "viewBox", "xmlns", "offset", "stop-color",
  "stop-opacity", "gradientUnits", "gradientTransform", "font-family", "font-size", "font-weight",
  "text-anchor", "dominant-baseline", "clip-path", "preserveAspectRatio",
  "stroke-dasharray", "stroke-dashoffset", "fill-rule", "transform",
  "xlink:href", "href", "marker-end", "marker-start", "marker-mid", "patternUnits", "patternContentUnits",
  "fx", "fy", "spreadMethod", "maskUnits", "maskContentUnits", "refX", "refY", "orient", "markerWidth", "markerHeight",
]);

export type SanitizeReport = { removedTags: string[]; removedAttrs: string[]; blockedUrls: string[] };

/**
 * Attribute names in SVG are case-sensitive for some entries (viewBox, gradientUnits,
 * preserveAspectRatio). The allow-list above keeps their canonical casing, and the lookup is
 * case-insensitive so the canonical name is matched while the original casing is preserved.
 * Before this fix the input was lowercased and then looked up in the camelCase set, which silently
 * stripped viewBox from every imported SVG.
 */
const ALLOWED_ATTRS_LC = new Set([...ALLOWED_ATTRS].map((a) => a.toLowerCase()));

const isDangerousUrl = (v: string) => {
  const s = v.trim().toLowerCase().replace(/\s+/g, "");
  return s.startsWith("javascript:") || s.startsWith("data:text/html") || s.startsWith("vbscript:") ||
    (s.includes("url(") && !s.includes("url(#"));
};

/** Strips scripting, event handlers, external refs and unknown elements. Returns a cleaned tree + report. */
export function sanitizeSvgNode(node: XNode, report: SanitizeReport): XNode | null {
  const tag = node.tag.includes(":") ? node.tag.split(":").pop()! : node.tag;
  if (!ALLOWED_TAGS.has(tag)) { report.removedTags.push(node.tag); return null; }
  const attrs: Record<string, string> = {};
  for (const [k, v] of Object.entries(node.attrs)) {
    const name = k.toLowerCase();
    if (name.startsWith("on") || name === "href" || name === "xlink:href" || name === "style") { report.removedAttrs.push(k); continue; }
    if (!ALLOWED_ATTRS_LC.has(name)) { report.removedAttrs.push(k); continue; }
    if (isDangerousUrl(v)) { report.blockedUrls.push(`${k}=${v.slice(0, 40)}`); continue; }
    attrs[k] = v;
  }
  const children: (XNode | string)[] = [];
  for (const c of node.children) {
    if (typeof c === "string") { children.push(c); continue; }
    const clean = sanitizeSvgNode(c, report);
    if (clean) children.push(clean);
  }
  return { tag, attrs, children };
}

export function sanitizeSvg(src: string): { svg: string; report: SanitizeReport } {
  const report: SanitizeReport = { removedTags: [], removedAttrs: [], blockedUrls: [] };
  const root = parseXml(src);
  const clean = sanitizeSvgNode(root, report);
  if (!clean) return { svg: '<svg xmlns="http://www.w3.org/2000/svg"/>', report };
  if (!clean.attrs.xmlns) clean.attrs.xmlns = "http://www.w3.org/2000/svg";
  return { svg: serializeXml(clean), report };
}

/* ───────────────── editable shape model ───────────────── */
export type GradientStop = { offset: number; color: string; opacity?: number };
export type Gradient = { id: string; kind: "linear" | "radial"; stops: GradientStop[]; x1?: number; y1?: number; x2?: number; y2?: number; cx?: number; cy?: number; r?: number };
export type VecShape =
  | { id: string; kind: "rect"; x: number; y: number; width: number; height: number; fill: string; stroke: string; strokeWidth: number; opacity?: number; dash?: string; rx?: number }
  | { id: string; kind: "circle"; cx: number; cy: number; r: number; fill: string; stroke: string; strokeWidth: number; opacity?: number; dash?: string }
  | { id: string; kind: "ellipse"; cx: number; cy: number; rx: number; ry: number; fill: string; stroke: string; strokeWidth: number; opacity?: number; dash?: string }
  | { id: string; kind: "line"; x1: number; y1: number; x2: number; y2: number; stroke: string; strokeWidth: number; opacity?: number; dash?: string; markerEnd?: string }
  | { id: string; kind: "polyline"; points: string; fill: string; stroke: string; strokeWidth: number; opacity?: number; dash?: string }
  | { id: string; kind: "polygon"; points: string; fill: string; stroke: string; strokeWidth: number; opacity?: number; dash?: string }
  | { id: string; kind: "path"; d: string; fill: string; stroke: string; strokeWidth: number; opacity?: number; dash?: string }
  | { id: string; kind: "text"; x: number; y: number; text: string; fill: string; fontSize: number; opacity?: number; fontWeight?: string }
  | { id: string; kind: "star"; cx: number; cy: number; outerR: number; innerR: number; points: number; fill: string; stroke: string; strokeWidth: number; opacity?: number }
  | { id: string; kind: "arrow"; x1: number; y1: number; x2: number; y2: number; stroke: string; strokeWidth: number; headSize?: number; opacity?: number }
  | { id: string; kind: "group"; id2?: never; children: VecShape[]; opacity?: number; transform?: string };
export type VecDoc = { width: number; height: number; shapes: VecShape[]; gradients: Gradient[] };

const num = (v: string | undefined, d = 0) => { const n = Number(v); return Number.isFinite(n) ? n : d; };

export function parseVectorDoc(src: string): { doc: VecDoc; report: SanitizeReport } {
  const { svg, report } = sanitizeSvg(src);
  const root = parseXml(svg);
  const vb = (root.attrs.viewBox ?? "").split(/[\s,]+/).map(Number);
  const width = num(root.attrs.width, vb.length === 4 ? vb[2] : 320);
  const height = num(root.attrs.height, vb.length === 4 ? vb[3] : 240);
  const shapes: VecShape[] = [];
  const gradients: Gradient[] = [];
  let seq = 0;

  // Parse gradient definitions in <defs>
  for (const g of findAll(root, "linearGradient")) {
    gradients.push({
      id: g.attrs.id || `grad${gradients.length}`,
      kind: "linear",
      x1: num(g.attrs.x1, 0), y1: num(g.attrs.y1, 0), x2: num(g.attrs.x2, 100), y2: num(g.attrs.y2, 0),
      stops: elChildren(g, "stop").map((st) => ({
        offset: num(st.attrs.offset, 0) * (st.attrs.offset?.endsWith("%") ? 0.01 : 1),
        color: st.attrs["stop-color"] ?? "#000",
        opacity: st.attrs["stop-opacity"] !== undefined ? num(st.attrs["stop-opacity"], 1) : undefined,
      })),
    });
  }
  for (const g of findAll(root, "radialGradient")) {
    gradients.push({
      id: g.attrs.id || `grad${gradients.length}`,
      kind: "radial",
      cx: num(g.attrs.cx, 50), cy: num(g.attrs.cy, 50), r: num(g.attrs.r, 50),
      stops: elChildren(g, "stop").map((st) => ({
        offset: num(st.attrs.offset, 0) * (st.attrs.offset?.endsWith("%") ? 0.01 : 1),
        color: st.attrs["stop-color"] ?? "#000",
        opacity: st.attrs["stop-opacity"] !== undefined ? num(st.attrs["stop-opacity"], 1) : undefined,
      })),
    });
  }

  const walk = (n: XNode) => {
    for (const c of n.children) {
      if (typeof c === "string") continue;
      const id = c.attrs.id || `s${++seq}`;
      let fill = c.attrs.fill ?? "#38bdf8";
      // Resolve url(#gradientId) fills
      const fillMatch = /^url\(#([^)]+)\)$/.exec(fill);
      if (fillMatch) fill = `url(#${fillMatch[1]})`;
      const stroke = c.attrs.stroke ?? "none";
      const strokeWidth = num(c.attrs["stroke-width"], 1);
      const opacity = c.attrs.opacity !== undefined ? num(c.attrs.opacity, 1) : undefined;
      const dash = c.attrs["stroke-dasharray"];
      const paint = { fill, stroke, strokeWidth, ...(opacity !== undefined ? { opacity } : {}), ...(dash ? { dash } : {}) };
      if (c.tag === "rect") shapes.push({ id, kind: "rect", x: num(c.attrs.x), y: num(c.attrs.y), width: num(c.attrs.width), height: num(c.attrs.height), rx: c.attrs.rx ? num(c.attrs.rx) : undefined, ...paint });
      else if (c.tag === "circle") shapes.push({ id, kind: "circle", cx: num(c.attrs.cx), cy: num(c.attrs.cy), r: num(c.attrs.r), ...paint });
      else if (c.tag === "ellipse") shapes.push({ id, kind: "ellipse", cx: num(c.attrs.cx), cy: num(c.attrs.cy), rx: num(c.attrs.rx), ry: num(c.attrs.ry), ...paint });
      else if (c.tag === "polyline") shapes.push({ id, kind: "polyline", points: c.attrs.points ?? "", fill: c.attrs.fill ?? "none", stroke, strokeWidth, ...(opacity !== undefined ? { opacity } : {}), ...(dash ? { dash } : {}) });
      else if (c.tag === "polygon") shapes.push({ id, kind: "polygon", points: c.attrs.points ?? "", ...paint });
      else if (c.tag === "line") shapes.push({ id, kind: "line", x1: num(c.attrs.x1), y1: num(c.attrs.y1), x2: num(c.attrs.x2), y2: num(c.attrs.y2), stroke: c.attrs.stroke ?? "#e2e8f0", strokeWidth, markerEnd: c.attrs["marker-end"], ...(opacity !== undefined ? { opacity } : {}), ...(dash ? { dash } : {}) });
      else if (c.tag === "path") shapes.push({ id, kind: "path", d: c.attrs.d ?? "", ...paint });
      else if (c.tag === "text") shapes.push({ id, kind: "text", x: num(c.attrs.x), y: num(c.attrs.y), text: c.children.filter((k): k is string => typeof k === "string").join(""), fill, fontSize: num(c.attrs["font-size"], 16), fontWeight: c.attrs["font-weight"], ...(opacity !== undefined ? { opacity } : {}) });
      else if (c.tag === "g") {
        // Group: parse children recursively and wrap
        const groupShapes: VecShape[] = [];
        const before = shapes.length;
        walk(c);
        const added = shapes.splice(before);
        groupShapes.push(...added);
        shapes.push({ id, kind: "group", children: groupShapes, opacity, transform: c.attrs.transform });
      }
      else walk(c);
    }
  };
  walk(root);
  return { doc: { width, height, shapes, gradients }, report };
}

/** Star polygon points string. */
export function starPoints(cx: number, cy: number, outerR: number, innerR: number, points: number): string {
  const pts: string[] = [];
  const total = Math.max(3, Math.floor(points)) * 2;
  for (let i = 0; i < total; i++) {
    const r = i % 2 === 0 ? outerR : innerR;
    const angle = (i * Math.PI) / points - Math.PI / 2;
    pts.push(`${(cx + r * Math.cos(angle)).toFixed(2)},${(cy + r * Math.sin(angle)).toFixed(2)}`);
  }
  return pts.join(" ");
}

/** Arrow as a path: shaft + triangular head. */
export function arrowPath(x1: number, y1: number, x2: number, y2: number, headSize = 10): string {
  const angle = Math.atan2(y2 - y1, x2 - x1);
  const hx = x2 - headSize * Math.cos(angle - Math.PI / 6);
  const hy = y2 - headSize * Math.sin(angle - Math.PI / 6);
  const hx2 = x2 - headSize * Math.cos(angle + Math.PI / 6);
  const hy2 = y2 - headSize * Math.sin(angle + Math.PI / 6);
  return `M${x1} ${y1}L${x2} ${y2}M${hx} ${hy}L${x2} ${y2}L${hx2} ${hy2}`;
}

export function serializeVectorDoc(doc: VecDoc): string {
  type Painted = Extract<VecShape, { fill: string; stroke: string; strokeWidth: number }>;
  const fx = (s: Painted) => [
    `fill="${escapeAttr(s.fill)}"`, `stroke="${escapeAttr(s.stroke)}"`, `stroke-width="${s.strokeWidth}"`,
    ...(s.opacity !== undefined ? [`opacity="${s.opacity}"`] : []),
    ...("dash" in s && s.dash ? [`stroke-dasharray="${s.dash}"`] : []),
  ].join(" ");

  // Gradient defs
  const defs = doc.gradients.map((g) => {
    const stops = g.stops.map((st) =>
      `<stop offset="${st.offset}" stop-color="${escapeAttr(st.color)}"${st.opacity !== undefined ? ` stop-opacity="${st.opacity}"` : ""}/>`).join("");
    if (g.kind === "linear") {
      return `<linearGradient id="${escapeAttr(g.id)}" x1="${g.x1 ?? 0}" y1="${g.y1 ?? 0}" x2="${g.x2 ?? 100}" y2="${g.y2 ?? 0}">${stops}</linearGradient>`;
    }
    return `<radialGradient id="${escapeAttr(g.id)}" cx="${g.cx ?? 50}" cy="${g.cy ?? 50}" r="${g.r ?? 50}">${stops}</radialGradient>`;
  }).join("");
  const defsSection = defs ? `<defs>${defs}</defs>` : "";

  const shapeXml = (s: VecShape): string => {
    switch (s.kind) {
      case "rect": return `<rect id="${escapeAttr(s.id)}" x="${s.x}" y="${s.y}" width="${s.width}" height="${s.height}"${s.rx ? ` rx="${s.rx}"` : ""} ${fx(s)}/>`;
      case "circle": return `<circle id="${escapeAttr(s.id)}" cx="${s.cx}" cy="${s.cy}" r="${s.r}" ${fx(s)}/>`;
      case "ellipse": return `<ellipse id="${escapeAttr(s.id)}" cx="${s.cx}" cy="${s.cy}" rx="${s.rx}" ry="${s.ry}" ${fx(s)}/>`;
      case "line": return `<line id="${escapeAttr(s.id)}" x1="${s.x1}" y1="${s.y1}" x2="${s.x2}" y2="${s.y2}" stroke="${escapeAttr(s.stroke)}" stroke-width="${s.strokeWidth}"${s.opacity !== undefined ? ` opacity="${s.opacity}"` : ""}${s.dash ? ` stroke-dasharray="${s.dash}"` : ""}${s.markerEnd ? ` marker-end="${escapeAttr(s.markerEnd)}"` : ""}/>`;
      case "polyline": return `<polyline id="${escapeAttr(s.id)}" points="${escapeXml(s.points)}" ${fx(s)}/>`;
      case "polygon": return `<polygon id="${escapeAttr(s.id)}" points="${escapeXml(s.points)}" ${fx(s)}/>`;
      case "path": return `<path id="${escapeAttr(s.id)}" d="${escapeXml(s.d)}" ${fx(s)}/>`;
      case "text": return `<text id="${escapeAttr(s.id)}" x="${s.x}" y="${s.y}" fill="${escapeAttr(s.fill)}" font-size="${s.fontSize}"${s.fontWeight ? ` font-weight="${escapeAttr(s.fontWeight)}"` : ""}${s.opacity !== undefined ? ` opacity="${s.opacity}"` : ""}>${escapeXml(s.text)}</text>`;
      case "star": return `<polygon id="${escapeAttr(s.id)}" points="${starPoints(s.cx, s.cy, s.outerR, s.innerR, s.points)}" ${fx(s)}/>`;
      case "arrow": return `<path id="${escapeAttr(s.id)}" d="${arrowPath(s.x1, s.y1, s.x2, s.y2, s.headSize ?? 10)}" fill="none" stroke="${escapeAttr(s.stroke)}" stroke-width="${s.strokeWidth}"${s.opacity !== undefined ? ` opacity="${s.opacity}"` : ""}/>`;
      case "group": return `<g id="${escapeAttr(s.id)}"${s.opacity !== undefined ? ` opacity="${s.opacity}"` : ""}${s.transform ? ` transform="${escapeAttr(s.transform)}"` : ""}>${s.children.map(shapeXml).join("")}</g>`;
    }
  };
  const body = doc.shapes.map(shapeXml).join("");
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${doc.width}" height="${doc.height}" viewBox="0 0 ${doc.width} ${doc.height}">${defsSection}${body}</svg>`;
}

/** Axis-aligned bounds. Path bounds use the explicit coordinates in the `d` data (no curve flattening). */
export function shapeBounds(s: VecShape): { x: number; y: number; w: number; h: number } {
  switch (s.kind) {
    case "rect": return { x: s.x, y: s.y, w: s.width, h: s.height };
    case "circle": return { x: s.cx - s.r, y: s.cy - s.r, w: s.r * 2, h: s.r * 2 };
    case "ellipse": return { x: s.cx - s.rx, y: s.cy - s.ry, w: s.rx * 2, h: s.ry * 2 };
    case "polyline": case "polygon": {
      const pts = (s.points.match(/-?\d*\.?\d+/g) ?? []).map(Number);
      if (pts.length < 2) return { x: 0, y: 0, w: 0, h: 0 };
      const xs = pts.filter((_, i) => i % 2 === 0), ys = pts.filter((_, i) => i % 2 === 1);
      const x = Math.min(...xs), y = Math.min(...ys);
      return { x, y, w: Math.max(...xs) - x, h: Math.max(...ys) - y };
    }
    case "line": return { x: Math.min(s.x1, s.x2), y: Math.min(s.y1, s.y2), w: Math.abs(s.x2 - s.x1), h: Math.abs(s.y2 - s.y1) };
    case "text": return { x: s.x, y: s.y - s.fontSize, w: s.text.length * s.fontSize * 0.6, h: s.fontSize };
    case "star": return { x: s.cx - s.outerR, y: s.cy - s.outerR, w: s.outerR * 2, h: s.outerR * 2 };
    case "arrow": return { x: Math.min(s.x1, s.x2), y: Math.min(s.y1, s.y2), w: Math.abs(s.x2 - s.x1), h: Math.abs(s.y2 - s.y1) };
    case "group": {
      if (!s.children.length) return { x: 0, y: 0, w: 0, h: 0 };
      const bs = s.children.map(shapeBounds);
      const x = Math.min(...bs.map((b) => b.x)), y = Math.min(...bs.map((b) => b.y));
      return { x, y, w: Math.max(...bs.map((b) => b.x + b.w)) - x, h: Math.max(...bs.map((b) => b.y + b.h)) - y };
    }
    case "path": {
      const nums = (s.d.match(/-?\d*\.?\d+/g) ?? []).map(Number);
      if (nums.length < 2) return { x: 0, y: 0, w: 0, h: 0 };
      const xs = nums.filter((_, i) => i % 2 === 0), ys = nums.filter((_, i) => i % 2 === 1);
      const x = Math.min(...xs), y = Math.min(...ys);
      return { x, y, w: Math.max(...xs) - x, h: Math.max(...ys) - y };
    }
  }
}
/* ───────────────── path builders (produce valid SVG path data) ───────────────── */
export const rectPath = (x: number, y: number, w: number, h: number, r = 0) =>
  r <= 0 ? `M${x} ${y}h${w}v${h}h${-w}Z` : `M${x + r} ${y}h${w - 2 * r}a${r} ${r} 0 0 1 ${r} ${r}v${h - 2 * r}a${r} ${r} 0 0 1 ${-r} ${r}h${-(w - 2 * r)}a${r} ${r} 0 0 1 ${-r} ${-r}v${-(h - 2 * r)}a${r} ${r} 0 0 1 ${r} ${-r}Z`;
export const circlePath = (cx: number, cy: number, r: number) =>
  `M${cx - r} ${cy}a${r} ${r} 0 1 0 ${2 * r} 0a${r} ${r} 0 1 0 ${-2 * r} 0Z`;
export const ellipsePath = (cx: number, cy: number, rx: number, ry: number) =>
  `M${cx - rx} ${cy}a${rx} ${ry} 0 1 0 ${2 * rx} 0a${rx} ${ry} 0 1 0 ${-2 * rx} 0Z`;

/** SVG transform attribute helpers for shape groups. */
export const translate = (x: number, y: number) => `translate(${x} ${y})`;
export const scale = (sx: number, sy = sx) => `scale(${sx} ${sy})`;
export const rotate = (deg: number, cx = 0, cy = 0) => (cx || cy ? `rotate(${deg} ${cx} ${cy})` : `rotate(${deg})`);

export function docBounds(doc: VecDoc) {
  if (!doc.shapes.length) return { x: 0, y: 0, w: doc.width, h: doc.height };
  const b = doc.shapes.map(shapeBounds);
  const x = Math.min(...b.map((v) => v.x)), y = Math.min(...b.map((v) => v.y));
  return { x, y, w: Math.max(...b.map((v) => v.x + v.w)) - x, h: Math.max(...b.map((v) => v.y + v.h)) - y };
}
