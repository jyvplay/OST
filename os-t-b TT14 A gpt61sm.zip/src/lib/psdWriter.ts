// Implements: FF-08 conformance fixture generator. TEST-ONLY: used by the self-test, the e2e suite and
// /api/fixtures/psd. It is never used to produce user files. Fixtures are validated by OUR reader;
// they have not been validated against Adobe Photoshop (declared gap).

export type LayerSpec = {
  name: string;
  left: number;
  top: number;
  width: number;
  height: number;
  rgba: Uint8Array; // width*height*4
  opacity?: number; // 0-255
  rle?: boolean;
  hidden?: boolean;
};
export type PsdSpec = { width: number; height: number; layers: LayerSpec[] };

const enc = new TextEncoder();

class BW {
  a: number[] = [];
  u8(v: number) { this.a.push(v & 0xff); }
  u16(v: number) { this.u8(v >>> 8); this.u8(v); }
  u32(v: number) { this.u16(Math.floor(v / 65536)); this.u16(v % 65536); }
  i16(v: number) { this.u16(v & 0xffff); }
  i32(v: number) { this.u32(v >>> 0); }
  bytes(b: ArrayLike<number>) { for (let i = 0; i < b.length; i++) this.a.push(b[i]); }
  str(s: string) { this.bytes(enc.encode(s)); }
  get length() { return this.a.length; }
  toU8() { return Uint8Array.from(this.a); }
}

/** PackBits encoder: runs of 2+ become repeat packets, everything else literal packets. */
function packBits(row: Uint8Array): number[] {
  const out: number[] = [];
  let i = 0;
  while (i < row.length) {
    let run = 1;
    while (i + run < row.length && run < 128 && row[i + run] === row[i]) run++;
    if (run >= 2) {
      out.push(257 - run, row[i]);
      i += run;
      continue;
    }
    const start = i;
    let lit = 0;
    while (i < row.length && lit < 128) {
      if (i + 1 < row.length && row[i] === row[i + 1]) break;
      i++;
      lit++;
    }
    out.push(lit - 1);
    for (let k = start; k < start + lit; k++) out.push(row[k]);
  }
  return out;
}

export function buildPsd(spec: PsdSpec): Uint8Array {
  const W = spec.width;
  const H = spec.height;
  const planeIds = [0, 1, 2, -1];
  const blobs: { len: number; bytes: number[] }[][] = [];

  for (const L of spec.layers) {
    const w = L.width;
    const h = L.height;
    const per: { len: number; bytes: number[] }[] = [];
    for (const id of planeIds) {
      const ch = id === -1 ? 3 : id;
      const plane = new Uint8Array(w * h);
      for (let i = 0; i < w * h; i++) plane[i] = L.rgba[i * 4 + ch];
      if (L.rle) {
        const rows = [];
        for (let y = 0; y < h; y++) rows.push(packBits(plane.subarray(y * w, y * w + w)));
        const bytes: number[] = [0, 1];
        for (const r of rows) bytes.push((r.length >> 8) & 0xff, r.length & 0xff);
        for (const r of rows) for (const b of r) bytes.push(b);
        per.push({ len: bytes.length, bytes });
      } else {
        const bytes: number[] = [0, 0];
        for (let i = 0; i < plane.length; i++) bytes.push(plane[i]);
        per.push({ len: bytes.length, bytes });
      }
    }
    blobs.push(per);
  }

  const recs = new BW();
  recs.i16(spec.layers.length);
  spec.layers.forEach((L, idx) => {
    recs.i32(L.top);
    recs.i32(L.left);
    recs.i32(L.top + L.height);
    recs.i32(L.left + L.width);
    recs.u16(planeIds.length);
    planeIds.forEach((id, c) => {
      recs.i16(id);
      recs.u32(blobs[idx][c].len);
    });
    recs.str("8BIM");
    recs.str("norm");
    recs.u8(L.opacity ?? 255);
    recs.u8(0); // clipping
    recs.u8(L.hidden ? 2 : 0); // flags: bit 1 = invisible
    recs.u8(0); // filler
    const nameBytes = enc.encode(L.name).slice(0, 255);
    const pascal = Math.ceil((1 + nameBytes.length) / 4) * 4;
    recs.u32(4 + 4 + pascal); // extra data length
    recs.u32(0); // layer mask
    recs.u32(0); // blending ranges
    recs.u8(nameBytes.length);
    recs.bytes(nameBytes);
    for (let k = 0; k < pascal - 1 - nameBytes.length; k++) recs.u8(0);
  });
  for (const per of blobs) for (const b of per) recs.bytes(b.bytes);
  if (recs.length % 2) recs.u8(0);

  const lmi = new BW();
  lmi.u32(recs.length);
  lmi.bytes(recs.a);
  lmi.u32(0); // global layer mask
  const lm = new BW();
  lm.u32(lmi.length);
  lm.bytes(lmi.a);

  const head = new BW();
  head.str("8BPS");
  head.u16(1);
  head.bytes([0, 0, 0, 0, 0, 0]);
  head.u16(3); // channels in merged image
  head.u32(H);
  head.u32(W);
  head.u16(8);
  head.u16(3); // RGB
  head.u32(0); // colour mode data
  head.u32(0); // image resources
  head.bytes(lm.a);
  head.u16(0); // merged image: raw, zeros (readers use the layers)
  for (let i = 0; i < W * H * 3; i++) head.u8(0);
  return head.toU8();
}

/** The canonical fixture used by tests: 64x48 canvas, RLE background, raw translucent blue, hidden green. */
export function makeFixtureSpec(): PsdSpec {
  const W = 64, H = 48;
  const bg = new Uint8Array(W * H * 4);
  for (let i = 0; i < W * H; i++) bg.set([255, 0, 0, 255], i * 4);
  const blue = new Uint8Array(32 * 24 * 4);
  for (let i = 0; i < 32 * 24; i++) blue.set([0, 0, 255, 128], i * 4);
  const green = new Uint8Array(W * H * 4);
  for (let i = 0; i < W * H; i++) green.set([0, 255, 0, 255], i * 4);
  return {
    width: W,
    height: H,
    layers: [
      { name: "Background", left: 0, top: 0, width: W, height: H, rgba: bg, rle: true },
      { name: "Blue 50%", left: 16, top: 12, width: 32, height: 24, rgba: blue, rle: false },
      { name: "Hidden green", left: 0, top: 0, width: W, height: H, rgba: green, rle: false, hidden: true },
    ],
  };
}
