/**
 * Spill-aware Office calculation, separate from evaluateWorkbook's legacy scalar contract.
 *
 * Counted resources: <=20,000 generated cells, <=8 recalculation passes, Excel grid dimensions.
 * Reservations are deterministic (sheet order then row-major anchor order). An occupied source cell
 * or already-reserved output blocks the ENTIRE array with #SPILL!; no partial publication occurs.
 * Empty styled cells do not obstruct. Input models/arrays are never mutated.
 *
 * This is a bounded fixed-point calculator, not Excel's dependency engine. A dependency graph which
 * does not stabilise in eight passes returns #CALC! at array anchors with a diagnostic. Table/merged
 * cell restrictions, # spill-reference syntax and Excel calc-chain interoperability are not implemented.
 */
import { evaluateWorkbook, makeRef, parseRef, type CellValue, type EvalOptions, type XlsxModel } from "./office";

export const SPILL_LIMIT = 20000;
export type Spill = { anchor: string; range: string; rows: number; cols: number; grid: CellValue[][] };
export type SpillIssue = { code: "#SPILL!" | "#CALC!"; reason: string; blockers: string[] };
export type Calculation = {
  values: Map<string, CellValue>;
  owners: Map<string, string>;
  spills: Map<string, Spill>;
  issues: Map<string, SpillIssue>;
  passes: number;
  stable: boolean;
};

export function calculateWorkbook(model: XlsxModel, opts: Pick<EvalOptions, "now" | "random"> = {}): Calculation {
  const now = opts.now ?? new Date();
  const names = new Map(model.sheets.map((s, i) => [s.name, i]));
  let virtual = new Map<string, CellValue>();
  let owners = new Map<string, string>();
  let spills = new Map<string, Spill>();
  let issues = new Map<string, SpillIssue>();
  let signature = "";
  let stable = false;
  let passes = 0;
  for (let pass = 1; pass <= 8; pass++) {
    passes = pass;
    const arrays = new Map<string, CellValue[][]>();
    evaluateWorkbook(model, { ...opts, now, virtualCells: virtual, captureArrays: arrays });
    const planned = new Map<string, CellValue>();
    const owned = new Map<string, string>();
    const nextSpills = new Map<string, Spill>();
    const errors = new Map<string, SpillIssue>();
    const entries = [...arrays].sort(([a], [b]) => {
      const [as, ar] = splitKey(a), [bs, br] = splitKey(b);
      const pa = parseRef(ar)!, pb = parseRef(br)!;
      return (names.get(as)! - names.get(bs)!) || pa.row - pb.row || pa.col - pb.col;
    });
    let generated = 0;
    for (const [anchor, grid] of entries) {
      const [sheetName, ref] = splitKey(anchor);
      const at = parseRef(ref);
      const sh = model.sheets.find((s) => s.name === sheetName);
      if (!at || !sh) continue;
      const rows = grid.length, cols = grid[0].length;
      if (generated + rows * cols > SPILL_LIMIT || at.row + rows - 1 > 1048576 || at.col + cols - 1 > 16384) {
        errors.set(anchor, { code: "#SPILL!", reason: "Output exceeds the grid or 20,000 generated-cell budget", blockers: [] });
        continue;
      }
      const blockers: string[] = [];
      for (let r = 0; r < rows; r++) for (let c = 0; c < cols; c++) {
        const target = makeRef(at.col + c, at.row + r);
        const key = `${sheetName}!${target}`;
        const original = sh.cells[target];
        if (key !== anchor && ((original && (original.formula || original.raw !== "")) || owned.has(key))) blockers.push(target);
      }
      if (blockers.length) {
        errors.set(anchor, { code: "#SPILL!", reason: "Output range contains source data or another spill", blockers: blockers.slice(0, 16) });
        continue;
      }
      generated += rows * cols;
      for (let r = 0; r < rows; r++) for (let c = 0; c < cols; c++) {
        const key = `${sheetName}!${makeRef(at.col + c, at.row + r)}`;
        planned.set(key, grid[r][c]);
        owned.set(key, anchor);
      }
      nextSpills.set(anchor, { anchor, range: `${ref}:${makeRef(at.col + cols - 1, at.row + rows - 1)}`, rows, cols, grid });
    }
    const nextSignature = JSON.stringify([[...planned], [...errors]]);
    virtual = planned; owners = owned; spills = nextSpills; issues = errors;
    if (nextSignature === signature) { stable = true; break; }
    signature = nextSignature;
  }
  if (!stable) {
    for (const anchor of spills.keys()) issues.set(anchor, { code: "#CALC!", reason: "Array dependencies did not stabilise in eight passes", blockers: [] });
    virtual = new Map(); owners = new Map(); spills = new Map();
  }
  const forced = new Map<string, CellValue>([...issues].map(([key, issue]) => [key, issue.code]));
  const values = evaluateWorkbook(model, { ...opts, now, virtualCells: virtual, forcedCells: forced });
  // Publish only absent/empty cells. Formula anchors keep the recomputed top-left value or error.
  for (const [key, value] of virtual) {
    const [sheetName, ref] = splitKey(key);
    const source = model.sheets.find((s) => s.name === sheetName)?.cells[ref];
    if (!source || (!source.formula && source.raw === "")) values.set(key, value);
  }
  return { values, owners, spills, issues, passes, stable };
}

export function splitKey(key: string): [string, string] {
  const i = key.lastIndexOf("!");
  return [key.slice(0, i), key.slice(i + 1)];
}

/** Values-only snapshot: explicit lossy alternative for interoperable export without dynamic-array metadata.
 * Formulas are replaced by computed values, including spill children; originals are not changed. */
export function valuesSnapshot(model: XlsxModel, result = calculateWorkbook(model)): XlsxModel {
  return {
    sheets: model.sheets.map((s) => {
      const cells = Object.fromEntries(Object.entries(s.cells).map(([ref, c]) => [ref, { ref, raw: String(result.values.get(`${s.name}!${ref}`) ?? ""), style: c.style }]));
      for (const [key, value] of result.values) {
        const [name, ref] = splitKey(key);
        if (name === s.name && value !== null) cells[ref] = { ref, raw: typeof value === "boolean" ? (value ? "TRUE" : "FALSE") : String(value), style: cells[ref]?.style };
      }
      return { name: s.name, cells, colWidths: s.colWidths, freeze: s.freeze };
    }),
    unsupported: ["Values-only snapshot: all formulas and rules removed; generated cells materialised"],
  };
}

/** Public API input guard; rejects malformed refs, duplicate sheets, oversized models and formulas. */
export function validateWorkbookInput(value: unknown): XlsxModel {
  if (!value || typeof value !== "object") throw new Error("Workbook must be an object");
  const m = value as XlsxModel;
  if (!Array.isArray(m.sheets) || !m.sheets.length || m.sheets.length > 8) throw new Error("Use 1–8 sheets");
  let count = 0;
  const seen = new Set<string>();
  for (const s of m.sheets) {
    if (typeof s.name !== "string" || !s.name || s.name.length > 31 || /[!\[\]:*?\\/]/.test(s.name) || seen.has(s.name.toLowerCase())) throw new Error("Invalid or duplicate sheet name");
    seen.add(s.name.toLowerCase());
    if (!s.cells || typeof s.cells !== "object" || Array.isArray(s.cells)) throw new Error("Cells must be a ref-keyed object");
    for (const [ref, c] of Object.entries(s.cells)) {
      const p = parseRef(ref);
      if (!p || p.row < 1 || p.col < 1 || p.row > 1048576 || p.col > 16384 || c.ref !== ref || typeof c.raw !== "string" || c.raw.length > 20000 || (c.formula !== undefined && (typeof c.formula !== "string" || c.formula.length > 4096))) throw new Error(`Invalid cell ${ref}`);
      if (++count > 1000) throw new Error("Input capped at 1,000 source cells");
    }
  }
  return { ...m, unsupported: Array.isArray(m.unsupported) ? m.unsupported : [] };
}
