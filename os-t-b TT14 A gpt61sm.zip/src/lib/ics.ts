// Implements: PR-04 (calendar with ICS import/export).
// Scope nuance: floating local times only. TZID and trailing-Z UTC values are read as their wall-clock
// digits (no timezone conversion). Recurrence (RRULE) and alarms (VALARM) are not interpreted.

export type CalEvent = {
  uid: string;
  summary: string;
  start: string; // "YYYY-MM-DDTHH:mm" (floating)
  end: string;
  location: string;
  description: string;
};

const escText = (s: string) =>
  s.replace(/\\/g, "\\\\").replace(/;/g, "\\;").replace(/,/g, "\\,").replace(/\r?\n/g, "\\n");
const unescText = (s: string) => s.replace(/\\n/gi, "\n").replace(/\\([,;\\])/g, "$1");

/** "2026-01-15T09:30" -> "20260115T093000" */
export function isoToIcs(iso: string): string {
  const m = /^(\d{4})-(\d{2})-(\d{2})(?:T(\d{2}):(\d{2})(?::(\d{2}))?)?/.exec(iso);
  if (!m) throw new Error(`bad date: ${iso}`);
  return `${m[1]}${m[2]}${m[3]}T${m[4] ?? "00"}${m[5] ?? "00"}${m[6] ?? "00"}`;
}

/** "20260115T093000" | "20260115" | "20260115T093000Z" -> "2026-01-15T09:30" */
export function icsToIso(v: string): string {
  const m = /^(\d{4})(\d{2})(\d{2})(?:T(\d{2})(\d{2})(\d{2})?)?/.exec(v.trim());
  if (!m) throw new Error(`bad ics date: ${v}`);
  return `${m[1]}-${m[2]}-${m[3]}T${m[4] ?? "00"}:${m[5] ?? "00"}`;
}

export function toIcs(events: CalEvent[], stamp: Date = new Date()): string {
  const dtstamp = stamp.toISOString().replace(/[-:]/g, "").replace(/\.\d{3}/, "");
  const out = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//Fusion Shell//Calendar 1.0//EN", "CALSCALE:GREGORIAN"];
  for (const e of events) {
    out.push(
      "BEGIN:VEVENT",
      `UID:${e.uid}`,
      `DTSTAMP:${dtstamp}`,
      `DTSTART:${isoToIcs(e.start)}`,
      `DTEND:${isoToIcs(e.end || e.start)}`,
      `SUMMARY:${escText(e.summary)}`,
    );
    if (e.location) out.push(`LOCATION:${escText(e.location)}`);
    if (e.description) out.push(`DESCRIPTION:${escText(e.description)}`);
    out.push("END:VEVENT");
  }
  out.push("END:VCALENDAR");
  return out.join("\r\n") + "\r\n";
}

export function fromIcs(text: string): CalEvent[] {
  // RFC 5545 unfolding: a CRLF followed by SPACE or TAB continues the previous line.
  const lines = text.replace(/\r?\n[ \t]/g, "").split(/\r?\n/);
  const events: CalEvent[] = [];
  let cur: Record<string, string> | null = null;
  for (const line of lines) {
    if (!line) continue;
    if (line === "BEGIN:VEVENT") {
      cur = {};
      continue;
    }
    if (line === "END:VEVENT") {
      if (cur && cur.DTSTART) {
        const start = icsToIso(cur.DTSTART);
        events.push({
          uid: cur.UID || `imp-${events.length}-${Math.random().toString(36).slice(2, 8)}`,
          summary: unescText(cur.SUMMARY ?? "(no title)"),
          start,
          end: cur.DTEND ? icsToIso(cur.DTEND) : start,
          location: unescText(cur.LOCATION ?? ""),
          description: unescText(cur.DESCRIPTION ?? ""),
        });
      }
      cur = null;
      continue;
    }
    if (!cur) continue;
    const colon = line.indexOf(":");
    if (colon < 0) continue;
    const key = line.slice(0, colon).split(";")[0].toUpperCase();
    cur[key] = line.slice(colon + 1);
  }
  return events;
}
