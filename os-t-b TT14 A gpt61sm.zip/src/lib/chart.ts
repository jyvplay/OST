/**
 * FF-09 chart rendering: bar, line and pie charts from a label/value series, emitted as SVG.
 *
 * The output uses only elements the vector sanitiser allow-lists (svg, rect, circle, path, polyline,
 * text), so a chart survives sanitizeSvg unchanged and is safe to inline. Labels and titles are
 * XML-escaped; non-finite values are refused rather than drawn as zero.
 *
 * Scope: linear value axis, one series, no legend for bars/lines, pie slices sized by share of the
 * non-negative total. Log scales, stacked/clustered series, data labels with number formats, and
 * trendlines are not implemented.
 */
import { escapeXml } from "./office";

export type ChartKind = "bar" | "line" | "pie";
export type ChartPoint = { label: string; value: number };

const PALETTE = ["#38bdf8", "#f472b6", "#34d399", "#fbbf24", "#a78bfa", "#fb7185", "#22d3ee", "#f97316"];

/** Keeps only rows whose value is a finite number (text and blanks are skipped, like Excel charts). */
export function pointsFromColumns(labels: unknown[], values: unknown[]): ChartPoint[] {
  const out: ChartPoint[] = [];
  const n = Math.min(labels.length, values.length);
  for (let i = 0; i < n; i++) {
    const v = values[i];
    if (typeof v === "number" && Number.isFinite(v)) out.push({ label: String(labels[i] ?? ""), value: v });
  }
  return out;
}

const fmt = (n: number) => (Math.abs(n) >= 100 ? Math.round(n).toString() : (Math.round(n * 100) / 100).toString());

export function buildChartSvg(kind: ChartKind, title: string, points: ChartPoint[], width = 480, height = 300): string {
  if (points.length === 0) throw new Error("a chart needs at least one numeric point");
  if (points.some((p) => !Number.isFinite(p.value))) throw new Error("non-finite values cannot be charted");
  const head = `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}">`;
  const titleEl = `<text x="${width / 2}" y="20" font-size="14" text-anchor="middle" fill="#e2e8f0">${escapeXml(title)}</text>`;
  if (kind === "pie") return head + titleEl + piePart(points, width, height) + "</svg>";

  const left = 48, right = 16, top = 36, bottom = 48;
  const pw = width - left - right, ph = height - top - bottom;
  const vals = points.map((p) => p.value);
  const lo = Math.min(0, ...vals), hi = Math.max(0, ...vals);
  const span = hi - lo || 1;
  const yOf = (v: number) => top + ((hi - v) / span) * ph;
  const zeroY = yOf(0);
  const slot = pw / points.length;
  const axis = `<polyline points="${left},${top} ${left},${top + ph} ${left + pw},${top + ph}" fill="none" stroke="#64748b" stroke-width="1"/>` +
    `<polyline points="${left},${zeroY} ${left + pw},${zeroY}" fill="none" stroke="#475569" stroke-width="1"/>`;
  const labels = points.map((p, i) => {
    const cx = left + i * slot + slot / 2;
    return `<text x="${cx}" y="${top + ph + 16}" font-size="10" text-anchor="middle" fill="#cbd5e1">${escapeXml(p.label.slice(0, 14))}</text>`;
  }).join("");
  let body = "";
  if (kind === "bar") {
    body = points.map((p, i) => {
      const barW = slot * 0.6;
      const x = left + i * slot + (slot - barW) / 2;
      const y = Math.min(yOf(p.value), zeroY);
      const h = Math.abs(yOf(p.value) - zeroY);
      return `<rect x="${x}" y="${y}" width="${barW}" height="${h}" fill="${PALETTE[i % PALETTE.length]}"/>` +
        `<text x="${x + barW / 2}" y="${p.value >= 0 ? y - 4 : y + h + 12}" font-size="10" text-anchor="middle" fill="#e2e8f0">${escapeXml(fmt(p.value))}</text>`;
    }).join("");
  } else {
    const pts = points.map((p, i) => `${left + i * slot + slot / 2},${yOf(p.value)}`);
    body = `<polyline points="${pts.join(" ")}" fill="none" stroke="#38bdf8" stroke-width="2" stroke-linejoin="round"/>` +
      points.map((p, i) => {
        const [x, y] = pts[i].split(",").map(Number);
        return `<circle cx="${x}" cy="${y}" r="3" fill="${PALETTE[0]}"/>`;
      }).join("");
  }
  return head + titleEl + axis + body + labels + "</svg>";
}

function piePart(points: ChartPoint[], width: number, height: number): string {
  const parts = points.filter((p) => p.value >= 0);
  const total = parts.reduce((a, p) => a + p.value, 0);
  if (total <= 0) throw new Error("a pie chart needs a positive total");
  const cx = 150, cy = height / 2 + 6, r = Math.min(height / 2 - 36, 110);
  let angle = -Math.PI / 2;
  const slices: string[] = [];
  const legend: string[] = [];
  parts.forEach((p, i) => {
    const frac = p.value / total;
    const color = PALETTE[i % PALETTE.length];
    if (frac >= 0.9999) {
      slices.push(`<circle cx="${cx}" cy="${cy}" r="${r}" fill="${color}"/>`);
    } else {
      const a2 = angle + frac * 2 * Math.PI;
      const x1 = cx + r * Math.cos(angle), y1 = cy + r * Math.sin(angle);
      const x2 = cx + r * Math.cos(a2), y2 = cy + r * Math.sin(a2);
      const large = frac > 0.5 ? 1 : 0;
      slices.push(`<path d="M${cx} ${cy}L${x1} ${y1}A${r} ${r} 0 ${large} 1 ${x2} ${y2}Z" fill="${color}"/>`);
      angle = a2;
    }
    const ly = 60 + i * 20;
    legend.push(`<rect x="${width - 170}" y="${ly - 9}" width="10" height="10" fill="${color}"/>` +
      `<text x="${width - 154}" y="${ly}" font-size="11" fill="#e2e8f0">${escapeXml(`${p.label} (${Math.round((frac) * 1000) / 10}%)`)}</text>`);
  });
  return slices.join("") + legend.join("");
}
