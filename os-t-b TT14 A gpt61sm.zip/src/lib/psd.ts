// Implements: FF-08 (PSD parse + composite, grade C).
// Pure TypeScript (no Node APIs): runs in the browser or on the server.
// Scope: version-1 (PSD, not PSB) 8-bit files. Compression 0 (raw) and 1 (PackBits) are decoded.
// Compositing uses Normal blend for every layer (other blend modes are composited as Normal, declared in
// lossReport). Adjustment layers, smart objects, text engine data, layer effects, zip compression and
// 16/32-bit depth are NOT rendered.

export type PsdChannel = { id: number; data: Uint8Array };
export type PsdLayer = {
  name: string;
  top: number;
  left: number;
  bottom: number;
  right: number;
  opacity: number;
  visible: boolean;
  blend: string;
  channels: PsdChannel[];
};
export type PsdDoc = {
  width: number;
  height: number;
  channels: number;
  depth: number;
  mode: number;
  layers: PsdLayer[];
  merged: PsdChannel[] | null;
  warnings: string[];
};

const MAX_PIXELS = 40_000_000;

function ascii(u8: Uint8Array, o: number, n: number): string {
  let s = "";
  for (let i = 0; i < n; i++) s += String.fromCharCode(u8[o + i]);
  return s;
}

/** PackBits decode of src[s..e) into out[o..oEnd). Returns the read position. */
function unpackBits(src: Uint8Array, s: number, e: number, out: Uint8Array, o: number, oEnd: number): number {
  let i = s;
  let k = o;
  while (i < e && k < oEnd) {
    const n = (src[i++] << 24) >> 24; // signed byte
    if (n >= 0) {
      for (let j = 0; j <= n && i < e && k < oEnd; j++) out[k++] = src[i++];
    } else if (n !== -128) {
      const v = src[i++];
      for (let j = 0; j < 1 - n && k < oEnd; j++) out[k++] = v;
    }
  }
  return i;
}

/** RLE planes: row-length table (nPlanes*h u16, big-endian) followed by PackBits rows. */
function decodeRle(payload: Uint8Array, nPlanes: number, w: number, h: number): Uint8Array[] {
  const dv = new DataView(payload.buffer, payload.byteOffset, payload.byteLength);
  let p = nPlanes * h * 2;
  const planes: Uint8Array[] = [];
  for (let c = 0; c < nPlanes; c++) {
    const out = new Uint8Array(w * h);
    for (let y = 0; y < h; y++) {
      const rl = dv.getUint16((c * h + y) * 2);
      const end = Math.min(payload.length, p + rl);
      unpackBits(payload, p, end, out, y * w, y * w + w);
      p = end;
    }
    planes.push(out);
  }
  return planes;
}

function decodePlanes(
  payload: Uint8Array,
  compression: number,
  nPlanes: number,
  w: number,
  h: number,
  warnings: string[],
): Uint8Array[] {
  if (compression === 0) {
    return Array.from({ length: nPlanes }, (_, c) => {
      const out = new Uint8Array(w * h);
      out.set(payload.subarray(c * w * h, (c + 1) * w * h).subarray(0, w * h));
      return out;
    });
  }
  if (compression === 1) return decodeRle(payload, nPlanes, w, h);
  warnings.push(`compression ${compression} not decoded (ZIP variants unsupported); channel left empty`);
  return Array.from({ length: nPlanes }, () => new Uint8Array(w * h));
}

export function parsePsd(u8: Uint8Array): PsdDoc {
  if (u8.length < 26 || ascii(u8, 0, 4) !== "8BPS") throw new Error("not a PSD file");
  const dv = new DataView(u8.buffer, u8.byteOffset, u8.byteLength);
  const version = dv.getUint16(4);
  if (version !== 1) throw new Error("PSB (version 2) is not supported in this build");
  const channels = dv.getUint16(12);
  const height = dv.getUint32(14);
  const width = dv.getUint32(18);
  const depth = dv.getUint16(22);
  const mode = dv.getUint16(24);
  if (depth !== 8) throw new Error(`${depth}-bit PSD not supported (8-bit only)`);
  if (width * height > MAX_PIXELS) throw new Error("canvas exceeds the pixel guard");
  const warnings: string[] = [];

  let p = 26;
  p += 4 + dv.getUint32(p); // colour mode data
  p += 4 + dv.getUint32(p); // image resources
  const lmLen = dv.getUint32(p);
  const lmStart = p + 4;
  const lmEnd = lmStart + lmLen;
  const layers: PsdLayer[] = [];

  if (lmLen > 0) {
    const liLen = dv.getUint32(lmStart);
    const liStart = lmStart + 4;
    if (liLen > 0) {
      let q = liStart;
      const count = dv.getInt16(q);
      q += 2;
      const n = Math.abs(count);
      if (count < 0) warnings.push("first alpha channel holds merged transparency (ignored)");
      const recs: {
        top: number; left: number; bottom: number; right: number;
        opacity: number; visible: boolean; blend: string; name: string;
        ch: { id: number; len: number }[];
      }[] = [];
      for (let i = 0; i < n; i++) {
        const top = dv.getInt32(q);
        const left = dv.getInt32(q + 4);
        const bottom = dv.getInt32(q + 8);
        const right = dv.getInt32(q + 12);
        q += 16;
        const nch = dv.getUint16(q);
        q += 2;
        const ch: { id: number; len: number }[] = [];
        for (let c = 0; c < nch; c++) {
          ch.push({ id: dv.getInt16(q), len: dv.getUint32(q + 2) });
          q += 6;
        }
        if (ascii(u8, q, 4) !== "8BIM") throw new Error("bad layer record signature");
        const blend = ascii(u8, q + 4, 4);
        const opacity = u8[q + 8];
        const flags = u8[q + 10];
        q += 12;
        const extraLen = dv.getUint32(q);
        q += 4;
        const extraStart = q;
        let e = extraStart;
        e += 4 + dv.getUint32(e); // layer mask data
        e += 4 + dv.getUint32(e); // blending ranges
        const nameLen = u8[e];
        const name = ascii(u8, e + 1, nameLen);
        q = extraStart + extraLen;
        recs.push({ top, left, bottom, right, opacity, visible: !(flags & 2), blend, name, ch });
      }
      // Channel image data follows the records, in record order then channel order.
      for (const r of recs) {
        const w = r.right - r.left;
        const h = r.bottom - r.top;
        const chans: PsdChannel[] = [];
        for (const c of r.ch) {
          const len = Math.max(2, c.len);
          const compression = dv.getUint16(q);
          const payload = u8.subarray(q + 2, q + len);
          const planes = w > 0 && h > 0 ? decodePlanes(payload, compression, 1, w, h, warnings) : [new Uint8Array(0)];
          chans.push({ id: c.id, data: planes[0] });
          q += len;
        }
        layers.push({
          name: r.name, top: r.top, left: r.left, bottom: r.bottom, right: r.right,
          opacity: r.opacity, visible: r.visible, blend: r.blend, channels: chans,
        });
      }
    }
  }

  let merged: PsdChannel[] | null = null;
  if (lmEnd + 2 <= u8.length) {
    const compression = dv.getUint16(lmEnd);
    const nPlanes = Math.min(channels, 4);
    const planes = decodePlanes(u8.subarray(lmEnd + 2), compression, nPlanes, width, height, warnings);
    merged = planes.map((data, i) => ({ id: i, data }));
  }
  return { width, height, channels, depth, mode, layers, merged, warnings };
}

/** Normal-blend composite of visible layers (bottom to top) onto a transparent RGBA canvas. */
export function compositePsd(doc: PsdDoc): { width: number; height: number; rgba: Uint8ClampedArray } {
  const W = doc.width;
  const H = doc.height;
  const out = new Uint8ClampedArray(W * H * 4);
  if (doc.layers.length === 0) {
    if (doc.merged) {
      const pick = (id: number) => doc.merged!.find((c) => c.id === id)?.data;
      const R = pick(0), G = pick(1), B = pick(2), A = pick(3);
      for (let i = 0; i < W * H; i++) {
        out[i * 4] = R ? R[i] : 0;
        out[i * 4 + 1] = G ? G[i] : 0;
        out[i * 4 + 2] = B ? B[i] : 0;
        out[i * 4 + 3] = A ? A[i] : 255;
      }
    }
    return { width: W, height: H, rgba: out };
  }
  for (const L of doc.layers) {
    if (!L.visible) continue;
    const w = L.right - L.left;
    const h = L.bottom - L.top;
    if (w <= 0 || h <= 0) continue;
    const get = (id: number) => L.channels.find((c) => c.id === id)?.data;
    const R = get(0), G = get(1), B = get(2), A = get(-1);
    const op = L.opacity / 255;
    for (let y = 0; y < h; y++) {
      const dy = L.top + y;
      if (dy < 0 || dy >= H) continue;
      for (let x = 0; x < w; x++) {
        const dx = L.left + x;
        if (dx < 0 || dx >= W) continue;
        const i = y * w + x;
        const sa = (A ? A[i] / 255 : 1) * op;
        if (sa <= 0) continue;
        const o = (dy * W + dx) * 4;
        const da = out[o + 3] / 255;
        const ra = sa + da * (1 - sa);
        if (ra <= 0) continue;
        out[o] = ((R ? R[i] : 0) * sa + out[o] * da * (1 - sa)) / ra;
        out[o + 1] = ((G ? G[i] : 0) * sa + out[o + 1] * da * (1 - sa)) / ra;
        out[o + 2] = ((B ? B[i] : 0) * sa + out[o + 2] * da * (1 - sa)) / ra;
        out[o + 3] = ra * 255;
      }
    }
  }
  return { width: W, height: H, rgba: out };
}

export function summarizePsd(doc: PsdDoc) {
  return doc.layers.map((L) => ({
    name: L.name,
    bounds: [L.left, L.top, L.right, L.bottom],
    opacity: Math.round((L.opacity / 255) * 100),
    visible: L.visible,
    blend: L.blend,
    channels: L.channels.map((c) => c.id),
  }));
}
