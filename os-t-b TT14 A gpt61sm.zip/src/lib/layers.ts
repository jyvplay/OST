/** FF-05 layered raster document. Pure byte maths; no canvas dependency.
 * Colour contract: straight-alpha sRGB RGBA8; integer pixel translations; no linear-light conversion.
 * Formula: W3C compositing-1 source-over with separable normal/multiply/screen blending.
 * Storage order is BOTTOM -> TOP. Layer opacity and alpha mask multiply source alpha, never RGB.
 * Limits are enforced before allocation and project decode: 4M pixels/canvas, 16M layer pixels,
 * 12 layers, 32 MB project JSON. This is not PSD round-trip support or a professional colour pipeline.
 */
import { createRaster, type Raster } from "./raster";

export type Blend = "normal" | "multiply" | "screen";
export type RasterLayer = {
  id: string; name: string; raster: Raster; x: number; y: number; visible: boolean; opacity: number;
  blend: Blend; mask?: Uint8ClampedArray;
};
export type LayerDoc = { width: number; height: number; layers: RasterLayer[] };
export const LAYER_LIMITS = { canvasPixels: 4_000_000, totalPixels: 16_000_000, layers: 12, projectBytes: 32_000_000 };

function dimensions(w: number, h: number, limit: number) {
  if (!Number.isInteger(w) || !Number.isInteger(h) || w < 1 || h < 1 || w * h > limit) throw new Error(`Invalid dimensions or pixel budget exceeded (${limit})`);
}
export function validateLayers(doc: LayerDoc): void {
  dimensions(doc.width, doc.height, LAYER_LIMITS.canvasPixels);
  if (!Array.isArray(doc.layers) || doc.layers.length > LAYER_LIMITS.layers) throw new Error("At most 12 layers");
  const ids = new Set<string>();
  let pixels = 0;
  for (const l of doc.layers) {
    if (typeof l.id !== "string" || !l.id || ids.has(l.id)) throw new Error("Layer ids must be unique");
    ids.add(l.id);
    dimensions(l.raster.width, l.raster.height, LAYER_LIMITS.canvasPixels);
    pixels += l.raster.width * l.raster.height;
    if (pixels > LAYER_LIMITS.totalPixels) throw new Error("Total layer pixel budget exceeded");
    if (l.raster.data.length !== l.raster.width * l.raster.height * 4 || (l.mask && l.mask.length !== l.raster.width * l.raster.height)) throw new Error("Pixel/mask buffer length mismatch");
    if (!Number.isInteger(l.x) || !Number.isInteger(l.y) || !Number.isFinite(l.opacity) || l.opacity < 0 || l.opacity > 1 || !["normal", "multiply", "screen"].includes(l.blend)) throw new Error("Invalid layer placement, opacity or blend mode");
  }
}

const blend = (b: number, s: number, mode: Blend) => mode === "multiply" ? b * s : mode === "screen" ? b + s - b * s : s;

export function compositeLayers(doc: LayerDoc): Raster {
  validateLayers(doc);
  const out = createRaster(doc.width, doc.height);
  // Float buffer avoids rounding at each layer boundary; quantise exactly once at output.
  const rgba = new Float64Array(doc.width * doc.height * 4);
  for (const l of doc.layers) {
    if (!l.visible || l.opacity === 0) continue;
    const { width: w, height: h, data } = l.raster;
    const x0 = Math.max(0, -l.x), y0 = Math.max(0, -l.y);
    const x1 = Math.min(w, doc.width - l.x), y1 = Math.min(h, doc.height - l.y);
    for (let y = y0; y < y1; y++) for (let x = x0; x < x1; x++) {
      const si = y * w + x, so = si * 4;
      const d = ((y + l.y) * doc.width + x + l.x) * 4;
      const as = data[so + 3] / 255 * l.opacity * (l.mask ? l.mask[si] / 255 : 1);
      if (as === 0) continue;
      const ab = rgba[d + 3], ao = as + ab * (1 - as);
      for (let c = 0; c < 3; c++) {
        const cs = data[so + c] / 255, cb = rgba[d + c];
        const mixed = (1 - ab) * cs + ab * blend(cb, cs, l.blend);
        const premult = as * mixed + ab * cb * (1 - as);
        rgba[d + c] = ao === 0 ? 0 : premult / ao;
      }
      rgba[d + 3] = ao;
    }
  }
  for (let i = 0; i < rgba.length; i++) out.data[i] = Math.round(rgba[i] * 255);
  return out;
}

/** White=visible, black=hidden; rectangle endpoints clipped to the layer. Never modifies source alpha. */
export function rectangleMask(width: number, height: number, x: number, y: number, w: number, h: number): Uint8ClampedArray {
  dimensions(width, height, LAYER_LIMITS.canvasPixels);
  const mask = new Uint8ClampedArray(width * height);
  for (let row = 0; row < height; row++) for (let col = 0; col < width; col++) {
    if (col >= x && row >= y && col < x + w && row < y + h) mask[row * width + col] = 255;
  }
  return mask;
}
export function invertMask(mask: Uint8ClampedArray): Uint8ClampedArray { return mask.map((n) => 255 - n); }

export function newLayer(id: string, name: string, raster: Raster): RasterLayer {
  return { id, name, raster, x: 0, y: 0, visible: true, opacity: 1, blend: "normal" };
}
export function patchLayer(doc: LayerDoc, id: string, patch: Partial<RasterLayer>): LayerDoc {
  const next = { ...doc, layers: doc.layers.map((l) => l.id === id ? { ...l, ...patch, id: l.id } : l) };
  validateLayers(next);
  return next;
}
export function moveLayer(doc: LayerDoc, id: string, direction: -1 | 1): LayerDoc {
  const layers = [...doc.layers];
  const i = layers.findIndex((l) => l.id === id), j = i + direction;
  if (i < 0 || j < 0 || j >= layers.length) return doc;
  [layers[i], layers[j]] = [layers[j], layers[i]];
  return { ...doc, layers };
}

const b64 = (bytes: Uint8ClampedArray) => {
  let s = "";
  for (let i = 0; i < bytes.length; i += 0x4000) s += String.fromCharCode(...bytes.subarray(i, i + 0x4000));
  return btoa(s);
};
function decode(s: string, expected: number): Uint8ClampedArray {
  if (typeof s !== "string" || s.length !== Math.ceil(expected / 3) * 4) throw new Error("Invalid base64 buffer size");
  const raw = atob(s);
  if (raw.length !== expected) throw new Error("Decoded buffer length mismatch");
  return Uint8ClampedArray.from(raw, (c) => c.charCodeAt(0));
}

export function serializeLayerProject(doc: LayerDoc): string {
  validateLayers(doc);
  const text = JSON.stringify({ kind: "fusion-layers", version: 1, width: doc.width, height: doc.height,
    layers: doc.layers.map(({ raster, mask, ...l }) => ({ ...l, width: raster.width, height: raster.height, pixels: b64(raster.data), ...(mask ? { mask: b64(mask) } : {}) })) });
  if (text.length > LAYER_LIMITS.projectBytes) throw new Error("Project exceeds 32 MB export budget");
  return text;
}
export function parseLayerProject(text: string): LayerDoc {
  if (text.length > LAYER_LIMITS.projectBytes) throw new Error("Project exceeds 32 MB import budget");
  const obj = JSON.parse(text) as { kind: string; version: number; width: number; height: number; layers: Array<RasterLayer & { width: number; height: number; pixels: string; mask?: string }> };
  if (obj.kind !== "fusion-layers" || obj.version !== 1) throw new Error("Unknown project format/version");
  dimensions(obj.width, obj.height, LAYER_LIMITS.canvasPixels);
  if (!Array.isArray(obj.layers) || obj.layers.length > LAYER_LIMITS.layers) throw new Error("At most 12 layers");
  let count = 0;
  const layers = obj.layers.map((l) => {
    dimensions(l.width, l.height, LAYER_LIMITS.canvasPixels);
    if ((count += l.width * l.height) > LAYER_LIMITS.totalPixels) throw new Error("Layer pixel budget exceeded before decoding");
    return { id: l.id, name: String(l.name).slice(0, 100), x: l.x, y: l.y, opacity: l.opacity, visible: !!l.visible,
      blend: l.blend, raster: { width: l.width, height: l.height, data: decode(l.pixels, l.width * l.height * 4) },
      ...(l.mask ? { mask: decode(l.mask, l.width * l.height) } : {}) };
  });
  const doc = { width: obj.width, height: obj.height, layers };
  validateLayers(doc);
  return doc;
}
