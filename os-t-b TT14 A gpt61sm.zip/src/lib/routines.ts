// Implements: AU-01 (routines: triggers, one action, dry-run by default, audit).
// Pure logic. Execution happens in Desktop.tsx so actions can touch the window engine.
import type { TileZone } from "./windowEngine";

export type Trigger =
  | { type: "app-open"; module: string }
  | { type: "interval"; minutes: number }
  | { type: "display-change" }
  | { type: "manual" };

export type Action =
  | { type: "notify"; text: string }
  | { type: "note"; title: string; body: string }
  | { type: "tile"; zone: TileZone }
  | { type: "focusMode"; on: boolean }
  | { type: "open"; module: string };

export type Routine = {
  id: string;
  name: string;
  enabled: boolean;
  mode: "dry-run" | "live";
  trigger: Trigger;
  action: Action;
};

export type RoutineEvent = Trigger;

export function describeTrigger(t: Trigger): string {
  switch (t.type) {
    case "app-open": return `when “${t.module}” opens`;
    case "interval": return `every ${t.minutes} min (skipped while battery saver or data saver is active)`;
    case "display-change": return "when the layout profile switches";
    case "manual": return "only when you press Run";
  }
}

export function describeAction(a: Action): string {
  switch (a.type) {
    case "notify": return `show “${a.text}”`;
    case "note": return `create note “${a.title}”`;
    case "tile": return `tile the focused window ${a.zone}`;
    case "focusMode": return `turn focus mode ${a.on ? "on" : "off"}`;
    case "open": return `open ${a.module}`;
  }
}

export function planFor(r: Routine): string {
  return `${r.name}: ${describeTrigger(r.trigger)} → ${describeAction(r.action)}`;
}

export function matchesEvent(r: Routine, ev: RoutineEvent): boolean {
  if (!r.enabled) return false;
  if (r.trigger.type !== ev.type) return false;
  if (r.trigger.type === "app-open" && ev.type === "app-open") return r.trigger.module === ev.module;
  return true;
}

export function intervalDue(r: Routine, now: number, last: number | undefined): boolean {
  if (!r.enabled || r.trigger.type !== "interval" || last === undefined) return false;
  return now - last >= r.trigger.minutes * 60_000;
}

export function validateRoutine(r: Partial<Routine>): string | null {
  if (!r.name || !r.name.trim()) return "name is required";
  if (!r.trigger) return "trigger is required";
  if (!r.action) return "action is required";
  if (r.trigger.type === "interval" && !(r.trigger.minutes >= 0.01 && r.trigger.minutes <= 1440))
    return "interval must be between 0.01 and 1440 minutes";
  if (r.trigger.type === "app-open" && !r.trigger.module) return "app-open trigger needs a module id";
  if (r.action.type === "note" && !r.action.title.trim()) return "note action needs a title";
  if (r.action.type === "notify" && !r.action.text.trim()) return "notify action needs text";
  return null;
}
