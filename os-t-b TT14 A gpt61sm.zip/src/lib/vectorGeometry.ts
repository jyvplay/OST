/** FF-09 geometry commands, pure and immutable. Affine matrices use SVG's [a,b,c,d,e,f] convention.
 * Rectangles, points, lines, stars, circles and ellipses have analytic bounds. Text/path bounds remain
 * estimates inherited from vector.ts; exact glyph metrics and Bézier extrema are not claimed.
 * Supported imported transforms: matrix/translate/scale/rotate. Other transforms throw rather than
 * being silently discarded. Selection is top-level (group contents are edited as one object).
 */
import { shapeBounds, starPoints, type VecDoc, type VecShape } from "./vector";
export type Matrix = [number, number, number, number, number, number];
export type Bounds = { x: number; y: number; w: number; h: number };
export const IDENTITY: Matrix = [1, 0, 0, 1, 0, 0];
export function multiply(a: Matrix, b: Matrix): Matrix {
  return [a[0] * b[0] + a[2] * b[1], a[1] * b[0] + a[3] * b[1], a[0] * b[2] + a[2] * b[3], a[1] * b[2] + a[3] * b[3], a[0] * b[4] + a[2] * b[5] + a[4], a[1] * b[4] + a[3] * b[5] + a[5]];
}
export function point(m: Matrix, x: number, y: number): [number, number] { return [m[0] * x + m[2] * y + m[4], m[1] * x + m[3] * y + m[5]]; }
export const translation = (x: number, y: number): Matrix => [1, 0, 0, 1, x, y];
export const scaling = (x: number, y = x): Matrix => [x, 0, 0, y, 0, 0];
export function rotation(deg: number, cx = 0, cy = 0): Matrix {
  const a = deg * Math.PI / 180, c = Math.cos(a), s = Math.sin(a);
  return multiply(translation(cx, cy), multiply([c, s, -s, c, 0, 0], translation(-cx, -cy)));
}
export function parseTransform(text = ""): Matrix {
  if (!text.trim()) return [...IDENTITY];
  let m: Matrix = [...IDENTITY], end = 0;
  const re = /(matrix|translate|scale|rotate)\s*\(([^)]*)\)/g;
  for (const match of text.matchAll(re)) {
    if (text.slice(end, match.index).trim()) throw new Error("Unsupported SVG transform");
    const nums = match[2].trim().split(/[\s,]+/).map(Number);
    if (!nums.length || nums.some((n) => !Number.isFinite(n))) throw new Error("Non-finite SVG transform");
    let part: Matrix;
    if (match[1] === "matrix" && nums.length === 6) part = nums as Matrix;
    else if (match[1] === "translate" && nums.length <= 2) part = translation(nums[0], nums[1] ?? 0);
    else if (match[1] === "scale" && nums.length <= 2) part = scaling(nums[0], nums[1] ?? nums[0]);
    else if (match[1] === "rotate" && (nums.length === 1 || nums.length === 3)) part = rotation(nums[0], nums[1] ?? 0, nums[2] ?? 0);
    else throw new Error("Unsupported SVG transform arguments");
    m = multiply(m, part); end = match.index! + match[0].length;
  }
  if (end === 0 || text.slice(end).trim()) throw new Error("Unsupported SVG transform");
  return m;
}
const matrixText = (m: Matrix) => `matrix(${m.map((n) => Math.abs(n) < 1e-12 ? 0 : Number(n.toFixed(8))).join(" ")})`;
const union = (bs: Bounds[]): Bounds => {
  if (!bs.length) return { x: 0, y: 0, w: 0, h: 0 };
  const x = Math.min(...bs.map((b) => b.x)), y = Math.min(...bs.map((b) => b.y));
  return { x, y, w: Math.max(...bs.map((b) => b.x + b.w)) - x, h: Math.max(...bs.map((b) => b.y + b.h)) - y };
};
function fromPoints(points: [number, number][]): Bounds {
  if (!points.length) return { x: 0, y: 0, w: 0, h: 0 };
  const xs = points.map((p) => p[0]), ys = points.map((p) => p[1]);
  const x = Math.min(...xs), y = Math.min(...ys);
  return { x, y, w: Math.max(...xs) - x, h: Math.max(...ys) - y };
}
export function geometryBounds(s: VecShape, matrix: Matrix = IDENTITY): Bounds {
  if (s.kind === "group") return union(s.children.map((c) => geometryBounds(c, multiply(matrix, parseTransform(s.transform)))));
  if (s.kind === "circle" || s.kind === "ellipse") {
    const [cx, cy] = point(matrix, s.cx, s.cy);
    const rx = s.kind === "circle" ? s.r : s.rx, ry = s.kind === "circle" ? s.r : s.ry;
    const ex = Math.hypot(matrix[0] * rx, matrix[2] * ry), ey = Math.hypot(matrix[1] * rx, matrix[3] * ry);
    return { x: cx - ex, y: cy - ey, w: ex * 2, h: ey * 2 };
  }
  let points: [number, number][] = [];
  if (s.kind === "line" || s.kind === "arrow") points = [[s.x1, s.y1], [s.x2, s.y2]];
  else if (["polygon", "polyline", "star"].includes(s.kind)) {
    const raw = s.kind === "star" ? starPoints(s.cx, s.cy, s.outerR, s.innerR, s.points) : "points" in s ? s.points : "";
    const ns = (raw.match(/-?\d*\.?\d+(?:e[+-]?\d+)?/gi) ?? []).map(Number);
    for (let i = 0; i + 1 < ns.length; i += 2) points.push([ns[i], ns[i + 1]]);
  } else {
    const b = shapeBounds(s);
    points = [[b.x, b.y], [b.x + b.w, b.y], [b.x + b.w, b.y + b.h], [b.x, b.y + b.h]];
  }
  return fromPoints(points.map(([x, y]) => point(matrix, x, y)));
}

export function transformShape(s: VecShape, matrix: Matrix): VecShape {
  if (matrix.some((n) => !Number.isFinite(n))) throw new Error("Non-finite geometry command");
  if (s.kind === "group") return { ...s, transform: matrixText(multiply(matrix, parseTransform(s.transform))) };
  return { id: s.id, kind: "group", transform: matrixText(matrix), children: [{ ...s, id: `${s.id}-content` }] };
}
export function moveShape(doc: VecDoc, id: string, dx: number, dy: number): VecDoc {
  return { ...doc, shapes: doc.shapes.map((s) => s.id === id ? transformShape(s, translation(dx, dy)) : s) };
}
export function rotateShape(doc: VecDoc, id: string, deg: number): VecDoc {
  return { ...doc, shapes: doc.shapes.map((s) => {
    if (s.id !== id) return s;
    const b = geometryBounds(s);
    return transformShape(s, rotation(deg, b.x + b.w / 2, b.y + b.h / 2));
  }) };
}
export function scaleShape(doc: VecDoc, id: string, scale: number): VecDoc {
  if (!Number.isFinite(scale) || scale <= 0 || scale > 20) throw new Error("Scale must be >0 and <=20");
  return { ...doc, shapes: doc.shapes.map((s) => {
    if (s.id !== id) return s;
    const b = geometryBounds(s), cx = b.x + b.w / 2, cy = b.y + b.h / 2;
    return transformShape(s, multiply(translation(cx, cy), multiply(scaling(scale), translation(-cx, -cy))));
  }) };
}
export function hitTest(doc: VecDoc, x: number, y: number): string | null {
  for (const s of [...doc.shapes].reverse()) {
    if (s.opacity === 0) continue;
    const b = geometryBounds(s);
    if (x >= b.x - 3 && y >= b.y - 3 && x <= b.x + b.w + 3 && y <= b.y + b.h + 3) return s.id;
  }
  return null;
}
export function alignShapes(doc: VecDoc, ids: string[], edge: "left" | "center" | "right" | "top" | "middle" | "bottom"): VecDoc {
  return { ...doc, shapes: doc.shapes.map((s) => {
    if (!ids.includes(s.id)) return s;
    const b = geometryBounds(s);
    const dx = edge === "left" ? -b.x : edge === "center" ? doc.width / 2 - b.x - b.w / 2 : edge === "right" ? doc.width - b.x - b.w : 0;
    const dy = edge === "top" ? -b.y : edge === "middle" ? doc.height / 2 - b.y - b.h / 2 : edge === "bottom" ? doc.height - b.y - b.h : 0;
    return transformShape(s, translation(dx, dy));
  }) };
}
export function stackShape(doc: VecDoc, id: string, direction: -1 | 1): VecDoc {
  const shapes = [...doc.shapes], i = shapes.findIndex((s) => s.id === id), j = i + direction;
  if (i < 0 || j < 0 || j >= shapes.length) return doc;
  [shapes[i], shapes[j]] = [shapes[j], shapes[i]];
  return { ...doc, shapes };
}
