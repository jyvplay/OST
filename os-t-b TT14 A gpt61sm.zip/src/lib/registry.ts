/**
 * Fusion Shell Web — feature register (port of Master Spec v2.1 §7 + Lens + Messages).
 * Tuple: [id, area, title, tier, phase, status, webNuance]
 *
 * tier:   A = plain web app capability
 *         A/B = needs a user-granted powerful capability (permission prompt / user gesture)
 *         B = needs an installed-PWA / secure-context / origin-trial-class capability
 *         C = approximated only (no web API) — UI must say so (DP-10)
 *         X = not possible on the web platform — must be declared, never faked
 * status: implemented | skeleton | spec | blocked | not-applicable
 */
export type FeatureRow = {
  id: string;
  area: string;
  title: string;
  tier: string;
  phase: string;
  status: string;
  webNuance: string;
};

const R: [string, string, string, string, string, string, string][] = [
  // ───────── SH shell surfaces
  ["SH-01","Shell","Launcher: pinned apps, all-apps grid, folders, search-first","A","P1","implemented","Android HOME role has no web analogue; we claim the *display* via display-mode:standalone + launch_handler:focus-existing so the PWA behaves as the session root."],
  ["SH-02","Shell","Shelf: pinned + running modules, badges, window previews","A","P1","implemented","Running = our own windows only. No usage-stats inference exists in a browser; the shelf never pretends to see other apps."],
  ["SH-03","Shell","Top bar: module menus, status, Beam indicator, clock","A","P1","implemented","Rendered inside the app, not the OS chrome; uses window-controls-overlay when the PWA is installed on desktop."],
  ["SH-04","Shell","Desktop surface: wallpaper, icons, right-click menu, per-workspace layout","A","P1","implemented","contextmenu is preventDefault-ed only over our own desktop/window surfaces, never over text inputs (keeps native spellcheck menu)."],
  ["SH-05","Shell","Widget host (crash-isolated tiles)","A","P2","skeleton","Widgets are our own sandboxed iframes with a postMessage contract; no third-party AppWidget equivalent exists."],
  ["SH-06","Shell","Hot corners / edge triggers / mouse gestures","A","P2","implemented","Pointer Events with pointerType filtering; edge detection uses visualViewport, not window.inner*, so it survives on-screen keyboards."],
  ["SH-07","Shell","First run: local profile, capability explainers, license activation","A","P1","implemented","No account. Entitlement is an HMAC-signed blob cached in the DB + localStorage; offline never loses features (BL-02)."],
  ["SH-08","Shell","Session restore after crash/reload","A","P1","implemented","Debounced (500 ms) persistence of DesktopState to Postgres via /api/state, plus a synchronous localStorage mirror for the pre-hydration paint."],
  ["SH-09","Shell","Mouse navigation: back/forward/middle/side buttons","A","P1","implemented","button 3/4 only arrive via pointerdown + preventDefault on auxclick; Safari never delivers them — probe exposes the gap instead of silently dropping."],
  ["SH-10","Shell","BlackTop: external-display session router","A/B","P1","implemented","Window Management API getScreenDetails() + requestFullscreen({screen}) replaces Android Presentation. Phone-blackout becomes a dimmed 'controller' surface with Wake Lock held."],
  ["SH-11","Shell","Phone-as-touchpad/keyboard for the external session","A","P2","skeleton","Controller surface injects synthetic pointer commands into our compositor only — never into the host OS (no web API, and we must not pretend)."],
  ["SH-12","Shell","Throttle detector + guidance","A","P1","implemented","rAF micro-benchmark at boot; detects background throttling, reduced-motion and low-end deviceMemory, then names the cause in plain language."],
  // ───────── WM window management
  ["WM-01","Windows","Compositor: move/resize/min/max/close/z-order/title bars","A","P1","implemented","Pure reducer (lib/windowEngine.ts) with invariants; DOM transform/width/height only — no React re-render of window *content* during drag (refs + rAF commit)."],
  ["WM-02","Windows","Tiles: halves/thirds/quarters, drag-to-edge, keyboard tiling","A","P1","implemented","Snap zones computed in CSS-pixel workspace coordinates so they stay correct under browser zoom and devicePixelRatio changes."],
  ["WM-03","Windows","Workspaces: named, reorderable, per-window","A","P2","implemented","Workspace switch is a state swap, not unmount: iframes/video keep their renderer alive (visibility:hidden + inert)."],
  ["WM-04","Windows","Overview: grid of windows/workspaces with live previews","A","P2","implemented","No cross-origin thumbnail capture is possible; previews are our own DOM scaled with CSS zoom, and third-party iframes show a labelled placeholder."],
  ["WM-05","Windows","Switcher: app / window / workspace modes","A","P1","implemented","Alt+Tab is reserved by every OS; we bind Ctrl+Alt+Tab (and Meta+Tab when installed) and show the conflict in the shortcut detector."],
  ["WM-06","Windows","External-content broker (iframe S1..S4 strategies)","B","P2","implemented","Replaces Android's freeform broker: probe X-Frame-Options/CSP via a HEAD preflight, then choose embed / popup window / open-in-tab, labelled honestly."],
  ["WM-07","Windows","Multi-display: per-display layouts, hotplug restore","A/B","P2","implemented","screen.isExtended + screendetails 'screenschange' events; layouts keyed by a screen fingerprint (label+size+scale)."],
  ["WM-08","Windows","Window rules per module/doc type, remembered geometry","A","P2","implemented","Geometry keyed by module+docId and clamped on restore against the *current* workspace rect."],
  ["WM-09","Windows","Keyboard-only move/resize/tile","A","P1","implemented","Meta+arrow tiling, Ctrl+Alt+arrow nudge, with aria-live announcements of the resulting rect (AX-01)."],
  ["WM-10","Windows","Focus mode","A","P2","implemented","Dims non-focused windows; respects prefers-reduced-motion and never hides state."],
  ["WM-11","Windows","Always-on-top mini windows","A","P3","implemented","In-compositor z-band; true OS always-on-top only exists via Document PiP (used by Beam/Lens)."],
  ["WM-12","Windows","Per-window density override + 'may not resize well' label","A","P2","implemented","Container queries drive density; embedded third-party pages are labelled because we cannot restyle them."],
  ["WM-13","Windows","Drag window across workspaces","A","P2","implemented","Edge-hold 600 ms or Meta+Shift+arrow; the drag is state-only so no iframe reload occurs (append-move would reload it)."],
  ["WM-14","Windows","Key-to-pointer mapper overlay","B","P4","spec","Only works over our own surfaces; cross-origin iframes cannot receive synthetic events — declared, not faked."],
  ["WM-15","Windows","Window-to-cast: send any window as a Beam source","A","P3","skeleton","Uses element capture where available, else getDisplayMedia('browser' surface) with a user-picked tab."],
  ["WM-16","Windows","Cursor confinement to the active display","A","P2","skeleton","Pointer Lock is the only confinement primitive; used for drag operations, released on Escape (browser-enforced)."],
  // ───────── SR find
  ["SR-01","Find","Command palette: apps, commands, windows, files, notes, settings, cast targets","A","P1","implemented","Single Postgres query with UNION ALL over typed sources + provenance badges; local rows always outrank web (SR-04)."],
  ["SR-02","Find","Index with health UI, exclusions, rebuild, churn quarantine","A/B","P1","implemented","Postgres to_tsvector computed at query time for small corpora; health card reports row counts, last build and skipped paths."],
  ["SR-03","Find","Exact + fuzzy (P1), semantic embeddings (P3)","A","P1","implemented","Fuzzy = trigram-ish similarity via ILIKE + Levenshtein-lite ranking in SQL; semantic path is gated on WebGPU presence."],
  ["SR-04","Find","Opt-in web results, never outranking local","A","P1","skeleton","Off by default; when on, results are visually separated and fetched only on explicit Enter."],
  ["SR-05","Find","In-folder scoped search","A","P1","implemented","Scope chips map to a recursive CTE over fs_nodes."],
  ["SR-06","Find","Palette actions: calculate, convert, quick note, cast to…, run routine","A","P2","implemented","Actions are registered command objects, so they are searchable, keyboard-complete and audit-logged."],
  ["SR-07","Find","Other apps' content","C","P4","blocked","No AppSearch analogue on the web. We expose a documented import API instead of pretending to read other origins."],
  ["SR-08","Find","Search diagnostics (why is this missing?)","A","P2","implemented","Explains exclusion, trash state, or tokenizer miss for a given query/path pair."],
  // ───────── FM files
  ["FM-01","Files","Browser: tabs, list/grid/column/gallery, breadcrumbs, tree, tags","B","P1","implemented","Two backends behind one interface: DB-VFS (always) and the real disk via File System Access API when granted (Chromium only; Safari/Firefox degrade visibly)."],
  ["FM-02","Files","Dual-pane / split with optional terminal pane","A","P1","implemented","Panes are independent navigation stacks; Tab moves focus between them, matching desktop file managers."],
  ["FM-03","Files","Ops engine: copy/move/delete/rename/batch-rename with journal + undo","B","P1","implemented","Full REQUESTED→COPYING_TO_TEMP→DEST_VERIFIED→DEST_PUBLISHED→SOURCE_RETIRE→COMPLETE machine, journaled per transition, recovered on boot. Web nuance: the 'temp' is a shadow row, verification is a byte-length+checksum compare."],
  ["FM-04","Files","Peek: images/PDF/text/audio/video/archives/Office in an isolated renderer","A","P1","implemented","Isolation = sandboxed iframe with a 5 s watchdog; the parser runs in a Worker so a malformed file cannot hang the compositor."],
  ["FM-05","Files","Archives: browse without extract; zip read/write, bomb guards","A","P2","implemented","Server-side zlib inflate-raw with ratio (>200:1) and entry-count guards; zip-slip names rejected before any write."],
  ["FM-06","Files","Context menus concise/full/custom + 'Open terminal here'","A","P1","implemented","Type-to-search inside the menu; every entry also exists as a palette command (DP-06)."],
  ["FM-07","Files","Storage overview: categories, duplicates, large files","B","P3","implemented","navigator.storage.estimate() for the origin quota + SQL aggregate over the VFS; duplicates by content hash."],
  ["FM-08","Files","Removable / network volumes","A/B","P2","skeleton","No SMB/SFTP in a browser. We mount: OPFS, user-picked directories, and HTTP(S)/WebDAV endpoints the user supplies — each labelled with its real transport."],
  ["FM-09","Files","Cloud / placeholder state badges","A","P3","implemented","Badges: local / mirrored / remote-only / needs-permission (re-prompt on stale handle)."],
  ["FM-10","Files","Expose Files to other apps","A","P2","skeleton","Web Share Target (installed PWA) + file_handlers in the manifest replace DocumentsProvider."],
  ["FM-11","Files","Trash with origin, date, size, retention","B","P1","implemented","Soft delete keeps the original path string so restore survives parent renames."],
  ["FM-13","Files","Templates and right-click → New","A","P1","implemented","Templates are themselves VFS rows under /System/Templates, so users can add their own."],
  ["FM-14","Files","Drag & drop between windows and the OS","A","P2","implemented","DataTransfer with both text/plain paths and real File blobs; DownloadURL is used for drag-out to the desktop on Chromium."],
  ["FM-15","Files","Selection toolbar with count and size","A","P1","implemented","Shift/Ctrl range selection implemented over a flat index so keyboard selection matches pointer selection exactly."],
  ["FM-16","Files","Quick filter bar","A","P1","implemented","Filters the current listing client-side without a round trip; never changes the stored view mode (UX-01)."],
  ["FM-17","Files","Folder size calculation","A","P2","implemented","Recursive CTE aggregate, cached per folder with an invalidation stamp."],
  ["FM-18","Files","SAF-equivalent safe-save contract","A","P1","implemented","Write to a shadow row/temp file → validate by re-read → atomic swap; if the FS Access handle refuses createWritable, we offer 'Save a Copy' rather than silently overwriting."],
  // ───────── NC alerts
  ["NC-01","Alerts","Alert center: grouping, history, snooze, rules, pin, batch dismiss","B","P1","implemented","No NotificationListenerService on the web: the store is fed by our modules plus the Notification API and a documented POST /api/alerts ingest for user-owned sources."],
  ["NC-02","Alerts","Focus modes by workspace/time with visible reason","B","P2","implemented","Suppression always records and shows why a given alert was held."],
  ["NC-03","Alerts","Quick panel: volume, media, DND, Beam targets, battery","A/B","P1","implemented","Volume applies to our own media elements only; system volume is unreachable — the slider says so (DP-10). Battery API is Chromium-only."],
  ["NC-04","Alerts","Notification diagnostics","B","P2","implemented","Shows Notification.permission, service-worker registration state and the last delivery error."],
  ["NC-05","Alerts","Progress / live updates for long operations","A","P1","implemented","Copy/backup/cast progress streams over Server-Sent Events, with a cancel acknowledged in <100 ms (UX-13)."],
  ["NC-06","Alerts","On-screen display for volume/brightness/layout","A","P2","implemented","Brightness is app-local (CSS filter) and labelled as such."],
  // ───────── ST settings
  ["ST-01","Settings","Settings graph: IDs, aliases, lock reasons, history, undo, export/import","A","P1","implemented","Every setting is a typed node with an id, alias list and reversible history row — searchable from the palette."],
  ["ST-02","Settings","Platform-settings index with deep links","A","P1","implemented","Browsers expose no settings deep links; we show exact navigation paths per browser and copyable chrome:// / about: URLs the user must paste (we cannot navigate there)."],
  ["ST-03","Settings","Default-apps / handler guide","A","P2","implemented","registerProtocolHandler + file_handlers, with the real installed state read back from the manifest where possible."],
  ["ST-04","Settings","About / diagnostics: capability report, redacted export","A","P1","implemented","One-click JSON export of the probe, with UA-CH high-entropy values requested only on demand."],
  ["ST-05","Settings","Appearance: theme, accent, density, motion, font scale","A","P1","implemented","All driven by CSS custom properties on :root; prefers-* media queries set the defaults, user choice overrides and persists."],
  ["ST-06","Settings","Shortcut presets + conflict detector","A","P2","implemented","Detector knows browser-reserved combos (Ctrl+T/N/W, Ctrl+Shift+Q…) and refuses to bind them unless running installed/standalone."],
  ["ST-07","Settings","UI scale independent of the browser zoom","A","P2","implemented","Our own rem scale, so it composes with browser zoom instead of fighting it."],
  ["ST-08","Settings","Managed configuration","A","P4","skeleton","JSON policy file fetched from /well-known on first run (enterprise deployment path)."],
  ["ST-09","Settings","Per-context profiles (laptop vs external display)","A","P2","implemented","Auto-switch on screenschange / display-mode change, with a visible banner and one-click revert."],
  // ───────── AP packages
  ["AP-01","Apps","Module info hub (storage, permissions, state)","A","P1","implemented","Per-module storage usage from the VFS + permission state from Permissions.query()."],
  ["AP-02","Apps","Module data reset assistant","A","P3","implemented","Scoped delete with an explicit preview of row counts, undoable for 30 s."],
  ["AP-03","Apps","Install manager","B","P4","skeleton","beforeinstallprompt capture + a catalogue of related PWAs; cannot install packages for the user."],
  ["AP-05","Apps","Background work inventory","B","P4","implemented","Lists our registered Periodic Background Sync / sync tags and their last run; third-party background work is invisible to us."],
  // ───────── TD terminal
  ["TD-01","Terminal","Terminal emulator: tabs, history, ANSI colour, search, safe paste","A","P1","implemented","Hand-written VT subset renderer (no xterm.js dependency) — safe paste strips control bytes and warns on multi-line paste."],
  ["TD-02","Terminal","Local shell over the VFS","A","P1","implemented","Commands run server-side against Postgres (ls/cd/cat/mkdir/touch/write/rm/mv/cp/find/du/grep/tree/ops/json) — a real interpreter, not a canned transcript."],
  ["TD-03","Terminal","Remote shells","A","P2","blocked","No raw TCP in a browser. Only a WebSocket-to-SSH bridge the user hosts would work; not shipped, declared."],
  ["TD-04","Terminal","Linux userland","B","P3","spec","Would require a WASM distro (v86/WASI) — a separate heavyweight module, gated behind an explicit download."],
  // ───────── PR productivity
  ["PR-01","Editor","Text/Markdown editor: encodings, large files, autosave, diff, regex find","A","P1","implemented","Large files stream in 64 KB windows; autosave writes a version row (BK-01) so undo survives a reload."],
  ["PR-02","Notes","Notes: Markdown, backlinks, tags, export","A","P2","implemented","Backlinks resolved server-side with a single ILIKE pass over bodies; export writes real .md files into the VFS."],
  ["PR-03","Tasks","Tasks / reminders","A","P3","skeleton","Notification scheduling is best-effort: Notification Triggers are unavailable, so timers only fire while a tab or the service worker is alive — stated in the UI."],
  ["PR-04","Calendar","Calendar","B","P3","spec","No platform calendar API; ICS import/export is the honest surface."],
  ["PR-05","Contacts","Contacts","A/B","P3","skeleton","Contact Picker API (Chromium/Android) when present, else manual entry; we never store the picked data without consent."],
  ["PR-06","Mail","Mail triage / handoff","A","P2","spec","mailto: handoff plus IMAP only through a user-hosted bridge; no credentials in the browser."],
  ["PR-07a","Browser","Horizontal tab strip","A","P2","implemented","Each tab is an iframe kept alive across tab switches via visibility toggling (removing it would reload the site)."],
  ["PR-07b","Browser","Vertical tab sidebar with groups and search","A","P2","implemented","Same tab model, alternative chrome; drag-reorder uses pointer events, not HTML5 DnD, so it works on touch."],
  ["PR-07c","Browser","Tab groups (named, coloured, collapsible)","A","P2","implemented","Groups are rows in the window state, so they restore with the session."],
  ["PR-07d","Browser","Split tab view — horizontal","A","P3","implemented","Two live iframes with a draggable divider; pointer events are captured on the divider so the drag is not swallowed by the iframes."],
  ["PR-07e","Browser","Split tab view — vertical","A","P3","implemented","Same engine, axis flag."],
  ["PR-07f","Browser","Pinned tabs","A","P2","implemented",""],
  ["PR-07g","Browser","Sleeping tabs","A","P3","implemented","Unload the iframe after N minutes and keep the URL + a snapshot placeholder — the only way to reclaim renderer memory."],
  ["PR-07h","Browser","Desktop user-agent","A","P2","blocked","A page inside an iframe cannot have its UA overridden by the embedder. We tell the truth and offer 'open in new window' instead of faking it."],
  ["PR-07i","Browser","Keyboard shortcuts","A","P2","implemented","Remapped away from browser-reserved combos unless installed standalone (see ST-06)."],
  ["PR-07l","Browser","Per-site permissions","A","P2","implemented","Implemented as the iframe allow= / sandbox= policy, computed per site and shown before load."],
  ["PR-07m","Browser","Download manager integrated with Files","A","P2","implemented","Downloads initiated by us land in the VFS; downloads triggered inside a cross-origin iframe go to the real browser and are labelled as such."],
  ["PR-07n","Browser","Find in page","A","P2","implemented","Works for same-origin content only; cross-origin frames show 'find unavailable' rather than a dead box."],
  ["PR-07o","Browser","Profiles","A","P3","implemented","Profiles scope our per-site sandbox-policy grants (iframe allow=) and our own history only. Real browser partitions (cookies/storage isolation) are not controllable from script — stated in the UI tooltip."],
  ["PR-07p","Browser","Content filter","A","P3","blocked","No request interception for cross-origin iframes; only our own service worker's fetches can be filtered."],
  ["PR-07q","Browser","Batch tab actions","A","P2","implemented",""],
  ["PR-07r","Browser","Session manager (named sessions)","A","P2","implemented","Sessions snapshot windows+tabs+groups+split layout as one JSON row."],
  ["PR-07s","Browser","Cast page media to Beam","A","P3","skeleton","Only works for same-origin media elements (Remote Playback requires an element reference)."],
  ["PR-08","Viewer","PDF / image viewer with annotation","A","P2","implemented","PDFs render through the browser's built-in viewer in a sandboxed frame; annotations are stored as our own overlay layer, exported as a sidecar JSON."],
  ["PR-09","Calc","Calculator: basic/scientific/programmer/units/history","A","P1","implemented","Shunting-yard parser written here (no eval), so palette 'calculate' and the app share one engine."],
  ["PR-11","Office","Office documents via Forge","A/B","P2","implemented","See FF-01: real OOXML parsing with Node zlib, not a mock preview."],
  ["PR-12","Clipboard","Clipboard history, sensitive flag, expiry","A/B","P2","implemented","Browsers only expose the clipboard on user gesture; history therefore records our own copies plus explicit pastes, and says so."],
  ["PR-13","Desktop","Sticky notes on the desktop","A","P3","implemented","Always-on-desktop layer, persisted per workspace."],
  // ───────── FF Forge formats
  ["FF-01","Forge","OOXML open/extract/render (docx, xlsx, pptx)","B","P2","implemented","Real implementation: Node zlib inflateRaw over the ZIP central directory → XML → text/sheet/slide model. No GPL dependency, no cloud conversion, 10 s watchdog + bomb guards."],
  ["FF-02","Forge","Headless convert/extract","A","P2","implemented","Same engine exposed at /api/forge for batch use; returns a fidelity grade with every response."],
  ["FF-03","Forge","PDF render","A","P2","skeleton","Delegated to the browser's own PDF renderer inside a sandboxed frame; annotation is ours."],
  ["FF-05","Forge","Raster open/edit/export","A","P1","implemented","Canvas 2D + OffscreenCanvas in a Worker; export via convertToBlob."],
  ["FF-06","Forge","HEIC/AVIF decode","A/B","P1","implemented","AVIF decodes natively in modern browsers; HEIC does not outside Safari — probed with an actual 1-pixel decode test, then labelled (never a silent failure)."],
  ["FF-07","Forge","HEIC/AVIF encode","B","P2","blocked","Only Safari can encode HEIC; we export AVIF/WebP and show the format-substitution warning (never silent re-encode)."],
  ["FF-08","Forge","PSD parse / composite","B","P3","skeleton","PSD header+layer-record parser is feasible in a Worker; composite fidelity is graded C and labelled before export."],
  ["FF-09","Forge","SVG / MD / CSV / RTF / TXT","A","P2","implemented","SVG is sanitised (script, foreignObject, external refs stripped) before it is ever inlined."],
  ["FF-11","Forge","Save-As with explicit fidelity grade","A","P2","implemented","Every lossy path shows a loss report listing exactly what will be dropped (FF-16)."],
  ["FF-12","Forge","Format sandbox: isolation, watchdog, bomb guards","A","P1","implemented","Server: size/entry/ratio caps + AbortSignal.timeout. Client: Worker with terminate-on-timeout."],
  ["FF-14","Forge","formats registry (format → engine → grade → boundary text)","A","P2","implemented","One table drives routing, the Peek chooser, and the user-facing boundary copy — they cannot drift apart."],
  ["FF-15","Forge","Document lifecycle: open/dirty/save/recover/close","A","P2","implemented","Dirty state is global and survives reload through the version table; beforeunload is only armed when actually dirty."],
  ["FF-17","Forge","Macros disabled by default","A","P2","implemented","vbaProject.bin is detected, reported, and never executed; there is no execution path at all in this implementation."],
  // ───────── MD media & capture
  ["MD-01","Capture","Capture studio: screenshot, recording, annotate, redact","A","P2","implemented","getDisplayMedia + MediaRecorder; the file is committed to the VFS before the editor opens (crash-safety rule from the spec)."],
  ["MD-02","Media","Media player with HW decode, subtitles, PiP, cast button","A","P2","implemented","<video> + Media Session API + Picture-in-Picture + Remote Playback; hardware decode is reported from MediaCapabilities.decodingInfo, not assumed."],
  ["MD-03","Photos","Photo library with non-destructive edits","A","P3","implemented","Gallery over image files under /Home; edits apply a pure-raster recipe (lib/raster.ts, headlessly tested) and save a NEW png — the original file bytes are never rewritten."],
  ["MD-04","Media","Voice recorder","A","P3","implemented","MediaRecorder + waveform from an AnalyserNode."],
  ["MD-06","Media","Audio device panel","A","P3","implemented","enumerateDevices + setSinkId (Chromium) to route output; labelled unavailable elsewhere."],
  ["MD-07","Media","Colour picker","A","P3","implemented","EyeDropper API when present, else canvas sampling of our own surfaces only."],
  ["MD-08","Media","Trim / export","A","P4","skeleton","WebCodecs path when available, else re-record; never silent quality loss."],
  // ───────── SC security
  ["SC-01","Vault","Vault: passwords, passkeys, TOTP, secure notes","A/B","P2","implemented","AES-GCM via WebCrypto with PBKDF2(600k) from the master passphrase; the server stores ciphertext+iv+salt only and has no decryption path. Passkeys via WebAuthn when available."],
  ["SC-02","Vault","Module lock","A","P2","implemented","Re-auth gate on the Vault window; auto-locks on visibilitychange after the configured idle."],
  ["SC-03","Security","Permission audit","A","P2","implemented","Permissions.query() across the full name list with a per-item 'why we would ask' explanation."],
  ["SC-04","Security","Per-app firewall","B","P3","not-applicable","No VpnService analogue. Only our own service-worker fetches can be policed; declared instead of faked."],
  ["SC-05","Security","Privacy dashboard","A","P2","implemented","Shows every network destination our code may contact (it is: this origin) and every stored category."],
  ["SC-06","Security","Secure-window flag","A","P2","skeleton","No FLAG_SECURE on the web; Beam/Lens instead *exclude* vault windows from any capture we control, and warn that OS-level capture cannot be blocked."],
  ["SC-08","Security","Telemetry off by default, local logs, redacted export","A","P1","implemented","There is no telemetry endpoint in the codebase; the audit log is local to your Postgres."],
  ["SC-09","Security","Cast privacy: exclusions, indicator, auto-stop on lock","A","P2","implemented","Capture stops on document hidden if the user chose that policy; the red indicator is non-dismissible while a track is live."],
  // ───────── BK backup
  ["BK-01","Backup","Timeline backup: versioned, verifiable, restorable","B","P2","implemented","Every write creates a version row; snapshots export to a single signed JSON bundle downloadable to disk, and restore re-verifies by hash before committing."],
  ["BK-03","Backup","Config export / import","A","P1","implemented","All settings + layouts + registry statuses in one file."],
  ["BK-05","Backup","Health state + restore drill","A","P2","implemented","Backup is 'healthy' only after a sampled restore actually verified — a status badge, not a claim."],
  ["BK-06","Backup","Key custody: user-held key, no escrow","A","P2","implemented","If the passphrase is lost, the data is gone; this is stated before the first encrypted write."],
  // ───────── CT continuity
  ["CT-01","Continuity","Share send/receive","A","P1","implemented","navigator.share + Web Share Target (installed); receives files straight into the VFS."],
  ["CT-02","Continuity","PC bridge","B","P3","implemented","Same-origin WebRTC data channel between two instances via the /api/signal append-only log; carries text and small files browser-to-browser. Host candidates only (no STUN/TURN), so peers must be directly reachable — declared in the UI."],
  ["CT-05","Continuity","Remote desktop client","A","P3","spec","Only with a user-hosted WebSocket gateway; not bundled."],
  ["CT-06","Continuity","Peripheral manager","A/B","P3","implemented","WebHID / WebUSB / Web Serial / Web Bluetooth device list with per-device grants; every one is behind a user gesture and shown as unavailable on Safari/Firefox."],
  // ───────── CA beam
  ["CA-01","Beam","Audio sender to a remote endpoint","A","P2","implemented","Web equivalent of AirPlay audio = Remote Playback API on an <audio> element (Chromium/Safari surface the OS picker, which includes AirPlay). We never implement RAOP — the browser owns the protocol."],
  ["CA-02","Beam","Video-by-URL sender","A","P2","implemented","Remote Playback on <video>; the media URL is served from this origin with Range support so a receiver can seek."],
  ["CA-04","Beam","Screen mirroring sender","B","P4","blocked","No FairPlay, no web API to mirror the screen to AirPlay. The honest web path is Presentation API to a second display/Chromecast tab. Stated in the UI; the spec's legal gate becomes a platform wall."],
  ["CA-05","Beam","Beam hub: targets, source picker, persistent indicator","A","P2","implemented","Shows the real capability matrix per browser; targets discovered via RemotePlayback.watchAvailability() and PresentationRequest.getAvailability()."],
  ["CA-08","Beam","Cast sender","A","P2","implemented","Presentation API (1-UA and 2-UA) covers Chromecast on Chromium; no SDK, no app-id, because our receiver page is just a URL on this origin."],
  ["CA-10","Beam","DLNA","A","P3","not-applicable","No multicast/SSDP from a browser. Declared impossible rather than stubbed."],
  ["CA-11","Beam","Together: synchronized watch rooms","A","P3","implemented","Server-held epoch clock + per-client drift correction (playbackRate nudging ±5%, hard seek past 400 ms); each participant supplies their own copy of the media (no streaming, no copyright exposure)."],
  ["CA-13","Beam","Quality governor","A","P2","implemented","Driven by the real NetworkInformation downlink + measured frame budget, not by a guess."],
  ["CA-14","Beam","Cast privacy and trust memory","A","P2","implemented","First connection to an unseen target requires confirmation; trust is stored per fingerprint."],
  ["CA-15","Beam","Multi-receiver synchronized playback","A","P3","skeleton","Same epoch clock as Together; drift target ≤40 ms measured, not assumed."],
  // ───────── LN lens
  ["LN-01","Lens","Background blur / replace / remove","A","P2","implemented","Real-time pipeline: getUserMedia → canvas/WebGL. Segmentation uses the browser's own experimental backgroundBlur constraint when present, else a luma/chroma + temporal-stability keyer we implement here (no MediaPipe download, no model licence problem)."],
  ["LN-02","Lens","Auto-framing","A","P2","implemented","Motion-energy centroid with a critically damped spring, so there is no model dependency and no jitter."],
  ["LN-04","Lens","Low-light and denoise","A","P2","implemented","Shader-free: per-frame CLAHE-ish tone curve computed on a downscaled histogram, applied as a canvas filter chain."],
  ["LN-05","Lens","Upscale / sharpen","A","P3","implemented","Unsharp mask via a two-pass canvas; honest about not being super-resolution."],
  ["LN-09","Lens","LUT / colour / vignette","A","P2","implemented","Loadable .cube parsed into a 3D sampling table."],
  ["LN-13","Lens","Presenter mode (person over slides or screen)","A","P2","implemented","Composites getDisplayMedia + the keyed camera onto one canvas; the composite is itself a MediaStream via captureStream(), so it can be recorded or cast."],
  ["LN-15","Lens","Thermal / quality ladder","A","P2","implemented","Measures its own per-frame cost and drops resolution → effects → fps in a defined order, surfacing the current rung."],
  ["LN-20","Lens","Fusion Meet (own client)","A","P2","skeleton","WebRTC peer connection with the Lens composite as the outgoing track; signalling reuses the Together room table."],
  ["LN-21","Lens","Lens output into other web conferencing pages","A","P2","blocked","We cannot inject a virtual camera into a cross-origin page: no extension, no getUserMedia override across origins. The only truthful routes are Fusion Meet, recording, and the OS-level virtual-camera companion. This is the exact web analogue of the Android VirtualDeviceManager wall."],
  ["LN-22","Lens","Virtual camera for native apps","X","—","not-applicable","Impossible from a web page by construction. Stated on the Lens panel so nobody ships a fake."],
  ["LN-23","Lens","Record / stream out","A","P2","implemented","MediaRecorder on the composite stream, written straight into the VFS."],
  // ───────── MS messages
  ["MS-01","Messages","iMessage via the user's own Mac bridge","A/B","P3","skeleton","Client speaks a BlueBubbles-shaped REST/socket API to a server the *user* runs. Without that host, the panel says 'not connected' — it never simulates iMessage."],
  ["MS-02","Messages","iMessage without Apple hardware","X","—","blocked","SSPL-licensed stacks and private FairPlay certificates: inadmissible. Documented as impossible-for-us."],
  ["MS-04","Messages","RCS","C","—","not-applicable","No third-party RCS API on any platform, let alone the web."],
  ["MS-05","Messages","SMS/MMS","B","P3","not-applicable","The web has no SMS send API (only OTP autofill reception). Declared."],
  ["MS-06","Messages","Matrix / XMPP / local threads","A","P3","implemented","Local threads are fully functional against Postgres; Matrix is a homeserver URL the user supplies."],
  // ───────── AX accessibility
  ["AX-01","Access","Semantics everywhere; compositor exposes panes","A","P1","implemented","Each window is role=dialog/region with aria-label, aria-modal=false, plus a live region announcing move/resize/tile results."],
  ["AX-02","Access","Keyboard-complete shell","A","P1","implemented","Release gate: every pointer action has a key path, and focus is trapped only where it must be."],
  ["AX-03","Access","Display adaptation","A","P1","implemented","prefers-reduced-motion, prefers-contrast, forced-colors and font-size scaling honoured."],
  ["AX-04","Access","Pointer, touch, trackpad behaviours, focus rings","A","P1","implemented",":focus-visible rings never removed; touch targets 48 px in Touch density."],
  ["AX-08","Access","Accessibility test harness","A","P1","implemented","In-app self-test runs axe-style structural checks (roles, names, tab order) against the live DOM."],
  // ───────── AU automation
  ["AU-01","Auto","Routines: triggers and actions with dry-run and audit","A/B","P3","implemented","Triggers: app open, time, display change, cast start. Every run writes an audit row; dry-run is the default."],
  ["AU-02","Auto","Workspace presets","A","P2","implemented",""],
  ["AU-05","Auto","Automation API for third parties","A","P3","implemented","POST /api/command with a signed token; the same command registry the palette uses."],
  // ───────── RG runtime governor
  ["RG-01","Runtime","Thermal / load governor (5 states)","A","P1","implemented","No thermal API on the web, so the state machine is driven by measured frame cost, long-task counts, memory pressure and battery — and the UI names the evidence for the current state."],
  ["RG-03","Runtime","Refresh-rate policy","A","P1","implemented","rAF cadence measured; animation complexity is reduced rather than frame-skipped."],
  ["RG-04","Runtime","Resource monitor","A/B","P1","implemented","performance.memory (Chromium), measureUserAgentSpecificMemory when crossOriginIsolated, long-task observer, storage estimate, and our own SQL row counts."],
  ["RG-06","Runtime","Battery / metered awareness","A","P2","implemented","Background work (index, backup, folder sizes) pauses on saveData or battery <20% and says why."],
  ["RG-07","Runtime","Low-memory mode","A","P2","implemented","Sleeps tabs, drops previews, reduces version retention."],
  ["RG-08","Runtime","Capability report and per-feature routing","A","P1","implemented","One probe object; every feature asks the probe instead of user-agent sniffing."],
  // ───────── BL commerce
  ["BL-01","Commerce","One-time purchase + Pro pack","A","P1","skeleton","Entitlement issuance endpoint is stubbed for a payment provider; the verification half (HMAC signature) is real."],
  ["BL-02","Commerce","Offline-tolerant entitlement cache","A","P1","implemented","Signed blob verified server-side, cached locally; expiry has a grace window so an offline user never loses features."],
  ["BL-04","Commerce","14-day trial then nag-free degraded state","A","P1","implemented","Degraded = read-only Files/Find. No ads, no interstitials, no dark patterns (DP-02)."],
  ["BL-05","Commerce","Refund-safe revocation","A","P1","implemented","Revocation never deletes user data; it only flips the entitlement flag."],
  // ───────── verification
  ["PR-10","Clock","Countdown timers (fire while the tab is alive)","A","P3","implemented","Timers are task rows with a due time. They fire only while the tab or installed app is running; no background alarm API exists for web apps."],
  ["VR-01","Verify","Window-engine invariant suite","A","P1","implemented","Pure reducer property checks (title bar on screen, min size, total z-order, idempotent commands) run live at /api/selftest and in the Verify app."],
  ["VR-02","Verify","File-op journal recovery test","A","P1","implemented","Injects an interrupt before/after publish and asserts the documented outcome (source authoritative / keep-both)."],
  ["VR-03","Verify","Capability-honesty detector","A","P1","implemented","Fails the build-time self-test if any feature marked 'implemented' depends on a probe that reports unavailable."],
  ["VR-04","Verify","Negative-space assertions","A","P1","implemented","Explicit tests that we do NOT claim: virtual camera, RCS, DLNA, cross-origin UA override, iMessage without a Mac."],
];

/**
 * Status corrections (v2.2 audit). The v2.1 build over-claimed these rows: their code was a skeleton, a
 * partial, or absent. Each entry is applied on top of the row's original status. Newly built rows are
 * upgraded here too. The traceability gate (scripts/traceability.mjs) and the self-test read this final status.
 */
const OVERRIDES: Record<string, string> = {
  // → partial (some of the row exists, the rest is named in the nuance)
  "SH-04": "partial", "SH-07": "partial", "SH-09": "partial", "SH-10": "partial",
  "WM-07": "partial", "WM-13": "partial",
  "SR-02": "partial", "SR-03": "partial", "SR-06": "partial",
  "FM-01": "partial", "FM-03": "partial", "FM-10": "partial", "FM-15": "partial", "FM-17": "partial", "FM-18": "partial",
  "NC-01": "partial", "NC-02": "partial", "NC-03": "partial", "NC-05": "partial",
  "ST-01": "partial", "ST-02": "partial", "ST-05": "partial", "ST-07": "partial", "ST-09": "partial",
  "AP-05": "partial", "TD-01": "partial", "PR-01": "partial", "PR-02": "partial", "PR-07b": "partial", "PR-07g": "partial",
  "PR-08": "partial", "PR-09": "partial", "FF-03": "partial", "FF-06": "partial",
  "FF-15": "partial", "MD-01": "partial", "MD-02": "partial", "MD-06": "partial",
  "BK-01": "partial", "BK-05": "partial", "BK-06": "partial", "CT-01": "partial", "CT-06": "partial",
  "CA-01": "partial", "CA-02": "partial", "CA-05": "partial", "CA-08": "partial", "CA-11": "partial", "CA-14": "partial",
  "LN-01": "partial", "LN-04": "partial", "LN-13": "partial", "LN-15": "partial", "LN-23": "partial",
  "MS-06": "partial", "AX-01": "partial", "AX-02": "partial", "AX-03": "partial", "AX-04": "partial",
  "RG-01": "partial", "RG-04": "partial", "RG-06": "partial", "RG-07": "partial",
  "SC-01": "partial", "BL-02": "partial", "BL-04": "partial", "BL-05": "partial",
  // → skeleton (declared, not built)
  "WM-08": "skeleton", "WM-12": "skeleton", "FM-04": "skeleton", "FM-05": "skeleton",
  "FM-06": "skeleton", "FM-07": "skeleton", "FM-13": "skeleton", "FM-14": "skeleton", 
  "NC-06": "skeleton", "AP-01": "skeleton", "AP-02": "skeleton", 
  "PR-07i": "skeleton", "PR-07l": "skeleton", "PR-07m": "skeleton", "PR-07n": "skeleton",
  "PR-13": "skeleton",
  "FF-14": "skeleton", "SC-02": "skeleton", "SC-09": "skeleton", "CA-13": "skeleton",
  "LN-02": "skeleton", "LN-05": "skeleton", "LN-09": "skeleton", "AX-08": "skeleton", "RG-03": "skeleton",
  "FM-09": "spec",
  // → implemented (built and verified in this turn; see tests/e2e and the self-test)
  "SH-05": "implemented", "SH-06": "implemented", "SH-11": "implemented", "WM-10": "implemented", "WM-11": "implemented",
  "NC-04": "implemented", "ST-06": "implemented", "ST-08": "implemented", "SR-04": "implemented",
  "AU-01": "implemented", "AU-02": "implemented", "AU-05": "implemented", "BK-03": "implemented",
  "LN-20": "implemented", "FF-08": "implemented", "FF-17": "implemented", "MD-04": "implemented", "MD-07": "implemented",
  "PR-03": "implemented", "PR-04": "implemented", "SC-03": "implemented", "SC-05": "implemented",
  // v2.3: these now have a real path (see the per-row ledger acceptance cases).
  "SR-05": "implemented", "PR-07c": "implemented", "PR-07f": "implemented", "PR-07r": "implemented",
  "PR-07d": "implemented", "PR-07e": "implemented", "PR-07q": "implemented", "PR-07o": "implemented",
  "SR-08": "partial", "CT-02": "implemented", "MD-03": "implemented", "WM-06": "implemented",
  "ST-03": "implemented", "PR-05": "implemented", "PR-06": "implemented", "PR-11": "implemented", "PR-12": "implemented", "FF-11": "implemented",
  "FF-01": "implemented", "FF-05": "implemented", "FF-09": "implemented",
};

// Replace inherited v2.1 claims that were materially stronger than this web implementation.
const HONEST_NUANCE: Record<string, string> = {
  "SH-08": "DesktopState is debounced to Postgres; there is no pre-hydration localStorage mirror. A reload restores geometry; concurrent clients still share one layout row.",
  "SH-10": "Capability probe + Fullscreen + Wake Lock prompts only. No verified external-display routing or phone blackout on a real device.",
  "SH-03": "Own top bar with status and clock. No OS chrome control and no live Beam indicator until a receiver/device test exists.",
  "WM-03": "Named workspaces can be added/switched; no reordering. Inactive workspace windows unmount and media/iframes may restart.",
  "WM-04": "Window metadata cards in Overview; no live thumbnail or cross-origin capture.",
  "WM-06": "Third-party URLs render in sandboxed iframes, with a real-browser link. A server HEAD preflight is restricted to vetted reference hosts to avoid SSRF and is advisory only.",
  "SR-02": "Literal SQL substring search over local rows. No FTS index, health coverage UI, watcher or churn quarantine.",
  "SR-03": "Case-insensitive literal substring ranking. No semantic embeddings or genuine fuzzy edit-distance matching.",
  "SR-04": "Opt-in Wikipedia OpenSearch results are shown separately after a debounce, never merged into the local ranking. Off by default; this is not general web search.",
  "SR-05": "Path-scoped VFS-only search uses a recursive descendant query, excludes Trash and rejects an invalid scope. No Android private-app access.",
  "SR-08": "Why-missing reports literal filename matches inside/outside the chosen folder or in Trash; it does not diagnose unindexed external files.",
  "FM-03": "DB-only file operations have a journal and injectable interruption. Copy publication / cross-volume move recovery and undo are not production-grade; the ledger grades this partial.",
  "FM-18": "DB-VFS saves update content, byte size and version history in one transaction with optimistic version checks. External SAF / real-file provider atomicity is not implemented.",
  "PR-07a": "Horizontal tab rail backed by stable iframe nodes, but cross-origin sites can refuse iframe embedding; ↗ opens a real browser tab.",
  "PR-07b": "Vertical tab rail includes group headers. Drag-reordering and tab search are not implemented.",
  "PR-07c": "Named coloured collapsible tab groups persist with each Browser window session. They do not partition cookies or storage.",
  "PR-07d": "Two stable iframes arranged left/right with pointer- and keyboard-resizable divider. Receiver-page / same-origin tests only; third-party CSP can block embed.",
  "PR-07e": "Two stable iframes arranged top/bottom with pointer- and keyboard-resizable divider. Receiver-page / same-origin tests only; third-party CSP can block embed.",
  "PR-07f": "Pinned tabs remain mounted and survive the sleep timer and close-to-right/others/duplicates batch actions; pin state persists in the window session.",
  "PR-07q": "Close duplicates, others and tabs to the right (pinned tabs protected). Bookmark-all and multi-select-to-window/send are not built.",
  "PR-07r": "Named sessions persist tabs, groups, pinned state and split geometry in app.browserSessions; no cookies, password state or browser process history is snapshotted.",
  "BK-01": "Content versions and JSON snapshot *download* exist; snapshot is a plain digest, not signed/encrypted, and POST verifies but does not restore. Not a tested disaster-recovery solution.",
  "BL-02": "HMAC token is generated by the server, but offline client verification and secure purchase are not implemented. Dev-only entitlement flow.",
  "FF-01": "Own XML/ZIP engine reads and writes DOCX (paragraphs, runs, simple tables) and PPTX (slide text boxes on a blank layout); XLSX via the model layer. Layout, themes, images and charts are not reproduced.",
  "FF-05": "Pure raster engine: crop/resize/bilinear/rotate90/arbitrary-rotate/flip/brightness/contrast/saturation/grayscale/invert/blur/sharpen/equalize/sepia/threshold/posterize/vignette/noise/edges plus production filters (pixelate, duotone, hue-shift, levels, curves, motion-blur, oil-paint, frame, colour-balance) — all non-destructive via an edit recipe; export via the browser's PNG/JPEG/WebP encoders. The Layers app adds opacity/visibility/order, integer translations, normal/multiply/screen blending, alpha masks, bounded undo/redo, lossless .fusion-layers.json projects, PNG flattening and explicit Files saves. No PSD layer write-back, colour management or RAW support.",
  "FF-09": "SVG parsed and rebuilt from a tag/attribute allow-list (script, handlers, foreignObject, external refs and style removed; viewBox preserved), plus an editable rect/circle/ellipse/line/polyline/polygon/path/text/star/arrow/group model with linear/radial gradients that round-trips. Bar, line and pie charts are generated from Calc ranges and pass the same sanitiser. Vector geometry adds pointer selection/drag, numeric movement, centered scale/rotation, canvas alignment and stacking with undo/redo. Matrix/translate/scale/rotate transforms supported; text/path hit boxes remain estimates. No SVG filters, full gradient editing or font embedding; no log axes, stacked series or data-label formats.",
  "FF-02": "Headless parse, formula evaluation and write-back for the supported subset. 216 functions (measured: 96 base + 23 extension + 19 dynamic arrays + 86 advanced): math, statistics (incl. STDEV.S/P, PERCENTILE.INC, RANK.EQ), logic, text (incl. TEXTBEFORE/TEXTAFTER, TEXTSPLIT, ARRAYTOTEXT, VALUETOTEXT), lookup (VLOOKUP/HLOOKUP/INDEX/MATCH/XLOOKUP with exact, approximate and wildcard modes), multi-criteria conditionals (SUMIFS/COUNTIFS/AVERAGEIFS/MAXIFS/MINIFS), financial (PMT/FV/PV/NPV/IRR), dates (DATEDIF, NETWORKDAYS, WORKDAY), and modern dynamic arrays (SEQUENCE, RANDARRAY, CHOOSEROWS, CHOOSECOLS, TAKE, DROP, EXPAND, TOCOL, TOROW, WRAPROWS, WRAPCOLS, VSTACK, HSTACK, FILTER, SORT, UNIQUE). Also: conditional-format/validation/autoFilter/named-range metadata read/write (UI edit enforcement, full expression-rule evaluation and named-range formula resolution are not complete), XLSX styles (bold/italic/numFmt/fill), column widths, freeze panes. Not implemented: XLOOKUP binary-search modes (return #VALUE!), LET/LAMBDA, pivot tables, charts embedded directly inside the binary file, data tables. Cached values are recomputed, never trusted. Calc now uses calculateWorkbook for bounded spill placement, read-only children, obstruction diagnostics and dependent-cell recomputation (20,000 generated cells / 8 passes). The legacy evaluator retains top-left scalar semantics. Values snapshots flatten results and remove formulas; Excel spill metadata, Tables/merged-cell spill rules and # references are not supported.",
  "FF-11": "Every Office export returns grade C plus a loss report naming dropped feature classes before the user saves.",
  "PR-11": "Editable Writer/Calc subset in the Office app (paragraphs, runs, cells, formulas, CSV). The UI supports bounded spill calculation, generated read-only children and SVG charts. No LibreOffice parity: no layout engine, complete style cascade, pivots, macros, or verified Excel spill-file interoperability.",
  "LN-20": "Two browsers can directly negotiate WebRTC audio/video via Postgres signalling with fake-device browser tests. No STUN/TURN, real-network validation or Lens composite as a track yet.",
  "ST-03": "Reads this PWA’s manifest file/share declarations and conditionally requests a web+fusion protocol handler. Browser installation/default approval remains user-controlled.",
  "PR-05": "Manual local contacts plus conditional Contact Picker import and JSON export. No background address-book access, sync, merge or system write-back.",
  "PR-06": "Validates and encodes a mailto handoff to the user’s default mail application. No IMAP account, inbox, send confirmation or credentials.",
  "PR-12": "History contains only text copied here or read after an explicit gesture. Sensitive rows expire after 60 seconds. No global passive clipboard capture.",
};

export const FEATURES: FeatureRow[] = R.map(([id, area, title, tier, phase, status, webNuance]) => ({
  id,
  area,
  title,
  tier,
  phase,
  status: OVERRIDES[id] ?? status,
  webNuance: HONEST_NUANCE[id] ?? webNuance,
}));

export const AREAS = Array.from(new Set(FEATURES.map((f) => f.area)));
