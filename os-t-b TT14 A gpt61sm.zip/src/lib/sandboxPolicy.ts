// WM-06 / FF-12 sandbox policy engine: the web's real sandbox is the iframe allow= + sandbox=
// attributes (plus COOP/COEP on the top-level document, set in next.config.ts). This module computes
// them per origin from a rules table so the Browser never ships a blanket policy. Pure and
// unit-tested in /api/selftest.

export type SiteRule = {
  origin: string; // exact host, e.g. "example.com"; "*" = default
  allow: string[]; // Permissions-Policy features to allow inside the frame
  sandbox: string[]; // sandbox tokens; empty = most permissive
  label: string;
};

// The default rule deliberately omits allow-same-origin: without it the frame's storage and
// credentials are partitioned, so a framed app cannot reach this shell's origin state.
const DEFAULT_RULE: SiteRule = {
  origin: "*",
  allow: [],
  sandbox: ["allow-scripts", "allow-forms", "allow-popups"],
  label: "default (no same-origin: storage and credentials are partitioned)",
};

const RULES: SiteRule[] = [
  { origin: "example.com", allow: [], sandbox: ["allow-scripts", "allow-same-origin", "allow-forms"], label: "demo (same-origin for the demo page)" },
  { origin: "wikipedia.org", allow: [], sandbox: ["allow-scripts", "allow-same-origin", "allow-forms"], label: "reference" },
  { origin: "news.ycombinator.com", allow: [], sandbox: ["allow-scripts", "allow-same-origin", "allow-forms"], label: "forum" },
];

export function ruleFor(url: string): SiteRule {
  let host = "";
  try {
    host = new URL(url).hostname;
  } catch {
    return { ...DEFAULT_RULE, label: "invalid URL (scripts allowed, nothing else)" };
  }
  return RULES.find((r) => r.origin === host) ?? { ...DEFAULT_RULE, origin: host };
}

/** iframe allow uses feature 'none' / feature *, not the HTTP header's feature=() syntax. */
export function allowAttribute(rule: SiteRule, extraAllow: string[] = []): string {
  const all = KNOWN_FEATURES;
  const granted = new Set([...rule.allow, ...extraAllow]);
  return all.map((f) => `${f} ${granted.has(f) ? "*" : "'none'"}`).join("; ");
}

export function sandboxAttribute(rule: SiteRule): string | undefined {
  return rule.sandbox.length ? rule.sandbox.join(" ") : undefined;
}

export function policyFor(url: string, extraAllow: string[] = []): { rule: SiteRule; allow: string; sandbox?: string } {
  const rule = ruleFor(url);
  return { rule, allow: allowAttribute(rule, extraAllow), sandbox: sandboxAttribute(rule) };
}

export const KNOWN_FEATURES = ["camera", "microphone", "geolocation", "fullscreen", "clipboard-read", "clipboard-write", "autoplay", "payment"];
