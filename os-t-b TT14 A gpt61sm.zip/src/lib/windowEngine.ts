/**
 * WM-01..WM-16 — pure window engine.
 * No DOM, no React, no time source: (state, command) -> state is deterministic,
 * so the same reducer runs in the browser, on the server (/api/selftest) and in tests.
 */

export type Rect = { x: number; y: number; w: number; h: number };
export type Density = "compact" | "balanced" | "touch";

export type WindowState = {
  id: string;
  module: string;
  title: string;
  docId?: string;
  rect: Rect;
  prevRect?: Rect;
  z: number;
  minimized: boolean;
  maximized: boolean;
  workspace: number;
  alwaysOnTop: boolean;
  tile?: string;
};

export type DesktopState = {
  version: number;
  windows: WindowState[];
  focus: string | null;
  workspace: number;
  workspaces: { id: number; name: string }[];
  viewport: { w: number; h: number };
  density: Density;
  nextZ: number;
  seq: number;
};

export type WindowCommand =
  | { t: "open"; module: string; title: string; docId?: string; rect?: Partial<Rect> }
  | { t: "close"; id: string }
  | { t: "focus"; id: string }
  | { t: "move"; id: string; x: number; y: number }
  | { t: "resize"; id: string; w: number; h: number; x?: number; y?: number }
  | { t: "minimize"; id: string }
  | { t: "restore"; id: string }
  | { t: "maximize"; id: string }
  | { t: "tile"; id: string; zone: TileZone }
  | { t: "toTop"; id: string; on: boolean }
  | { t: "toWorkspace"; id: string; workspace: number }
  | { t: "switchWorkspace"; workspace: number }
  | { t: "addWorkspace"; name?: string }
  | { t: "renameWorkspace"; workspace: number; name: string }
  | { t: "viewport"; w: number; h: number }
  | { t: "density"; density: Density }
  | { t: "cycle"; dir: 1 | -1 }
  | { t: "closeAll" }
  | { t: "hydrate"; state: DesktopState };

export type TileZone =
  | "left" | "right" | "top" | "bottom"
  | "tl" | "tr" | "bl" | "br"
  | "third-l" | "third-c" | "third-r"
  | "center" | "full";

/** Invariant constants (spec §5.4, BUG-06). */
export const TITLEBAR_VISIBLE_PX = 48;
export const MIN_SIZE: Record<Density, { w: number; h: number }> = {
  compact: { w: 240, h: 180 },
  balanced: { w: 280, h: 200 },
  touch: { w: 320, h: 240 },
};
export const SHELL_TOP = 36; // top bar
export const SHELL_BOTTOM = 52; // shelf

export function workArea(s: DesktopState): Rect {
  return { x: 0, y: SHELL_TOP, w: s.viewport.w, h: Math.max(120, s.viewport.h - SHELL_TOP - SHELL_BOTTOM) };
}

export function initialState(viewport = { w: 1440, h: 900 }): DesktopState {
  return {
    version: 2,
    windows: [],
    focus: null,
    workspace: 1,
    workspaces: [
      { id: 1, name: "Main" },
      { id: 2, name: "Media" },
    ],
    viewport,
    density: "balanced",
    nextZ: 1,
    seq: 1,
  };
}

function clampRect(s: DesktopState, r: Rect): Rect {
  const wa = workArea(s);
  const min = MIN_SIZE[s.density];
  const w = Math.max(min.w, Math.min(r.w, Math.max(min.w, wa.w)));
  const h = Math.max(min.h, Math.min(r.h, Math.max(min.h, wa.h)));
  // Invariant: at least TITLEBAR_VISIBLE_PX of the title bar stays reachable.
  const x = Math.max(wa.x - w + TITLEBAR_VISIBLE_PX, Math.min(r.x, wa.x + wa.w - TITLEBAR_VISIBLE_PX));
  const y = Math.max(wa.y, Math.min(r.y, wa.y + wa.h - TITLEBAR_VISIBLE_PX));
  return { x: Math.round(x), y: Math.round(y), w: Math.round(w), h: Math.round(h) };
}

export function tileRect(s: DesktopState, zone: TileZone): Rect {
  const a = workArea(s);
  const half = { w: Math.round(a.w / 2), h: Math.round(a.h / 2) };
  const third = Math.round(a.w / 3);
  switch (zone) {
    case "left": return { x: a.x, y: a.y, w: half.w, h: a.h };
    case "right": return { x: a.x + half.w, y: a.y, w: a.w - half.w, h: a.h };
    case "top": return { x: a.x, y: a.y, w: a.w, h: half.h };
    case "bottom": return { x: a.x, y: a.y + half.h, w: a.w, h: a.h - half.h };
    case "tl": return { x: a.x, y: a.y, w: half.w, h: half.h };
    case "tr": return { x: a.x + half.w, y: a.y, w: a.w - half.w, h: half.h };
    case "bl": return { x: a.x, y: a.y + half.h, w: half.w, h: a.h - half.h };
    case "br": return { x: a.x + half.w, y: a.y + half.h, w: a.w - half.w, h: a.h - half.h };
    case "third-l": return { x: a.x, y: a.y, w: third, h: a.h };
    case "third-c": return { x: a.x + third, y: a.y, w: third, h: a.h };
    case "third-r": return { x: a.x + 2 * third, y: a.y, w: a.w - 2 * third, h: a.h };
    case "center": return { x: a.x + Math.round(a.w / 8), y: a.y + Math.round(a.h / 8), w: Math.round(a.w * 0.75), h: Math.round(a.h * 0.75) };
    case "full": default: return { ...a };
  }
}

function cascade(s: DesktopState): Rect {
  const a = workArea(s);
  const n = s.windows.filter((w) => w.workspace === s.workspace).length;
  const off = (n % 8) * 28;
  return {
    x: a.x + 60 + off,
    y: a.y + 24 + off,
    w: Math.min(880, Math.round(a.w * 0.62)),
    h: Math.min(620, Math.round(a.h * 0.72)),
  };
}

function patch(s: DesktopState, id: string, fn: (w: WindowState) => WindowState): DesktopState {
  return { ...s, windows: s.windows.map((w) => (w.id === id ? fn(w) : w)) };
}

export function reduce(s: DesktopState, c: WindowCommand): DesktopState {
  switch (c.t) {
    case "hydrate":
      return normalize(c.state);
    case "open": {
      const existingDoc = c.docId
        ? s.windows.find((w) => w.module === c.module && w.docId === c.docId)
        : undefined;
      if (existingDoc) return reduce(s, { t: "focus", id: existingDoc.id });
      const id = `w${s.seq}`;
      const base = { ...cascade(s), ...(c.rect ?? {}) } as Rect;
      const win: WindowState = {
        id,
        module: c.module,
        title: c.title,
        docId: c.docId,
        rect: clampRect(s, base),
        z: s.nextZ,
        minimized: false,
        maximized: false,
        workspace: s.workspace,
        alwaysOnTop: false,
      };
      return { ...s, windows: [...s.windows, win], focus: id, nextZ: s.nextZ + 1, seq: s.seq + 1 };
    }
    case "close": {
      const rest = s.windows.filter((w) => w.id !== c.id);
      const focus =
        s.focus === c.id
          ? [...rest].filter((w) => w.workspace === s.workspace && !w.minimized).sort((a, b) => b.z - a.z)[0]?.id ?? null
          : s.focus;
      return { ...s, windows: rest, focus };
    }
    case "closeAll":
      return { ...s, windows: [], focus: null };
    case "focus": {
      const w = s.windows.find((x) => x.id === c.id);
      if (!w) return s;
      if (s.focus === c.id && w.z === s.nextZ - 1 && !w.minimized) return s; // idempotent
      const next = patch(s, c.id, (x) => ({ ...x, z: s.nextZ, minimized: false }));
      return { ...next, focus: c.id, nextZ: s.nextZ + 1, workspace: w.workspace };
    }
    case "move":
      return patch(s, c.id, (w) => ({
        ...w,
        maximized: false,
        tile: undefined,
        rect: clampRect(s, { ...w.rect, x: c.x, y: c.y }),
      }));
    case "resize":
      return patch(s, c.id, (w) => ({
        ...w,
        maximized: false,
        tile: undefined,
        rect: clampRect(s, { x: c.x ?? w.rect.x, y: c.y ?? w.rect.y, w: c.w, h: c.h }),
      }));
    case "minimize": {
      const next = patch(s, c.id, (w) => ({ ...w, minimized: true }));
      const focus =
        s.focus === c.id
          ? next.windows.filter((w) => w.workspace === s.workspace && !w.minimized).sort((a, b) => b.z - a.z)[0]?.id ?? null
          : s.focus;
      return { ...next, focus };
    }
    case "restore":
      return reduce(
        patch(s, c.id, (w) => ({
          ...w,
          minimized: false,
          maximized: false,
          tile: undefined,
          rect: w.prevRect ? clampRect(s, w.prevRect) : w.rect,
          prevRect: undefined,
        })),
        { t: "focus", id: c.id },
      );
    case "maximize": {
      const w = s.windows.find((x) => x.id === c.id);
      if (!w) return s;
      if (w.maximized) return reduce(s, { t: "restore", id: c.id });
      return reduce(
        patch(s, c.id, (x) => ({ ...x, maximized: true, prevRect: x.prevRect ?? x.rect, rect: clampRect(s, tileRect(s, "full")), tile: "full" })),
        { t: "focus", id: c.id },
      );
    }
    case "tile": {
      const w = s.windows.find((x) => x.id === c.id);
      if (!w) return s;
      return reduce(
        patch(s, c.id, (x) => ({
          ...x,
          minimized: false,
          maximized: c.zone === "full",
          prevRect: x.prevRect ?? x.rect,
          rect: clampRect(s, tileRect(s, c.zone)),
          tile: c.zone,
        })),
        { t: "focus", id: c.id },
      );
    }
    case "toTop":
      return patch(s, c.id, (w) => ({ ...w, alwaysOnTop: c.on }));
    case "toWorkspace": {
      if (!s.workspaces.some((w) => w.id === c.workspace)) return s;
      return patch(s, c.id, (w) => ({ ...w, workspace: c.workspace }));
    }
    case "switchWorkspace": {
      if (!s.workspaces.some((w) => w.id === c.workspace)) return s;
      const top = s.windows
        .filter((w) => w.workspace === c.workspace && !w.minimized)
        .sort((a, b) => b.z - a.z)[0];
      return { ...s, workspace: c.workspace, focus: top?.id ?? null };
    }
    case "addWorkspace": {
      const id = Math.max(0, ...s.workspaces.map((w) => w.id)) + 1;
      return { ...s, workspaces: [...s.workspaces, { id, name: c.name ?? `Space ${id}` }] };
    }
    case "renameWorkspace":
      return {
        ...s,
        workspaces: s.workspaces.map((w) => (w.id === c.workspace ? { ...w, name: c.name } : w)),
      };
    case "viewport": {
      const next = { ...s, viewport: { w: Math.max(320, c.w), h: Math.max(320, c.h) } };
      return {
        ...next,
        windows: next.windows.map((w) => ({
          ...w,
          rect: clampRect(next, w.tile ? tileRect(next, w.tile as TileZone) : w.rect),
        })),
      };
    }
    case "density": {
      const next = { ...s, density: c.density };
      return { ...next, windows: next.windows.map((w) => ({ ...w, rect: clampRect(next, w.rect) })) };
    }
    case "cycle": {
      const list = s.windows
        .filter((w) => w.workspace === s.workspace)
        .sort((a, b) => a.id.localeCompare(b.id, undefined, { numeric: true }));
      if (list.length === 0) return s;
      const i = Math.max(0, list.findIndex((w) => w.id === s.focus));
      const n = (i + (c.dir === 1 ? 1 : list.length - 1)) % list.length;
      return reduce(s, { t: "focus", id: list[n].id });
    }
    default:
      return s;
  }
}

/** Repair a persisted/foreign state so invariants hold before it is ever rendered. */
export function normalize(raw: DesktopState): DesktopState {
  const base = initialState(raw?.viewport ?? { w: 1440, h: 900 });
  const s: DesktopState = { ...base, ...raw, version: 2 };
  const seen = new Set<string>();
  const windows = (s.windows ?? [])
    .filter((w) => w && typeof w.id === "string" && !seen.has(w.id) && (seen.add(w.id), true))
    .map((w) => ({
      ...w,
      workspace: s.workspaces.some((k) => k.id === w.workspace) ? w.workspace : s.workspaces[0].id,
      rect: clampRect(s, w.rect ?? { x: 80, y: 80, w: 640, h: 440 }),
    }));
  // Total z-order invariant: strictly increasing, no ties.
  const ordered = [...windows].sort((a, b) => a.z - b.z).map((w, i) => ({ ...w, z: i + 1 }));
  const nextZ = ordered.length + 1;
  const focus = ordered.some((w) => w.id === s.focus) ? s.focus : (ordered[ordered.length - 1]?.id ?? null);
  const seq = Math.max(s.seq ?? 1, ...ordered.map((w) => Number(w.id.replace(/\D/g, "")) + 1), 1);
  return { ...s, windows: ordered, nextZ, focus, seq };
}

/** VR-01: machine-checkable invariants. Returned by /api/selftest. */
export type Violation = { rule: string; detail: string };

export function checkInvariants(s: DesktopState): Violation[] {
  const v: Violation[] = [];
  const wa = workArea(s);
  const min = MIN_SIZE[s.density];
  const zs = new Set<number>();
  for (const w of s.windows) {
    if (w.rect.w < min.w - 0.5 || w.rect.h < min.h - 0.5)
      v.push({ rule: "min-size", detail: `${w.id} ${w.rect.w}x${w.rect.h} < ${min.w}x${min.h}` });
    const titleRight = w.rect.x + w.rect.w;
    if (titleRight < wa.x + TITLEBAR_VISIBLE_PX || w.rect.x > wa.x + wa.w - TITLEBAR_VISIBLE_PX)
      v.push({ rule: "titlebar-reachable-x", detail: `${w.id} x=${w.rect.x}` });
    if (w.rect.y < wa.y - 0.5 || w.rect.y > wa.y + wa.h - TITLEBAR_VISIBLE_PX + 0.5)
      v.push({ rule: "titlebar-reachable-y", detail: `${w.id} y=${w.rect.y}` });
    if (zs.has(w.z)) v.push({ rule: "total-z-order", detail: `duplicate z=${w.z}` });
    zs.add(w.z);
    if (!s.workspaces.some((k) => k.id === w.workspace))
      v.push({ rule: "workspace-exists", detail: `${w.id} ws=${w.workspace}` });
  }
  if (s.focus && !s.windows.some((w) => w.id === s.focus))
    v.push({ rule: "focus-exists", detail: `focus=${s.focus}` });
  if (s.windows.some((w) => w.z >= s.nextZ)) v.push({ rule: "nextZ-monotonic", detail: `nextZ=${s.nextZ}` });
  return v;
}

/** Deterministic randomized exercise used by the self-test (seeded LCG, no Math.random). */
export function fuzz(steps = 600, seed = 12345): { state: DesktopState; violations: Violation[]; applied: number } {
  let x = seed >>> 0;
  const rnd = () => ((x = (1664525 * x + 1013904223) >>> 0) / 4294967296);
  const pick = <T,>(a: T[]) => a[Math.floor(rnd() * a.length)];
  let s = initialState({ w: 1280, h: 800 });
  const zones: TileZone[] = ["left", "right", "top", "bottom", "tl", "tr", "bl", "br", "third-l", "third-c", "third-r", "center", "full"];
  let applied = 0;
  const violations: Violation[] = [];
  for (let i = 0; i < steps; i++) {
    const ids = s.windows.map((w) => w.id);
    const id = ids.length ? pick(ids) : null;
    const roll = rnd();
    let cmd: WindowCommand;
    if (!id || roll < 0.18) cmd = { t: "open", module: pick(["files", "editor", "terminal", "notes"]), title: "W" };
    else if (roll < 0.26) cmd = { t: "close", id };
    else if (roll < 0.42) cmd = { t: "move", id, x: Math.round(rnd() * 3000 - 1200), y: Math.round(rnd() * 2000 - 800) };
    else if (roll < 0.58) cmd = { t: "resize", id, w: Math.round(rnd() * 2400 - 300), h: Math.round(rnd() * 1800 - 200) };
    else if (roll < 0.66) cmd = { t: "tile", id, zone: pick(zones) };
    else if (roll < 0.72) cmd = { t: "maximize", id };
    else if (roll < 0.78) cmd = { t: "minimize", id };
    else if (roll < 0.83) cmd = { t: "restore", id };
    else if (roll < 0.88) cmd = { t: "viewport", w: 360 + Math.round(rnd() * 2200), h: 400 + Math.round(rnd() * 1400) };
    else if (roll < 0.92) cmd = { t: "density", density: pick<Density>(["compact", "balanced", "touch"]) };
    else if (roll < 0.95) cmd = { t: "toWorkspace", id, workspace: pick(s.workspaces).id };
    else if (roll < 0.98) cmd = { t: "switchWorkspace", workspace: pick(s.workspaces).id };
    else cmd = { t: "cycle", dir: rnd() > 0.5 ? 1 : -1 };
    s = reduce(s, cmd);
    applied++;
    const bad = checkInvariants(s);
    if (bad.length) {
      violations.push(...bad.map((b) => ({ ...b, detail: `${b.detail} after ${cmd.t} (step ${i})` })));
      break;
    }
  }
  return { state: s, violations, applied };
}

/** Idempotency / determinism probes (VR-01). */
export function checkAlgebra(): Violation[] {
  const v: Violation[] = [];
  let s = initialState({ w: 1200, h: 800 });
  s = reduce(s, { t: "open", module: "files", title: "Files" });
  const id = s.windows[0].id;
  const a = reduce(reduce(s, { t: "focus", id }), { t: "focus", id });
  const b = reduce(s, { t: "focus", id });
  if (JSON.stringify(a) !== JSON.stringify(b)) v.push({ rule: "focus-idempotent", detail: "double focus changed state" });
  const t1 = reduce(s, { t: "tile", id, zone: "left" });
  const t2 = reduce(t1, { t: "tile", id, zone: "left" });
  if (JSON.stringify(t1.windows[0].rect) !== JSON.stringify(t2.windows[0].rect))
    v.push({ rule: "tile-idempotent", detail: "repeat tile moved the window" });
  const m1 = reduce(s, { t: "maximize", id });
  const m2 = reduce(m1, { t: "maximize", id });
  if (JSON.stringify(m2.windows[0].rect) !== JSON.stringify(s.windows[0].rect))
    v.push({ rule: "maximize-involutive", detail: "maximize twice did not restore" });
  const h = normalize(JSON.parse(JSON.stringify(reduce(s, { t: "open", module: "x", title: "x" }))));
  if (checkInvariants(h).length) v.push({ rule: "hydrate-safe", detail: "normalize left violations" });
  return v;
}
