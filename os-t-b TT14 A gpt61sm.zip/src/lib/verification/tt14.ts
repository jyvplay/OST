/** Deterministic TT14 acceptance checks over the real engines; callable in Node and /api/selftest.
 * Generated pixels/workbooks are test inputs, not claims of independent Office/PSD interoperability.
 */
import { evaluateWorkbook, type XlsxModel } from "../office";
import { calculateWorkbook, validateWorkbookInput, valuesSnapshot } from "../workbook";
import { createRaster } from "../raster";
import { compositeLayers, invertMask, moveLayer, newLayer, parseLayerProject, patchLayer, rectangleMask, serializeLayerProject, type LayerDoc } from "../layers";
import { history, commit, undo, redo } from "../history";
import { parseVectorDoc, serializeVectorDoc, type VecDoc, type VecShape } from "../vector";
import { alignShapes, geometryBounds, hitTest, moveShape, multiply, parseTransform, point, rotateShape, rotation, scaleShape, scaling, stackShape, translation } from "../vectorGeometry";

export type Acceptance = { id: string; name: string; pass: boolean; detail: string };
const assert = (ok: unknown, message: string) => { if (!ok) throw new Error(message); };
const near = (a: number, b: number, tol = 1e-6) => Math.abs(a - b) <= tol;
const throws = (fn: () => unknown) => { try { fn(); return false; } catch { return true; } };
const wb = (cells: XlsxModel["sheets"][number]["cells"]): XlsxModel => ({ sheets: [{ name: "S", cells }], unsupported: [] });
const formula = (ref: string, f: string) => ({ ref, raw: "", formula: f });

export function runTT14Checks(): Acceptance[] {
  const cases: Acceptance[] = [];
  const check = (id: string, name: string, fn: () => string | void) => {
    try { cases.push({ id, name, pass: true, detail: fn() ?? "All assertions passed" }); }
    catch (e) { cases.push({ id, name, pass: false, detail: e instanceof Error ? e.message : String(e) }); }
  };
  check("FF-02.spill.allocate", "An array populates all six output cells with ownership, without mutating input", () => {
    const m = wb({ A1: formula("A1", "SEQUENCE(2,3,1,1)") }), before = JSON.stringify(m);
    const c = calculateWorkbook(m);
    assert(c.values.get("S!A1") === 1 && c.values.get("S!A2") === 4 && c.values.get("S!C2") === 6, "Not all array values published");
    assert(c.owners.get("S!C2") === "S!A1" && c.spills.get("S!A1")?.range === "A1:C2", "Missing ownership/range metadata");
    assert(c.stable && c.passes <= 8 && JSON.stringify(m) === before, "Input mutated or unbounded recalculation");
    return `${c.spills.get("S!A1")?.range}, ${c.passes} passes, C2=6`;
  });
  check("FF-02.spill.block", "An occupied cell blocks the whole array, preserving the obstruction", () => {
    const m = wb({ A1: formula("A1", "SEQUENCE(2,2)"), B2: { ref: "B2", raw: "keep" } });
    const c = calculateWorkbook(m);
    assert(c.values.get("S!A1") === "#SPILL!" && c.values.get("S!B2") === "keep", "Obstruction overwritten or no #SPILL!");
    assert(c.spills.size === 0 && c.owners.size === 0 && c.issues.get("S!A1")?.blockers.includes("B2"), "Partial spill published");
  });
  check("FF-02.spill.recover", "Removing an obstruction recomputes the spill; a blank-looking formula still blocks it", () => {
    const blankFormula = wb({ A1: formula("A1", "SEQUENCE(2,2)"), B1: formula("B1", '""') });
    assert(calculateWorkbook(blankFormula).values.get("S!A1") === "#SPILL!", "Formula returning empty text must still obstruct");
    const emptyStyled = wb({ A1: formula("A1", "SEQUENCE(2,2)"), B1: { ref: "B1", raw: "", style: { bold: true } } });
    const c = calculateWorkbook(emptyStyled);
    assert(c.values.get("S!B1") === 2 && c.values.get("S!B2") === 4, "Empty styled cell incorrectly obstructs");
  });
  check("FF-02.spill.dependency", "A scalar formula referencing a generated child recomputes regardless of source order", () => {
    const cells = { D1: formula("D1", "C2*2"), A1: formula("A1", "SEQUENCE(2,3)") };
    const a = calculateWorkbook(wb(cells)), b = calculateWorkbook(wb({ A1: cells.A1, D1: cells.D1 }));
    assert(a.values.get("S!D1") === 12 && b.values.get("S!D1") === 12, "Dependent cell used stale null/zero");
  });
  check("FF-02.spill.array-dependency", "An array whose start depends on a spill child converges", () => {
    const c = calculateWorkbook(wb({ E1: formula("E1", "SEQUENCE(1,2,B2*10)"), A1: formula("A1", "SEQUENCE(2,2)") }));
    assert(c.stable && c.values.get("S!E1") === 40 && c.values.get("S!F1") === 41, "Chained array did not converge");
  });
  check("FF-02.spill.overlap", "Overlapping anchors cannot overwrite another source formula", () => {
    const c = calculateWorkbook(wb({ A1: formula("A1", "SEQUENCE(2,3)"), B2: formula("B2", "SEQUENCE(2,3,10)") }));
    assert(c.values.get("S!A1") === "#SPILL!" && c.values.get("S!D3") === 15, "Overlapping anchors resolved incorrectly");
    assert(c.owners.get("S!D3") === "S!B2", "Unexpected ownership");
  });
  check("FF-02.spill.bounds", "Grid-edge spills and oversized output requests refuse without truncation", () => {
    const c = calculateWorkbook(wb({ XFD1048576: formula("XFD1048576", "SEQUENCE(2)") }));
    assert(c.values.get("S!XFD1048576") === "#SPILL!" && c.owners.size === 0, "Grid overflow not refused");
    const m = wb({ A1: formula("A1", "SEQUENCE(20001)"), C1: formula("C1", "EXPAND(1,100000000,2)"), E1: formula("E1", "WRAPROWS(1,100000000)") });
    const v = evaluateWorkbook(m);
    assert(v.get("S!A1") === "#NUM!" && v.get("S!C1") === "#NUM!" && v.get("S!E1") === "#VALUE!", "Oversized arrays were silently truncated or allocated");
  });
  check("FF-02.spill.snapshot", "Values-only export materialises children and removes formulas, preserving the source", () => {
    const m = wb({ A1: formula("A1", "SEQUENCE(2,2,10,5)") });
    const snap = valuesSnapshot(m);
    assert(snap.sheets[0].cells.B2.raw === "25" && !snap.sheets[0].cells.A1.formula, "Snapshot incomplete");
    assert(!!m.sheets[0].cells.A1.formula && !m.sheets[0].cells.B2, "Source workbook changed");
  });
  check("FF-02.spill.broadcast", "Array arithmetic broadcasts scalar functions and preserves unary-array shape", () => {
    const c = calculateWorkbook(wb({ A1: formula("A1", "SEQUENCE(2,2)+SUM(10,20)"), D1: formula("D1", "-SEQUENCE(2,2)") }));
    assert(c.values.get("S!B2") === 34 && c.values.get("S!E2") === -4, "Shape lost during array arithmetic");
    const v = evaluateWorkbook(wb({ A1: formula("A1", "SUM(SEQUENCE(2,3))"), A2: formula("A2", "SUM(-SEQUENCE(2,2))") }));
    assert(v.get("S!A1") === 21 && v.get("S!A2") === -10, "Legacy scalar aggregator regressed");
  });
  check("FF-02.spill.nonconvergent", "A generated-cell dependency which grows each pass stops at the pass budget", () => {
    const c = calculateWorkbook(wb({ A1: formula("A1", "SEQUENCE(1,2,B1+1)") }));
    assert(!c.stable && c.passes === 8 && c.values.get("S!A1") === "#CALC!", "Nonconverging array did not stop visibly");
    assert(c.owners.size === 0 && c.spills.size === 0, "Unstable generated values leaked into output");
  });
  check("FF-02.spill.input", "API input guard rejects bad refs, duplicate names, malformed cells and huge formulas", () => {
    assert(throws(() => validateWorkbookInput(wb({ A0: { ref: "A0", raw: "x" } }))), "A0 accepted");
    assert(throws(() => validateWorkbookInput({ sheets: [{ name: "s", cells: {} }, { name: "S", cells: {} }] })), "Duplicate names accepted");
    assert(throws(() => validateWorkbookInput(wb({ A1: formula("A1", "1".repeat(5000)) }))), "Huge formula accepted");
    assert(validateWorkbookInput(wb({ A1: { ref: "A1", raw: "1" } })).sheets.length === 1, "Valid workbook refused");
  });

  const red = newLayer("r", "red", createRaster(2, 1, [255, 0, 0, 255]));
  const blue = newLayer("b", "blue", createRaster(2, 1, [0, 0, 255, 128]));
  const ld: LayerDoc = { width: 2, height: 1, layers: [red, blue] };
  check("FF-05.layers.alpha", "Normal source-over matches analytic opaque-backdrop result", () => {
    const px = compositeLayers(ld).data;
    assert(px[0] === 127 && px[2] === 128 && px[3] === 255, `RGBA ${px.slice(0, 4)}`);
  });
  check("FF-05.layers.transparent", "Transparent backdrop/source do not inject black or hidden RGB", () => {
    const d: LayerDoc = { width: 1, height: 1, layers: [newLayer("a", "transparent red", createRaster(1, 1, [255, 0, 0, 0])), newLayer("b", "blue", createRaster(1, 1, [0, 0, 255, 128]))] };
    const px = compositeLayers(d).data;
    assert(px.join() === "0,0,255,128", `Transparent composition ${px}`);
  });
  check("FF-05.layers.blends", "Multiply and screen match analytic opaque results", () => {
    const a = newLayer("a", "a", createRaster(1, 1, [128, 128, 128, 255]));
    const b = { ...a, id: "b", blend: "multiply" as const };
    assert(compositeLayers({ width: 1, height: 1, layers: [a, b] }).data[0] === 64, "Multiply(128,128) must be 64");
    assert(compositeLayers({ width: 1, height: 1, layers: [a, { ...b, blend: "screen" }] }).data[0] === 192, "Screen(128,128) must be 192");
  });
  check("FF-05.layers.masks", "Mask and opacity multiply alpha only; source buffers remain byte-identical", () => {
    const a = newLayer("a", "a", createRaster(2, 1, [100, 50, 10, 255]));
    const before = a.raster.data.join();
    const mask = rectangleMask(2, 1, 0, 0, 1, 1);
    const out = compositeLayers({ width: 2, height: 1, layers: [{ ...a, opacity: 0.5, mask }] });
    assert(out.data.slice(0, 4).join() === "100,50,10,128" && out.data[7] === 0, `Masked RGBA ${out.data}`);
    assert(a.raster.data.join() === before && invertMask(invertMask(mask)).join() === mask.join(), "Source mutated or mask inversion wrong");
  });
  check("FF-05.layers.position", "Integer offsets clip correctly; visibility and order are operative", () => {
    const top = { ...blue, raster: createRaster(2, 1, [0, 0, 255, 255]), x: -1 };
    const out = compositeLayers({ ...ld, layers: [red, top] }).data;
    assert(out[2] === 255 && out[4] === 255 && out[6] === 0, `Clipping wrong: ${out}`);
    const hidden = compositeLayers({ ...ld, layers: [red, { ...top, visible: false }] });
    assert(hidden.data[0] === 255 && hidden.data[2] === 0, "Hidden layer still contributes");
    const reorder = moveLayer(ld, "b", -1);
    assert(compositeLayers(reorder).data[0] === 255, "Bottom-to-top order not respected");
  });
  check("FF-05.layers.project", "Versioned layer project preserves pixels, blend, placement, visibility and masks", () => {
    const src = patchLayer(ld, "b", { blend: "screen", opacity: 0.4, x: 1, mask: rectangleMask(2, 1, 0, 0, 1, 1) });
    const back = parseLayerProject(serializeLayerProject(src));
    assert(back.layers[1].mask?.join() === "255,0" && back.layers[1].blend === "screen" && back.layers[1].x === 1, "Layer metadata changed");
    assert(compositeLayers(src).data.join() === compositeLayers(back).data.join(), "Project composite changed");
  });
  check("FF-05.layers.guards", "Layer/project guards refuse oversized dimensions, duplicate ids and corrupt bytes", () => {
    assert(throws(() => compositeLayers({ width: 100000, height: 100000, layers: [] })), "Huge canvas accepted");
    assert(throws(() => compositeLayers({ ...ld, layers: [red, red] })), "Duplicate id accepted");
    assert(throws(() => parseLayerProject('{"kind":"fusion-layers","version":9}')), "Unknown version accepted");
    const corrupt = JSON.parse(serializeLayerProject(ld)); corrupt.layers[0].pixels = "AAAA";
    assert(throws(() => parseLayerProject(JSON.stringify(corrupt))), "Truncated buffer accepted");
  });
  check("FF-05.layers.undo", "Undo/redo is bounded, branch edits discard redo, and documents are not mutated", () => {
    let h = history(ld, 3);
    for (let i = 0; i < 6; i++) h = commit(h, patchLayer(h.present, "b", { x: i }));
    assert(h.past.length === 3 && h.present.layers[1].x === 5 && ld.layers[1].x === 0, "Unbounded history or source mutation");
    h = undo(h); assert(h.present.layers[1].x === 4, "Undo wrong");
    h = redo(h); assert(h.present.layers[1].x === 5, "Redo wrong");
    h = commit(undo(h), patchLayer(undo(h).present, "b", { y: 8 }));
    assert(h.future.length === 0, "Branch edit retained stale redo");
  });

  const rect: VecShape = { id: "rect", kind: "rect", x: 10, y: 20, width: 30, height: 40, fill: "#f00", stroke: "none", strokeWidth: 1 };
  const vdoc: VecDoc = { width: 200, height: 100, gradients: [], shapes: [rect] };
  check("FF-09.geometry.matrix", "SVG transform order, point mapping and pivot rotation agree with analytic values", () => {
    const p = point(parseTransform("translate(10 20) scale(2)"), 1, 1);
    assert(p[0] === 12 && p[1] === 22, "Transform order reversed");
    const rp = point(rotation(90, 5, 5), 10, 5);
    assert(near(rp[0], 5) && near(rp[1], 10), `Pivot rotation ${rp}`);
    const m = multiply(translation(10, 0), scaling(2));
    assert(point(m, 2, 1)[0] === 14, "Matrix product wrong");
    assert(throws(() => parseTransform("skewX(30)")), "Unsupported transform silently ignored");
  });
  check("FF-09.geometry.move", "Movement commands round-trip through SVG and leave original geometry intact", () => {
    const moved = moveShape(vdoc, "rect", 15, -5), b = geometryBounds(moved.shapes[0]);
    assert(b.x === 25 && b.y === 15 && geometryBounds(rect).x === 10, "Move mutated source or wrong coordinates");
    const back = parseVectorDoc(serializeVectorDoc(moved)).doc;
    assert(near(geometryBounds(back.shapes[0]).x, 25), "Move lost on save/load");
  });
  check("FF-09.geometry.align", "Canvas alignment and centered scaling use transformed bounds", () => {
    const a = alignShapes(vdoc, ["rect"], "right"), b = geometryBounds(a.shapes[0]);
    assert(near(b.x + b.w, 200), "Right alignment wrong");
    const s = scaleShape(vdoc, "rect", 2), sb = geometryBounds(s.shapes[0]);
    assert(near(sb.w, 60) && near(sb.h, 80) && near(sb.x + sb.w / 2, 25), "Centered scale wrong");
  });
  check("FF-09.geometry.rotate", "Rotated rectangles and circles have transform-aware bounds", () => {
    const rotated = rotateShape(vdoc, "rect", 90), b = geometryBounds(rotated.shapes[0]);
    assert(near(b.w, 40) && near(b.h, 30), "Rotated rectangle bounds wrong");
    const circle: VecShape = { id: "c", kind: "circle", cx: 40, cy: 40, r: 10, fill: "red", stroke: "none", strokeWidth: 1 };
    const c = rotateShape({ ...vdoc, shapes: [circle] }, "c", 45);
    assert(near(geometryBounds(c.shapes[0]).w, 20), "Circle bounds incorrectly inflated by rotation");
  });
  check("FF-09.geometry.hit", "Hit-testing and layer ordering select the topmost object", () => {
    const d = { ...vdoc, shapes: [rect, { ...rect, id: "top" }] };
    assert(hitTest(d, 20, 30) === "top", "Topmost hit wrong");
    assert(hitTest(stackShape(d, "top", -1), 20, 30) === "rect", "Stacking did not affect hit order");
    assert(hitTest(d, 999, 999) === null, "Hit outside content");
  });
  check("FF-09.geometry.escape", "SVG export escapes quote-bearing ids and paints (regression attack on attribute breakout)", () => {
    const d = { ...vdoc, shapes: [{ ...rect, id: 'x"><script>alert(1)</script><g a="', fill: 'red" onload="alert(2)' }] };
    const svg = serializeVectorDoc(d);
    assert(!svg.includes("<script>") && !svg.includes('fill="red" onload='), "Attribute breakout in exported SVG");
    assert(svg.includes("&quot;"), "Attribute quote not encoded");
  });
  return cases;
}
