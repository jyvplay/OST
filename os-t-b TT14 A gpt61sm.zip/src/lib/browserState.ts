// PR-07a..r: deterministic browser-tab model. Tabs always keep stable ids; a view switch must not
// remount the iframe. Serialised sessions contain *URLs and UI state*, not cookies or renderer internals.
export type BrowserTab = { id: number; url: string; title: string; groupId: string | null; pinned: boolean; asleep: boolean; lastActive: number };
export type BrowserGroup = { id: string; name: string; color: string; collapsed: boolean };
export type BrowserSession = {
  version: 1;
  tabs: BrowserTab[];
  groups: BrowserGroup[];
  activeId: number;
  secondId: number | null;
  split: "off" | "horizontal" | "vertical";
  divider: number;
  verticalTabs: boolean;
  nextId: number;
};
export type BrowserAction =
  | { type: "add"; url?: string; now: number }
  | { type: "activate"; id: number; now: number }
  | { type: "navigate"; id: number; url: string; now: number }
  | { type: "close"; id: number }
  | { type: "pin"; id: number }
  | { type: "group"; id: number; groupId: string | null }
  | { type: "createGroup"; id: string; name: string; color: string; tabId: number }
  | { type: "collapseGroup"; id: string }
  | { type: "renameGroup"; id: string; name: string }
  | { type: "split"; split: BrowserSession["split"] }
  | { type: "second"; id: number | null }
  | { type: "divider"; value: number }
  | { type: "verticalTabs"; on: boolean }
  | { type: "sleep"; id: number }
  | { type: "wake"; id: number; now: number }
  | { type: "batch"; target: "duplicates" | "others" | "toRight"; id: number }
  | { type: "hydrate"; session: BrowserSession };

export function safeBrowserUrl(input: string): string | null {
  const text = input.trim();
  if (text === "about:blank") return text;
  const candidate = /^https?:\/\//i.test(text) ? text : `https://${text}`;
  try {
    const u = new URL(candidate);
    if (!(["https:", "http:"].includes(u.protocol)) || u.username || u.password) return null;
    return u.href;
  } catch { return null; }
}

export function browserInitial(now = 0): BrowserSession {
  return {
    version: 1, tabs: [
      { id: 1, url: "about:blank", title: "Start", groupId: null, pinned: false, asleep: false, lastActive: now },
      { id: 2, url: "about:blank", title: "New tab", groupId: null, pinned: false, asleep: false, lastActive: now },
    ], groups: [], activeId: 1, secondId: 2, split: "off", divider: 50, verticalTabs: false, nextId: 3,
  };
}
const withTitle = (url: string) => url === "about:blank" ? "New tab" : new URL(url).hostname;

function reconcile(s: BrowserSession, tabs: BrowserTab[]): BrowserSession {
  // A session always has at least one tab; a closed split partner is replaced or split is disabled.
  if (tabs.length === 0) return { ...browserInitial(0), nextId: s.nextId };
  const activeId = tabs.some(t => t.id === s.activeId) ? s.activeId : tabs[0].id;
  const secondId = s.secondId !== activeId && tabs.some(t => t.id === s.secondId) ? s.secondId : (tabs.find(t => t.id !== activeId)?.id ?? null);
  return { ...s, tabs, activeId, secondId, split: secondId ? s.split : "off" };
}

export function browserReduce(s: BrowserSession, a: BrowserAction): BrowserSession {
  switch (a.type) {
    case "add": {
      const url = safeBrowserUrl(a.url ?? "about:blank");
      if (!url) return s;
      const t: BrowserTab = { id: s.nextId, url, title: withTitle(url), groupId: null, pinned: false, asleep: false, lastActive: a.now };
      return { ...s, tabs: [...s.tabs, t], activeId: t.id, nextId: s.nextId + 1 };
    }
    case "activate": return s.tabs.some(t => t.id === a.id) ? { ...s, activeId: a.id, tabs: s.tabs.map(t => t.id === a.id ? { ...t, asleep: false, lastActive: a.now } : t) } : s;
    case "navigate": {
      const url = safeBrowserUrl(a.url);
      return url ? { ...s, tabs: s.tabs.map(t => t.id === a.id ? { ...t, url, title: withTitle(url), asleep: false, lastActive: a.now } : t) } : s;
    }
    case "close": return reconcile(s, s.tabs.filter(t => t.id !== a.id));
    case "pin": return { ...s, tabs: s.tabs.map(t => t.id === a.id ? { ...t, pinned: !t.pinned } : t) };
    case "group": return { ...s, tabs: s.tabs.map(t => t.id === a.id ? { ...t, groupId: a.groupId } : t) };
    case "createGroup": {
      if (s.groups.some(g => g.id === a.id)) return s;
      return { ...s, groups: [...s.groups, { id: a.id, name: a.name.trim() || "Group", color: a.color, collapsed: false }], tabs: s.tabs.map(t => t.id === a.tabId ? { ...t, groupId: a.id } : t) };
    }
    case "collapseGroup": return { ...s, groups: s.groups.map(g => g.id === a.id ? { ...g, collapsed: !g.collapsed } : g) };
    case "renameGroup": return { ...s, groups: s.groups.map(g => g.id === a.id ? { ...g, name: a.name.trim() || g.name } : g) };
    case "split": return { ...s,
      split: a.split !== "off" && (!s.secondId || s.secondId === s.activeId) ? "off" : a.split,
      tabs: a.split !== "off" ? s.tabs.map(t => t.id === s.secondId ? { ...t, asleep: false } : t) : s.tabs,
    };
    case "second": return { ...s, secondId: a.id !== s.activeId && s.tabs.some(t => t.id === a.id) ? a.id : null, split: a.id === null ? "off" : s.split };
    case "divider": return { ...s, divider: Math.round(Math.min(80, Math.max(20, a.value))) };
    case "verticalTabs": return { ...s, verticalTabs: a.on };
    case "sleep": return s.tabs.some(t => t.id === a.id && !t.pinned && t.id !== s.activeId && !(s.split !== "off" && t.id === s.secondId))
      ? { ...s, tabs: s.tabs.map(t => t.id === a.id ? { ...t, asleep: true } : t) } : s;
    case "wake": return { ...s, tabs: s.tabs.map(t => t.id === a.id ? { ...t, asleep: false, lastActive: a.now } : t) };
    case "batch": {
      const target = s.tabs.find(t => t.id === a.id);
      if (!target) return s;
      const idx = s.tabs.indexOf(target);
      const tabs = s.tabs.filter((t, i) => t.pinned || (a.target === "duplicates" ? t.id === a.id || t.url !== target.url || i < idx
        : a.target === "others" ? t.id === a.id
        : i <= idx));
      return reconcile(s, tabs);
    }
    case "hydrate": return browserNormalize(a.session);
    default: return s;
  }
}

export function browserNormalize(raw: BrowserSession): BrowserSession {
  if (!raw || !Array.isArray(raw.tabs)) return browserInitial();
  const tabs = raw.tabs.slice(0, 100).filter(t => Number.isSafeInteger(t.id) && !!safeBrowserUrl(t.url)).map(t => ({ ...t, url: safeBrowserUrl(t.url)!, title: String(t.title ?? "Tab").slice(0, 100), groupId: t.groupId || null, pinned: !!t.pinned, asleep: !!t.asleep, lastActive: Number(t.lastActive) || 0 }));
  const groups = (Array.isArray(raw.groups) ? raw.groups : []).slice(0, 30).map(g => ({ id: String(g.id), name: String(g.name).slice(0, 70), color: /^#[0-9a-f]{6}$/i.test(g.color) ? g.color : "#38bdf8", collapsed: !!g.collapsed }));
  const base = { ...browserInitial(), ...raw, version: 1 as const, groups, divider: Math.min(80, Math.max(20, Number(raw.divider) || 50)), nextId: Math.max(Number(raw.nextId) || 1, ...tabs.map(t => t.id + 1), 1) };
  return reconcile(base, tabs);
}
