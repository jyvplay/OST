import { db } from "@/db";
import { alerts, castTargets, features, fsNodes, kv, messages, notes } from "@/db/schema";
import { sql } from "drizzle-orm";
import { FEATURES } from "@/lib/registry";
import { createNode, ensureDir } from "./vfs";

let seeding: Promise<void> | null = null;

export async function ensureSeed() {
  if (!seeding) seeding = doSeed().catch((e) => { seeding = null; throw e; });
  return seeding;
}

async function doSeed() {
  // Feature register is upserted on every boot: the spec is the source of truth,
  // the DB only carries the *status* overlay the user can edit.
  for (const f of FEATURES) {
    await db
      .insert(features)
      .values({ ...f, route: "" })
      .onConflictDoUpdate({
        target: features.id,
        set: { area: f.area, title: f.title, tier: f.tier, phase: f.phase, webNuance: f.webNuance, status: f.status },
      });
  }

  const [{ count }] = await db.select({ count: sql<number>`count(*)::int` }).from(fsNodes);
  if (Number(count) === 0) {
    const home = await ensureDir("/Home");
    const docs = await ensureDir("/Home/Documents");
    await ensureDir("/Home/Downloads");
    const projects = await ensureDir("/Home/Projects");
    const templates = await ensureDir("/System/Templates");
    await ensureDir("/System/Logs");

    await createNode(docs.id, "readme.md", "file", "text/markdown",
`# Fusion Shell (Web)

This is a real file in Postgres, not a mock. Every write creates a version row
(BK-01) and every copy/move runs the journaled state machine (FM-03).

Try in Terminal:
  ls /Home/Documents
  cat readme.md
  ops copy readme.md /Home/Projects
  ops copy readme.md /Home/Projects --interrupt before_publish
`);
    await createNode(docs.id, "budget.csv", "file", "text/csv", "item,qty,unit\nmonitor,1,399\nkeyboard,2,89\ndock,1,129\n");
    await createNode(projects.id, "notes.txt", "file", "text/plain", "Fusion Shell port notes.\nWindow engine is a pure reducer.\n");
    await createNode(templates.id, "Empty note.md", "file", "text/markdown", "# \n");
    await createNode(templates.id, "Empty sheet.csv", "file", "text/csv", "a,b,c\n");
    await createNode(home.id, "wallpaper.txt", "file", "text/plain", "gradient:aurora");
  }

  const [{ n }] = await db.select({ n: sql<number>`count(*)::int` }).from(notes);
  if (Number(n) === 0) {
    await db.insert(notes).values([
      { title: "Capability honesty", body: "DP-10: probe, then degrade visibly. Never stub a capability we do not have.\n\nSee the Capabilities app for the live probe.", tags: "spec" },
      { title: "What the web cannot do", body: "- virtual camera for other apps\n- RCS\n- DLNA/SSDP\n- UA override inside a cross-origin iframe\n- AirPlay mirroring", tags: "negative-space" },
    ]);
  }

  const [{ a }] = await db.select({ a: sql<number>`count(*)::int` }).from(alerts);
  if (Number(a) === 0) {
    await db.insert(alerts).values([
      { app: "Backup", title: "First backup not run yet", body: "BK-05: status is 'unverified' until a sampled restore succeeds.", priority: "normal" },
      { app: "Beam", title: "No cast targets discovered", body: "Remote Playback availability is watched live; nothing is invented.", priority: "low" },
      { app: "Forge", title: "Macros are disabled", body: "FF-17: vbaProject.bin is reported, never executed.", priority: "low" },
    ]);
  }

  const [{ m }] = await db.select({ m: sql<number>`count(*)::int` }).from(messages);
  if (Number(m) === 0) {
    await db.insert(messages).values([
      { thread: "Fusion", author: "system", body: "Local threads are real. iMessage requires your own Mac bridge (MS-01); without it this panel stays disconnected.", channel: "local" },
    ]);
  }

  const [{ c }] = await db.select({ c: sql<number>`count(*)::int` }).from(castTargets);
  if (Number(c) === 0) {
    await db.insert(castTargets).values([
      { name: "This browser window (Presentation receiver)", protocol: "presentation", trusted: true, fingerprint: "self" },
    ]);
  }

  await db
    .insert(kv)
    .values({ key: "settings.root", scope: "settings", value: defaultSettings })
    .onConflictDoNothing();
  await db
    .insert(kv)
    .values({ key: "entitlement", scope: "commerce", value: { plan: "trial", startedAt: new Date().toISOString(), days: 14 } })
    .onConflictDoNothing();
}

export const defaultSettings: Record<string, unknown> = {
  "appearance.theme": "dark",
  "appearance.accent": "#5eead4",
  "appearance.density": "balanced",
  "appearance.motion": "system",
  "shell.shelfEdge": "bottom",
  "shell.hotCorners": true,
  "shell.shortcutPreset": "hybrid",
  "find.webResults": false,
  "files.confirmDestructive": true,
  "files.versionRetention": 20,
  "privacy.telemetry": false,
  "beam.autoStopOnHide": true,
  "runtime.lowMemoryMode": false,
  "appearance.fontScale": 100,
  "profiles.auto": true,
  "focus.dnd": false,
};
