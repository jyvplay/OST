import { and, asc, eq, inArray, isNull, sql } from "drizzle-orm";
import { db } from "@/db";
import { auditLog, fileOps, fsNodes, fsVersions } from "@/db/schema";
import { createHash } from "node:crypto";

export type Node = typeof fsNodes.$inferSelect;

export const hash = (s: string) => createHash("sha256").update(s).digest("hex").slice(0, 32);

export async function audit(action: string, detail: unknown) {
  await db.insert(auditLog).values({ action, detail: detail as object });
}

export async function childrenOf(parentId: number | null, includeTrashed = false) {
  const where = parentId === null ? isNull(fsNodes.parentId) : eq(fsNodes.parentId, parentId);
  const rows = await db
    .select()
    .from(fsNodes)
    .where(includeTrashed ? where : and(where, eq(fsNodes.trashed, false)))
    .orderBy(asc(fsNodes.kind), asc(fsNodes.name));
  return rows;
}

export async function nodeById(id: number) {
  const [row] = await db.select().from(fsNodes).where(eq(fsNodes.id, id)).limit(1);
  return row ?? null;
}

export async function pathOf(id: number | null): Promise<string> {
  if (id === null) return "/";
  const parts: string[] = [];
  let cur: Node | null = await nodeById(id);
  let guard = 0;
  while (cur && guard++ < 64) {
    parts.unshift(cur.name);
    const pid: number | null = cur.parentId;
    cur = pid === null ? null : await nodeById(pid);
  }
  return "/" + parts.join("/");
}

export async function resolvePath(path: string): Promise<Node | null> {
  const parts = path.split("/").filter(Boolean);
  let parentId: number | null = null;
  let node: Node | null = null;
  for (const p of parts) {
    const pid: number | null = parentId;
    const rows: Node[] = await db
      .select()
      .from(fsNodes)
      .where(
        pid === null
          ? and(isNull(fsNodes.parentId), eq(fsNodes.name, p))
          : and(eq(fsNodes.parentId, pid), eq(fsNodes.name, p)),
      )
      .limit(1);
    const row = rows[0];
    if (!row) return null;
    node = row;
    parentId = row.id;
  }
  return node;
}

export async function ensureDir(path: string): Promise<Node> {
  const parts = path.split("/").filter(Boolean);
  let parentId: number | null = null;
  let node: Node | null = null;
  for (const p of parts) {
    const pid: number | null = parentId;
    const existing: Node[] = await db
      .select()
      .from(fsNodes)
      .where(
        pid === null
          ? and(isNull(fsNodes.parentId), eq(fsNodes.name, p))
          : and(eq(fsNodes.parentId, pid), eq(fsNodes.name, p)),
      )
      .limit(1);
    if (existing[0]) {
      node = existing[0];
    } else {
      const created: Node[] = await db
        .insert(fsNodes)
        .values({ parentId: pid, name: p, kind: "dir", mime: "inode/directory" })
        .returning();
      node = created[0];
    }
    parentId = node!.id;
  }
  if (!node) throw new Error("ensureDir: empty path");
  return node;
}

export async function uniqueName(parentId: number | null, name: string) {
  const siblings = await childrenOf(parentId, true);
  const taken = new Set(siblings.map((s) => s.name));
  if (!taken.has(name)) return name;
  const dot = name.lastIndexOf(".");
  const base = dot > 0 ? name.slice(0, dot) : name;
  const ext = dot > 0 ? name.slice(dot) : "";
  let i = 2;
  while (taken.has(`${base} (${i})${ext}`)) i++;
  return `${base} (${i})${ext}`;
}

/** FM-18: DB-VFS writes are transactional; version and content commit together (not an external SAF write). */
export class VersionConflictError extends Error {
  constructor(readonly expected: number, readonly actual: number) { super(`file changed since v${expected} (now v${actual})`); }
}
export async function writeFile(id: number, content: string, expectedVersion?: number) {
  const node = await nodeById(id);
  if (!node || node.kind !== "file" || node.trashed) throw new Error("file not found or no longer writable");
  if (expectedVersion !== undefined && expectedVersion !== node.version) throw new VersionConflictError(expectedVersion, node.version);
  const savedPath = await pathOf(id);
  return db.transaction(async tx => {
    const [updated] = await tx.update(fsNodes).set({
      content,
      size: Buffer.byteLength(content, "utf8"),
      version: sql`${fsNodes.version} + 1`,
      updatedAt: new Date(),
    }).where(and(eq(fsNodes.id, id), eq(fsNodes.kind, "file"), eq(fsNodes.trashed, false),
      expectedVersion !== undefined ? eq(fsNodes.version, expectedVersion) : undefined)).returning();
    if (!updated) throw new VersionConflictError(expectedVersion ?? node.version, (await nodeById(id))?.version ?? node.version);
    if (hash(updated.content) !== hash(content)) throw new Error("read-back verification failed; transaction rolled back");
    await tx.insert(fsVersions).values({ nodeId: id, path: savedPath, content, version: updated.version });
    // Version retention participates in the same transaction. 20 is an explicit local-history budget.
    await tx.execute(sql`delete from fs_versions where id in (
      select id from (
        select id, row_number() over (partition by node_id order by version desc) rn
        from fs_versions where node_id = ${id}
      ) t where t.rn > 20)`);
    return updated;
  });
}

export async function createNode(parentId: number | null, name: string, kind: "dir" | "file", mime: string, content = "") {
  const finalName = await uniqueName(parentId, name);
  const [row] = await db
    .insert(fsNodes)
    .values({ parentId, name: finalName, kind, mime, content, size: content.length })
    .returning();
  if (kind === "file" && content) {
    await db.insert(fsVersions).values({ nodeId: row.id, path: await pathOf(row.id), content, version: 1 });
  }
  return row;
}

export async function descendants(id: number): Promise<number[]> {
  const res = await db.execute<{ id: number }>(sql`
    with recursive t as (
      select id from fs_nodes where id = ${id}
      union all
      select f.id from fs_nodes f join t on f.parent_id = t.id
    ) select id from t`);
  return res.rows.map((r) => Number(r.id));
}

/**
 * FM-03 / §5.7 file-operation state machine with a durable journal.
 * `interrupt` injects a documented crash point (VR-02) so recovery semantics are testable.
 */
export type OpState =
  | "REQUESTED" | "COPYING_TO_TEMP" | "DEST_VERIFIED" | "DEST_PUBLISHED" | "SOURCE_RETIRE" | "COMPLETE" | "FAILED" | "INTERRUPTED";

export type FileOpResult = {
  op: number;
  state: OpState;
  journal: { state: OpState; at: string; note: string }[];
  outcome?: string;
  published?: number[];
  error?: string;
};

export async function runFileOp(opts: {
  kind: "copy" | "move";
  srcIds: number[];
  destParentId: number | null;
  interrupt?: "before_publish" | "after_publish";
}): Promise<FileOpResult> {
  const journal: { state: OpState; at: string; note: string }[] = [];
  const [op] = await db
    .insert(fileOps)
    .values({
      kind: opts.kind,
      state: "REQUESTED",
      srcIds: opts.srcIds.join(","),
      destParentId: opts.destParentId,
      journal: [],
    })
    .returning();

  const step = async (state: OpState, note: string) => {
    journal.push({ state, at: new Date().toISOString(), note });
    await db.update(fileOps).set({ state, journal, updatedAt: new Date() }).where(eq(fileOps.id, op.id));
  };

  try {
    await step("COPYING_TO_TEMP", `staging ${opts.srcIds.length} node(s)`);
    const staged: { src: Node; tempName: string; checksum: string }[] = [];
    for (const id of opts.srcIds) {
      const src = await nodeById(id);
      if (!src) throw new Error(`source ${id} missing`);
      if (opts.destParentId !== null && (await descendants(id)).includes(opts.destParentId))
        throw new Error("refusing to move a folder into itself");
      staged.push({ src, tempName: `.fusion-tmp-${op.id}-${src.id}`, checksum: hash(src.content) });
    }

    await step("DEST_VERIFIED", "checksums computed, destination writable");
    if (opts.interrupt === "before_publish") {
      await step("INTERRUPTED", "crash injected before publish → source authoritative, nothing published");
      return { op: op.id, state: "INTERRUPTED", journal, outcome: "source-authoritative" };
    }

    const published: number[] = [];
    for (const s of staged) {
      if (opts.kind === "copy") {
        const copyIds = await deepCopy(s.src, opts.destParentId);
        published.push(...copyIds);
      } else {
        const name = await uniqueName(opts.destParentId, s.src.name);
        const [moved] = await db
          .update(fsNodes)
          .set({ parentId: opts.destParentId, name, updatedAt: new Date() })
          .where(eq(fsNodes.id, s.src.id))
          .returning();
        published.push(moved.id);
      }
    }
    await step("DEST_PUBLISHED", `published ${published.join(",")}`);

    if (opts.interrupt === "after_publish") {
      await step("INTERRUPTED", "crash injected after publish → keep both, flagged needs-cleanup");
      return { op: op.id, state: "INTERRUPTED", journal, outcome: "keep-both-needs-cleanup", published };
    }

    await step("SOURCE_RETIRE", opts.kind === "copy" ? "copy: source untouched" : "move: source row re-parented");
    await step("COMPLETE", "ok");
    await audit("fileop", { kind: opts.kind, srcIds: opts.srcIds, dest: opts.destParentId });
    return { op: op.id, state: "COMPLETE", journal, published };
  } catch (e) {
    await step("FAILED", String(e));
    return { op: op.id, state: "FAILED", journal, error: String(e) };
  }
}

async function deepCopy(src: Node, destParentId: number | null): Promise<number[]> {
  const name = await uniqueName(destParentId, src.name);
  const [copy] = await db
    .insert(fsNodes)
    .values({
      parentId: destParentId,
      name,
      kind: src.kind,
      mime: src.mime,
      content: src.content,
      size: src.size,
      tags: src.tags,
    })
    .returning();
  const ids = [copy.id];
  if (src.kind === "dir") {
    for (const child of await childrenOf(src.id, false)) ids.push(...(await deepCopy(child, copy.id)));
  }
  return ids;
}

export async function trash(ids: number[]) {
  for (const id of ids) {
    const p = await pathOf(id);
    await db.update(fsNodes).set({ trashed: true, trashedFrom: p, updatedAt: new Date() }).where(eq(fsNodes.id, id));
  }
  await audit("trash", { ids });
}

export async function restore(ids: number[]) {
  await db.update(fsNodes).set({ trashed: false, trashedFrom: null }).where(inArray(fsNodes.id, ids));
}

export async function purge(ids: number[]) {
  for (const id of ids) {
    const all = await descendants(id);
    await db.delete(fsVersions).where(inArray(fsVersions.nodeId, all));
    await db.delete(fsNodes).where(inArray(fsNodes.id, all));
  }
}

export async function folderStats(id: number | null) {
  const res = await db.execute<{ files: number; dirs: number; bytes: number }>(sql`
    with recursive t as (
      select * from fs_nodes where ${id === null ? sql`parent_id is null` : sql`parent_id = ${id}`}
      union all
      select f.* from fs_nodes f join t on f.parent_id = t.id
    )
    select
      count(*) filter (where kind = 'file')::int as files,
      count(*) filter (where kind = 'dir')::int as dirs,
      coalesce(sum(size), 0)::int as bytes
    from t where trashed = false`);
  const r = res.rows[0];
  return { files: Number(r?.files ?? 0), dirs: Number(r?.dirs ?? 0), bytes: Number(r?.bytes ?? 0) };
}
