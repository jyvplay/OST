// Implements: AU-05 (automation API token). HMAC-SHA256, scope-bound, expiring.
// Trust boundary: token issuance (/api/command/token) refuses requests that browsers mark cross-site.
// Nuance: the default secret is a development placeholder; set FUSION_LICENSE_SECRET in production.
import { createHmac, timingSafeEqual } from "node:crypto";

const SECRET = process.env.FUSION_LICENSE_SECRET ?? "dev-only-local-secret";

export function signScoped(scope: string, ttlMs: number): string {
  const body = `${scope}.${Date.now() + ttlMs}`;
  const mac = createHmac("sha256", SECRET).update(`scoped|${body}`).digest("base64url");
  return `${body}.${mac}`;
}

export function verifyScoped(token: string | null, scope: string): boolean {
  if (!token) return false;
  const parts = token.split(".");
  if (parts.length !== 3) return false;
  const [s, exp, mac] = parts;
  if (s !== scope || !(Number(exp) > Date.now())) return false;
  const expected = createHmac("sha256", SECRET).update(`scoped|${s}.${exp}`).digest("base64url");
  const a = Buffer.from(mac);
  const b = Buffer.from(expected);
  return a.length === b.length && timingSafeEqual(a, b);
}
