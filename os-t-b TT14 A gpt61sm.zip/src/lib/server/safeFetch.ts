import { lookup } from "node:dns/promises";
import { request as httpsRequest } from "node:https";
import { isIP } from "node:net";

/**
 * Server-side URL probes must not become an SSRF tunnel. Embedding arbitrary sites happens in the
 * user's browser; the server probes only a small allow-list. Matrix user-defined servers are allowed
 * only if every DNS address is public and the TLS request pins the vetted IP in a custom lookup.
 * Redirects are never followed. No cookies or credentials are forwarded. Payload is capped.
 */
const PRIVATE_V4 = [
  /^0\./, /^10\./, /^127\./, /^169\.254\./, /^192\.168\./,
  /^172\.(1[6-9]|2\d|3[01])\./, /^100\.(6[4-9]|[7-9]\d|1[01]\d|12[0-7])\./,
  /^192\.0\.0\./, /^192\.0\.2\./,
  /^198\.(1[89]|5[12])\./, /^203\.0\.113\./, /^224\./, /^2(2[4-9]|[3-5]\d)\./,
  /^255\./,
];
export function publicAddress(address: string): boolean {
  const family = isIP(address);
  if (family === 4) return !PRIVATE_V4.some(re => re.test(address));
  if (family === 6) {
    const s = address.toLowerCase();
    return !(!s.includes(":") || s === "::" || s === "::1" || s.startsWith("fc") || s.startsWith("fd") || s.startsWith("fe8") || s.startsWith("fe9") || s.startsWith("fea") || s.startsWith("feb") || s.startsWith("ff") || s.startsWith("2001:db8") || s.startsWith("::ffff:"));
  }
  return false;
}
export function safePublicUrl(raw: string): URL | null {
  try {
    const u = new URL(raw);
    if (u.protocol !== "https:" || (u.port && u.port !== "443") || u.username || u.password || u.hash || u.hostname.length > 253 || !u.hostname.includes(".")) return null;
    if (isIP(u.hostname) || /(?:^|\.)localhost$|(?:^|\.)local$|(?:^|\.)internal$|(?:^|\.)test$/i.test(u.hostname)) return null;
    return u;
  } catch { return null; }
}
export type SafeResponse = { status: number; headers: Record<string, string>; body: string };
export async function safePublicFetch(raw: string, method: "GET" | "HEAD" = "GET"): Promise<SafeResponse> {
  const u = safePublicUrl(raw);
  if (!u) throw new Error("Only public HTTPS hosts on port 443 are allowed; local, IP, credential and fragment URLs are refused.");
  const addresses = await lookup(u.hostname, { all: true });
  if (!addresses.length || addresses.some(a => !publicAddress(a.address))) throw new Error("DNS includes a non-public address");
  const pinned = addresses[0];
  return new Promise((resolve, reject) => {
    const req = httpsRequest({
      hostname: u.hostname, servername: u.hostname, port: 443, path: u.pathname + u.search, method,
      timeout: 5500, maxHeaderSize: 12_288,
      headers: { "user-agent": "FusionShell/2.3 (public URL probe)", accept: method === "HEAD" ? "*/*" : "application/json" },
      lookup: (_host, options, callback) => {
        // Node 22's family auto-selection asks for all:true. The callback MUST return an array then;
        // returning (address, family) in that mode raises ERR_INVALID_IP_ADDRESS before TLS connects.
        if (options.all) callback(null, [{ address: pinned.address, family: pinned.family }]);
        else callback(null, pinned.address, pinned.family);
      },
    }, res => {
      const status = res.statusCode ?? 502;
      if (status >= 300 && status < 400) { res.destroy(); reject(new Error("redirect refused; redirected destinations are not probed")); return; }
      let bytes = 0;
      const chunks: Buffer[] = [];
      res.on("data", chunk => {
        const buf = Buffer.from(chunk);
        bytes += buf.length;
        if (bytes > 128_000) { req.destroy(new Error("response over 128 KB cap")); return; }
        chunks.push(buf);
      });
      res.on("end", () => {
        const headers = Object.fromEntries(Object.entries(res.headers).filter(([, v]) => typeof v === "string") as [string, string][]);
        resolve({ status, headers, body: Buffer.concat(chunks).toString("utf8") });
      });
      res.on("error", reject);
    });
    req.on("timeout", () => req.destroy(new Error("public HTTPS probe timed out")));
    req.on("error", reject);
    req.end();
  });
}
