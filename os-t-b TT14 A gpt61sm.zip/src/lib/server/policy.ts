// Implements: ST-08 (managed configuration). Reads policy/fusion-policy.json from the project root.
// Locked keys cannot be changed through /api/settings (HTTP 409). Nothing is fetched remotely.
import { readFileSync } from "node:fs";
import path from "node:path";

export type Policy = { name: string; source: string; locked: Record<string, unknown>; note: string };

export function loadPolicy(): Policy {
  try {
    const raw = readFileSync(path.join(process.cwd(), "policy", "fusion-policy.json"), "utf8");
    const j = JSON.parse(raw) as { name?: string; locked?: Record<string, unknown>; note?: string };
    return { name: j.name ?? "policy", source: "policy/fusion-policy.json", locked: j.locked ?? {}, note: j.note ?? "" };
  } catch {
    return { name: "none", source: "absent", locked: {}, note: "No managed policy file found; every setting is user-controlled." };
  }
}
