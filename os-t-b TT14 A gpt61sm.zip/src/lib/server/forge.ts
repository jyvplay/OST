import { inflateRawSync } from "node:zlib";
import { compositePsd, parsePsd, summarizePsd } from "@/lib/psd";
import { encodePng } from "./png";
import { docxToText, evaluateWorkbook, parseDocxXml, parsePptxModel, parseXlsxModel, pptxToText, makeRef } from "@/lib/office";

/**
 * FF-01/FF-02/FF-05/FF-08/FF-12 — Forge format engine.
 *
 * No JSZip, no mammoth, no SheetJS, no LibreOffice, no cloud converter. OOXML files are ZIP containers,
 * so we read the central directory ourselves and inflate members with Node's zlib. That keeps the format
 * layer permissively licensed and lets the bomb guards run before anything is inflated.
 */

export const GUARDS = {
  maxZipBytes: 40 * 1024 * 1024,
  maxEntries: 2000,
  maxEntryBytes: 24 * 1024 * 1024,
  maxTotalBytes: 120 * 1024 * 1024,
  maxRatio: 200,
};

export type ZipEntry = { name: string; size: number; compressedSize: number; method: number; local: number };

function u16(b: Buffer, o: number) { return b.readUInt16LE(o); }
function u32(b: Buffer, o: number) { return b.readUInt32LE(o); }

export function listZip(buf: Buffer): ZipEntry[] {
  if (buf.length > GUARDS.maxZipBytes) throw new Error("archive too large");
  let eocd = -1;
  for (let i = buf.length - 22; i >= Math.max(0, buf.length - 66000); i--) {
    if (u32(buf, i) === 0x06054b50) { eocd = i; break; }
  }
  if (eocd < 0) throw new Error("not a zip container");
  const count = u16(buf, eocd + 10);
  if (count > GUARDS.maxEntries) throw new Error("too many entries");
  let off = u32(buf, eocd + 16);
  const out: ZipEntry[] = [];
  for (let i = 0; i < count; i++) {
    if (u32(buf, off) !== 0x02014b50) break;
    const method = u16(buf, off + 10);
    const compressedSize = u32(buf, off + 20);
    const size = u32(buf, off + 24);
    const nameLen = u16(buf, off + 28);
    const extraLen = u16(buf, off + 30);
    const commentLen = u16(buf, off + 32);
    const local = u32(buf, off + 42);
    const name = buf.subarray(off + 46, off + 46 + nameLen).toString("utf8");
    if (name.includes("..") || name.startsWith("/")) throw new Error(`zip-slip entry rejected: ${name}`);
    out.push({ name, size, compressedSize, method, local });
    off += 46 + nameLen + extraLen + commentLen;
  }
  const total = out.reduce((a, e) => a + e.size, 0);
  if (total > GUARDS.maxTotalBytes) throw new Error("uncompressed size over guard");
  const ratio = total / Math.max(1, buf.length);
  if (ratio > GUARDS.maxRatio) throw new Error(`compression ratio ${ratio.toFixed(0)}:1 over guard (zip bomb)`);
  return out;
}

export function readEntry(buf: Buffer, entry: ZipEntry): Buffer {
  if (u32(buf, entry.local) !== 0x04034b50) throw new Error("bad local header");
  const nameLen = u16(buf, entry.local + 26);
  const extraLen = u16(buf, entry.local + 28);
  const start = entry.local + 30 + nameLen + extraLen;
  const raw = buf.subarray(start, start + (entry.compressedSize || entry.size));
  if (entry.size > GUARDS.maxEntryBytes) throw new Error("entry over guard");
  if (entry.method === 0) return Buffer.from(raw);
  if (entry.method === 8) return inflateRawSync(raw, { maxOutputLength: GUARDS.maxEntryBytes });
  throw new Error(`unsupported compression method ${entry.method}`);
}

const strip = (xml: string) =>
  xml
    .replace(/<w:p[ >][\s\S]*?(?=<\/w:p>)/g, (m) => m + "\n")
    .replace(/<[^>]+>/g, "")
    .replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#39;/g, "'");

export type ForgeResult = {
  format: string;
  grade: "A" | "B" | "C" | "D";
  engine: string;
  text: string;
  sheets?: { name: string; rows: string[][] }[];
  slides?: { index: number; text: string }[];
  layers?: { name: string; bounds: number[]; opacity: number; visible: boolean; blend: string; channels: number[] }[];
  previewPng?: string;
  entries: { name: string; size: number }[];
  warnings: string[];
  lossReport: string[];
};

export function forgeParse(name: string, buf: Buffer): ForgeResult {
  const ext = name.toLowerCase().split(".").pop() ?? "";
  const warnings: string[] = [];
  const lossReport: string[] = [];

  if (["docx", "docm", "xlsx", "xlsm", "pptx", "pptm", "odt", "ods", "odp"].includes(ext)) {
    const entries = listZip(buf);
    if (entries.some((e) => e.name.toLowerCase().includes("vbaproject.bin"))) {
      warnings.push("FF-17: document contains vbaProject.bin — macros detected, never executed, not exported.");
    }
    const get = (n: string) => {
      const e = entries.find((x) => x.name === n);
      return e ? readEntry(buf, e).toString("utf8") : null;
    };
    const entryList = entries.map((e) => ({ name: e.name, size: e.size }));
    if (ext === "docx" || ext === "docm") {
      const model = parseDocxXml(get("word/document.xml") ?? "");
      lossReport.push("Paragraphs and bold/italic/underline runs are modelled; layout and the style cascade are not.");
      lossReport.push(...model.unsupported.map((u) => `Not modelled: ${u}`));
      return { format: "OOXML Word", grade: "C", engine: "forge/office-model", text: docxToText(model), entries: entryList, warnings, lossReport };
    }
    if (ext === "xlsx" || ext === "xlsm") {
      const model = parseXlsxModel(get, entries.map((e) => e.name));
      const values = evaluateWorkbook(model);
      const sheets = model.sheets.map((s) => {
        let maxRow = 0, maxCol = 0;
        for (const ref of Object.keys(s.cells)) {
          const row = Number(ref.replace(/^[A-Z]+/i, "")); const col = ref.replace(/\d+/g, "");
          maxRow = Math.max(maxRow, row); maxCol = Math.max(maxCol, col.length === 1 ? col.charCodeAt(0) - 64 : 26);
        }
        const rows: string[][] = [];
        for (let r = 1; r <= Math.min(maxRow, 500); r++) {
          const row: string[] = [];
          for (let c = 1; c <= maxCol; c++) {
            const v = values.get(`${s.name}!${makeRef(c, r)}`);
            row.push(v === null || v === undefined ? "" : String(v));
          }
          rows.push(row);
        }
        return { name: s.name, rows };
      });
      lossReport.push("Formulas are evaluated by our engine (not the file's cached values); formatting and charts are not modelled.");
      lossReport.push(...model.unsupported.map((u) => `Not modelled: ${u}`));
      return {
        format: "OOXML Spreadsheet", grade: "C", engine: "forge/office-model",
        text: sheets.map((s) => `# ${s.name}\n` + s.rows.map((r) => r.join("\t")).join("\n")).join("\n\n"),
        sheets, entries: entryList, warnings, lossReport,
      };
    }
    if (ext === "pptx" || ext === "pptm") {
      const nameSet = new Set(entries.map((e) => e.name));
      const model = parsePptxModel((n) => {
        const e = entries.find((x) => x.name === n);
        return e ? readEntry(buf, e).toString("utf8") : null;
      }, [...nameSet]);
      const slides = model.slides.map((s) => ({ index: s.index, text: s.shapes.join("\n"), notes: s.notes ?? "" }));
      lossReport.push("Slide shape text and speaker notes are extracted; layouts, media and animations are not rendered (grade C).");
      return {
        format: "OOXML Presentation", grade: "C", engine: "forge/office-model",
        text: pptxToText(model.slides), slides, entries: entryList, warnings, lossReport: [...lossReport, ...model.unsupported.map((u) => `Dropped from source: ${u}`)],
      };
    }
    lossReport.push("OpenDocument text extraction only.");
    return { format: "OpenDocument", grade: "D", engine: "forge/zlib+xml", text: strip(get("content.xml") ?? ""), entries: entryList, warnings, lossReport };
  }

  if (ext === "zip") {
    const entries = listZip(buf);
    return {
      format: "ZIP archive", grade: "A", engine: "forge/zlib",
      text: entries.map((e) => `${e.name}\t${e.size}`).join("\n"),
      entries: entries.map((e) => ({ name: e.name, size: e.size })), warnings, lossReport,
    };
  }

  if (ext === "psd") {
    const doc = parsePsd(buf);
    const flat = compositePsd(doc);
    const layers = summarizePsd(doc);
    lossReport.push("Blend modes other than Normal are composited as Normal.");
    lossReport.push("Adjustment layers, smart objects, text engine data and layer effects are not rendered.");
    lossReport.push("Only 8-bit, uncompressed-or-PackBits channels are decoded; ZIP-compressed channels stay empty.");
    warnings.push(...doc.warnings);
    const previewPng =
      doc.width * doc.height <= 4_000_000 ? encodePng(flat.width, flat.height, new Uint8Array(flat.rgba.buffer)).toString("base64") : undefined;
    return {
      format: "Photoshop PSD", grade: "C", engine: "forge/psd-native",
      text: `${doc.width}×${doc.height}px · ${doc.channels} channels · ${doc.layers.length} layer(s)\n` +
        layers.map((l, i) => `${i + 1}. ${l.name} [${l.bounds.join(",")}] ${l.opacity}%${l.visible ? "" : " (hidden)"}`).join("\n"),
      layers, previewPng, entries: [], warnings, lossReport,
    };
  }

  const text = buf.toString("utf8");
  return { format: ext.toUpperCase() || "TEXT", grade: "A", engine: "forge/native", text, entries: [], warnings, lossReport };
}
