import { createHash } from "node:crypto";
import { existsSync, readFileSync, readdirSync } from "node:fs";
import { join } from "node:path";
import { FEATURES, type FeatureRow } from "@/lib/registry";

/**
 * Independent axes: build completeness != test completeness. Count only 189 register rows, never
 * individual button callbacks. A pass needs a direct test with matching ID, not text mentioning an ID.
 * 'fully tested' requires *all* declared acceptance cases for an audited full-build row to have passed
 * in the current source fingerprint; browser/hardware-only features cannot pass on server tests alone.
 */
export type BuildGrade = "full" | "partial" | "not-built" | "blocked";
export type TestGrade = "full" | "partial" | "untested" | "not-applicable";
export type TestCase = { id: string; pass: boolean; detail?: string; at?: string };
export type LedgerRow = FeatureRow & { buildGrade: BuildGrade; testGrade: TestGrade; passedCases: string[]; missingCases: string[] };

// Audit of *scoped web* contracts. A registry "implemented" flag alone is NOT proof of full build.
// All other implemented rows are downgraded to partial in the ledger until audited individually.
export const FULL_BUILD_CASES: Record<string, string[]> = {
  "FM-16": ["FM-16.filter"], // literal current-folder quick filter, view unchanged
  "SR-04": ["SR-04"], // off by default, opt-in Wikipedia separated below local
  "SR-05": ["SR-05.scope", "SR-05.escape"], // descendant-only query, trash/outside excluded
  "ST-08": ["ST-08", "ST-08a"], // policy locked in API and parser
  "PR-07c": ["PR-07c.group", "PR-07c.collapse"], // named colored group + collapse
  "PR-07f": ["PR-07f.pin", "PR-07f.sleep"], // pinned survives sleep timer and batch close
  "PR-07r": ["PR-07r.save", "PR-07r.reload"], // named session restore of tabs/groups/split
  "FF-17": ["FF-17.macro"], // macro detected and never executed
  "ST-03": ["ST-03.manifest", "ST-03.boundary"], // manifest declarations + user/browser-controlled registration boundary
  "PR-05": ["PR-05.validate", "PR-05.manual", "PR-05.export", "PR-05.picker-boundary"],
  "PR-06": ["PR-06.mailto", "PR-06.handoff"], // encoding + real mailto handoff only
  "PR-12": ["PR-12.sensitive", "PR-12.own-copy", "PR-12.explicit-paste"],
  "FF-02": ["FF-02.formula", "FF-02.roundtrip", "FF-02.library", "FF-02.parser", "FF-02.lookup", "FF-02.conditional", "FF-02.dates", "FF-02.textfn", "FF-02.finance", "FF-02.arity", "FF-02.dynamic-arrays", "FF-02.advanced", "FF-02.ui", "FF-02.spill.allocate", "FF-02.spill.block", "FF-02.spill.dependency", "FF-02.spill.snapshot", "FF-02.spill.broadcast", "FF-02.spill.ui", "FF-02.spill.api", "FF-02.spill.nonconvergent", "FF-02.spill.independent-xlsx"], // + database/engineering/info/stats/depreciation libraries
  "FF-11": ["FF-11.report"], // grade-C fidelity/loss report on every export
  "FF-01": ["FF-01.tables", "FF-01.pptx", "FF-02.roundtrip", "FF-01.tables-ui", "FF-01.condfmt"], // + conditional formatting/validation/autofilter/named ranges
  "FF-05": ["FF-05.raster", "FF-05.ui", "FF-05.filters", "FF-05.production", "FF-05.layers.alpha", "FF-05.layers.masks", "FF-05.layers.project", "FF-05.layers.guards", "FF-05.layers.ui", "FF-05.layers.project-ui", "FF-05.layers.files", "FF-05.layers.canvas-oracle"], // + production filter set (pixelate/duotone/hue/levels/curves/motion/oil/frame/rotate/color)
  "FF-09": ["FF-09.svg", "FF-09.ui", "FF-09.chart", "FF-09.viewbox", "FF-09.shapes", "FF-09.chart-ui", "FF-09.advanced", "FF-09.geometry.matrix", "FF-09.geometry.move", "FF-09.geometry.align", "FF-09.geometry.escape", "FF-09.geometry.ui"], // + gradients/groups/star/arrow round trip
  "CT-02": ["CT-02.bridge"], // real WebRTC data channel between two browser contexts
  "PR-07o": ["PR-07o.profile", "PR-07o.history"], // profile switch + per-profile history
  "MD-03": ["MD-03.gallery", "MD-03.nondestructive"], // gallery lists VFS images; edit saves a new file
  "WM-06": ["WM-06.policy", "WM-06.ssrf", "WM-06.policy-browser"], // per-site sandbox/allow policy applied per tab + SSRF guard
  "PR-07d": ["PR-07d.split"], // horizontal split with interactive resizable divider
  "PR-07e": ["PR-07e.split"], // vertical split without frame remounting
  "PR-07q": ["PR-07q.batch"], // batch close-to-right/duplicates protecting pinned tabs
  "PR-11": ["PR-11.edit", "PR-11.calc"], // in-app document & spreadsheet live editor with formulas
};

// Files whose content materially affects the attested checks. If source changes, the test evidence
// is stale, not magically still passing. Generated evidence files are deliberately excluded.
/** Complete reproducibility boundary, not a hand-maintained subset of helper files. */
function fingerprintFiles(dir: string): string[] {
  const full = join(/* turbopackIgnore: true */ process.cwd(), dir);
  return readdirSync(full, { withFileTypes: true }).flatMap((e) => {
    const p = `${dir}/${e.name}`;
    return e.isDirectory() ? fingerprintFiles(p) : /\.(ts|tsx|js|mjs|css)$/.test(p) ? [p] : [];
  });
}
export function ledgerFingerprint(): string {
  const h = createHash("sha256");
  const files = [
    ...fingerprintFiles("src"), ...fingerprintFiles("tests"), ...fingerprintFiles("scripts"),
    "package.json", "package-lock.json", "next.config.ts", "tsconfig.json", "public/manifest.webmanifest", "public/sw.js", "policy/fusion-policy.json",
  ].sort();
  for (const name of files) {
    h.update(name).update("\0");
    const p = join(/* turbopackIgnore: true */ process.cwd(), name);
    h.update(existsSync(p) ? readFileSync(p) : "missing");
  }
  return h.digest("hex").slice(0, 20);
}

type EvidenceFile = { fingerprint: string; runAt: string; suite: string; passed: boolean; cases: TestCase[] };
export function readEvidence(fingerprint: string): { cases: TestCase[]; acceptedSuites: string[]; staleSuites: string[] } {
  const cases: TestCase[] = [];
  const acceptedSuites: string[] = [];
  const staleSuites: string[] = [];
  for (const file of ["server.json", "legacy-browser.json", "extended-browser.json", "tt14-browser.json"]) {
    try {
      const j = JSON.parse(readFileSync(join(/* turbopackIgnore: true */ process.cwd(), "verification", file), "utf8")) as EvidenceFile;
      const age = Date.now() - Date.parse(j.runAt);
      if (j.fingerprint !== fingerprint || !Array.isArray(j.cases) || !Number.isFinite(age) || age < 0 || age > 7 * 864e5) { staleSuites.push(file); continue; }
      acceptedSuites.push(`${j.suite}@${j.runAt}${j.passed ? " pass" : " failures"}`);
      cases.push(...j.cases);
    } catch { staleSuites.push(file); }
  }
  return { cases, acceptedSuites, staleSuites };
}

export function computeLedger(browserCases: TestCase[], serverCases: TestCase[]): {
  rows: LedgerRow[];
  counts: { total: number; fullBuild: number; partialBuild: number; notBuilt: number; blocked: number; fullTest: number; partialTest: number; untested: number; notApplicable: number };
} {
  const latest = new Map<string, boolean>();
  for (const c of [...serverCases, ...browserCases]) latest.set(c.id, c.pass);
  const rows: LedgerRow[] = FEATURES.map(f => {
    const buildGrade: BuildGrade = f.status === "blocked" || f.status === "not-applicable" ? "blocked"
      : f.status === "spec" || f.status === "skeleton" ? "not-built"
      : f.status === "implemented" && f.id in FULL_BUILD_CASES ? "full" : "partial";
    const seen = [...latest.keys()].filter(id => id === f.id || id.startsWith(`${f.id}.`) || id.match(new RegExp(`^${f.id}[a-z]$`)));
    const passedCases = seen.filter(id => latest.get(id) === true);
    const required = FULL_BUILD_CASES[f.id] ?? [];
    const missingCases = required.filter(id => latest.get(id) !== true);
    const testGrade: TestGrade = buildGrade === "blocked" ? "not-applicable"
      : buildGrade === "full" && required.length > 0 && missingCases.length === 0 ? "full"
      : passedCases.length > 0 ? "partial" : "untested";
    return { ...f, buildGrade, testGrade, passedCases, missingCases };
  });
  const counts = {
    total: rows.length,
    fullBuild: rows.filter(r => r.buildGrade === "full").length,
    partialBuild: rows.filter(r => r.buildGrade === "partial").length,
    notBuilt: rows.filter(r => r.buildGrade === "not-built").length,
    blocked: rows.filter(r => r.buildGrade === "blocked").length,
    fullTest: rows.filter(r => r.testGrade === "full").length,
    partialTest: rows.filter(r => r.testGrade === "partial").length,
    untested: rows.filter(r => r.testGrade === "untested").length,
    notApplicable: rows.filter(r => r.testGrade === "not-applicable").length,
  };
  return { rows, counts };
}
