// Implements: ST-06 (shortcut presets + conflict detector).
// Pure module shared by the Desktop (matching), Settings (table + conflicts) and the self-test.

export const PRESET_NAMES = ["hybrid", "windows", "mac"] as const;
export type Preset = (typeof PRESET_NAMES)[number];

export type Binding = { id: string; label: string; keys: Record<Preset, string> };

export const BINDINGS: Binding[] = [
  { id: "palette", label: "Command palette", keys: { hybrid: "Ctrl+K", windows: "Ctrl+K", mac: "Meta+K" } },
  { id: "overview", label: "Overview", keys: { hybrid: "F1", windows: "F1", mac: "Ctrl+ArrowUp" } },
  { id: "focus", label: "Focus mode", keys: { hybrid: "Ctrl+Shift+F", windows: "Ctrl+Shift+F", mac: "Meta+Shift+F" } },
  { id: "close", label: "Close window", keys: { hybrid: "Ctrl+Shift+W", windows: "Ctrl+Shift+W", mac: "Meta+W" } },
  { id: "cycle", label: "Cycle windows", keys: { hybrid: "Ctrl+Alt+Tab", windows: "Ctrl+Alt+Tab", mac: "Ctrl+Alt+Tab" } },
  { id: "tileLeft", label: "Tile left", keys: { hybrid: "Meta+ArrowLeft", windows: "Meta+ArrowLeft", mac: "Meta+Alt+ArrowLeft" } },
  { id: "tileRight", label: "Tile right", keys: { hybrid: "Meta+ArrowRight", windows: "Meta+ArrowRight", mac: "Meta+Alt+ArrowRight" } },
  { id: "tileFull", label: "Maximise", keys: { hybrid: "Meta+ArrowUp", windows: "Meta+ArrowUp", mac: "Meta+Alt+ArrowUp" } },
  { id: "tileCenter", label: "Centre", keys: { hybrid: "Meta+ArrowDown", windows: "Meta+ArrowDown", mac: "Meta+Alt+ArrowDown" } },
  { id: "nudge", label: "Nudge window (fixed)", keys: { hybrid: "Ctrl+Alt+ArrowLeft", windows: "Ctrl+Alt+ArrowLeft", mac: "Ctrl+Alt+ArrowLeft" } },
];

/** Keys the browser or OS takes before the page sees them. */
export const RESERVED: { keys: string; why: string; blocking: boolean }[] = [
  { keys: "Ctrl+T", why: "new tab", blocking: true },
  { keys: "Ctrl+N", why: "new window", blocking: true },
  { keys: "Ctrl+W", why: "close tab", blocking: true },
  { keys: "Ctrl+Shift+N", why: "private window", blocking: true },
  { keys: "Ctrl+Shift+T", why: "reopen closed tab", blocking: true },
  { keys: "Ctrl+Shift+W", why: "close window (Chromium)", blocking: true },
  { keys: "Ctrl+L", why: "address bar", blocking: true },
  { keys: "Ctrl+R", why: "reload", blocking: true },
  { keys: "F5", why: "reload", blocking: true },
  { keys: "Ctrl+Tab", why: "next tab", blocking: true },
  { keys: "Ctrl+P", why: "print", blocking: true },
  { keys: "Ctrl+H", why: "history", blocking: true },
  { keys: "Ctrl+D", why: "bookmark", blocking: true },
  { keys: "Ctrl+J", why: "downloads", blocking: true },
  { keys: "Alt+F4", why: "close window (OS)", blocking: true },
  { keys: "Meta+W", why: "close tab (macOS browsers)", blocking: true },
  { keys: "Meta+Q", why: "quit (macOS)", blocking: true },
  { keys: "Ctrl+K", why: "search box (Chromium/Firefox, pages may intercept)", blocking: false },
  { keys: "Ctrl+F", why: "find in page (pages may intercept)", blocking: false },
  { keys: "Ctrl+S", why: "save page (pages may intercept)", blocking: false },
  { keys: "Ctrl+Alt+Tab", why: "OS window switcher on some systems", blocking: false },
];

const MOD_ORDER = ["Ctrl", "Alt", "Shift", "Meta"] as const;

/** Canonical form: modifiers in fixed order, single letters upper-cased. Aliases folded (Control, Cmd, Option). */
export function normalizeCombo(s: string): string {
  const parts = s.split("+").map((p) => p.trim()).filter(Boolean);
  const key = parts.pop() ?? "";
  const mods = new Set<string>();
  for (const p of parts) {
    const m = p.toLowerCase();
    if (m === "ctrl" || m === "control") mods.add("Ctrl");
    else if (m === "alt" || m === "option") mods.add("Alt");
    else if (m === "shift") mods.add("Shift");
    else if (m === "meta" || m === "cmd" || m === "command") mods.add("Meta");
  }
  const k = key.length === 1 ? key.toUpperCase() : key;
  return [...MOD_ORDER.filter((m) => mods.has(m)), k].join("+");
}

export function eventCombo(e: Pick<KeyboardEvent, "ctrlKey" | "altKey" | "shiftKey" | "metaKey" | "key">): string {
  const parts: string[] = [];
  if (e.ctrlKey) parts.push("Ctrl");
  if (e.altKey) parts.push("Alt");
  if (e.shiftKey) parts.push("Shift");
  if (e.metaKey) parts.push("Meta");
  parts.push(e.key);
  return normalizeCombo(parts.join("+"));
}

export function matchCombo(e: Pick<KeyboardEvent, "ctrlKey" | "altKey" | "shiftKey" | "metaKey" | "key">, combo: string): boolean {
  if (!combo) return false;
  return eventCombo(e) === normalizeCombo(combo);
}

export function bindingCombo(preset: Preset, id: string): string {
  return BINDINGS.find((b) => b.id === id)?.keys[preset] ?? "";
}

export type Conflict = {
  id: string;
  label: string;
  combo: string;
  kind: "reserved" | "duplicate";
  severity: "block" | "warn";
  detail: string;
};

export function detectConflicts(preset: Preset, standalone: boolean): Conflict[] {
  const out: Conflict[] = [];
  const seen = new Map<string, string>();
  for (const b of BINDINGS) {
    const combo = b.keys[preset];
    if (!combo) continue;
    const norm = normalizeCombo(combo);
    const r = RESERVED.find((x) => normalizeCombo(x.keys) === norm);
    if (r) {
      out.push({
        id: b.id,
        label: b.label,
        combo,
        kind: "reserved",
        severity: r.blocking && !standalone ? "block" : "warn",
        detail: `${r.why}${r.blocking ? (standalone ? " (installed window: may still receive it, verify per browser)" : " (the browser takes this key before the page)") : ""}`,
      });
    }
    if (seen.has(norm)) {
      out.push({ id: b.id, label: b.label, combo, kind: "duplicate", severity: "block", detail: `same keys as “${seen.get(norm)}”` });
    } else {
      seen.set(norm, b.label);
    }
  }
  return out;
}
