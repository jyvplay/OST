// Pure validation/encoding shared by Contacts, Clipboard and Mail acceptance tests.
export type Contact = { id: string; name: string; email: string; tel: string; createdAt: string; source: "manual" | "picker" };
export type ClipItem = { id: string; text: string; sensitive: boolean; createdAt: string; expiresAt: string | null; source: "own-copy" | "explicit-paste" };
export function normaliseContact(input: Partial<Contact>): Omit<Contact, "id" | "createdAt"> | null {
  const name = String(input.name ?? "").trim().slice(0, 120);
  const email = String(input.email ?? "").trim().slice(0, 254);
  const tel = String(input.tel ?? "").trim().slice(0, 60);
  if (!name || (!email && !tel)) return null;
  if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return null;
  return { name, email, tel, source: input.source === "picker" ? "picker" : "manual" };
}
export function liveClips(items: ClipItem[], now = Date.now()): ClipItem[] {
  return items.filter(x => !x.expiresAt || Date.parse(x.expiresAt) > now).slice(0, 100);
}
export function makeClip(text: string, sensitive: boolean, source: ClipItem["source"], now = Date.now()): ClipItem | null {
  const value = text.replace(/\0/g, "").slice(0, 20_000);
  if (!value) return null;
  return { id: `c${now}-${Math.random().toString(36).slice(2, 7)}`, text: value, sensitive, source,
    createdAt: new Date(now).toISOString(), expiresAt: sensitive ? new Date(now + 60_000).toISOString() : null };
}
export function mailtoUrl(to: string, subject: string, body: string): string | null {
  const addr = to.trim();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(addr)) return null;
  const q = new URLSearchParams();
  if (subject) q.set("subject", subject.slice(0, 500));
  if (body) q.set("body", body.slice(0, 10_000));
  return `mailto:${encodeURIComponent(addr)}${q.size ? `?${q.toString()}` : ""}`;
}
