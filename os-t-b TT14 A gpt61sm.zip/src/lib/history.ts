/** Immutable, bounded history. Document versions share unchanged buffers; edit operations must not mutate them. */
export type History<T> = { past: T[]; present: T; future: T[]; limit: number };
export const history = <T>(value: T, limit = 16): History<T> => ({ past: [], present: value, future: [], limit });
export function commit<T>(h: History<T>, next: T): History<T> {
  return next === h.present ? h : { ...h, past: [...h.past, h.present].slice(-h.limit), present: next, future: [] };
}
export function undo<T>(h: History<T>): History<T> {
  if (!h.past.length) return h;
  return { ...h, past: h.past.slice(0, -1), present: h.past[h.past.length - 1], future: [h.present, ...h.future].slice(0, h.limit) };
}
export function redo<T>(h: History<T>): History<T> {
  if (!h.future.length) return h;
  return { ...h, past: [...h.past, h.present].slice(-h.limit), present: h.future[0], future: h.future.slice(1) };
}
