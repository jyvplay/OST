"use client";
import { useCallback, useState, type SetStateAction } from "react";
import { commit, history, redo, undo, type History } from "@/lib/history";

export function useUndo<T>(initial: () => T) {
  const [h, setH] = useState<History<T>>(() => history(initial()));
  const set = useCallback((value: SetStateAction<T>) => setH((s) => commit(s, typeof value === "function" ? (value as (p: T) => T)(s.present) : value)), []);
  return {
    value: h.present, set,
    undo: useCallback(() => setH((s) => undo(s)), []),
    redo: useCallback(() => setH((s) => redo(s)), []),
    reset: useCallback((v: T) => setH(history(v)), []),
    canUndo: h.past.length > 0, canRedo: h.future.length > 0,
  };
}
