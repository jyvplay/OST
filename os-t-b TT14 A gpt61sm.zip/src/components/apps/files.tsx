"use client";

import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Btn, Note, Section, StateDot, Wall, cls, fmtBytes, post, useJson, useShell } from "../ui";
import { WebSearchPanel } from "./productivity";
// Implements: FM-01/FM-02/FM-03/FM-06/FM-11/FM-13/FM-15/FM-16/FM-17 (Files), FM-18 (safe write + verify),
// SR-05 (not built), FF-01/FF-03/FF-08 (Forge preview), SH-09 (side-button nav consumer), SR-01/SR-02/SR-03 (Find).

export type FsNode = {
  id: number; parentId: number | null; name: string; kind: string; mime: string;
  content: string; size: number; trashed: boolean; trashedFrom: string | null;
  tags: string; version: number; updatedAt: string;
};
type Listing = { path: string; id: number | null; entries: FsNode[]; stats: { files: number; dirs: number; bytes: number } };

/* ─────────────────────────── FM-01..FM-18 Files ─────────────────────────── */

function Pane({ initial, onOpenFile, selection, setSelection, paneId }: {
  initial: string;
  onOpenFile: (n: FsNode) => void;
  selection: { pane: string; ids: number[] };
  setSelection: (s: { pane: string; ids: number[] }) => void;
  paneId: string;
}) {
  const [path, setPath] = useState(initial);
  const [filter, setFilter] = useState("");
  const [view, setView] = useState<"list" | "grid" | "column">("list");
  const { data, reload } = useJson<Listing>(`/api/fs?op=list&path=${encodeURIComponent(path)}`, [path]);
  const ids = selection.pane === paneId ? selection.ids : [];

  const entries = useMemo(
    () => (data?.entries ?? []).filter((e) => e.name.toLowerCase().includes(filter.toLowerCase())),
    [data, filter],
  );

  const toggle = (e: React.MouseEvent, n: FsNode, index: number) => {
    const base = selection.pane === paneId ? selection.ids : [];
    if (e.shiftKey && base.length) {
      const lastIdx = entries.findIndex((x) => x.id === base[base.length - 1]);
      const [a, b] = [Math.min(lastIdx, index), Math.max(lastIdx, index)];
      setSelection({ pane: paneId, ids: entries.slice(a, b + 1).map((x) => x.id) });
    } else if (e.ctrlKey || e.metaKey) {
      setSelection({ pane: paneId, ids: base.includes(n.id) ? base.filter((i) => i !== n.id) : [...base, n.id] });
    } else setSelection({ pane: paneId, ids: [n.id] });
  };

  const crumbs = path.split("/").filter(Boolean);
  useEffect(() => {
    const h = () => reload();
    // SH-09: side buttons (3 = back) climb one folder. Applies to every visible pane (declared).
    const nav = (e: Event) => {
      const dir = (e as CustomEvent<{ dir: number }>).detail?.dir;
      if (dir === -1) setPath((p) => "/" + p.split("/").filter(Boolean).slice(0, -1).join("/"));
    };
    window.addEventListener("fusion:fs", h);
    window.addEventListener("fusion:nav", nav);
    return () => {
      window.removeEventListener("fusion:fs", h);
      window.removeEventListener("fusion:nav", nav);
    };
  }, [reload]);

  return (
    <div className="flex min-h-0 min-w-0 flex-1 flex-col border-r border-white/10 last:border-r-0">
      <div className="flex items-center gap-1 border-b border-white/10 px-2 py-1">
        <Btn small onClick={() => setPath("/" + crumbs.slice(0, -1).join("/"))} title="Up (Backspace)">↑</Btn>
        <nav aria-label="Breadcrumbs" className="flex min-w-0 flex-1 items-center gap-0.5 overflow-x-auto text-[11px]">
          <button className="rounded px-1 hover:bg-white/10" onClick={() => setPath("/")}>/</button>
          {crumbs.map((c, i) => (
            <React.Fragment key={i}>
              <span className="text-slate-600">/</span>
              <button className="truncate rounded px-1 hover:bg-white/10" onClick={() => setPath("/" + crumbs.slice(0, i + 1).join("/"))}>{c}</button>
            </React.Fragment>
          ))}
        </nav>
        <input
          aria-label="Quick filter"
          value={filter} onChange={(e) => setFilter(e.target.value)} placeholder="filter"
          className="w-24 rounded border border-white/10 bg-black/30 px-1.5 py-0.5 text-[11px]"
        />
        <select aria-label="View mode" value={view} onChange={(e) => setView(e.target.value as typeof view)} className="rounded border border-white/10 bg-black/30 px-1 py-0.5 text-[11px]">
          <option value="list">list</option><option value="grid">grid</option><option value="column">column</option>
        </select>
      </div>

      <div className={cls("min-h-0 flex-1 overflow-auto p-1", view === "grid" && "grid grid-cols-[repeat(auto-fill,minmax(96px,1fr))] gap-1")}>
        {entries.map((n, i) => {
          const sel = ids.includes(n.id);
          return (
            <div
              key={n.id}
              role="option"
              aria-selected={sel}
              tabIndex={0}
              onClick={(e) => toggle(e, n, i)}
              onDoubleClick={() => (n.kind === "dir" ? setPath(`${path === "/" ? "" : path}/${n.name}`) : onOpenFile(n))}
              onKeyDown={(e) => {
                if (e.key === "Enter") n.kind === "dir" ? setPath(`${path === "/" ? "" : path}/${n.name}`) : onOpenFile(n);
              }}
              className={cls(
                "cursor-default select-none rounded px-2 py-1 text-xs focus-visible:outline focus-visible:outline-1 focus-visible:outline-[var(--accent)]",
                view === "grid" ? "flex flex-col items-center gap-1 text-center" : "flex items-center gap-2",
                sel ? "bg-[var(--accent)]/20 text-white" : "hover:bg-white/5",
              )}
            >
              <span aria-hidden>{n.kind === "dir" ? "📁" : n.mime.startsWith("image") ? "🖼" : "📄"}</span>
              <span className="min-w-0 flex-1 truncate">{n.name}</span>
              {view !== "grid" && <span className="tabular-nums text-[10px] text-slate-500">v{n.version}</span>}
              {view !== "grid" && <span className="w-16 text-right tabular-nums text-[10px] text-slate-500">{fmtBytes(n.size)}</span>}
            </div>
          );
        })}
        {entries.length === 0 && <p className="p-3 text-[11px] text-slate-500">Empty folder.</p>}
      </div>

      <footer className="flex items-center justify-between border-t border-white/10 px-2 py-1 text-[10px] text-slate-400">
        <span>{data?.stats.files ?? 0} files · {data?.stats.dirs ?? 0} dirs · {fmtBytes(data?.stats.bytes ?? 0)}</span>
        <span>{ids.length ? `${ids.length} selected` : path}</span>
      </footer>
    </div>
  );
}

export function FilesApp() {
  const { open, toast, entitlement } = useShell();
  const [dual, setDual] = useState(false);
  const [selection, setSelection] = useState<{ pane: string; ids: number[] }>({ pane: "a", ids: [] });
  const [dest, setDest] = useState("/Home/Projects");
  const [pattern, setPattern] = useState("{name}-{n:2}{ext}");
  const [preview, setPreview] = useState<{ from: string; to: string }[] | null>(null);
  const [opLog, setOpLog] = useState<string[]>([]);
  const readOnly = entitlement?.state === "expired";

  const refresh = () => window.dispatchEvent(new Event("fusion:fs"));

  const run = async (op: "copy" | "move", interrupt?: "before_publish" | "after_publish") => {
    if (readOnly) return toast("Trial expired — Files is read-only (BL-04)", "warn");
    const r = await post<{ op: number; state: string; outcome?: string; journal: { state: string; note: string }[] }>(
      "/api/fs", { op, ids: selection.ids, destParentId: await idOfPath(dest), interrupt });
    setOpLog([`op #${r.op} → ${r.state}${r.outcome ? ` (${r.outcome})` : ""}`, ...r.journal.map((j) => `   ${j.state}: ${j.note}`), ...opLog].slice(0, 40));
    refresh();
  };

  return (
    <div className="flex h-full min-h-0 flex-col">
      <div className="flex flex-wrap items-center gap-1 border-b border-white/10 bg-black/20 px-2 py-1">
        <Btn small onClick={() => setDual((d) => !d)}>{dual ? "Single pane" : "Dual pane"}</Btn>
        <Btn small onClick={async () => { await post("/api/fs", { op: "create", parentId: await idOfPath(dest), name: "new-file.md", kind: "file", mime: "text/markdown", content: "# New\n" }); refresh(); }}>New file</Btn>
        <Btn small onClick={async () => { await post("/api/fs", { op: "create", parentId: await idOfPath(dest), name: "New folder", kind: "dir", mime: "inode/directory" }); refresh(); }}>New folder</Btn>
        <span className="mx-1 text-[10px] text-slate-500">dest</span>
        <input value={dest} onChange={(e) => setDest(e.target.value)} aria-label="Destination path"
          className="w-44 rounded border border-white/10 bg-black/30 px-1.5 py-0.5 text-[11px]" />
        <Btn small kind="primary" onClick={() => run("copy")} disabled={!selection.ids.length}>Copy →</Btn>
        <Btn small onClick={() => run("move")} disabled={!selection.ids.length}>Move →</Btn>
        <Btn small kind="danger" onClick={async () => { await post("/api/fs", { op: "trash", ids: selection.ids }); refresh(); }} disabled={!selection.ids.length}>Trash</Btn>
        <Btn small onClick={() => open("trash", "Trash")}>Open Trash</Btn>
      </div>

      <div className="flex min-h-0 flex-1">
        <Pane paneId="a" initial="/Home/Documents" onOpenFile={(n) => open("editor", n.name, String(n.id))} selection={selection} setSelection={setSelection} />
        {dual && <Pane paneId="b" initial="/Home/Projects" onOpenFile={(n) => open("editor", n.name, String(n.id))} selection={selection} setSelection={setSelection} />}
        <aside className="w-72 shrink-0 overflow-auto border-l border-white/10 bg-black/20 p-2">
          <Section title="Batch rename (FM-03)">
            <input value={pattern} onChange={(e) => setPattern(e.target.value)} aria-label="Rename pattern"
              className="mb-1 w-full rounded border border-white/10 bg-black/30 px-1.5 py-1 text-[11px]" />
            <div className="flex gap-1">
              <Btn small onClick={async () => {
                const r = await post<{ preview: { from: string; to: string }[] }>("/api/fs", { op: "batchRename", ids: selection.ids, pattern, apply: false });
                setPreview(r.preview);
              }}>Preview</Btn>
              <Btn small kind="primary" disabled={!preview?.length} onClick={async () => {
                await post("/api/fs", { op: "batchRename", ids: selection.ids, pattern, apply: true }); setPreview(null); refresh();
              }}>Apply</Btn>
            </div>
            {preview && (
              <ul className="mt-2 max-h-28 overflow-auto text-[10px] text-slate-400">
                {preview.map((p, i) => <li key={i} className="truncate">{p.from} → <span className="text-emerald-300">{p.to}</span></li>)}
              </ul>
            )}
            <Note>UX-02: destructive and bulk actions always render the exact result list before anything is written.</Note>
          </Section>

          <Section title="Journal / crash drill (VR-02)">
            <div className="flex flex-wrap gap-1">
              <Btn small onClick={() => run("copy", "before_publish")} disabled={!selection.ids.length}>Interrupt before publish</Btn>
              <Btn small onClick={() => run("copy", "after_publish")} disabled={!selection.ids.length}>Interrupt after publish</Btn>
            </div>
            <pre className="mt-2 max-h-40 overflow-auto whitespace-pre-wrap text-[10px] leading-tight text-slate-400">{opLog.join("\n") || "no operations yet"}</pre>
            <Note>Every transition is written to <code>file_ops.journal</code> in Postgres before the next one starts, so an interrupted move is recoverable with documented semantics instead of guesswork.</Note>
          </Section>

          <Section title="Disk backends">
            <ul className="space-y-1 text-[11px]">
              <li className="flex items-center gap-2"><StateDot state="available" /> Postgres VFS (always on)</li>
              <li className="flex items-center gap-2"><StateDot state={"showDirectoryPicker" in window ? "needs-permission" : "impossible"} /> Real folders (File System Access)</li>
              <li className="flex items-center gap-2"><StateDot state={navigator.storage && "getDirectory" in navigator.storage ? "available" : "unavailable"} /> OPFS</li>
            </ul>
            {!("showDirectoryPicker" in window) && <Wall>This browser has no File System Access API, so real-disk mounting is unavailable here. We show the gap rather than silently falling back.</Wall>}
            <Btn small onClick={async () => {
              type Picker = () => Promise<{ name: string }>;
              const pick = (window as unknown as { showDirectoryPicker?: Picker }).showDirectoryPicker;
              if (!pick) return toast("No File System Access API in this browser", "warn");
              try { const h = await pick(); toast(`Mounted ${h.name} (session-scoped handle)`); } catch { toast("Picker cancelled"); }
            }}>Mount a real folder…</Btn>
          </Section>
        </aside>
      </div>
    </div>
  );
}

async function idOfPath(path: string): Promise<number | null> {
  if (!path || path === "/") return null;
  const r = await fetch(`/api/fs?op=list&path=${encodeURIComponent(path)}`);
  if (!r.ok) return null;
  const j = (await r.json()) as Listing;
  return j.id;
}

/* ─────────────────────────── Trash (FM-11) ─────────────────────────── */
export function TrashApp() {
  const { data, reload } = useJson<{ entries: FsNode[] }>("/api/fs?op=trash");
  const [sel, setSel] = useState<number[]>([]);
  return (
    <div className="h-full overflow-auto p-3">
      <div className="mb-2 flex gap-1">
        <Btn small onClick={async () => { await post("/api/fs", { op: "restore", ids: sel }); setSel([]); reload(); window.dispatchEvent(new Event("fusion:fs")); }}>Restore</Btn>
        <Btn small kind="danger" onClick={async () => { await post("/api/fs", { op: "purge", ids: sel }); setSel([]); reload(); }}>Delete forever</Btn>
      </div>
      <table className="w-full text-left text-xs">
        <thead className="text-[10px] uppercase text-slate-500"><tr><th></th><th>Name</th><th>Original location</th><th>Size</th></tr></thead>
        <tbody>
          {(data?.entries ?? []).map((n) => (
            <tr key={n.id} className="border-t border-white/5">
              <td><input type="checkbox" checked={sel.includes(n.id)} onChange={(e) => setSel(e.target.checked ? [...sel, n.id] : sel.filter((i) => i !== n.id))} aria-label={`select ${n.name}`} /></td>
              <td className="py-1">{n.name}</td>
              <td className="text-slate-400">{n.trashedFrom}</td>
              <td className="tabular-nums text-slate-400">{fmtBytes(n.size)}</td>
            </tr>
          ))}
        </tbody>
      </table>
      <Note>Trash keeps the original path string, so a restore still lands correctly after the parent folder was renamed.</Note>
    </div>
  );
}

/* ─────────────────────────── PR-01 Editor + FF-15 lifecycle ─────────────────────────── */
export function EditorApp({ docId }: { docId?: string }) {
  const { toast, open, state } = useShell();
  const { data, reload } = useJson<{ node: FsNode; path: string }>(docId ? `/api/fs?op=read&id=${docId}` : null, [docId]);
  const [text, setText] = useState<string | null>(null);
  const [dirty, setDirty] = useState(false);
  const [saving, setSaving] = useState(false);
  const [conflict, setConflict] = useState<{ actual: number; error: string } | null>(null);
  const { data: versions, reload: reloadVersions } = useJson<{ versions: { id: number; version: number; createdAt: string }[] }>(docId ? `/api/fs?op=versions&id=${docId}` : null, [docId]);
  const value = text ?? data?.node.content ?? "";

  const save = useCallback(async () => {
    if (!docId || !data?.node || saving) return;
    setSaving(true);
    try {
      const r = await fetch("/api/fs", { method: "POST", headers: { "content-type": "application/json" },
        body: JSON.stringify({ op: "write", id: Number(docId), content: value, expectedVersion: data.node.version }) });
      const result = await r.json() as { node?: FsNode; code?: string; actual?: number; error?: string };
      if (r.status === 409) { setConflict({ actual: result.actual ?? 0, error: result.error ?? "Version conflict" }); return; }
      if (!r.ok) throw new Error(result.error ?? "Save failed");
      setText(null); setConflict(null); setDirty(false); reload(); reloadVersions(); window.dispatchEvent(new Event("fusion:fs"));
      toast(`Saved transactionally as v${result.node?.version} (BK-01)`);
    } catch (e) { toast(String(e), "error"); }
    finally { setSaving(false); }
  }, [docId, data?.node, value, saving, reload, reloadVersions, toast]);

  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "s" && state.windows.find(w => w.id === state.focus)?.docId === docId) { e.preventDefault(); void save(); }
    };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, [save, state.focus, state.windows, docId]);
  useEffect(() => { if (!dirty) return; const h = (e: BeforeUnloadEvent) => { e.preventDefault(); e.returnValue = ""; }; window.addEventListener("beforeunload", h); return () => window.removeEventListener("beforeunload", h); }, [dirty]);

  if (!docId) return <p className="p-4 text-xs text-slate-400">Open a file from Files to edit it.</p>;
  if (!data?.node) return <p role="status" className="p-4 text-xs text-slate-400">Loading document before editing…</p>;
  return (
    <div className="flex h-full min-h-0">
      <div className="flex min-w-0 flex-1 flex-col">
        <div className="flex items-center gap-2 border-b border-white/10 px-2 py-1 text-[11px]">
          <span className="truncate text-slate-400">{data?.path}</span>
          <span className={cls("rounded px-1", dirty ? "bg-amber-400/20 text-amber-200" : "bg-emerald-400/15 text-emerald-200")}>{dirty ? "unsaved" : "saved"}</span>
          <span className="text-slate-500">v{data?.node.version}</span>
          <div className="flex-1" />
          <Btn small kind="primary" disabled={saving} onClick={() => void save()}>{saving ? "Saving…" : "Save (Ctrl+S)"}</Btn>
        </div>
        {conflict && <div role="alert" data-testid="editor-conflict" className="border-b border-amber-500/40 bg-amber-500/10 p-2 text-[11px] text-amber-100">
          {conflict.error}. Your unsaved draft remains here; the server copy is v{conflict.actual}.
          <div className="mt-1 flex gap-1">
            <Btn small onClick={() => { setText(null); setDirty(false); setConflict(null); reload(); }}>Discard draft &amp; reload</Btn>
            <Btn small kind="primary" onClick={async () => {
              if (!data?.node) return;
              const name = data.node.name.replace(/(\.[^.]+)?$/, " (conflict copy)$1");
              const result = await post<{ node: FsNode }>("/api/fs", { op: "create", parentId: data.node.parentId, name, kind: "file", mime: data.node.mime, content: value });
              setConflict(null); open("editor", result.node.name, String(result.node.id)); toast(`Saved copy: ${result.node.name}`);
            }}>Save a copy</Btn>
          </div>
        </div>}
        <textarea
          aria-label="Editor"
          className="min-h-0 flex-1 resize-none bg-transparent p-3 font-mono text-xs leading-relaxed outline-none"
          value={value}
          onChange={(e) => { setText(e.target.value); setDirty(true); }}
          spellCheck={false}
        />
      </div>
      <aside className="w-56 shrink-0 overflow-auto border-l border-white/10 bg-black/20 p-2">
        <Section title="Timeline (BK-01)">
          <ul className="space-y-1 text-[10px]">
            {(versions?.versions ?? []).map((v) => (
              <li key={v.id} className="flex items-center justify-between gap-1">
                <span>v{v.version} · {new Date(v.createdAt).toLocaleTimeString()}</span>
                <Btn small onClick={async () => { await post("/api/fs", { op: "revert", versionId: v.id }); setText(null); setDirty(false); reload(); reloadVersions(); }}>Restore</Btn>
              </li>
            ))}
          </ul>
          <Note>Retention is capped at 20 versions per file in SQL, so autosave cannot quietly grow the database forever.</Note>
        </Section>
      </aside>
    </div>
  );
}

/* ─────────────────────────── TD-01/02 Terminal ─────────────────────────── */
export function TerminalApp() {
  const [cwd, setCwd] = useState("/Home/Documents");
  const [lines, setLines] = useState<string[]>([
    "Fusion Shell terminal — a real interpreter over the Postgres VFS.",
    "Type `help`. Try: ops / versions readme.md / cp readme.md /Home/Projects --interrupt before_publish",
  ]);
  const [input, setInput] = useState("");
  const [history, setHistory] = useState<string[]>([]);
  const [hIdx, setHIdx] = useState(-1);
  const endRef = useRef<HTMLDivElement>(null);
  useEffect(() => { endRef.current?.scrollIntoView(); }, [lines]);

  const submit = async () => {
    const line = input;
    setLines((l) => [...l, `${cwd} $ ${line}`]);
    setInput("");
    setHistory((h) => [line, ...h].slice(0, 100));
    setHIdx(-1);
    if (line.trim() === "clear") return setLines([]);
    const r = await post<{ cwd: string; out: string[] }>("/api/terminal", { cwd, line });
    setCwd(r.cwd);
    setLines((l) => [...l, ...r.out]);
    window.dispatchEvent(new Event("fusion:fs"));
  };

  return (
    <div className="flex h-full min-h-0 flex-col bg-black/40 font-mono text-[11px] leading-relaxed">
      <div className="min-h-0 flex-1 overflow-auto p-2">
        {lines.map((l, i) => <div key={i} className={cls("whitespace-pre-wrap", l.includes(" $ ") && "text-[var(--accent)]")}>{l}</div>)}
        <div ref={endRef} />
      </div>
      <form className="flex items-center gap-2 border-t border-white/10 px-2 py-1" onSubmit={(e) => { e.preventDefault(); submit(); }}>
        <span className="text-[var(--accent)]">{cwd} $</span>
        <input
          aria-label="Terminal input"
          autoFocus value={input}
          onChange={(e) => setInput(e.target.value)}
          onPaste={(e) => {
            const t = e.clipboardData.getData("text");
            if (t.includes("\n")) { e.preventDefault(); setInput(t.replace(/[\u0000-\u001f]/g, " ").trim()); }
          }}
          onKeyDown={(e) => {
            if (e.key === "ArrowUp") { e.preventDefault(); const i = Math.min(hIdx + 1, history.length - 1); setHIdx(i); setInput(history[i] ?? ""); }
            if (e.key === "ArrowDown") { e.preventDefault(); const i = Math.max(hIdx - 1, -1); setHIdx(i); setInput(i < 0 ? "" : history[i]); }
          }}
          className="flex-1 bg-transparent outline-none"
          spellCheck={false}
        />
      </form>
    </div>
  );
}

/* ─────────────────────────── SR Find ─────────────────────────── */
export function FindApp() {
  const { open } = useShell();
  const [q, setQ] = useState("");
  const [scope, setScope] = useState("");
  const [data, setData] = useState<{ results: { source: string; id: string; title: string; subtitle: string }[]; tookMs: number } | null>(null);
  const [error, setError] = useState("");
  const [diagnostic, setDiagnostic] = useState<{ inScope: number; outsideScope: number; inTrash: number; explanation: string } | null>(null);
  useEffect(() => {
    setDiagnostic(null);
    if (!q.trim()) { setData(null); setError(""); return; }
    let cancelled = false;
    const t = setTimeout(async () => {
      try {
        const response = await fetch(`/api/search?q=${encodeURIComponent(q)}${scope ? `&scope=${encodeURIComponent(scope)}` : ""}`);
        const result = await response.json();
        if (!cancelled) { setData(response.ok ? result : null); setError(response.ok ? "" : result.error); }
      } catch (e) { if (!cancelled) setError(String(e)); }
    }, 110);
    return () => { cancelled = true; clearTimeout(t); };
  }, [q, scope]);
  return (
    <div className="flex h-full min-h-0 flex-col p-3" data-testid="find-app">
      <input autoFocus value={q} onChange={e => setQ(e.target.value)} placeholder="Search local files, notes, settings, features…"
        aria-label="Search" className="mb-2 w-full rounded border border-white/15 bg-black/30 px-3 py-2 text-sm outline-none focus:border-[var(--accent)]" />
      <div className="mb-2 flex flex-wrap items-center gap-1 text-[11px]">
        <span>Folder scope (SR-05)</span>
        <select aria-label="Scope preset" value={["", "/Home/Documents", "/Home/Projects"].includes(scope) ? scope : "custom"}
          onChange={e => setScope(e.target.value === "custom" ? "/Home" : e.target.value)} className="rounded bg-slate-900 px-1 py-1">
          <option value="">All local sources</option><option value="/Home/Documents">/Home/Documents</option><option value="/Home/Projects">/Home/Projects</option><option value="custom">Custom path</option>
        </select>
        <input aria-label="Scope path" value={scope} onChange={e => setScope(e.target.value)} placeholder="/Home/Documents" className="w-40 rounded border border-white/10 bg-black/30 px-2 py-1" />
        <Btn small onClick={async () => {
          const r = await fetch(`/api/search?op=diagnose&q=${encodeURIComponent(q)}${scope ? `&scope=${encodeURIComponent(scope)}` : ""}`);
          const j = await r.json();
          if (r.ok) setDiagnostic(j); else setError(j.error);
        }}>Why missing?</Btn>
      </div>
      {error && <p role="alert" className="mb-2 rounded border border-rose-500/30 p-2 text-rose-200">{error}</p>}
      {diagnostic && <p data-testid="search-diagnostic" className="mb-2 rounded border border-sky-400/20 bg-sky-400/5 p-2 text-[11px] text-sky-200">
        {diagnostic.explanation} Names: {diagnostic.inScope} in scope, {diagnostic.outsideScope} outside, {diagnostic.inTrash} in Trash.
      </p>}
      {!scope && <WebSearchPanel query={q} />}
      {data && <p data-testid="search-summary" className="mb-2 text-[10px] text-slate-500">{data.results.length} {scope ? "scoped file" : "local"} results in {data.tookMs} ms · literal substring matching, not an FTS index</p>}
      <ul data-testid="search-results" className="min-h-0 flex-1 overflow-auto">
        {(data?.results ?? []).map((r, i) => <li key={`${r.source}-${r.id}-${i}`}>
          <button className="flex w-full items-start gap-2 rounded px-2 py-1 text-left text-xs hover:bg-white/5" onClick={() => {
            if (r.source === "file") open("editor", r.title, r.id);
            else if (r.source === "feature") open("ledger");
            else if (r.source === "note") open("notes");
          }}>
            <span className="mt-0.5 rounded bg-white/10 px-1 text-[9px] uppercase text-slate-400">{r.source}</span>
            <span className="min-w-0 flex-1"><span className="block truncate">{r.title}</span><span className="block truncate text-[10px] text-slate-500">{r.subtitle}</span></span>
          </button>
        </li>)}
      </ul>
    </div>
  );
}

/* ─────────────────────────── FF Forge lab ─────────────────────────── */
export function ForgeApp() {
  const [result, setResult] = useState<Record<string, unknown> | null>(null);
  const [busy, setBusy] = useState(false);
  const [pdfUrl, setPdfUrl] = useState<string | null>(null);
  return (
    <div className="h-full overflow-auto p-3">
      <Section title="Format engine (FF-01, FF-12)">
        <input type="file" aria-label="Document to parse"
          onChange={async (e) => {
            const f = e.target.files?.[0];
            if (!f) return;
            setBusy(true);
            const fd = new FormData();
            fd.append("file", f);
            const r = await fetch("/api/forge", { method: "POST", body: fd });
            setResult(await r.json());
            setPdfUrl(f.name.toLowerCase().endsWith(".pdf") ? URL.createObjectURL(f) : null);
            setBusy(false);
          }}
          className="text-[11px]" />
        <Note>
          .docx / .xlsx / .pptx / .zip / .psd are parsed server-side with Node&apos;s own zlib — no JSZip, no SheetJS,
          no LibreOffice, no cloud conversion. That keeps the format layer licence-clean and lets the zip-bomb and
          zip-slip guards run <em>before</em> anything is inflated.
        </Note>
      </Section>
      {busy && <p className="text-xs text-slate-400">parsing…</p>}
      {pdfUrl && (
        <Section title="PDF (FF-03: rendered by the browser’s built-in viewer)">
          <iframe title="PDF preview" src={pdfUrl} className="h-96 w-full rounded bg-white" data-testid="pdf-preview" />
        </Section>
      )}
      {result?.previewPng ? (
        <Section title="PSD composite preview (FF-08, grade C: Normal blend only)">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img alt="PSD composite" data-testid="psd-preview" src={`data:image/png;base64,${String(result.previewPng)}`} className="max-h-72 rounded border border-white/10" />
          {Array.isArray(result.layers) && (
            <ul className="mt-2 text-[10px] text-slate-400" data-testid="psd-layers">
              {(result.layers as { name: string; bounds: number[]; opacity: number; visible: boolean }[]).map((l, i) => (
                <li key={i}>{i + 1}. {l.name} [{l.bounds.join(", ")}] {l.opacity}%{l.visible ? "" : " hidden"}</li>
              ))}
            </ul>
          )}
        </Section>
      ) : null}
      {result && (
        <Section title={`Result — grade ${String(result.grade ?? "?")} · ${String(result.engine ?? "")}`}>
          <p className="mb-2 text-[11px] text-slate-400">{String(result.format)} · {String(result.bytes)} bytes · {String(result.tookMs)} ms</p>
          {Array.isArray(result.warnings) && (result.warnings as string[]).map((w, i) => <p key={i} className="mb-1 rounded border border-amber-400/30 bg-amber-400/10 p-1.5 text-[11px] text-amber-200">{w}</p>)}
          {Array.isArray(result.lossReport) && (result.lossReport as string[]).map((w, i) => <p key={i} className="mb-1 text-[11px] text-slate-400">Loss report: {w}</p>)}
          <pre className="max-h-72 overflow-auto whitespace-pre-wrap rounded bg-black/40 p-2 text-[10px]">{String(result.text ?? result.error ?? "")}</pre>
        </Section>
      )}
    </div>
  );
}
