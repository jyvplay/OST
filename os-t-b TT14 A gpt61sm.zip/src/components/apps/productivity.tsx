"use client";

// Implements: PR-03 (tasks, due alarms while the tab is alive), PR-04 (calendar + ICS import/export),
// PR-10 (countdown timers), AU-01 (routines UI: dry-run default, audit), AU-02 (workspace presets),
// SC-03 (permission audit), SC-05 (privacy dashboard), SH-11 (touchpad acting on own windows),
// MS-06 (Matrix homeserver check), SR-04 (opt-in web results UI).

import React, { useCallback, useEffect, useRef, useState } from "react";
import { Btn, Note, Section, StateDot, Wall, cls, post, useShell } from "../ui";
import { fromIcs, toIcs, type CalEvent } from "@/lib/ics";
import { describeAction, describeTrigger, planFor, validateRoutine, type Action, type Routine, type Trigger } from "@/lib/routines";
import type { DesktopState, TileZone } from "@/lib/windowEngine";

/* ───────────── kv helpers (namespaced, allow-listed server side) ───────────── */

export async function kvGet<T>(key: string, fallback: T): Promise<T> {
  try {
    const r = await fetch(`/api/kvstore?key=${encodeURIComponent(key)}`);
    const j = (await r.json()) as { value: T | null };
    return j.value ?? fallback;
  } catch {
    return fallback;
  }
}

export async function kvPut(key: string, value: unknown): Promise<void> {
  await post("/api/kvstore", { key, value }, "PUT");
  window.dispatchEvent(new CustomEvent("fusion:kv", { detail: { key } }));
}

export function useKvWatch(key: string, cb: () => void) {
  const ref = useRef(cb);
  ref.current = cb;
  useEffect(() => {
    const h = (e: Event) => {
      if ((e as CustomEvent<{ key: string }>).detail?.key === key) ref.current();
    };
    window.addEventListener("fusion:kv", h);
    return () => window.removeEventListener("fusion:kv", h);
  }, [key]);
}

/* ───────────── PR-03 / PR-10 tasks and timers ───────────── */

export type Task = { id: string; title: string; due: string | null; done: boolean; kind: "task" | "timer"; notified: boolean };

/** Called every few seconds by the Desktop. Last-writer-wins on app.tasks (declared gap). */
export async function checkDueTasks(now = Date.now()): Promise<Task[]> {
  const tasks = await kvGet<Task[]>("app.tasks", []);
  const due = tasks.filter((t) => !t.done && !t.notified && t.due && Date.parse(t.due) <= now);
  if (due.length === 0) return [];
  const next = tasks.map((t) => (due.some((d) => d.id === t.id) ? { ...t, notified: true } : t));
  await kvPut("app.tasks", next);
  for (const d of due) {
    await post("/api/alerts", {
      app: d.kind === "timer" ? "Timer" : "Tasks",
      title: d.title,
      body: `Due ${new Date(d.due as string).toLocaleTimeString()}`,
      priority: "high",
    });
  }
  return due;
}

export function TasksApp() {
  const { toast } = useShell();
  const [tasks, setTasks] = useState<Task[]>([]);
  const [title, setTitle] = useState("");
  const [mins, setMins] = useState("");
  const [kind, setKind] = useState<"task" | "timer">("task");
  const reload = useCallback(() => kvGet<Task[]>("app.tasks", []).then(setTasks), []);
  useEffect(() => { void reload(); }, [reload]);
  useKvWatch("app.tasks", reload);

  const add = async () => {
    if (!title.trim()) return toast("Give the task a title", "warn");
    const m = Number(mins);
    if (mins && !(m > 0 && m <= 1440)) return toast("Minutes must be between 0 and 1440", "warn");
    const due = mins ? new Date(Date.now() + m * 60_000).toISOString() : null;
    const t: Task = { id: `t${Date.now()}${Math.random().toString(36).slice(2, 6)}`, title: title.trim(), due, done: false, kind: due && kind === "timer" ? "timer" : "task", notified: false };
    await kvPut("app.tasks", [t, ...tasks]);
    setTitle("");
    setMins("");
    void reload();
  };

  const toggle = async (id: string) => { await kvPut("app.tasks", tasks.map((t) => (t.id === id ? { ...t, done: !t.done } : t))); };
  const remove = async (id: string) => { await kvPut("app.tasks", tasks.filter((t) => t.id !== id)); };

  return (
    <div className="h-full overflow-auto p-3" data-testid="tasks-app">
      <Section title="New item">
        <div className="flex flex-wrap items-center gap-1">
          <input aria-label="Task title" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Title"
            className="min-w-0 flex-1 rounded border border-white/10 bg-black/30 px-2 py-1 text-[11px]" />
          <input aria-label="Minutes until due" value={mins} onChange={(e) => setMins(e.target.value)} placeholder="min (0.05 = 3 s)" inputMode="decimal"
            className="w-36 rounded border border-white/10 bg-black/30 px-2 py-1 text-[11px]" />
          <select aria-label="Kind" value={kind} onChange={(e) => setKind(e.target.value as "task" | "timer")} className="rounded border border-white/10 bg-black/30 px-1 py-1 text-[11px]">
            <option value="task">task</option><option value="timer">timer</option>
          </select>
          <Btn small kind="primary" onClick={add}>Add</Btn>
        </div>
        <div className="mt-2 flex gap-1">
          {[["30 s", 0.5], ["1 min", 1], ["5 min", 5]].map(([l, m]) => (
            <Btn key={String(l)} small onClick={() => { setMins(String(m)); setKind("timer"); }}>{String(l)} timer</Btn>
          ))}
        </div>
        <Note>Alarms fire only while this tab (or the installed app) is running. Browsers offer no background alarm API for web apps, so this is stated rather than hidden.</Note>
      </Section>
      <Section title="Items">
        <ul className="space-y-1" data-testid="task-list">
          {tasks.map((t) => (
            <li key={t.id} className="flex items-center gap-2 rounded border border-white/10 bg-black/20 p-2 text-[11px]">
              <input type="checkbox" checked={t.done} onChange={() => toggle(t.id)} aria-label={`done ${t.title}`} />
              <span className={cls("min-w-0 flex-1 truncate", t.done && "line-through text-slate-500")}>{t.title}</span>
              <span className="text-[10px] text-slate-500">{t.kind}{t.due ? ` · ${new Date(t.due).toLocaleTimeString()}` : ""}{t.notified ? " · fired" : ""}</span>
              <Btn small kind="danger" onClick={() => remove(t.id)}>Delete</Btn>
            </li>
          ))}
          {tasks.length === 0 && <li className="text-[11px] text-slate-500">No items.</li>}
        </ul>
      </Section>
    </div>
  );
}

/* ───────────── PR-04 calendar ───────────── */

export function CalendarApp() {
  const { toast } = useShell();
  const [events, setEvents] = useState<CalEvent[]>([]);
  const [summary, setSummary] = useState("");
  const [start, setStart] = useState("");
  const [end, setEnd] = useState("");
  const reload = useCallback(() => kvGet<CalEvent[]>("app.calendar", []).then(setEvents), []);
  useEffect(() => { void reload(); }, [reload]);
  useKvWatch("app.calendar", reload);

  const save = async (next: CalEvent[]) => {
    const sorted = [...next].sort((a, b) => a.start.localeCompare(b.start));
    await kvPut("app.calendar", sorted);
    setEvents(sorted);
  };

  const add = async () => {
    if (!summary.trim() || !start) return toast("A title and a start time are required", "warn");
    if (end && end < start) return toast("End is before start", "warn");
    await save([...events, { uid: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}@fusion`, summary: summary.trim(), start, end: end || start, location: "", description: "" }]);
    setSummary("");
  };

  const exportIcs = () => {
    const blob = new Blob([toIcs(events)], { type: "text/calendar" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "fusion-calendar.ics";
    a.click();
  };

  const importIcs = async (file: File) => {
    const incoming = fromIcs(await file.text());
    const have = new Set(events.map((e) => e.uid));
    const fresh = incoming.filter((e) => !have.has(e.uid));
    await save([...events, ...fresh]);
    toast(`Imported ${fresh.length} new event(s) from ${file.name} (floating local times)`);
  };

  return (
    <div className="h-full overflow-auto p-3" data-testid="calendar-app">
      <Section title="Add event">
        <div className="flex flex-wrap items-center gap-1">
          <input aria-label="Event title" value={summary} onChange={(e) => setSummary(e.target.value)} placeholder="Title" className="min-w-0 flex-1 rounded border border-white/10 bg-black/30 px-2 py-1 text-[11px]" />
          <input aria-label="Start" type="datetime-local" value={start} onChange={(e) => setStart(e.target.value)} className="rounded border border-white/10 bg-black/30 px-1 py-1 text-[11px]" />
          <input aria-label="End" type="datetime-local" value={end} onChange={(e) => setEnd(e.target.value)} className="rounded border border-white/10 bg-black/30 px-1 py-1 text-[11px]" />
          <Btn small kind="primary" onClick={add}>Add</Btn>
        </div>
      </Section>
      <Section title={`Events (${events.length})`} right={
        <div className="flex gap-1">
          <Btn small onClick={exportIcs}>Export .ics</Btn>
          <label className="cursor-pointer rounded border border-white/15 bg-white/5 px-2 py-1 text-[11px] hover:bg-white/10">
            Import .ics
            <input type="file" accept=".ics,text/calendar" aria-label="Import ICS" className="hidden"
              onChange={(e) => { const f = e.target.files?.[0]; if (f) void importIcs(f); e.currentTarget.value = ""; }} />
          </label>
        </div>}>
        <ul className="space-y-1" data-testid="calendar-events">
          {events.map((e) => (
            <li key={e.uid} className="flex items-center gap-2 text-[11px]">
              <span className="w-40 shrink-0 tabular-nums text-slate-400">{e.start.replace("T", " ")}</span>
              <span className="min-w-0 flex-1 truncate">{e.summary}</span>
              <Btn small kind="danger" onClick={() => save(events.filter((x) => x.uid !== e.uid))}>Remove</Btn>
            </li>
          ))}
          {events.length === 0 && <li className="text-[11px] text-slate-500">No events yet.</li>}
        </ul>
        <Note>Times are floating (no timezone). Imported TZID / UTC values keep their wall-clock digits; recurrence rules and alarms are not expanded.</Note>
      </Section>
    </div>
  );
}

/* ───────────── AU-01 routines ───────────── */

type AuditRow = { id: number; action: string; detail: unknown; at: string };

export function RoutinesApp() {
  const shell = useShell();
  const [list, setList] = useState<Routine[]>([]);
  const [audit, setAudit] = useState<AuditRow[]>([]);
  const [name, setName] = useState("");
  const [tType, setTType] = useState<Trigger["type"]>("app-open");
  const [tVal, setTVal] = useState("calculator");
  const [aType, setAType] = useState<Action["type"]>("notify");
  const [aVal, setAVal] = useState("Routine ran");
  const [aBody, setABody] = useState("");
  const [mode, setMode] = useState<"dry-run" | "live">("dry-run");

  const reload = useCallback(async () => {
    setList(await kvGet<Routine[]>("app.routines", []));
    const a = (await fetch("/api/audit").then((r) => r.json())) as { entries: AuditRow[] };
    setAudit(a.entries.slice(0, 8));
  }, []);
  useEffect(() => { void reload(); }, [reload]);
  useKvWatch("app.routines", reload);

  const save = async (next: Routine[]) => { await kvPut("app.routines", next); setList(next); };

  const add = async () => {
    const trigger: Trigger =
      tType === "app-open" ? { type: "app-open", module: tVal.trim() }
      : tType === "interval" ? { type: "interval", minutes: Number(tVal) }
      : ({ type: tType } as Trigger);
    const action: Action =
      aType === "notify" ? { type: "notify", text: aVal }
      : aType === "note" ? { type: "note", title: aVal, body: aBody }
      : aType === "tile" ? { type: "tile", zone: aVal as TileZone }
      : aType === "focusMode" ? { type: "focusMode", on: aVal === "on" }
      : { type: "open", module: aVal.trim() };
    const r: Routine = { id: `r${Date.now()}`, name: name.trim() || "Untitled routine", enabled: true, mode, trigger, action };
    const err = validateRoutine(r);
    if (err) return shell.toast(err, "warn");
    await save([r, ...list]);
    setName("");
  };

  return (
    <div className="h-full overflow-auto p-3" data-testid="routines-app">
      <Section title="New routine (one trigger, one action)">
        <div className="grid grid-cols-2 gap-1 text-[11px]">
          <input aria-label="Routine name" value={name} onChange={(e) => setName(e.target.value)} placeholder="Name" className="col-span-2 rounded border border-white/10 bg-black/30 px-2 py-1" />
          <select aria-label="Trigger type" value={tType} onChange={(e) => setTType(e.target.value as Trigger["type"])} className="rounded border border-white/10 bg-black/30 px-1 py-1">
            <option value="app-open">when app opens</option><option value="interval">every N minutes</option><option value="display-change">on profile switch</option><option value="manual">manual</option>
          </select>
          <input aria-label="Trigger value" value={tVal} onChange={(e) => setTVal(e.target.value)} disabled={tType === "display-change" || tType === "manual"} placeholder={tType === "interval" ? "minutes" : "module id"} className="rounded border border-white/10 bg-black/30 px-2 py-1 disabled:opacity-40" />
          <select aria-label="Action type" value={aType} onChange={(e) => setAType(e.target.value as Action["type"])} className="rounded border border-white/10 bg-black/30 px-1 py-1">
            <option value="notify">show message</option><option value="note">create note</option><option value="tile">tile focused window</option><option value="focusMode">focus mode on/off</option><option value="open">open app</option>
          </select>
          <input aria-label="Action value" value={aVal} onChange={(e) => setAVal(e.target.value)} placeholder="text / title / zone / on|off / module" className="rounded border border-white/10 bg-black/30 px-2 py-1" />
          {aType === "note" && <input aria-label="Note body" value={aBody} onChange={(e) => setABody(e.target.value)} placeholder="body" className="col-span-2 rounded border border-white/10 bg-black/30 px-2 py-1" />}
          <div className="col-span-2 flex items-center gap-2">
            <label className="flex items-center gap-1"><input type="radio" checked={mode === "dry-run"} onChange={() => setMode("dry-run")} /> dry-run (default)</label>
            <label className="flex items-center gap-1"><input type="radio" checked={mode === "live"} onChange={() => setMode("live")} /> live</label>
            <div className="flex-1" />
            <Btn small kind="primary" onClick={add}>Save routine</Btn>
          </div>
        </div>
      </Section>
      <Section title="Routines">
        <ul className="space-y-2" data-testid="routine-list">
          {list.map((r) => (
            <li key={r.id} className="rounded border border-white/10 bg-black/20 p-2 text-[11px]">
              <div className="flex items-center gap-2">
                <input type="checkbox" aria-label={`enable ${r.name}`} checked={r.enabled} onChange={() => save(list.map((x) => (x.id === r.id ? { ...x, enabled: !x.enabled } : x)))} />
                <span className="font-medium">{r.name}</span>
                <span className="rounded bg-white/10 px-1 text-[9px] uppercase">{r.mode}</span>
                <div className="flex-1" />
                <Btn small onClick={() => save(list.map((x) => (x.id === r.id ? { ...x, mode: x.mode === "live" ? "dry-run" : "live" } : x)))}>{r.mode === "live" ? "→ dry-run" : "→ live"}</Btn>
                <Btn small onClick={() => shell.runRoutine(r, "manual")}>Run now</Btn>
                <Btn small kind="danger" onClick={() => save(list.filter((x) => x.id !== r.id))}>Delete</Btn>
              </div>
              <p className="mt-1 text-slate-400">{planFor(r)}</p>
              <p className="text-[10px] text-slate-500">{describeTrigger(r.trigger)} · {describeAction(r.action)}</p>
            </li>
          ))}
          {list.length === 0 && <li className="text-slate-500">No routines.</li>}
        </ul>
        <Note>Dry-run is the default: a firing writes an audit row and shows the plan instead of acting. Interval routines are skipped while battery saver or data saver is active (RG-06).</Note>
      </Section>
      <Section title="Audit (latest 8)" right={<Btn small onClick={() => void reload()}>Refresh</Btn>}>
        <ul className="space-y-0.5 font-mono text-[10px] text-slate-400" data-testid="audit-list">
          {audit.map((a) => <li key={a.id}>#{a.id} {a.action} {JSON.stringify(a.detail).slice(0, 110)}</li>)}
        </ul>
      </Section>
    </div>
  );
}

/* ───────────── AU-02 workspace presets ───────────── */

type Preset = { id: string; name: string; savedAt: string; state: DesktopState };

export function PresetsApp() {
  const shell = useShell();
  const [presets, setPresets] = useState<Preset[]>([]);
  const [name, setName] = useState("");
  const reload = useCallback(() => kvGet<Preset[]>("app.presets", []).then(setPresets), []);
  useEffect(() => { void reload(); }, [reload]);
  useKvWatch("app.presets", reload);
  const save = async (next: Preset[]) => { await kvPut("app.presets", next); setPresets(next); };

  return (
    <div className="h-full overflow-auto p-3" data-testid="presets-app">
      <Section title="Save the current layout">
        <div className="flex gap-1">
          <input aria-label="Preset name" value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Writing" className="flex-1 rounded border border-white/10 bg-black/30 px-2 py-1 text-[11px]" />
          <Btn small kind="primary" onClick={() => {
            const p: Preset = { id: `p${Date.now()}`, name: name.trim() || `Layout ${presets.length + 1}`, savedAt: new Date().toISOString(), state: shell.snapshot() };
            void save([p, ...presets]);
            setName("");
            shell.toast(`Saved preset “${p.name}” (${p.state.windows.length} windows)`);
          }}>Save</Btn>
        </div>
      </Section>
      <Section title="Presets">
        <ul className="space-y-1" data-testid="preset-list">
          {presets.map((p) => (
            <li key={p.id} className="flex items-center gap-2 text-[11px]">
              <span className="min-w-0 flex-1 truncate">{p.name}</span>
              <span className="text-slate-500">{p.state.windows.length} windows · {new Date(p.savedAt).toLocaleString()}</span>
              <Btn small onClick={() => { shell.loadState(p.state); shell.toast(`Loaded “${p.name}”`); }}>Load</Btn>
              <Btn small kind="danger" onClick={() => void save(presets.filter((x) => x.id !== p.id))}>Delete</Btn>
            </li>
          ))}
          {presets.length === 0 && <li className="text-slate-500">No presets saved.</li>}
        </ul>
        <Note>A preset stores window geometry, z-order, workspaces and focus. It does not store the contents of documents; those are in Files.</Note>
      </Section>
    </div>
  );
}

/* ───────────── SC-03 / SC-05 privacy ───────────── */

const WHY: Record<string, string> = {
  geolocation: "Only for location-aware modules; none exist yet.",
  notifications: "Needed for due-task alarms as OS notifications (optional: in-app toast works without it).",
  camera: "Fusion Lens and Meet capture video only while you press Start.",
  microphone: "Voice recorder and Meet. Never requested at boot.",
  "clipboard-read": "Not requested by the shell; the browser prompts on paste.",
  "clipboard-write": "Used for copy actions.",
  "persistent-storage": "Would protect IndexedDB/OPFS data from eviction. Not requested.",
  midi: "Not used by any module.",
};

export function PrivacyApp() {
  const [perms, setPerms] = useState<Record<string, string>>({});
  const [server, setServer] = useState<{ counts: Record<string, number>; destinations: string[]; telemetry: string } | null>(null);
  useEffect(() => {
    (async () => {
      const out: Record<string, string> = {};
      for (const n of Object.keys(WHY)) {
        try {
          out[n] = (await navigator.permissions.query({ name: n as PermissionName })).state;
        } catch {
          out[n] = "not supported here";
        }
      }
      setPerms(out);
    })();
    fetch("/api/privacy").then((r) => r.json()).then(setServer);
  }, []);
  return (
    <div className="h-full overflow-auto p-3" data-testid="privacy-app">
      <Section title="Browser permissions (SC-03)">
        <ul className="space-y-1 text-[11px]" data-testid="privacy-list">
          {Object.entries(WHY).map(([n, why]) => (
            <li key={n} className="flex items-start gap-2">
              <StateDot state={perms[n] === "granted" ? "available" : perms[n] === "prompt" ? "needs-permission" : perms[n] === "denied" ? "blocked" : "unavailable"} />
              <span className="w-32 shrink-0 font-mono text-[10px]">{n}</span>
              <span className="w-24 shrink-0 text-slate-300">{perms[n] ?? "…"}</span>
              <span className="text-slate-500">{why}</span>
            </li>
          ))}
        </ul>
        <Note>Revoke any grant from the padlock icon in the address bar; the browser, not this app, is the authority.</Note>
      </Section>
      <Section title="Stored data and destinations (SC-05)">
        <div data-testid="privacy-counts" className="grid grid-cols-2 gap-1 text-[11px]">
          {Object.entries(server?.counts ?? {}).map(([k, v]) => <span key={k}>{k}: <b>{v}</b></span>)}
        </div>
        <ul className="mt-2 list-disc pl-4 text-[11px] text-slate-300">
          {(server?.destinations ?? []).map((d) => <li key={d}>{d}</li>)}
        </ul>
        <p className="mt-2 text-[11px] text-slate-400">{server?.telemetry}</p>
      </Section>
    </div>
  );
}

/* ───────────── SH-11 touchpad (acts on this desktop's windows only) ───────────── */

export function TouchpadApp() {
  const { state, dispatch } = useShell();
  const stRef = useRef(state);
  stRef.current = state;
  const [last, setLast] = useState("idle");
  const drag = useRef<{ x: number; y: number; moved: number; wid: string; ox: number; oy: number; dx: number; dy: number } | null>(null);

  const target = () =>
    stRef.current.windows
      .filter((w) => w.workspace === stRef.current.workspace && w.module !== "touchpad" && !w.minimized)
      .sort((a, b) => b.z - a.z)[0];

  return (
    <div className="flex h-full flex-col p-2 text-[11px]">
      <div
        data-testid="touchpad-pad"
        className="flex-1 touch-none select-none rounded-lg border border-white/15 bg-white/5"
        onPointerDown={(e) => {
          const w = target();
          if (!w) { setLast("no window to move"); return; }
          drag.current = { x: e.clientX, y: e.clientY, moved: 0, wid: w.id, ox: w.rect.x, oy: w.rect.y, dx: 0, dy: 0 };
          (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
        }}
        onPointerMove={(e) => {
          const d = drag.current;
          if (!d) return;
          const sx = e.clientX - d.x;
          const sy = e.clientY - d.y;
          d.x = e.clientX;
          d.y = e.clientY;
          d.moved += Math.abs(sx) + Math.abs(sy);
          d.dx += sx * 2; // 2x sensitivity (SH-11 nuance: pointer deltas, not absolute positions)
          d.dy += sy * 2;
          dispatch({ t: "move", id: d.wid, x: d.ox + d.dx, y: d.oy + d.dy });
          setLast(`moved by ${Math.round(d.dx)}, ${Math.round(d.dy)} px`);
        }}
        onPointerUp={() => {
          const d = drag.current;
          drag.current = null;
          if (d && d.moved < 4) {
            dispatch({ t: "cycle", dir: 1 });
            setLast("tap → next window");
          }
        }}
      >
        <div className="flex h-full items-center justify-center text-slate-500">drag here</div>
      </div>
      <p className="mt-1 text-slate-400" data-testid="touchpad-status">{last}</p>
      <Note>Moves windows of this desktop only. A touch surface inside a web page cannot move the operating-system cursor, and this pad never pretends to.</Note>
    </div>
  );
}

/* ───────────── MS-06 Matrix homeserver check ───────────── */

type MatrixRes = { server: string; latencyMs: number; versions: string[]; unstableFeatures: number; loginFlows: string[]; status: { versions: number; login: number } } | { error: string };

export function MatrixPanel() {
  const [server, setServer] = useState("https://matrix.org");
  const [res, setRes] = useState<MatrixRes | null>(null);
  const [busy, setBusy] = useState(false);
  useEffect(() => {
    void kvGet<{ server: string } | null>("app.matrix", null).then((v) => { if (v?.server) setServer(v.server); });
  }, []);
  const check = async () => {
    setBusy(true);
    const r = await fetch(`/api/matrix?server=${encodeURIComponent(server)}`);
    const j = (await r.json()) as MatrixRes;
    setRes(j);
    if (r.ok) await kvPut("app.matrix", { server });
    setBusy(false);
  };
  return (
    <div className="mt-2 rounded border border-white/10 p-2 text-[11px]" data-testid="matrix-panel">
      <p className="mb-1 font-medium">Matrix homeserver (MS-06, partial)</p>
      <div className="flex gap-1">
        <input aria-label="Homeserver URL" value={server} onChange={(e) => setServer(e.target.value)} className="flex-1 rounded border border-white/10 bg-black/30 px-2 py-1" />
        <Btn small onClick={check} disabled={busy}>{busy ? "Checking…" : "Check"}</Btn>
      </div>
      {res && "error" in res && <p className="mt-1 text-amber-300">{res.error}</p>}
      {res && "versions" in res && (
        <div className="mt-1 text-slate-300" data-testid="matrix-result">
          <p>{res.server} · {res.latencyMs} ms · client-server versions: {res.versions.join(", ") || "none"} · unstable features: {res.unstableFeatures}</p>
          <p>login flows: {res.loginFlows.join(", ") || "none"}</p>
        </div>
      )}
      <p className="mt-1 text-[10px] text-slate-500">Read-only probe. Sending needs an access token; that is not configured, so this panel cannot post messages.</p>
    </div>
  );
}

/* ───────────── SR-04 opt-in web results (rendered inside Find) ───────────── */

export function WebSearchPanel({ query }: { query: string }) {
  const { settings, setSetting } = useShell();
  const enabled = settings["find.webResults"] === true;
  const [res, setRes] = useState<{ results?: { title: string; url: string; snippet: string }[]; error?: string; provider?: string } | null>(null);
  useEffect(() => {
    if (!enabled || !query.trim()) { setRes(null); return; }
    const t = setTimeout(() => {
      fetch(`/api/websearch?q=${encodeURIComponent(query)}`).then((r) => r.json()).then(setRes).catch(() => setRes({ error: "request failed" }));
    }, 300);
    return () => clearTimeout(t);
  }, [enabled, query]);
  return (
    <div className="mb-2 rounded border border-white/10 p-2 text-[11px]">
      <label className="flex items-center gap-2">
        <input type="checkbox" checked={enabled} onChange={(e) => void setSetting("find.webResults", e.target.checked)} data-testid="websearch-toggle" />
        Include web results (SR-04: off by default, shown separately, never ranked above local)
      </label>
      {enabled && res?.provider && <p className="mt-1 text-[10px] text-slate-500">{res.provider}</p>}
      {enabled && res?.error && <p className="mt-1 text-amber-300">{res.error}</p>}
      {enabled && res?.results && (
        <ul className="mt-1 space-y-1" data-testid="websearch-results">
          {res.results.map((r) => (
            <li key={r.url}><a className="text-sky-300 underline" href={r.url} target="_blank" rel="noopener noreferrer">{r.title}</a> <span className="text-slate-500">{r.snippet.slice(0, 90)}</span></li>
          ))}
          {res.results.length === 0 && <li className="text-slate-500">No web results.</li>}
        </ul>
      )}
    </div>
  );
}

export { Wall };
