"use client";

import React, { useCallback, useEffect, useRef, useState } from "react";
import { Btn, Note, Section, Wall, useShell } from "../ui";
import { applyRecipe, histogram, type EditRecipe, type Raster } from "@/lib/raster";
import { docBounds, parseVectorDoc, sanitizeSvg, serializeVectorDoc, type VecDoc, type VecShape } from "@/lib/vector";
import { alignShapes, geometryBounds, hitTest, moveShape, rotateShape, scaleShape, stackShape } from "@/lib/vectorGeometry";
import { useUndo } from "../useUndo";

/* ───────────────── FF-05 raster editor ───────────────── */
// The pixel maths lives in lib/raster.ts (pure, headlessly tested). This component only moves bytes
// between a canvas and that engine, and keeps the edit recipe non-destructive.

const EMPTY_RECIPE: EditRecipe = { adjust: { brightness: 1, contrast: 1, saturation: 1 } };

export function ImageApp() {
  const { toast } = useShell();
  const [source, setSource] = useState<Raster | null>(null);
  const [name, setName] = useState("image");
  const [recipe, setRecipe] = useState<EditRecipe>(EMPTY_RECIPE);
  const [stats, setStats] = useState<{ w: number; h: number; peak: number } | null>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const load = useCallback(async (file: File) => {
    try {
      const bitmap = await createImageBitmap(file);
      const off = document.createElement("canvas");
      off.width = bitmap.width; off.height = bitmap.height;
      const ctx = off.getContext("2d", { willReadFrequently: true });
      if (!ctx) throw new Error("2D context unavailable");
      ctx.drawImage(bitmap, 0, 0);
      const img = ctx.getImageData(0, 0, bitmap.width, bitmap.height);
      setSource({ width: img.width, height: img.height, data: img.data });
      setName(file.name.replace(/\.[^.]+$/, ""));
      setRecipe(EMPTY_RECIPE);
    } catch (e) { toast(`Could not decode image: ${String(e)}`, "error"); }
  }, [toast]);

  useEffect(() => {
    if (!source || !canvasRef.current) return;
    const out = applyRecipe(source, recipe);
    const cv = canvasRef.current;
    cv.width = out.width; cv.height = out.height;
    const ctx = cv.getContext("2d");
    if (!ctx) return;
    // Copy into a fresh ArrayBuffer-backed view: ImageData rejects SharedArrayBuffer-backed arrays.
    const framed = new Uint8ClampedArray(out.width * out.height * 4);
    framed.set(out.data);
    ctx.putImageData(new ImageData(framed, out.width, out.height), 0, 0);
    const bins = histogram(out);
    setStats({ w: out.width, h: out.height, peak: bins.indexOf(Math.max(...bins)) });
  }, [source, recipe]);

  const patchAdjust = (k: keyof NonNullable<EditRecipe["adjust"]>, v: number | boolean) =>
    setRecipe((r) => ({ ...r, adjust: { ...r.adjust, [k]: v } }));

  const exportAs = (type: string, ext: string) => {
    const cv = canvasRef.current;
    if (!cv) return;
    cv.toBlob((blob) => {
      if (!blob) return toast(`${ext.toUpperCase()} encoding is not supported by this browser`, "warn");
      const a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      a.download = `${name}.fusion.${ext}`;
      a.click();
    }, type, 0.92);
  };

  return (
    <div className="h-full overflow-auto p-3" data-testid="image-app">
      <Section title="Open a raster image (decoded in this tab)">
        <input type="file" accept="image/*" aria-label="Open image" className="text-[11px]"
          onChange={(e) => { const f = e.target.files?.[0]; if (f) void load(f); e.currentTarget.value = ""; }} />
        <Note>Pixels are processed by our own engine (lib/raster.ts), not a filter library. The source buffer is never mutated — every control re-applies an edit recipe.</Note>
      </Section>

      {source && (
        <>
          <Section title={`Canvas — ${stats?.w ?? 0}×${stats?.h ?? 0}px`} right={
            <div className="flex gap-1">
              <Btn small onClick={() => exportAs("image/png", "png")}>PNG</Btn>
              <Btn small onClick={() => exportAs("image/jpeg", "jpg")}>JPEG</Btn>
              <Btn small onClick={() => exportAs("image/webp", "webp")}>WebP</Btn>
            </div>}>
            <canvas ref={canvasRef} data-testid="image-canvas" className="max-h-80 max-w-full rounded border border-white/10 bg-[repeating-conic-gradient(#222_0_25%,#333_0_50%)_50%/16px_16px]" />
            <p className="mt-1 text-[10px] text-slate-500">Histogram peak luminance: {stats?.peak ?? 0}</p>
          </Section>

          <Section title="Adjustments (non-destructive)">
            <div className="grid grid-cols-2 gap-2 text-[11px]">
              {([["brightness", "Brightness"], ["contrast", "Contrast"], ["saturation", "Saturation"]] as const).map(([k, label]) => (
                <label key={k} className="block">
                  {label} {(recipe.adjust?.[k] ?? 1).toFixed(2)}
                  <input type="range" min={0} max={2} step={0.05} aria-label={label} data-testid={`adj-${k}`}
                    value={recipe.adjust?.[k] ?? 1} onChange={(e) => patchAdjust(k, Number(e.target.value))} className="w-full" />
                </label>
              ))}
              <label className="block">
                Blur radius {recipe.blur ?? 0}
                <input type="range" min={0} max={8} step={1} aria-label="Blur" data-testid="adj-blur"
                  value={recipe.blur ?? 0} onChange={(e) => setRecipe((r) => ({ ...r, blur: Number(e.target.value) }))} className="w-full" />
              </label>
            </div>
            <div className="mt-2 flex flex-wrap gap-1">
              <Btn small testId="grayscale-btn" onClick={() => patchAdjust("grayscale", !recipe.adjust?.grayscale)}>{recipe.adjust?.grayscale ? "Colour" : "Grayscale"}</Btn>
              <Btn small onClick={() => patchAdjust("invert", !recipe.adjust?.invert)}>Invert</Btn>
              <Btn small testId="rotate-btn" onClick={() => setRecipe((r) => ({ ...r, rotate: ((r.rotate ?? 0) + 1) % 4 }))}>Rotate 90°</Btn>
              <Btn small onClick={() => setRecipe((r) => ({ ...r, flip: r.flip === "horizontal" ? null : "horizontal" }))}>Flip H</Btn>
              <Btn small onClick={() => setRecipe((r) => ({ ...r, flip: r.flip === "vertical" ? null : "vertical" }))}>Flip V</Btn>
              <Btn small onClick={() => source && setRecipe((r) => ({ ...r, resize: { width: Math.max(1, Math.round(source.width / 2)), height: Math.max(1, Math.round(source.height / 2)) } }))}>Half size</Btn>
              <Btn small onClick={() => source && setRecipe((r) => ({ ...r, crop: { x: 0, y: 0, w: Math.max(1, Math.round(source.width / 2)), h: source.height } }))}>Crop left half</Btn>
              <Btn small kind="danger" testId="reset-btn" onClick={() => setRecipe(EMPTY_RECIPE)}>Reset recipe</Btn>
            </div>
            <div className="mt-1 flex flex-wrap gap-1">
              {([["equalize", "Equalize"], ["sepia", "Sepia"], ["edges", "Edges"]] as const).map(([k, label]) => (
                <Btn key={k} small kind={recipe[k as keyof EditRecipe] ? "primary" : "ghost"} testId={`fx-${k}`}
                  onClick={() => setRecipe((r) => ({ ...r, [k]: !r[k as keyof EditRecipe] }))}>{label}</Btn>
              ))}
              <Btn small kind={recipe.posterize ? "primary" : "ghost"} testId="fx-posterize"
                onClick={() => setRecipe((r) => ({ ...r, posterize: r.posterize ? null : 4 }))}>Posterize {recipe.posterize ?? "off"}</Btn>
              <Btn small kind={recipe.threshold != null ? "primary" : "ghost"} testId="fx-threshold"
                onClick={() => setRecipe((r) => ({ ...r, threshold: r.threshold != null ? null : 128 }))}>Threshold {recipe.threshold ?? "off"}</Btn>
              <Btn small kind={recipe.vignette != null ? "primary" : "ghost"} testId="fx-vignette"
                onClick={() => setRecipe((r) => ({ ...r, vignette: r.vignette != null ? null : 0.6 }))}>Vignette {recipe.vignette ?? "off"}</Btn>
              <Btn small kind={recipe.noise != null ? "primary" : "ghost"} testId="fx-noise"
                onClick={() => setRecipe((r) => ({ ...r, noise: r.noise != null ? null : 24 }))}>Noise {recipe.noise ?? "off"}</Btn>
            </div>
            <div className="mt-1 flex flex-wrap gap-1">
              <Btn small kind={recipe.pixelate != null ? "primary" : "ghost"} testId="fx-pixelate"
                onClick={() => setRecipe((r) => ({ ...r, pixelate: r.pixelate != null ? null : 8 }))}>Pixelate {recipe.pixelate ?? "off"}</Btn>
              <Btn small kind={recipe.duotone != null ? "primary" : "ghost"} testId="fx-duotone"
                onClick={() => setRecipe((r) => ({ ...r, duotone: r.duotone != null ? null : { dark: [20, 30, 60], light: [240, 220, 180] } }))}>Duotone</Btn>
              <Btn small kind={recipe.hueShift != null ? "primary" : "ghost"} testId="fx-hueshift"
                onClick={() => setRecipe((r) => ({ ...r, hueShift: r.hueShift != null ? null : 180 }))}>Hue {recipe.hueShift ?? "off"}</Btn>
              <Btn small kind={recipe.levels != null ? "primary" : "ghost"} testId="fx-levels"
                onClick={() => setRecipe((r) => ({ ...r, levels: r.levels != null ? null : { black: 20, white: 235, gamma: 1 } }))}>Levels</Btn>
              <Btn small kind={recipe.motionBlur != null ? "primary" : "ghost"} testId="fx-motionblur"
                onClick={() => setRecipe((r) => ({ ...r, motionBlur: r.motionBlur != null ? null : { length: 10, angle: 0 } }))}>Motion blur</Btn>
              <Btn small kind={recipe.oilPaint != null ? "primary" : "ghost"} testId="fx-oilpaint"
                onClick={() => setRecipe((r) => ({ ...r, oilPaint: r.oilPaint != null ? null : { radius: 4, levels: 20 } }))}>Oil paint</Btn>
              <Btn small kind={recipe.frame != null ? "primary" : "ghost"} testId="fx-frame"
                onClick={() => setRecipe((r) => ({ ...r, frame: r.frame != null ? null : { thickness: 10, color: [255, 255, 255] } }))}>Frame</Btn>
              <Btn small kind={recipe.colorBalance != null ? "primary" : "ghost"} testId="fx-colorbalance"
                onClick={() => setRecipe((r) => ({ ...r, colorBalance: r.colorBalance != null ? null : { cyanRed: 10, magentaGreen: -5, yellowBlue: 5 } }))}>Colour balance</Btn>
            </div>
            <label className="mt-1 block text-[10px]">Sharpen {recipe.sharpen ?? 0}
              <input type="range" min={0} max={3} step={0.1} aria-label="Sharpen" data-testid="adj-sharpen"
                value={recipe.sharpen ?? 0} onChange={(e) => setRecipe((r) => ({ ...r, sharpen: Number(e.target.value) }))} className="w-full" />
            </label>
            <pre className="mt-2 overflow-auto rounded bg-black/30 p-2 text-[10px]" data-testid="image-recipe">{JSON.stringify(recipe)}</pre>
          </Section>
        </>
      )}
      <Wall>HEIC decoding and HEIC encoding depend on the browser; where absent the picker simply fails to decode rather than silently substituting a format.</Wall>
    </div>
  );
}

/* ───────────────── FF-09 vector editor ───────────────── */
const STARTER = '<svg xmlns="http://www.w3.org/2000/svg" width="320" height="200"><defs><linearGradient id="sky" x1="0" y1="0" x2="0" y2="100"><stop offset="0" stop-color="#38bdf8"/><stop offset="1" stop-color="#1e3a8a"/></linearGradient></defs><rect x="20" y="20" width="120" height="80" fill="url(#sky)"/><circle cx="230" cy="90" r="45" fill="#f472b6"/><polygon points="280,140 300,170 260,170" fill="#34d399"/><text x="24" y="150" font-size="18" fill="#e2e8f0">Fusion vector</text></svg>';

export function VectorApp() {
  const { toast } = useShell();
  const vh = useUndo<VecDoc>(() => parseVectorDoc(STARTER).doc);
  const doc = vh.value;
  const setDoc = vh.set;
  const [dragPreview, setDragPreview] = useState<VecDoc | null>(null);
  const drag = useRef<{ id: string; x: number; y: number; original: VecDoc; preview: VecDoc | null } | null>(null);
  const [geometryError, setGeometryError] = useState("");
  const [selected, setSelected] = useState<string | null>(null);
  const [report, setReport] = useState<{ removedTags: string[]; removedAttrs: string[]; blockedUrls: string[] } | null>(null);
  const svg = serializeVectorDoc(dragPreview ?? doc);
  const bounds = docBounds(doc);
  const shape = doc.shapes.find((s) => s.id === selected) ?? null;

  const patch = (id: string, change: Partial<VecShape>) =>
    setDoc((d) => ({ ...d, shapes: d.shapes.map((s) => (s.id === id ? ({ ...s, ...change } as VecShape) : s)) }));

  const importSvg = async (file: File) => {
    const text = await file.text();
    const parsed = parseVectorDoc(text);
    vh.reset(parsed.doc);
    setSelected(null);
    setReport(parsed.report);
    const removed = parsed.report.removedTags.length + parsed.report.removedAttrs.length;
    toast(removed ? `Imported after removing ${removed} unsafe node(s)/attribute(s)` : "Imported; nothing unsafe found");
  };

  const command = (fn: () => VecDoc) => { try { setDoc(fn()); setGeometryError(""); } catch (e) { setGeometryError(String(e)); } };
  const scenePoint = (e: React.PointerEvent<HTMLDivElement>) => {
    const el = e.currentTarget.querySelector("svg");
    const ctm = el?.getScreenCTM();
    if (!ctm) return null;
    const p = new DOMPoint(e.clientX, e.clientY).matrixTransform(ctm.inverse());
    return { x: p.x, y: p.y };
  };
  let selectionBounds = null;
  try { if (shape) selectionBounds = geometryBounds(shape); } catch { /* a disclosed unsupported transform */ }

  return (
    <div className="flex h-full min-h-0" data-testid="vector-app">
      <div className="flex min-w-0 flex-1 flex-col items-center justify-center bg-slate-950/60 p-3">
        {/* Sanitised markup only: every import passes through the allow-list before it reaches the DOM. */}
        <div data-testid="vector-canvas" role="region" aria-label="Editable vector canvas" tabIndex={0}
          className="touch-none rounded border border-white/10 bg-slate-900 p-2"
          onPointerDown={(e) => {
            if (e.button !== 0) return;
            const p = scenePoint(e); if (!p) return;
            try {
              const id = hitTest(doc, p.x, p.y); setSelected(id);
              if (id) { drag.current = { id, ...p, original: doc, preview: null }; e.currentTarget.setPointerCapture(e.pointerId); }
            } catch (err) { setGeometryError(String(err)); }
          }}
          onPointerMove={(e) => {
            const d = drag.current; if (!d) return;
            const p = scenePoint(e); if (!p) return;
            d.preview = moveShape(d.original, d.id, p.x - d.x, p.y - d.y); setDragPreview(d.preview);
          }}
          onPointerUp={() => { const d = drag.current; drag.current = null; if (d?.preview) setDoc(d.preview); setDragPreview(null); }}
          onPointerCancel={() => { drag.current = null; setDragPreview(null); }}
          dangerouslySetInnerHTML={{ __html: sanitizeSvg(svg).svg }} />
        <p className="mt-1 text-[10px] text-slate-500">{doc.shapes.length} shape(s) · content bounds {Math.round(bounds.w)}×{Math.round(bounds.h)}</p>
      </div>
      <aside className="w-72 shrink-0 overflow-auto border-l border-white/10 bg-black/20 p-2">
        <Section title="Document">
          <div className="mb-2 flex gap-1">
            <Btn small testId="vector-undo" disabled={!vh.canUndo} onClick={vh.undo}>Undo</Btn>
            <Btn small testId="vector-redo" disabled={!vh.canRedo} onClick={vh.redo}>Redo</Btn>
          </div>
          <div className="flex flex-wrap gap-1">
            <Btn small onClick={() => setDoc((d) => ({ ...d, shapes: [...d.shapes, { id: `s${Date.now()}`, kind: "rect", x: 30, y: 30, width: 80, height: 50, fill: "#34d399", stroke: "none", strokeWidth: 1 }] }))}>+ Rect</Btn>
            <Btn small onClick={() => setDoc((d) => ({ ...d, shapes: [...d.shapes, { id: `s${Date.now()}`, kind: "circle", cx: 90, cy: 90, r: 35, fill: "#fbbf24", stroke: "none", strokeWidth: 1 }] }))}>+ Circle</Btn>
            <Btn small onClick={() => setDoc((d) => ({ ...d, shapes: [...d.shapes, { id: `s${Date.now()}`, kind: "text", x: 30, y: 120, text: "Label", fill: "#e2e8f0", fontSize: 16 }] }))}>+ Text</Btn>
            <Btn small onClick={() => setDoc((d) => ({ ...d, shapes: [...d.shapes, { id: `s${Date.now()}`, kind: "ellipse", cx: 160, cy: 120, rx: 50, ry: 28, fill: "#a78bfa", stroke: "none", strokeWidth: 1 }] }))}>+ Ellipse</Btn>
            <Btn small onClick={() => setDoc((d) => ({ ...d, shapes: [...d.shapes, { id: `s${Date.now()}`, kind: "polygon", points: "60,160 100,200 20,200", fill: "#f472b6", stroke: "#e2e8f0", strokeWidth: 1 }] }))}>+ Polygon</Btn>
            <Btn small onClick={() => setDoc((d) => ({ ...d, shapes: [...d.shapes, { id: `s${Date.now()}`, kind: "polyline", points: "150,190 180,150 210,190", fill: "none", stroke: "#34d399", strokeWidth: 2 }] }))}>+ Polyline</Btn>
            <Btn small testId="add-star" onClick={() => setDoc((d) => ({ ...d, shapes: [...d.shapes, { id: `s${Date.now()}`, kind: "star", cx: 60, cy: 100, outerR: 40, innerR: 18, points: 5, fill: "#fbbf24", stroke: "none", strokeWidth: 1 }] }))}>+ Star</Btn>
            <Btn small testId="add-arrow" onClick={() => setDoc((d) => ({ ...d, shapes: [...d.shapes, { id: `s${Date.now()}`, kind: "arrow", x1: 200, y1: 160, x2: 300, y2: 100, stroke: "#f472b6", strokeWidth: 3, headSize: 12 }] }))}>+ Arrow</Btn>
            <Btn small testId="add-gradient" onClick={() => {
              const gid = `grad${Date.now()}`;
              setDoc((d) => ({
                ...d,
                gradients: [...d.gradients, { id: gid, kind: "linear", x1: 0, y1: 0, x2: 100, y2: 100, stops: [{ offset: 0, color: "#f472b6" }, { offset: 1, color: "#fbbf24" }] }],
                shapes: [...d.shapes, { id: `s${Date.now()}`, kind: "rect", x: 100, y: 100, width: 100, height: 70, fill: `url(#${gid})`, stroke: "none", strokeWidth: 1 }],
              }));
            }}>+ Gradient</Btn>
            <Btn small kind="primary" onClick={() => {
              const a = document.createElement("a");
              a.href = URL.createObjectURL(new Blob([svg], { type: "image/svg+xml" }));
              a.download = "fusion-drawing.svg";
              a.click();
            }}>Export SVG</Btn>
            <label className="cursor-pointer rounded border border-white/15 bg-white/5 px-2 py-1 text-[11px] hover:bg-white/10">
              Import SVG
              <input type="file" accept=".svg,image/svg+xml" aria-label="Import SVG" className="hidden"
                onChange={(e) => { const f = e.target.files?.[0]; if (f) void importSvg(f); e.currentTarget.value = ""; }} />
            </label>
          </div>
        </Section>
        <Section title="Shapes">
          <ul className="space-y-1 text-[11px]" data-testid="vector-list">
            {doc.shapes.map((s) => (
              <li key={s.id} className="flex items-center gap-1">
                <button onClick={() => setSelected(s.id)} className={`min-w-0 flex-1 truncate rounded px-1 text-left ${selected === s.id ? "bg-[var(--accent)]/25" : "hover:bg-white/10"}`}>
                  {s.kind}{s.kind === "text" ? ` — ${s.text}` : ""}
                </button>
                <Btn small kind="danger" onClick={() => setDoc((d) => ({ ...d, shapes: d.shapes.filter((x) => x.id !== s.id) }))}>✕</Btn>
              </li>
            ))}
          </ul>
        </Section>
        {shape && (
          <Section title={`Selected — ${shape.kind}`}>
            <p className="mb-1 text-[10px] text-slate-400" data-testid="vector-bounds">
              {selectionBounds ? `x=${selectionBounds.x.toFixed(1)} y=${selectionBounds.y.toFixed(1)} w=${selectionBounds.w.toFixed(1)} h=${selectionBounds.h.toFixed(1)}` : "Unsupported transform for geometry tools"}
            </p>
            <div className="mb-2 flex flex-wrap gap-1">
              <Btn small testId="vector-nudge" onClick={() => command(() => moveShape(doc, shape.id, 10, 0))}>Move +10 X</Btn>
              <Btn small onClick={() => command(() => moveShape(doc, shape.id, 0, 10))}>Move +10 Y</Btn>
              <Btn small testId="vector-rotate" onClick={() => command(() => rotateShape(doc, shape.id, 15))}>Rotate +15°</Btn>
              <Btn small onClick={() => command(() => scaleShape(doc, shape.id, 1.25))}>Scale 125%</Btn>
              <Btn small onClick={() => command(() => scaleShape(doc, shape.id, 0.8))}>Scale 80%</Btn>
              <Btn small onClick={() => command(() => stackShape(doc, shape.id, 1))}>Raise</Btn>
              <Btn small onClick={() => command(() => stackShape(doc, shape.id, -1))}>Lower</Btn>
              {(["left", "center", "right", "top", "middle", "bottom"] as const).map((edge) => <Btn key={edge} small testId={`vector-align-${edge}`} onClick={() => command(() => alignShapes(doc, [shape.id], edge))}>Align {edge}</Btn>)}
            </div>
            {"fill" in shape && (
              <label className="mb-1 block text-[11px]">Fill
                <input type="color" aria-label="Fill colour" data-testid="vector-fill" value={shape.fill.startsWith("#") ? shape.fill : "#38bdf8"}
                  onChange={(e) => patch(shape.id, { fill: e.target.value } as Partial<VecShape>)} className="ml-2 h-5 w-10 align-middle" />
              </label>
            )}
            {shape.kind === "text" && (
              <label className="mb-1 block text-[11px]">Text
                <input aria-label="Shape text" data-testid="vector-text" value={shape.text}
                  onChange={(e) => patch(shape.id, { text: e.target.value } as Partial<VecShape>)}
                  className="mt-0.5 w-full rounded border border-white/10 bg-black/30 px-1 py-0.5" />
              </label>
            )}
            {shape.kind === "rect" && (
              <label className="block text-[11px]">Width {shape.width}
                <input type="range" min={10} max={300} aria-label="Rect width" value={shape.width}
                  onChange={(e) => patch(shape.id, { width: Number(e.target.value) } as Partial<VecShape>)} className="w-full" />
              </label>
            )}
          </Section>
        )}
        {geometryError && <p role="alert" className="mb-2 text-[10px] text-amber-200">{geometryError}</p>}
        <p className="mb-2 text-[10px] text-slate-500">Drag objects on the canvas or use the movement buttons. Top-level groups move together. Text/path hit boxes are estimates; unsupported imported transforms report an error.</p>
        <Section title="Import safety report (FF-09)">
          <p className="text-[11px] text-slate-400" data-testid="vector-report">
            {report ? `removed tags: ${report.removedTags.join(", ") || "none"}; removed attributes: ${report.removedAttrs.join(", ") || "none"}` : "Import an SVG to see what was stripped."}
          </p>
          <Wall>Imported SVG is parsed and rebuilt from an allow-list: script, event handlers, foreignObject, external references and style blocks never reach the DOM.</Wall>
        </Section>
      </aside>
    </div>
  );
}
