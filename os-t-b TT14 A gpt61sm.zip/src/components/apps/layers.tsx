"use client";
import React, { useEffect, useMemo, useRef, useState } from "react";
import { compositeLayers, invertMask, LAYER_LIMITS, moveLayer, newLayer, parseLayerProject, patchLayer, rectangleMask, serializeLayerProject, type Blend, type LayerDoc } from "@/lib/layers";
import { adjust, createRaster, type Raster } from "@/lib/raster";
import { useUndo } from "../useUndo";
import { Btn, Note, post, useShell } from "../ui";

const id = () => crypto.randomUUID();
const download = (blob: Blob, name: string) => {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a"); a.href = url; a.download = name; a.click();
  setTimeout(() => URL.revokeObjectURL(url), 5000);
};
async function decodeImage(f: File): Promise<Raster> {
  if (f.size > 20_000_000) throw new Error("Image input exceeds 20 MB");
  const bitmap = await createImageBitmap(f);
  try {
    if (bitmap.width * bitmap.height > LAYER_LIMITS.canvasPixels) throw new Error("Image exceeds the 4 MP layer budget");
    const cv = document.createElement("canvas"); cv.width = bitmap.width; cv.height = bitmap.height;
    const ctx = cv.getContext("2d", { willReadFrequently: true });
    if (!ctx) throw new Error("2D canvas unavailable");
    ctx.drawImage(bitmap, 0, 0);
    const img = ctx.getImageData(0, 0, bitmap.width, bitmap.height);
    return { width: img.width, height: img.height, data: img.data };
  } finally { bitmap.close(); }
}
const field = "w-20 rounded border border-white/15 bg-slate-950 px-2 py-1 text-xs";

/** FF-05: operational layer/mask UI over the pure engine, not a claimed PSD editor. */
export function LayersApp() {
  const { toast } = useShell();
  const h = useUndo<LayerDoc>(() => ({ width: 320, height: 200, layers: [] }));
  const doc = h.value;
  const [selected, setSelected] = useState<string | null>(null);
  const [color, setColor] = useState("#f472b6");
  const [message, setMessage] = useState("Open an image or add a fill layer to start.");
  const cvRef = useRef<HTMLCanvasElement>(null);
  const active = doc.layers.find((l) => l.id === selected) ?? doc.layers.at(-1);
  const composite = useMemo(() => {
    try { return { raster: compositeLayers(doc), error: "" }; }
    catch (e) { return { raster: null, error: String(e) }; }
  }, [doc]);

  useEffect(() => {
    if (!cvRef.current || !composite.raster) return;
    const out = composite.raster;
    const cv = cvRef.current; cv.width = out.width; cv.height = out.height;
    const bytes = new Uint8ClampedArray(out.data.length); bytes.set(out.data);
    cv.getContext("2d")?.putImageData(new ImageData(bytes, out.width, out.height), 0, 0);
  }, [composite]);

  const safe = (work: () => void | Promise<void>) => {
    Promise.resolve().then(work).catch((e: unknown) => { const m = String(e instanceof Error ? e.message : e); setMessage(m); toast(m, "error"); });
  };
  const update = (p: Parameters<typeof patchLayer>[2]) => safe(() => { if (active) h.set((d) => patchLayer(d, active.id, p)); });
  const addFill = () => safe(() => {
    const rgb = [1, 3, 5].map((o) => parseInt(color.slice(o, o + 2), 16));
    const raster = createRaster(Math.max(1, Math.round(doc.width / 2)), Math.max(1, Math.round(doc.height / 2)), [rgb[0], rgb[1], rgb[2], 255]);
    if (doc.layers.length >= LAYER_LIMITS.layers) throw new Error("At most 12 layers");
    const layer = newLayer(id(), `Fill ${color}`, raster);
    h.set((d) => ({ ...d, layers: [...d.layers, layer] })); setSelected(layer.id); setMessage("Fill layer added; original layers are unchanged.");
  });
  const addImage = (file: File, base: boolean) => safe(async () => {
    const raster = await decodeImage(file);
    const layer = newLayer(id(), file.name, raster);
    if (base) h.reset({ width: raster.width, height: raster.height, layers: [layer] });
    else {
      if (doc.layers.length >= LAYER_LIMITS.layers) throw new Error("At most 12 layers");
      h.set((d) => ({ ...d, layers: [...d.layers, layer] }));
    }
    setSelected(layer.id); setMessage(`Imported ${file.name} (${raster.width}×${raster.height}). No upload occurred.`);
  });
  const pngBlob = () => new Promise<Blob>((resolve, reject) => {
    cvRef.current?.toBlob((blob) => blob && blob.type === "image/png" ? resolve(blob) : reject(new Error("PNG encoding failed")), "image/png");
  });

  return (
    <div data-testid="layers-app" className="flex h-full min-h-0 flex-col bg-[#0c1321]"
      onKeyDown={(e) => { if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "z" && !(e.target as HTMLElement).matches("input,textarea")) { e.preventDefault(); e.shiftKey ? h.redo() : h.undo(); } }}>
      <div className="flex flex-wrap items-center gap-1 border-b border-white/10 bg-slate-900/80 p-2">
        {[true, false].map((base) => <label key={String(base)} className="cursor-pointer rounded border border-white/15 px-2 py-1 text-[11px] hover:bg-white/10">
          {base ? "Open base…" : "Add image layer…"}
          <input type="file" accept="image/*" aria-label={base ? "Open base image" : "Add image layer"} className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) addImage(f, base); e.currentTarget.value = ""; }} />
        </label>)}
        <Btn small testId="layers-undo" disabled={!h.canUndo} onClick={h.undo}>Undo</Btn>
        <Btn small testId="layers-redo" disabled={!h.canRedo} onClick={h.redo}>Redo</Btn>
        <div className="flex-1" />
        <Btn small onClick={() => safe(async () => download(await pngBlob(), "fusion-composite.png"))}>Export PNG</Btn>
        <Btn small onClick={() => safe(() => download(new Blob([serializeLayerProject(doc)], { type: "application/json" }), "drawing.fusion-layers.json"))}>Save project</Btn>
        <label className="cursor-pointer rounded border border-white/15 px-2 py-1 text-[11px] hover:bg-white/10">Open project…
          <input type="file" accept=".json" aria-label="Open layer project" className="hidden" onChange={(e) => {
            const f = e.target.files?.[0]; if (f) safe(async () => {
              if (f.size > LAYER_LIMITS.projectBytes) throw new Error("Project exceeds 32 MB");
              const loaded = parseLayerProject(await f.text()); h.reset(loaded); setSelected(loaded.layers.at(-1)?.id ?? null); setMessage("Layer project restored with masks and source pixels.");
            }); e.currentTarget.value = "";
          }} />
        </label>
      </div>
      <div className="flex min-h-0 flex-1">
        <main className="flex min-w-0 flex-1 flex-col items-center justify-center overflow-auto p-4">
          <div className="mb-3 flex w-full items-center gap-2 text-[10px] tracking-wide text-slate-400"><span className="rounded bg-teal-400/10 px-2 py-1 text-teal-200">RGBA / sRGB</span><span>{doc.width} × {doc.height} px</span><span className="ml-auto">{doc.layers.length} / 12 layers</span></div>
          <canvas ref={cvRef} data-testid="layers-canvas" aria-label="Layer composite" className="w-full max-w-lg rounded border border-white/15 [image-rendering:pixelated]" style={{ background: "repeating-conic-gradient(#263044 0% 25%,#151f30 0% 50%) 0 0 / 16px 16px" }} />
          <p data-testid="layers-message" role="status" className="mt-3 text-[11px] text-slate-400">{composite.error || message}</p>
        </main>
        <aside className="w-64 shrink-0 overflow-auto border-l border-white/10 bg-[#111b2c] p-3 text-[11px]">
          <h3 className="mb-2 font-semibold uppercase tracking-widest text-slate-400">Layer stack</h3>
          <div className="mb-2 flex items-center gap-2"><input type="color" aria-label="Fill layer colour" value={color} onChange={(e) => setColor(e.target.value)} className="h-6 w-8" /><Btn small testId="layers-add-fill" onClick={addFill}>Add fill layer</Btn></div>
          <ol className="mb-3 space-y-1" data-testid="layers-list">
            {[...doc.layers].reverse().map((l) => <li key={l.id} className={`flex items-center gap-1 rounded border px-2 py-1 ${active?.id === l.id ? "border-teal-300/50 bg-teal-400/10" : "border-white/5"}`}>
              <input type="checkbox" checked={l.visible} aria-label={`Show ${l.name}`} onChange={(e) => safe(() => h.set((d) => patchLayer(d, l.id, { visible: e.target.checked })))} />
              <button className="min-w-0 flex-1 truncate text-left" onClick={() => setSelected(l.id)}>{l.name}</button>
              <span className="text-[9px] text-slate-500">{l.mask ? "MASK" : ""}</span>
            </li>)}
          </ol>
          {active && <div className="space-y-2 border-t border-white/10 pt-3">
            <label className="block">Blend mode<select aria-label="Layer blend mode" value={active.blend} onChange={(e) => update({ blend: e.target.value as Blend })} className="mt-1 w-full rounded bg-slate-950 p-1"><option>normal</option><option>multiply</option><option>screen</option></select></label>
            <label className="block">Opacity <b>{Math.round(active.opacity * 100)}%</b><input type="range" aria-label="Layer opacity" min={0} max={100} value={Math.round(active.opacity * 100)} onChange={(e) => update({ opacity: Number(e.target.value) / 100 })} className="w-full" /></label>
            <div className="flex gap-2"><label>X <input type="number" aria-label="Layer X" value={active.x} onChange={(e) => update({ x: Math.round(Number(e.target.value)) })} className={field} /></label><label>Y <input type="number" aria-label="Layer Y" value={active.y} onChange={(e) => update({ y: Math.round(Number(e.target.value)) })} className={field} /></label></div>
            <div className="flex flex-wrap gap-1">
              <Btn small onClick={() => h.set((d) => moveLayer(d, active.id, 1))}>Raise</Btn><Btn small onClick={() => h.set((d) => moveLayer(d, active.id, -1))}>Lower</Btn>
              <Btn small onClick={() => update({ mask: rectangleMask(active.raster.width, active.raster.height, 0, 0, Math.ceil(active.raster.width / 2), active.raster.height) })}>Keep left half</Btn>
              <Btn small disabled={!active.mask} onClick={() => update({ mask: invertMask(active.mask!) })}>Invert mask</Btn>
              <Btn small disabled={!active.mask} onClick={() => update({ mask: undefined })}>Clear mask</Btn>
              <Btn small onClick={() => update({ raster: adjust(active.raster, { invert: true }) })}>Invert pixels</Btn>
              <Btn small kind="danger" onClick={() => h.set((d) => ({ ...d, layers: d.layers.filter((l) => l.id !== active.id) }))}>Delete layer</Btn>
            </div>
          </div>}
          <div className="mt-3 border-t border-white/10 pt-3"><Btn small kind="primary" onClick={() => safe(async () => {
            const blob = await pngBlob();
            if (blob.size > 2_000_000) throw new Error("PNG exceeds this VFS upload budget; use Export PNG");
            const data = await new Promise<string>((res) => { const r = new FileReader(); r.onload = () => res(String(r.result)); r.readAsDataURL(blob); });
            const folder = await post<{ node: { id: number } }>("/api/fs", { op: "ensureDir", path: "/Home/Pictures" });
            const r = await post<{ node?: { name: string }; error?: string }>("/api/fs", { op: "create", parentId: folder.node.id, name: "composite.png", kind: "file", mime: "image/png", content: data });
            if (!r.node) throw new Error(r.error ?? "Save failed");
            window.dispatchEvent(new Event("fusion:fs")); setMessage(`Saved /Home/Pictures/${r.node.name}; source files were not overwritten.`);
          })}>Save PNG to Files</Btn></div>
          <Note>Normal/multiply/screen use source-over alpha. White masks keep pixels; black masks hide them. Project files preserve layers; PNG flattens them. Undo retains at most 16 states in this tab.</Note>
        </aside>
      </div>
    </div>
  );
}
