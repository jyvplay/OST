"use client";

// Implements: RG-08 (capability report, feature routing by probe), ST-04 (diagnostics export),
// SC-08 (no telemetry; local audit only), ST-01/05/06/07/08/09 (Settings), NC-01/02/04 (Alerts),
// BK-01/03/05 (Backup), SC-01 (Vault), FM/AU/PR/TD/MS/AX/RG cross-references in the feature register.
import React, { useEffect, useMemo, useState } from "react";
import { Badge, Btn, Note, Section, StateDot, Wall, cls, fmtBytes, post, useInterval, useJson, useShell } from "../ui";
import { runProbe, type Probe } from "@/lib/capabilities";
import { BINDINGS, detectConflicts, PRESET_NAMES, type Preset } from "@/lib/shortcuts";
import { kvGet, kvPut, MatrixPanel } from "./productivity";

/* ───────────── PR-09 Calculator (shared engine with the palette) ───────────── */
// Implements: PR-09 basic arithmetic (shunting-yard, no eval). Scientific/units/history: not built.
export function evaluate(expr: string): number {
  const tokens = expr.match(/\d+\.?\d*|[-+*/%^()]|[a-z]+/gi) ?? [];
  const prec: Record<string, number> = { "+": 1, "-": 1, "*": 2, "/": 2, "%": 2, "^": 3 };
  const out: (number | string)[] = [];
  const ops: string[] = [];
  let prev: string | null = null;
  for (const t of tokens) {
    if (/^\d/.test(t)) out.push(parseFloat(t));
    else if (t === "(") ops.push(t);
    else if (t === ")") { while (ops.length && ops[ops.length - 1] !== "(") out.push(ops.pop()!); ops.pop(); }
    else if (prec[t]) {
      if (t === "-" && (prev === null || prec[prev] || prev === "(")) out.push(0);
      while (ops.length && prec[ops[ops.length - 1]] >= prec[t]) out.push(ops.pop()!);
      ops.push(t);
    }
    prev = t;
  }
  while (ops.length) out.push(ops.pop()!);
  const st: number[] = [];
  for (const t of out) {
    if (typeof t === "number") st.push(t);
    else {
      const b = st.pop() ?? 0, a = st.pop() ?? 0;
      st.push(t === "+" ? a + b : t === "-" ? a - b : t === "*" ? a * b : t === "/" ? a / b : t === "%" ? a % b : a ** b);
    }
  }
  return st.pop() ?? NaN;
}

export function CalculatorApp() {
  const [expr, setExpr] = useState("12 * (3 + 4) ^ 2");
  const [history, setHistory] = useState<string[]>([]);
  let value = "";
  try { value = String(evaluate(expr)); } catch { value = "—"; }
  return (
    <div className="h-full overflow-auto p-3">
      <input value={expr} onChange={(e) => setExpr(e.target.value)} aria-label="Expression"
        onKeyDown={(e) => { if (e.key === "Enter") setHistory([`${expr} = ${value}`, ...history].slice(0, 20)); }}
        className="w-full rounded border border-white/15 bg-black/30 px-3 py-2 font-mono text-sm outline-none" />
      <p className="mt-2 font-mono text-2xl text-[var(--accent)]" data-testid="calc-result">{value}</p>
      <ul className="mt-3 space-y-0.5 font-mono text-[11px] text-slate-400">{history.map((h, i) => <li key={i}>{h}</li>)}</ul>
      <Note>Shunting-yard parser, never <code>eval</code>. The palette’s inline calculation and this app share one implementation.</Note>
    </div>
  );
}

/* ───────────── PR-02 Notes ───────────── */
type Note2 = { id: number; title: string; body: string; tags: string; updatedAt: string };
export function NotesApp() {
  const { data, reload } = useJson<{ notes: Note2[]; backlinks: Record<number, number[]> }>("/api/notes");
  const [sel, setSel] = useState<number | null>(null);
  const note = data?.notes.find((n) => n.id === sel) ?? data?.notes[0];
  const [draft, setDraft] = useState<string | null>(null);
  useEffect(() => setDraft(null), [note?.id]);
  return (
    <div className="flex h-full min-h-0">
      <div className="w-52 shrink-0 overflow-auto border-r border-white/10 p-1">
        <Btn small onClick={async () => { await post("/api/notes", { title: "Untitled" }); reload(); }}>+ New note</Btn>
        {(data?.notes ?? []).map((n) => (
          <button key={n.id} onClick={() => setSel(n.id)}
            className={cls("mt-1 block w-full truncate rounded px-2 py-1 text-left text-[11px]", n.id === note?.id ? "bg-[var(--accent)]/20" : "hover:bg-white/5")}>
            {n.title}
            {(data?.backlinks[n.id]?.length ?? 0) > 0 && <span className="ml-1 text-[9px] text-sky-300">↩{data!.backlinks[n.id].length}</span>}
          </button>
        ))}
      </div>
      {note && (
        <div className="flex min-w-0 flex-1 flex-col">
          <input value={note.title} onChange={async (e) => { await post("/api/notes", { id: note.id, title: e.target.value }, "PATCH"); reload(); }}
            aria-label="Note title" className="border-b border-white/10 bg-transparent px-3 py-2 text-sm outline-none" />
          <textarea value={draft ?? note.body} onChange={(e) => setDraft(e.target.value)}
            onBlur={async () => { if (draft !== null) { await post("/api/notes", { id: note.id, body: draft }, "PATCH"); reload(); } }}
            aria-label="Note body" className="min-h-0 flex-1 resize-none bg-transparent p-3 text-xs outline-none" />
          <p className="border-t border-white/10 px-3 py-1 text-[10px] text-slate-500">Link another note with [[Its Title]]. Backlinks resolve on the server. Markdown is stored, not rendered.</p>
        </div>
      )}
    </div>
  );
}

/* ───────────── NC-01 / NC-02 / NC-04 Alerts ───────────── */
type Alert = { id: number; app: string; title: string; body: string; priority: string; read: boolean; pinned: boolean; createdAt: string };
export function AlertsApp() {
  const { data, reload } = useJson<{ alerts: Alert[]; groups: Record<string, Alert[]>; expired: number }>("/api/alerts");
  const { dnd, heldCount, setDnd } = useShell();
  const [diag, setDiag] = useState<{ permission: string; sw: string }>({ permission: "n/a", sw: "checking" });
  useEffect(() => {
    const permission = typeof Notification === "undefined" ? "API absent" : Notification.permission;
    const sw = !("serviceWorker" in navigator) ? "unsupported"
      : "getRegistration" in navigator.serviceWorker ? "checking" : "unsupported";
    setDiag({ permission, sw });
    if ("serviceWorker" in navigator) {
      navigator.serviceWorker.getRegistration().then((r) => setDiag({ permission, sw: r ? `registered (${r.active?.state ?? "installing"})` : "not registered" }));
    }
  }, []);
  return (
    <div className="h-full overflow-auto p-3" data-testid="alerts-app">
      <div className="mb-2 flex flex-wrap gap-1">
        <Btn small onClick={async () => { await post("/api/alerts", { app: "Fusion", title: "Test alert", body: "Generated locally." }); reload(); }}>Add test alert</Btn>
        <Btn small onClick={() => { if (typeof Notification !== "undefined") void Notification.requestPermission().then(() => location.reload()); }}>Enable OS notifications</Btn>
        <Btn small kind="danger" onClick={async () => { await fetch("/api/alerts?all=1", { method: "DELETE" }); reload(); }}>Dismiss all (unpinned)</Btn>
        <label className="ml-auto flex items-center gap-1 text-[11px]"><input type="checkbox" checked={dnd} onChange={(e) => setDnd(e.target.checked)} /> Do not disturb</label>
      </div>
      <Section title="Diagnostics (NC-04)">
        <ul className="space-y-0.5 text-[11px]">
          <li className="flex items-center gap-2"><StateDot state={diag.permission === "granted" ? "available" : diag.permission === "denied" ? "blocked" : "needs-permission"} />OS notification permission: {diag.permission}</li>
          <li className="flex items-center gap-2"><StateDot state={diag.sw.startsWith("registered") ? "available" : "needs-permission"} />Service worker: {diag.sw}</li>
          <li>Do-not-disturb holds this session: {heldCount} (stored in alerts with app “Held (DND)”)</li>
        </ul>
      </Section>
      {Object.entries(data?.groups ?? {}).map(([app, list]) => (
        <Section key={app} title={`${app} (${list.length})`}>
          {list.map((a) => (
            <div key={a.id} className="mb-1 flex items-start gap-2 rounded border border-white/10 bg-black/20 p-2">
              <StateDot state={a.priority === "high" ? "blocked" : "available"} />
              <div className="min-w-0 flex-1">
                <p className="text-[11px] font-medium">{a.title}</p>
                <p className="text-[10px] text-slate-400">{a.body}</p>
              </div>
              <Btn small onClick={async () => { await post("/api/alerts", { ids: [a.id], pinned: !a.pinned }, "PATCH"); reload(); }}>{a.pinned ? "Unpin" : "Pin"}</Btn>
              <Btn small onClick={async () => { await post("/api/alerts", { ids: [a.id], snoozeMinutes: 15 }, "PATCH"); reload(); }}>Snooze</Btn>
            </div>
          ))}
        </Section>
      ))}
      <Note>NC-01: history has a 7-day TTL enforced at read time ({data?.expired ?? 0} rows currently past it). No other app’s notifications are read: the browser offers no listener API.</Note>
    </div>
  );
}

/* ───────────── ST-01 / ST-05 / ST-06 / ST-07 / ST-08 / ST-09 Settings ───────────── */
export function SettingsApp() {
  const { settings, setSetting, locked } = useShell();
  const [history, setHistory] = useState<{ key: string; from: unknown; to: unknown; at: string }[]>([]);
  const [policy, setPolicy] = useState<{ name: string; note: string } | null>(null);
  const [q, setQ] = useState("");
  const reloadHistory = () => fetch("/api/settings").then((r) => r.json()).then((j) => setHistory(j.history ?? []));
  useEffect(() => {
    void reloadHistory();
    fetch("/api/policy").then((r) => r.json()).then(setPolicy);
  }, []);

  const preset = String(settings["shell.shortcutPreset"] ?? "hybrid") as Preset;
  const standalone = typeof matchMedia === "function" && matchMedia("(display-mode: standalone)").matches;
  const conflicts = useMemo(() => detectConflicts(preset, standalone), [preset, standalone]);
  const isLocked = (k: string) => k in locked;

  const row = (k: string, label: string, control: React.ReactNode) => (
    <div key={k} className="flex items-center gap-2 border-b border-white/5 py-1 text-[11px]">
      <span className="w-52 shrink-0 text-slate-300">{label} <code className="text-[9px] text-slate-600">{k}</code></span>
      <div className="flex-1">{control}</div>
      {isLocked(k) && <Badge tone="amber">locked by policy</Badge>}
    </div>
  );
  const sel = (k: string, opts: string[]) => (
    <select aria-label={k} disabled={isLocked(k)} value={String(settings[k] ?? opts[0])} onChange={(e) => void setSetting(k, e.target.value)}
      className="rounded border border-white/10 bg-black/30 px-1 py-0.5 disabled:opacity-40">
      {opts.map((o) => <option key={o}>{o}</option>)}
    </select>
  );
  const chk = (k: string) => (
    <input type="checkbox" aria-label={k} disabled={isLocked(k)} checked={settings[k] === true} onChange={(e) => void setSetting(k, e.target.checked)} />
  );

  const visibleKeys = Object.keys(settings).filter((k) => k.toLowerCase().includes(q.toLowerCase()));

  return (
    <div className="h-full overflow-auto p-3" data-testid="settings-app">
      <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search settings" aria-label="Search settings"
        className="mb-2 w-full rounded border border-white/15 bg-black/30 px-2 py-1 text-xs" />
      <Section title="Appearance (ST-05, ST-07, AX-03)">
        {row("appearance.density", "Density", sel("appearance.density", ["compact", "balanced", "touch"]))}
        {row("appearance.motion", "Motion", sel("appearance.motion", ["system", "reduce", "full"]))}
        {row("appearance.fontScale", `Text scale ${settings["appearance.fontScale"] ?? 100}%`,
          <input type="range" min={85} max={140} aria-label="appearance.fontScale" disabled={isLocked("appearance.fontScale")}
            value={Number(settings["appearance.fontScale"] ?? 100)} onChange={(e) => void setSetting("appearance.fontScale", Number(e.target.value))} className="w-full" />)}
        {row("appearance.accent", "Accent", <input type="color" aria-label="appearance.accent" value={String(settings["appearance.accent"] ?? "#5eead4")} onChange={(e) => void setSetting("appearance.accent", e.target.value)} />)}
        {row("profiles.auto", "Switch density profile on display change (ST-09)", chk("profiles.auto"))}
        <Note>Only the dark theme exists. Text scale affects rem-based text; window geometry stays in CSS pixels.</Note>
      </Section>
      <Section title="Shortcuts (ST-06)">
        {row("shell.shortcutPreset", "Preset", sel("shell.shortcutPreset", [...PRESET_NAMES]))}
        {row("shell.hotCorners", "Hot corners open Overview (SH-06)", chk("shell.hotCorners"))}
        <div className="mt-2" data-testid="shortcut-conflicts">
          {conflicts.length === 0 && <p className="text-emerald-300">No conflicts for the “{preset}” preset.</p>}
          {conflicts.map((c) => (
            <p key={`${c.id}-${c.kind}`} className={cls("mb-1 rounded border p-1", c.severity === "block" ? "border-rose-400/40 text-rose-200" : "border-amber-400/40 text-amber-200")}>
              <b>{c.severity.toUpperCase()}</b> {c.label} ({c.combo}): {c.kind === "duplicate" ? c.detail : `${c.detail}`}
            </p>
          ))}
        </div>
        <table className="mt-2 w-full text-left text-[10px]">
          <thead className="text-slate-500"><tr><th>Action</th><th>hybrid</th><th>windows</th><th>mac</th></tr></thead>
          <tbody>
            {BINDINGS.map((b) => (
              <tr key={b.id} className="border-t border-white/5"><td className="py-0.5">{b.label}</td><td>{b.keys.hybrid}</td><td>{b.keys.windows}</td><td>{b.keys.mac}</td></tr>
            ))}
          </tbody>
        </table>
        <Note>The browser reserves several combinations (Ctrl+T, Ctrl+W, Ctrl+Shift+W…). Those are flagged, never bound silently. Installed windows may still receive some of them; verify per browser.</Note>
      </Section>
      <Section title="Runtime, privacy and notifications">
        {row("runtime.lowMemoryMode", "Low-memory mode (RG-07: sleep tabs after 20 s)", chk("runtime.lowMemoryMode"))}
        {row("focus.dnd", "Do not disturb (NC-02)", chk("focus.dnd"))}
        {row("privacy.telemetry", "Telemetry (none exists in this build)", chk("privacy.telemetry"))}
        {row("find.webResults", "Web results in Find (SR-04)", chk("find.webResults"))}
        {row("files.confirmDestructive", "Confirm destructive actions", chk("files.confirmDestructive"))}
      </Section>
      <Section title={`Managed policy (ST-08): ${policy?.name ?? "…"}`}>
        <p className="text-[11px] text-slate-400">{policy?.note}</p>
        <p className="mt-1 text-[11px]">Locked keys: {Object.keys(locked).length ? Object.keys(locked).join(", ") : "none"}</p>
      </Section>
      <Section title="All keys">
        {visibleKeys.map((k) => (
          <div key={k} className="flex items-center gap-2 py-0.5 text-[10px]">
            <code className="w-56 shrink-0 text-slate-400">{k}</code>
            <span className="truncate text-slate-300">{JSON.stringify(settings[k])}</span>
          </div>
        ))}
      </Section>
      <Section title="Reversible history (DP-05)">
        <ul className="space-y-1 text-[10px] text-slate-400">
          {history.slice(0, 12).map((h, i) => (
            <li key={i} className="flex items-center gap-2">
              <span className="flex-1 truncate">{h.key}: {JSON.stringify(h.from)} → {JSON.stringify(h.to)}</span>
              <Btn small onClick={async () => { await setSetting(h.key, h.from); void reloadHistory(); }}>Undo</Btn>
            </li>
          ))}
        </ul>
      </Section>
      <Section title="Platform settings (ST-02)">
        <Wall>A web page cannot deep-link into browser settings. Path: padlock in the address bar → Site settings.</Wall>
      </Section>
    </div>
  );
}

/* ───────────── Feature register (source of truth, browsable) ───────────── */
type Feature = { id: string; area: string; title: string; tier: string; phase: string; status: string; webNuance: string };
export function RegistryApp() {
  const { data, reload } = useJson<{ features: Feature[]; total: number; byStatus: Record<string, number>; byTier: Record<string, number> }>("/api/registry");
  const [q, setQ] = useState("");
  const [area, setArea] = useState("all");
  const areas = useMemo(() => ["all", ...Array.from(new Set((data?.features ?? []).map((f) => f.area)))], [data]);
  const rows = (data?.features ?? []).filter((f) =>
    (area === "all" || f.area === area) &&
    (q === "" || `${f.id} ${f.title} ${f.webNuance}`.toLowerCase().includes(q.toLowerCase())));
  return (
    <div className="flex h-full min-h-0 flex-col">
      <div className="flex flex-wrap items-center gap-2 border-b border-white/10 p-2 text-[11px]">
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="filter rows" aria-label="Filter features"
          className="w-48 rounded border border-white/10 bg-black/30 px-2 py-1" />
        <select value={area} onChange={(e) => setArea(e.target.value)} aria-label="Area" className="rounded border border-white/10 bg-black/30 px-1 py-1">
          {areas.map((a) => <option key={a}>{a}</option>)}
        </select>
        <span className="text-slate-400">{rows.length} of {data?.total ?? 0} rows</span>
        {Object.entries(data?.byStatus ?? {}).map(([k, v]) => <Badge key={k}>{k}: {v}</Badge>)}
      </div>
      <div className="min-h-0 flex-1 overflow-auto">
        <table className="w-full text-left text-[11px]">
          <thead className="sticky top-0 bg-slate-900/95 text-[10px] uppercase text-slate-500">
            <tr><th className="p-1">ID</th><th>Feature</th><th>Tier</th><th>Phase</th><th>Status</th><th>Web nuance</th></tr>
          </thead>
          <tbody>
            {rows.map((f) => (
              <tr key={f.id} className="border-t border-white/5 align-top hover:bg-white/5">
                <td className="p-1 font-mono text-[10px] text-[var(--accent)]">{f.id}</td>
                <td className="p-1">{f.title}</td>
                <td className="p-1">{f.tier}</td>
                <td className="p-1">{f.phase}</td>
                <td className="p-1"><span className="rounded border border-white/10 px-1 text-[10px]">{f.status}</span></td>
                <td className="max-w-md p-1 text-[10px] leading-snug text-slate-400">{f.webNuance}</td>
              </tr>
            ))}
          </tbody>
        </table>
        <p className="p-2 text-[10px] text-slate-500">Status overrides are re-applied from the code register on every server start, so this dropdown is a view, not a source of truth.</p>
      </div>
    </div>
  );
}

/* ───────────── Capability probe ───────────── */
export function CapabilitiesApp() {
  const [probe, setProbe] = useState<Probe | null>(null);
  useEffect(() => { void runProbe().then(setProbe); }, []);
  if (!probe) return <p className="p-4 text-xs text-slate-400">probing…</p>;
  const groups: Record<string, number> = { available: 0, "needs-permission": 0, unavailable: 0, impossible: 0 };
  probe.caps.forEach((c) => (groups[c.state] += 1));
  return (
    <div className="h-full overflow-auto p-3" data-testid="capabilities-app">
      <Section title="Summary" right={<Btn small onClick={() => runProbe().then(setProbe)}>Re-probe</Btn>}>
        <div className="flex flex-wrap gap-2 text-[11px]">
          {Object.entries(groups).map(([k, v]) => <span key={k} className="flex items-center gap-1"><StateDot state={k} />{k}: {v}</span>)}
          <span className="text-slate-400">· frame budget {probe.frameBudgetMs ?? "?"} ms</span>
        </div>
      </Section>
      <Section title="Capabilities (feature tests, never UA sniffing)">
        <table className="w-full text-left text-[11px]">
          <tbody>
            {probe.caps.map((c) => (
              <tr key={c.id} className="border-t border-white/5 align-top">
                <td className="w-5 p-1"><StateDot state={c.state} /></td>
                <td className="p-1">{c.label}</td>
                <td className="p-1 text-[10px] text-slate-500">{c.evidence}</td>
                <td className="p-1 font-mono text-[9px] text-sky-300/80">{c.featureIds.join(" ")}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </Section>
      <Section title="Environment">
        <pre className="overflow-auto text-[10px] text-slate-400">{JSON.stringify(probe.env, null, 2)}</pre>
        <Btn small onClick={() => {
          const blob = new Blob([JSON.stringify(probe, null, 2)], { type: "application/json" });
          const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = "fusion-capability-report.json"; a.click();
        }}>Export report</Btn>
      </Section>
    </div>
  );
}

/* ───────────── Verification (VR-*) ───────────── */
export function VerifyApp() {
  const { data, loading, reload } = useJson<{ pass: number; total: number; ok: boolean; checks: { id: string; name: string; pass: boolean; detail: string }[] }>("/api/selftest");
  return (
    <div className="h-full overflow-auto p-3" data-testid="verify-app">
      <Section title="Executable self-test" right={<Btn small onClick={reload}>Run again</Btn>}>
        {loading && <p className="text-xs text-slate-400">running…</p>}
        {data && <p className={cls("mb-2 text-xs", data.ok ? "text-emerald-300" : "text-rose-300")} data-testid="verify-summary">{data.pass}/{data.total} checks passed</p>}
        <ul className="space-y-1">
          {(data?.checks ?? []).map((c) => (
            <li key={c.id} className="flex items-start gap-2 rounded border border-white/10 bg-black/20 p-2 text-[11px]">
              <StateDot state={c.pass ? "available" : "blocked"} />
              <div>
                <p><span className="font-mono text-[10px] text-[var(--accent)]">{c.id}</span> {c.name}</p>
                <p className="text-[10px] text-slate-400">{c.detail}</p>
              </div>
            </li>
          ))}
        </ul>
        <Note>These run on the server against the same modules the UI uses. They are assertions, not a status page. Browser-level checks run in tests/e2e.</Note>
      </Section>
    </div>
  );
}

/* ───────────── RG-01 / RG-04 / RG-06 / RG-07 Monitor ───────────── */
export function MonitorApp() {
  const { governor, probe, bgPaused, pauseReason, settings, heldCount, dnd } = useShell();
  const [mem, setMem] = useState<{ used: number; limit: number } | null>(null);
  const [longTasks, setLongTasks] = useState(0);
  const [storage, setStorage] = useState<{ usage: number; quota: number } | null>(null);
  useEffect(() => {
    const po = new PerformanceObserver((l) => setLongTasks((n) => n + l.getEntries().length));
    try { po.observe({ entryTypes: ["longtask"] }); } catch { /* not supported */ }
    return () => po.disconnect();
  }, []);
  useInterval(() => {
    const p = performance as Performance & { memory?: { usedJSHeapSize: number; jsHeapSizeLimit: number } };
    if (p.memory) setMem({ used: p.memory.usedJSHeapSize, limit: p.memory.jsHeapSizeLimit });
    navigator.storage?.estimate?.().then((e) => setStorage({ usage: e.usage ?? 0, quota: e.quota ?? 0 }));
  }, 1500);
  return (
    <div className="h-full overflow-auto p-3" data-testid="monitor-app">
      <Section title="Governor (RG-01)">
        <p className="text-sm" data-testid="governor-state">{governor.state}</p>
        <p className="text-[11px] text-slate-400">{governor.evidence}</p>
        <Note>The web exposes no thermal API. The state comes from measured frame time and is always shown with its evidence.</Note>
      </Section>
      <Section title="Background work (RG-06, RG-07)">
        <p className="text-[11px]" data-testid="bg-state">{bgPaused ? `Paused: ${pauseReason}. Interval routines are skipped.` : "Running."}</p>
        <p className="text-[11px]">Low-memory mode: {settings["runtime.lowMemoryMode"] ? "on (tabs sleep after 20 s)" : "off (tabs sleep after 2 min)"}</p>
        <p className="text-[11px]">Do-not-disturb: {dnd ? `on, ${heldCount} held this session` : "off"}</p>
      </Section>
      <Section title="Resources (RG-04)">
        <ul className="space-y-1 text-[11px]">
          <li>frame: {governor.frameMs.toFixed(1)} ms (probe at boot: {probe?.frameBudgetMs ?? "?"} ms)</li>
          <li>long tasks since open: {longTasks}</li>
          <li>JS heap: {mem ? `${fmtBytes(mem.used)} of ${fmtBytes(mem.limit)}` : "performance.memory unavailable in this browser"}</li>
          <li>origin storage: {storage ? `${fmtBytes(storage.usage)} of ${fmtBytes(storage.quota)}` : "—"}</li>
          <li>cores: {navigator.hardwareConcurrency}</li>
        </ul>
      </Section>
    </div>
  );
}

/* ───────────── BK-01 / BK-03 / BK-05 Backup and config ───────────── */
const APP_KEYS = ["app.tasks", "app.calendar", "app.routines", "app.presets", "app.widgets", "app.matrix", "app.websearch"] as const;

export function BackupApp() {
  const { toast, setSetting } = useShell();
  const [snap, setSnap] = useState<{ digest: string; bytes: number; bundle: unknown } | null>(null);
  const [health, setHealth] = useState<string>("unverified");
  return (
    <div className="h-full overflow-auto p-3" data-testid="backup-app">
      <Section title="Snapshot (BK-01)">
        <div className="flex flex-wrap gap-1">
          <Btn small kind="primary" onClick={async () => { const s = await fetch("/api/backup").then((r) => r.json()); setSnap(s); toast(`Snapshot ${s.digest.slice(0, 12)}… (${fmtBytes(s.bytes)})`); }}>Create snapshot</Btn>
          <Btn small disabled={!snap} onClick={() => {
            const blob = new Blob([JSON.stringify(snap)], { type: "application/json" });
            const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = `fusion-snapshot-${Date.now()}.json`; a.click();
          }}>Download</Btn>
          <Btn small disabled={!snap} onClick={async () => {
            const r = await post<{ ok: boolean; health: string; error?: string }>("/api/backup", { digest: snap!.digest, bundle: snap!.bundle, sampleCount: 5 });
            setHealth(r.ok ? r.health : `failed: ${r.error}`);
          }}>Run restore drill</Btn>
        </div>
        <p className="mt-2 text-[11px]">Health: <span className={health.startsWith("healthy") ? "text-emerald-300" : "text-amber-300"} data-testid="backup-health">{health}</span></p>
        <Note>BK-05: “healthy” only after a sampled restore verified the digest and the sampled rows.</Note>
      </Section>
      <Section title="Configuration (BK-03)">
        <div className="flex flex-wrap gap-1">
          <Btn small onClick={async () => {
            const settings = await fetch("/api/settings").then((r) => r.json());
            const app: Record<string, unknown> = {};
            for (const k of APP_KEYS) app[k] = await kvGet<unknown>(k, null);
            const blob = new Blob([JSON.stringify({ kind: "fusion-config", version: 1, exportedAt: new Date().toISOString(), settings: settings.settings, app }, null, 2)], { type: "application/json" });
            const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = "fusion-config.json"; a.click();
          }}>Export config</Btn>
          <label className="cursor-pointer rounded border border-white/15 bg-white/5 px-2 py-1 text-[11px] hover:bg-white/10">
            Import config…
            <input type="file" accept="application/json" aria-label="Import config" className="hidden" onChange={async (e) => {
              const f = e.target.files?.[0];
              if (!f) return;
              const j = JSON.parse(await f.text()) as { kind?: string; settings?: Record<string, unknown>; app?: Record<string, unknown> };
              if (j.kind !== "fusion-config") return toast("Not a Fusion config file", "error");
              for (const k of APP_KEYS) if (j.app?.[k] !== undefined && j.app[k] !== null) await kvPut(k, j.app[k]);
              for (const [k, v] of Object.entries(j.settings ?? {})) await setSetting(k, v);
              toast(`Imported config (${Object.keys(j.settings ?? {}).length} settings, ${APP_KEYS.length} app stores checked)`);
            }} />
          </label>
        </div>
        <Note>Import writes settings through the policy-checked API, so locked keys stay locked.</Note>
      </Section>
    </div>
  );
}

/* ───────────── SC-01 Vault ───────────── */
export function VaultApp() {
  const { toast } = useShell();
  const { data, reload } = useJson<{ items: { id: number; label: string; kind: string; ciphertext: string; iv: string; salt: string }[]; serverCanDecrypt: boolean }>("/api/vault");
  const [pass, setPass] = useState("");
  const [label, setLabel] = useState("");
  const [secret, setSecret] = useState("");
  const [revealed, setRevealed] = useState<Record<number, string>>({});

  const keyFrom = async (salt: Uint8Array) => {
    const base = await crypto.subtle.importKey("raw", new TextEncoder().encode(pass), "PBKDF2", false, ["deriveKey"]);
    return crypto.subtle.deriveKey({ name: "PBKDF2", salt: salt as BufferSource, iterations: 600000, hash: "SHA-256" }, base, { name: "AES-GCM", length: 256 }, false, ["encrypt", "decrypt"]);
  };
  const b64 = (b: ArrayBuffer) => btoa(String.fromCharCode(...new Uint8Array(b)));
  const unb64 = (s: string) => Uint8Array.from(atob(s), (c) => c.charCodeAt(0));

  return (
    <div className="h-full overflow-auto p-3" data-testid="vault-app">
      <Section title="Master passphrase (never leaves this tab)">
        <input type="password" value={pass} onChange={(e) => setPass(e.target.value)} aria-label="Master passphrase"
          className="w-full rounded border border-white/15 bg-black/30 px-2 py-1 text-xs" placeholder="passphrase" />
        <Note>PBKDF2-SHA256 at 600 000 iterations derives an AES-GCM key in the browser. The server stores ciphertext, iv and salt only and has no decryption code path (BK-06: lose the passphrase and the data is gone).</Note>
      </Section>
      <Section title="Add item">
        <div className="flex flex-wrap gap-1">
          <input value={label} onChange={(e) => setLabel(e.target.value)} placeholder="label" aria-label="Label" className="rounded border border-white/10 bg-black/30 px-2 py-1 text-[11px]" />
          <input value={secret} onChange={(e) => setSecret(e.target.value)} placeholder="secret" aria-label="Secret" className="rounded border border-white/10 bg-black/30 px-2 py-1 text-[11px]" />
          <Btn small kind="primary" disabled={!pass || !label} onClick={async () => {
            const salt = crypto.getRandomValues(new Uint8Array(16));
            const iv = crypto.getRandomValues(new Uint8Array(12));
            const key = await keyFrom(salt);
            const ct = await crypto.subtle.encrypt({ name: "AES-GCM", iv }, key, new TextEncoder().encode(secret));
            await post("/api/vault", { label, kind: "password", ciphertext: b64(ct), iv: b64(iv.buffer as ArrayBuffer), salt: b64(salt.buffer as ArrayBuffer) });
            setSecret(""); setLabel(""); reload(); toast("Encrypted locally, then stored");
          }}>Encrypt &amp; store</Btn>
          <Btn small onClick={() => toast("Passkey enrolment needs a registered relying-party ID; not configured here, so no credential is faked.", "warn")}>Passkey…</Btn>
        </div>
      </Section>
      <Section title="Items">
        <ul className="space-y-1 text-[11px]">
          {(data?.items ?? []).map((it) => (
            <li key={it.id} className="flex items-center gap-2">
              <span className="flex-1">{it.label}</span>
              <code className="text-[9px] text-slate-500">{revealed[it.id] ?? `${it.ciphertext.slice(0, 16)}…`}</code>
              <Btn small onClick={async () => {
                try {
                  const key = await keyFrom(unb64(it.salt));
                  const pt = await crypto.subtle.decrypt({ name: "AES-GCM", iv: unb64(it.iv) as BufferSource }, key, unb64(it.ciphertext) as BufferSource);
                  setRevealed({ ...revealed, [it.id]: new TextDecoder().decode(pt) });
                } catch { toast("Wrong passphrase: AES-GCM authentication failed", "error"); }
              }}>Reveal</Btn>
              <Btn small kind="danger" onClick={async () => { await fetch(`/api/vault?id=${it.id}`, { method: "DELETE" }); reload(); }}>Delete</Btn>
            </li>
          ))}
        </ul>
      </Section>
    </div>
  );
}

/* ───────────── MS Messages (local threads; Matrix probe) ───────────── */
export function MessagesApp() {
  const { data, reload } = useJson<{ threads: Record<string, { id: number; author: string; body: string; channel: string }[]>; capabilities: Record<string, string> }>("/api/messages");
  const [text, setText] = useState("");
  const [thread, setThread] = useState("Fusion");
  return (
    <div className="flex h-full min-h-0 flex-col overflow-auto" data-testid="messages-app">
      <div className="flex min-h-0 flex-1">
        <div className="w-44 shrink-0 border-r border-white/10 p-1">
          {Object.keys(data?.threads ?? {}).map((t) => (
            <button key={t} onClick={() => setThread(t)} className={cls("block w-full rounded px-2 py-1 text-left text-[11px]", t === thread ? "bg-[var(--accent)]/20" : "hover:bg-white/5")}>{t}</button>
          ))}
        </div>
        <div className="flex min-w-0 flex-1 flex-col">
          <div className="min-h-0 flex-1 overflow-auto p-2">
            {(data?.threads[thread] ?? []).map((m) => (
              <div key={m.id} className="mb-1 rounded bg-white/5 p-2 text-[11px]"><b className="text-slate-400">{m.author}</b> {m.body}</div>
            ))}
          </div>
          <form className="flex gap-1 border-t border-white/10 p-2" onSubmit={async (e) => { e.preventDefault(); await post("/api/messages", { thread, body: text }); setText(""); reload(); }}>
            <input value={text} onChange={(e) => setText(e.target.value)} aria-label="Message" className="flex-1 rounded border border-white/10 bg-black/30 px-2 py-1 text-[11px]" />
            <Btn small type="submit" kind="primary">Send (local)</Btn>
          </form>
          <div className="border-t border-white/10 p-2">
            {Object.entries(data?.capabilities ?? {}).map(([k, v]) => (
              <p key={k} className="text-[10px] text-slate-400"><b className="uppercase">{k}:</b> {v}</p>
            ))}
            <Wall>iMessage requires a server you host on your own Mac (MS-01). Without it this panel stays disconnected and never simulates a conversation.</Wall>
            <MatrixPanel />
          </div>
        </div>
      </div>
    </div>
  );
}

/* ───────────── About / entitlement (BL-02/04/05) ───────────── */
export function AboutApp() {
  const { entitlement, refreshEntitlement } = useShell();
  return (
    <div className="h-full overflow-auto p-3" data-testid="about-app">
      <Section title="Fusion Shell (Web), v2.2 — port of Master Spec v2.1">
        <p className="text-[11px] leading-relaxed text-slate-300">
          A desktop environment delivered as an installable PWA: window compositor, launcher, shelf, palette, a journaled
          file engine on Postgres, terminal, format engine (OOXML, PSD), casting hub, camera and Meet, vault, backup,
          routines, and a browsable register of every feature with its honest status.
        </p>
      </Section>
      <Section title="Entitlement (BL-02/04/05)">
        <p className="text-[11px]">plan: {entitlement?.plan} · state: {entitlement?.state} · {entitlement?.daysLeft} day(s) left</p>
        <div className="mt-1 flex gap-1">
          <Btn small onClick={async () => { await post("/api/entitlement", { plan: "pro" }); refreshEntitlement(); }}>Simulate purchase</Btn>
          <Btn small onClick={async () => { await post("/api/entitlement", { plan: "trial" }); refreshEntitlement(); }}>Reset trial</Btn>
          <Btn small kind="danger" onClick={async () => { await post("/api/entitlement", { plan: "expired" }); refreshEntitlement(); }}>Expire now</Btn>
        </div>
        <Note>Expiry degrades Files/Find to read-only and never deletes data. The signature half is real HMAC; the payment half is a deliberate stub, not a fake checkout.</Note>
      </Section>
    </div>
  );
}

export { StateDot };
