"use client";

import React, { useMemo, useState } from "react";
import { Btn, StateDot, useJson } from "../ui";
import type { LedgerRow } from "@/lib/server/ledger";

type Payload = {
  counts: { total: number; fullBuild: number; partialBuild: number; notBuilt: number; blocked: number; fullTest: number; partialTest: number; untested: number; notApplicable: number };
  rows: LedgerRow[];
  fingerprint: string;
  evidence: { acceptedSuites: string[]; staleSuites: string[] };
  policy: string;
};
export function LedgerApp() {
  const { data, loading, error, reload } = useJson<Payload>("/api/ledger");
  const [query, setQuery] = useState("");
  const [build, setBuild] = useState("all");
  const [test, setTest] = useState("all");
  const [area, setArea] = useState("all");
  const [selected, setSelected] = useState<string | null>(null);
  const c = data?.counts;
  const areas = useMemo(() => ["all", ...new Set((data?.rows ?? []).map(r => r.area))], [data]);
  const filtered = useMemo(() => (data?.rows ?? []).filter(r =>
    (build === "all" || build === r.buildGrade) && (test === "all" || test === r.testGrade) &&
    (area === "all" || area === r.area) && `${r.id} ${r.title} ${r.webNuance}`.toLowerCase().includes(query.toLowerCase()),
  ), [data, build, test, area, query]);
  const focused = data?.rows.find(r => r.id === selected);
  return (
    <div data-testid="ledger-app" className="flex h-full min-h-0 flex-col overflow-hidden p-3 text-xs">
      <div className="flex items-center justify-between gap-2">
        <div><h2 className="text-base font-semibold">Build & verification ledger</h2>
          <p className="mt-1 text-[11px] text-slate-400">Scope: the {c?.total ?? "…"} rows actually present in the web register. Android-only capabilities are not counted as built.</p></div>
        <Btn small onClick={reload}>Refresh evidence</Btn>
      </div>
      {loading && <p className="text-slate-400">Loading evidence…</p>}
      {error && <p role="alert" className="text-rose-300">Ledger error: {error}</p>}
      {c && <div className="mt-3 grid grid-cols-2 gap-1 sm:grid-cols-4" data-testid="ledger-counts">
        {[
          ["Fully built", c.fullBuild, "full-build"], ["Partially built", c.partialBuild, "partial-build"],
          ["Fully tested", c.fullTest, "full-test"], ["Partially tested", c.partialTest, "partial-test"],
        ].map(([label, value, id]) => <div key={String(id)} data-testid={`ledger-${id}`} className="rounded-lg border border-white/10 bg-white/5 px-3 py-2">
          <span className="block text-[10px] uppercase tracking-widest text-slate-400">{label}</span>
          <strong className="block text-xl tabular-nums text-[var(--accent)]">{value}</strong>
        </div>)}
      </div>}
      {c && <p className="mt-1 text-[11px] text-slate-400">Remaining: {c.notBuilt} not built; {c.blocked} blocked/not-applicable. Tests: {c.untested} untested; {c.notApplicable} not applicable. Build total = {c.fullBuild + c.partialBuild + c.notBuilt + c.blocked}; test total = {c.fullTest + c.partialTest + c.untested + c.notApplicable}.</p>}
      <div className="mt-2 rounded border border-sky-400/20 bg-sky-400/5 p-2 text-[11px] leading-relaxed text-sky-100">
        <b>Counting rule.</b> “Fully built” requires explicit audit against a reduced, stated web contract. “Partially built” includes every un-audited “implemented” claim. “Fully tested” means every declared acceptance case passed on this source fingerprint in the stated Chromium/server environment—not Safari/Firefox or hardware certification. A code citation is not a test. Hardware and receiver paths cannot be fully tested here.
      </div>
      <div className="mt-2 flex flex-wrap gap-1 text-[10px]" data-testid="ledger-evidence">
        <span className="rounded bg-white/10 px-1">source {data?.fingerprint ?? "…"}</span>
        {(data?.evidence.acceptedSuites ?? []).map(s => <span key={s} className="rounded bg-emerald-400/10 px-1 text-emerald-200">✓ {s}</span>)}
        {(data?.evidence.staleSuites ?? []).map(s => <span key={s} className="rounded bg-amber-400/10 px-1 text-amber-200">not current: {s}</span>)}
      </div>
      <div className="mt-2 flex flex-wrap items-center gap-1">
        <input value={query} onChange={e => setQuery(e.target.value)} aria-label="Filter ledger" placeholder="ID or text"
          className="w-36 rounded border border-white/15 bg-black/30 px-2 py-1 text-[11px]" />
        <select aria-label="Build grade" value={build} onChange={e => setBuild(e.target.value)} className="rounded bg-slate-900 px-1 py-1 text-[11px]">
          {["all", "full", "partial", "not-built", "blocked"].map(v => <option key={v}>{v}</option>)}
        </select>
        <select aria-label="Test grade" value={test} onChange={e => setTest(e.target.value)} className="rounded bg-slate-900 px-1 py-1 text-[11px]">
          {["all", "full", "partial", "untested", "not-applicable"].map(v => <option key={v}>{v}</option>)}
        </select>
        <select aria-label="Area" value={area} onChange={e => setArea(e.target.value)} className="rounded bg-slate-900 px-1 py-1 text-[11px]">
          {areas.map(v => <option key={v}>{v}</option>)}
        </select>
        <span className="ml-auto text-slate-400">{filtered.length} rows</span>
      </div>
      <div className="mt-2 flex min-h-0 flex-1 gap-2">
        <div className="min-h-0 min-w-0 flex-1 overflow-auto rounded border border-white/10">
          <table className="w-full text-left text-[11px]"><thead className="sticky top-0 bg-slate-950 text-slate-400"><tr><th className="px-2 py-1">ID</th><th>Feature / contract</th><th>Build</th><th>Test</th></tr></thead>
            <tbody>{filtered.map(r => <tr key={r.id} data-testid={`ledger-row-${r.id}`} onClick={() => setSelected(r.id)}
              className="cursor-pointer border-t border-white/5 hover:bg-white/5">
              <td className="px-2 py-1 font-mono text-[var(--accent)]">{r.id}</td>
              <td className="max-w-xs truncate py-1" title={r.title}>{r.title}</td>
              <td className="px-1"><span className="inline-flex items-center gap-1"><StateDot state={r.buildGrade === "full" ? "implemented" : r.buildGrade === "partial" ? "partial" : "unavailable"} />{r.buildGrade}</span></td>
              <td className="px-1"><span className="inline-flex items-center gap-1"><StateDot state={r.testGrade === "full" ? "implemented" : r.testGrade === "partial" ? "partial" : "unavailable"} />{r.testGrade}</span></td>
            </tr>)}</tbody></table>
        </div>
        {focused && <aside data-testid="ledger-detail" className="hidden w-64 shrink-0 overflow-auto rounded border border-white/10 bg-black/20 p-2 text-[11px] lg:block">
          <p className="font-semibold text-[var(--accent)]">{focused.id} · {focused.title}</p>
          <p className="mt-1">Build: {focused.buildGrade} · Tests: {focused.testGrade}</p>
          <p className="mt-2 text-slate-400">{focused.webNuance}</p>
          <p className="mt-3 font-medium">Direct passing cases</p><p className="font-mono text-emerald-200">{focused.passedCases.join(", ") || "none"}</p>
          <p className="mt-2 font-medium">Required but missing</p><p className="font-mono text-amber-200">{focused.missingCases.join(", ") || "none"}</p>
          <p className="mt-3 text-slate-500">A passing case may still cover only one branch of a partial feature. No simulation counts as external hardware evidence.</p>
        </aside>}
      </div>
    </div>
  );
}
