"use client";

// Implements: CT-02 PC bridge — a same-origin WebRTC data channel between two Fusion instances.
// Signalling reuses /api/signal (the same append-only log Meet uses); the channel carries text
// messages and small files as base64 chunks. Scope nuance: no STUN/TURN, so peers must be on the
// same network (host candidates only) — declared, not hidden. This is a real peer-to-peer channel,
// not a relay: bytes go browser → browser.

import React, { useEffect, useRef, useState } from "react";
import { Btn, Note, Section, post, useShell } from "../ui";

type Msg = { id: number; from: string; kind: string; payload: Record<string, unknown>; createdAt: string };

type Peer = {
  id: string;
  pc: RTCPeerConnection;
  dc: RTCDataChannel | null;
  lastId: number;
  timer: number;
  name: string | null;
};

export function BridgeApp() {
  const { toast } = useShell();
  const [room, setRoom] = useState("fusion-bridge");
  const [joined, setJoined] = useState(false);
  const [status, setStatus] = useState("idle");
  const [peerState, setPeerState] = useState("—");
  const [log, setLog] = useState<string[]>([]);
  const [draft, setDraft] = useState("");
  const peer = useRef<Peer | null>(null);
  const logRef = useRef<string[]>([]);

  const say = (line: string) => {
    logRef.current = [...logRef.current, line].slice(-60);
    setLog(logRef.current);
  };

  const send = async (p: Peer, kind: string, payload: Record<string, unknown> = {}) => {
    await post("/api/signal", { room, from: p.id, kind, payload });
  };

  const wire = (p: Peer, dc: RTCDataChannel) => {
    p.dc = dc;
    dc.onopen = () => { setPeerState("connected"); setStatus("connected"); say("channel open"); };
    dc.onclose = () => { setPeerState("closed"); say("channel closed"); };
    dc.onmessage = (e) => {
      try {
        const m = JSON.parse(String(e.data)) as { kind: string; text?: string; name?: string; size?: number };
        if (m.kind === "text") say(`peer: ${m.text ?? ""}`);
        else if (m.kind === "file") say(`peer sent file "${m.name}" (${m.size} bytes, base64 in channel)`);
        else if (m.kind === "hello") { p.name = m.name ?? null; say(`peer is "${p.name}"`); }
      } catch { say(`peer: ${String(e.data).slice(0, 120)}`); }
    };
  };

  const handle = async (p: Peer, m: Msg) => {
    if (m.from === p.id) return;
    if (m.kind === "hello") {
      if (peerState !== "—") return;
      if (p.id < m.from) {
        const dc = p.pc.createDataChannel("bridge");
        wire(p, dc);
        const offer = await p.pc.createOffer();
        await p.pc.setLocalDescription(offer);
        await send(p, "offer", { sdp: offer.sdp });
      } else {
        await send(p, "hello", { name: "fusion-peer" });
      }
    } else if (m.kind === "offer") {
      p.pc.ondatachannel = (e) => wire(p, e.channel);
      await p.pc.setRemoteDescription({ type: "offer", sdp: String(m.payload.sdp) });
      const answer = await p.pc.createAnswer();
      await p.pc.setLocalDescription(answer);
      await send(p, "answer", { sdp: answer.sdp });
    } else if (m.kind === "answer") {
      await p.pc.setRemoteDescription({ type: "answer", sdp: String(m.payload.sdp) });
    } else if (m.kind === "ice") {
      await p.pc.addIceCandidate(m.payload.c as RTCIceCandidateInit).catch(() => undefined);
    } else if (m.kind === "bye") {
      setPeerState("peer left");
      say("peer left the room");
    }
  };

  const join = async () => {
    const id = `p${Math.random().toString(36).slice(2, 10)}`;
    const pc = new RTCPeerConnection({ iceServers: [] });
    pc.onicecandidate = (e) => { if (e.candidate) void send(p, "ice", { c: e.candidate.toJSON() }); };
    pc.onconnectionstatechange = () => {
      if (pc.connectionState === "failed") setStatus("failed: no route between peers (host candidates only)");
    };
    const init = (await (await fetch(`/api/signal?room=${encodeURIComponent(room)}&after=0`)).json()) as { maxId: number };
    const p: Peer = { id, pc, dc: null, lastId: init.maxId ?? 0, timer: 0, name: null };
    peer.current = p;
    setJoined(true);
    setStatus("joined — waiting for a peer");
    await send(p, "hello", { name: "fusion-peer" });
    let lastHello = Date.now();
    p.timer = window.setInterval(async () => {
      const r = (await fetch(`/api/signal?room=${encodeURIComponent(room)}&after=${p.lastId}`).then((x) => x.json())) as { messages: Msg[] };
      for (const m of r.messages) {
        p.lastId = Math.max(p.lastId, m.id);
        await handle(p, m).catch((e: unknown) => setStatus(`signal error: ${String(e)}`));
      }
      if (peerState === "—" && Date.now() - lastHello > 3000) { lastHello = Date.now(); await send(p, "hello", { name: "fusion-peer" }); }
    }, 700);
    say(`joined room "${room}" as ${id}`);
  };

  const leave = async () => {
    const p = peer.current;
    if (!p) return;
    clearInterval(p.timer);
    await send(p, "bye").catch(() => undefined);
    p.dc?.close();
    p.pc.close();
    peer.current = null;
    setJoined(false);
    setPeerState("—");
    setStatus("left");
    say("left the room");
  };

  useEffect(() => () => {
    const p = peer.current;
    if (p) { clearInterval(p.timer); p.dc?.close(); p.pc.close(); }
  }, []);

  const sendText = () => {
    const dc = peer.current?.dc;
    if (!dc || dc.readyState !== "open") return toast("No open channel", "warn");
    dc.send(JSON.stringify({ kind: "text", text: draft }));
    say(`me: ${draft}`);
    setDraft("");
  };

  const sendFile = async (file: File) => {
    const dc = peer.current?.dc;
    if (!dc || dc.readyState !== "open") return toast("No open channel", "warn");
    if (file.size > 512 * 1024) return toast("Files over 512 KB are refused on the bridge channel", "warn");
    const b64 = await new Promise<string>((res) => {
      const r = new FileReader();
      r.onload = () => res(String(r.result).split(",")[1] ?? "");
      r.readAsDataURL(file);
    });
    dc.send(JSON.stringify({ kind: "file", name: file.name, size: file.size, data: b64 }));
    say(`me → file "${file.name}" (${file.size} bytes)`);
  };

  return (
    <div className="flex h-full min-h-0 flex-col p-3" data-testid="bridge-app">
      <div className="mb-2 flex items-center gap-2 text-[11px]">
        <input aria-label="Room code" value={room} onChange={(e) => setRoom(e.target.value)} disabled={joined}
          className="rounded border border-white/10 bg-black/30 px-2 py-1 disabled:opacity-40" />
        {!joined ? <Btn small kind="primary" onClick={join}>Join</Btn> : <Btn small kind="danger" onClick={leave}>Leave</Btn>}
        <span data-testid="bridge-status" className="text-slate-300">{status}</span>
        <span className="text-slate-500">· channel: <span data-testid="bridge-peer">{peerState}</span></span>
      </div>
      <Section title="Send over the peer-to-peer channel">
        <div className="flex gap-1">
          <input aria-label="Message" value={draft} onChange={(e) => setDraft(e.target.value)} placeholder="Message to peer"
            className="flex-1 rounded border border-white/10 bg-black/30 px-2 py-1 text-[11px]" />
          <Btn small kind="primary" onClick={sendText}>Send text</Btn>
          <label className="cursor-pointer rounded border border-white/15 bg-white/5 px-2 py-1 text-[11px] hover:bg-white/10">
            Send file…
            <input type="file" aria-label="Send file" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) void sendFile(f); e.currentTarget.value = ""; }} />
          </label>
        </div>
      </Section>
      <Section title="Channel log">
        <pre data-testid="bridge-log" className="h-48 overflow-auto whitespace-pre-wrap rounded bg-black/40 p-2 text-[10px] text-slate-300">
          {log.join("\n") || "no traffic yet"}
        </pre>
      </Section>
      <Note>CT-02: a direct WebRTC data channel between two Fusion instances. Without STUN/TURN, only peers that can reach each other directly (same LAN or host) connect.</Note>
    </div>
  );
}
