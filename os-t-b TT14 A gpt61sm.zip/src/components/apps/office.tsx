"use client";

import React, { useMemo, useState } from "react";
import { Btn, Note, Section, Wall, post, useShell } from "../ui";
import { calculateWorkbook, valuesSnapshot, type Calculation } from "@/lib/workbook";
import {
  csvToSheet, effectiveStyle, evaluateWorkbook, exportDocx, exportXlsx, makeRef, parseDocxXml, parseRef, parseXlsxModel,
  sheetToCsv, unzipTextEntries, type ConditionalRule, type DataValidation, type DocxModel, type XlsxModel,
} from "@/lib/office";
import { buildChartSvg, pointsFromColumns, type ChartKind } from "@/lib/chart";
import type { CellValue } from "@/lib/office";
import { sanitizeSvg } from "@/lib/vector";

// PR-11 / FF-01 / FF-11: editable Office subset on our own engine (lib/office.ts).
// Parity boundary is printed in the app: this is not LibreOffice and does not claim to be.

type Doc = { kind: "docx"; model: DocxModel; name: string } | { kind: "xlsx"; model: XlsxModel; name: string };

const PARITY: [string, string, string][] = [
  ["Writer (.docx)", "Paragraphs, Heading1/2 style names, bold/italic/underline runs, edit + write-back", "Layout/pagination, fonts, tables, images, comments, tracked changes, fields"],
  ["Calc (.xlsx)", "Cells, formulas and composable arrays; bounded spill allocation, #SPILL! diagnostics, generated read-only cells, values-only export, SVG charts, basic style metadata", "Excel calc-chain/dynamic-array metadata interoperability, pivots, LET/LAMBDA, merged-cell/Table spilling, # references, full number-format/style cascade"],
  ["Impress (.pptx)", "Slide shape-text extraction (via Forge)", "Slide editing/write-back, layouts, media, animation"],
  ["Engine", "Own XML parser/serializer + stored-entry ZIP writer; runs fully in the browser; macros detected and never executed", "LibreOffice itself (millions of lines, native) — not reproduced and not claimed"],
];

export function OfficeApp() {
  const { toast } = useShell();
  const [doc, setDoc] = useState<Doc | null>(null);
  const [sheetIdx, setSheetIdx] = useState(0);
  const [loss, setLoss] = useState<string[]>([]);
  const [calcStatus, setCalcStatus] = useState("");

  const openFile = async (f: File) => {
    try {
      const bytes = new Uint8Array(await f.arrayBuffer());
      if (/\.csv$/i.test(f.name)) {
        setDoc({ kind: "xlsx", model: csvToSheet(new TextDecoder().decode(bytes), f.name.replace(/\.csv$/i, "")), name: f.name });
        setSheetIdx(0); setLoss([]);
        return;
      }
      const entries = await unzipTextEntries(bytes);
      if (/\.docx$/i.test(f.name)) {
        const xml = entries.get("word/document.xml");
        if (!xml) throw new Error("word/document.xml not found");
        const model = parseDocxXml(xml);
        setDoc({ kind: "docx", model, name: f.name });
        setLoss(model.unsupported.map((u) => `Not modelled: ${u}`));
      } else if (/\.xlsx$/i.test(f.name)) {
        const model = parseXlsxModel((n) => entries.get(n) ?? null, [...entries.keys()]);
        setDoc({ kind: "xlsx", model, name: f.name });
        setSheetIdx(0);
        setLoss(model.unsupported.map((u) => `Not modelled: ${u}`));
      } else toast("Only .docx, .xlsx and .csv are supported here", "warn");
    } catch (e) { toast(`Open failed: ${String(e)}`, "error"); }
  };

  const download = (bytes: Uint8Array, name: string, type: string) => {
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([bytes as BlobPart], { type }));
    a.download = name;
    a.click();
  };

  const calculation = useMemo(() => (doc?.kind === "xlsx" ? calculateWorkbook(doc.model) : null), [doc]);
  const values = calculation?.values ?? null;

  return (
    <div className="h-full overflow-auto p-3" data-testid="office-app">
      <Section title="Open a document (parsed locally in this tab)">
        <input type="file" accept=".docx,.xlsx,.csv" aria-label="Open office file" className="text-[11px]"
          onChange={(e) => { const f = e.target.files?.[0]; if (f) void openFile(f); e.currentTarget.value = ""; }} />
        <div className="mt-2 flex gap-1">
          <Btn small onClick={() => { setDoc({ kind: "xlsx", name: "Untitled.xlsx", model: { sheets: [{ name: "Sheet1", cells: {} }], unsupported: [] } }); setSheetIdx(0); setLoss([]); }}>New workbook</Btn>
          <Btn small onClick={() => { setDoc({ kind: "docx", name: "Untitled.docx", model: { blocks: [{ kind: "p", style: null, runs: [{ text: "", bold: false, italic: false, underline: false }] }], unsupported: [] } }); setLoss([]); }}>New document</Btn>
        </div>
        <Note>Opening/parsing happens locally. Only “Calculate on server” sends the current workbook model to this origin; saving to Files is explicit.</Note>
      </Section>

      {doc?.kind === "docx" && (
        <Section title={`Writer — ${doc.name}`} right={
          <Btn small kind="primary" onClick={() => {
            const out = exportDocx(doc.model);
            setLoss(out.lossReport);
            download(out.bytes, doc.name.replace(/\.docx$/i, "") + ".fusion.docx", "application/vnd.openxmlformats-officedocument.wordprocessingml.document");
          }}>Download .docx</Btn>}>
          <div className="space-y-2">
            {doc.model.blocks.map((b, i) => b.kind === "p" ? (
              <div key={i} className="flex items-start gap-1">
                <select aria-label={`Style ${i + 1}`} value={b.style ?? "Normal"} className="rounded bg-slate-900 px-1 py-1 text-[10px]"
                  onChange={(e) => {
                    const model = structuredClone(doc.model);
                    const blk = model.blocks[i];
                    if (blk.kind === "p") blk.style = e.target.value === "Normal" ? null : e.target.value;
                    setDoc({ ...doc, model });
                  }}>
                  <option>Normal</option><option>Heading1</option><option>Heading2</option>
                </select>
                <textarea aria-label={`Paragraph ${i + 1}`} data-testid={`office-para-${i}`} value={b.runs.map((r) => r.text).join("")}
                  onChange={(e) => {
                    const model = structuredClone(doc.model);
                    const blk = model.blocks[i];
                    if (blk.kind === "p") {
                      const first = blk.runs[0];
                      blk.runs = [{ text: e.target.value, bold: first?.bold ?? false, italic: first?.italic ?? false, underline: first?.underline ?? false }];
                    }
                    setDoc({ ...doc, model });
                  }}
                  className="min-h-8 flex-1 rounded border border-white/10 bg-black/30 p-1 text-[11px]" />
                <Btn small kind="danger" onClick={() => { const model = structuredClone(doc.model); model.blocks.splice(i, 1); setDoc({ ...doc, model }); }}>✕</Btn>
              </div>
            ) : (
              <div key={i} data-testid={`office-table-${i}`} className="rounded border border-white/15 p-1">
                <div className="mb-1 flex items-center gap-1 text-[10px] text-slate-400">
                  Table {b.rows.length}×{b.rows[0]?.length ?? 0}
                  <Btn small onClick={() => {
                    const model = structuredClone(doc.model);
                    const blk = model.blocks[i];
                    if (blk.kind === "table") blk.rows.push(new Array(blk.rows[0]?.length ?? 1).fill(""));
                    setDoc({ ...doc, model });
                  }}>+ Row</Btn>
                  <Btn small kind="danger" onClick={() => { const model = structuredClone(doc.model); model.blocks.splice(i, 1); setDoc({ ...doc, model }); }}>Remove table</Btn>
                </div>
                <table className="border-collapse">
                  <tbody>{b.rows.map((row, ri) => (
                    <tr key={ri}>{row.map((cell, ci) => (
                      <td key={ci} className="border border-white/10 p-0.5">
                        <input aria-label={`Table ${i} cell ${ri + 1},${ci + 1}`} data-testid={`office-cell-${i}-${ri}-${ci}`} value={cell}
                          onChange={(e) => {
                            const model = structuredClone(doc.model);
                            const blk = model.blocks[i];
                            if (blk.kind === "table") blk.rows[ri][ci] = e.target.value;
                            setDoc({ ...doc, model });
                          }}
                          className="w-24 bg-transparent px-1 py-0.5 text-[11px] outline-none" />
                      </td>))}
                    </tr>))}
                  </tbody>
                </table>
              </div>
            ))}
          </div>
          <div className="mt-1 flex gap-1">
            <Btn small onClick={() => { const model = structuredClone(doc.model); model.blocks.push({ kind: "p", style: null, runs: [{ text: "", bold: false, italic: false, underline: false }] }); setDoc({ ...doc, model }); }}>+ Paragraph</Btn>
            <Btn small onClick={() => { const model = structuredClone(doc.model); model.blocks.push({ kind: "table", rows: [["", ""], ["", ""]] }); setDoc({ ...doc, model }); }}>+ Table</Btn>
          </div>
        </Section>
      )}

      {doc?.kind === "xlsx" && values && calculation && (
        <Section title={`Calc — ${doc.name}`} right={
          <div className="flex gap-1">
            <Btn small onClick={() => download(new TextEncoder().encode(sheetToCsv(valuesSnapshot(doc.model, calculation), sheetIdx)), doc.name.replace(/\.(xlsx|csv)$/i, "") + ".csv", "text/csv")}>Export CSV</Btn>
            <Btn small kind="primary" onClick={() => {
              const out = exportXlsx(doc.model);
              setLoss(out.lossReport);
              download(out.bytes, doc.name.replace(/\.(xlsx|csv)$/i, "") + ".fusion.xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
            }}>Download .xlsx</Btn>
          </div>}>
          <div className="mb-2 flex gap-1">
            {doc.model.sheets.map((s, i) => (
              <button key={s.name} onClick={() => setSheetIdx(i)} className={`rounded px-2 py-0.5 text-[10px] ${i === sheetIdx ? "bg-[var(--accent)]/25" : "bg-white/5"}`}>{s.name}</button>
            ))}
            <Btn small onClick={() => {
              const model = structuredClone(doc.model);
              const sheet = model.sheets[sheetIdx];
              let maxRow = 0;
              for (const ref of Object.keys(sheet.cells)) maxRow = Math.max(maxRow, parseRef(ref)?.row ?? 0);
              const ref = makeRef(1, maxRow + 1);
              sheet.cells[ref] = { ref, raw: "" };
              setDoc({ ...doc, model });
            }}>+ Row</Btn>
          </div>
          <div className="mb-2 flex flex-wrap items-center gap-1">
            <Btn small testId="office-server-calc" onClick={async () => {
              try {
                const r = await post<{ values?: Record<string, CellValue>; error?: string; stable?: boolean }>("/api/office/calculate", { model: doc.model });
                if (!r.values) throw new Error(r.error ?? "Server calculation failed");
                setCalcStatus(`Server calculated ${Object.keys(r.values).length} values; stable=${r.stable}.`);
              } catch (e) { setCalcStatus(String(e)); }
            }}>Calculate on server</Btn>
            <Btn small testId="office-values-export" onClick={() => {
              const out = exportXlsx(valuesSnapshot(doc.model, calculation));
              setLoss(["Values-only snapshot: formulas/rules removed; generated spill cells saved as ordinary values.", ...out.lossReport]);
              download(out.bytes, "values-snapshot.xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
            }}>Download values snapshot</Btn>
            <span className="text-[10px] text-slate-400" data-testid="office-calc-status">{calcStatus || `${calculation.spills.size} spill(s), ${calculation.passes} passes`}</span>
          </div>
          {calculation.issues.size > 0 && <ul className="mb-2 rounded border border-amber-400/30 bg-amber-400/5 p-2 text-[11px] text-amber-100" data-testid="office-spill-errors">
            {[...calculation.issues].map(([key, e]) => <li key={key}>{key}: {e.code} — {e.reason}{e.blockers.length ? ` (${e.blockers.join(", ")})` : ""}</li>)}
          </ul>}
          <SheetGrid doc={doc} setDoc={setDoc} sheetIdx={sheetIdx} values={values} calculation={calculation} />
          <ConditionalPanel doc={doc} setDoc={setDoc} sheetIdx={sheetIdx} />
          <ChartPanel doc={doc} sheetIdx={sheetIdx} values={values} />
          <p className="mt-1 text-[10px] text-slate-500">Array formulas populate neighbouring cells. Only the anchor is editable; occupied outputs show #SPILL!. Normal .xlsx export keeps source formulas, not Excel spill metadata. Use values snapshot or CSV to save all generated values (formulas removed).</p>
        </Section>
      )}

      {(loss.length > 0 || doc) && (
        <Section title="Fidelity report (FF-11) — grade C">
          <ul className="list-disc pl-4 text-[11px] text-amber-100/90" data-testid="office-loss">
            {(loss.length ? loss : ["Export to see the exact loss report for this document."]).map((l, i) => <li key={i}>{l}</li>)}
          </ul>
        </Section>
      )}

      <Section title="Parity matrix — what this engine is and is not">
        <table className="w-full text-left text-[10px]">
          <thead className="text-slate-500"><tr><th className="py-1">Area</th><th>Implemented</th><th>Not claimed</th></tr></thead>
          <tbody>
            {PARITY.map(([a, yes, no]) => (
              <tr key={a} className="border-t border-white/5 align-top"><td className="py-1 pr-2 font-medium">{a}</td><td className="py-1 pr-2 text-emerald-200/90">{yes}</td><td className="py-1 text-rose-200/80">{no}</td></tr>
            ))}
          </tbody>
        </table>
        <Wall>This engine does not have 1:1 LibreOffice parity. Only the declared bounded subset is implemented and tested; browser technology alone is not a proof of impossibility for larger architectures.</Wall>
      </Section>
    </div>
  );
}

function SheetGrid({ doc, setDoc, sheetIdx, values, calculation }: {
  doc: Extract<Doc, { kind: "xlsx" }>; setDoc: (d: Doc) => void; sheetIdx: number;
  values: Map<string, unknown>; calculation: Calculation;
}) {
  const sheet = doc.model.sheets[sheetIdx];
  let maxRow = 6, maxCol = 6;
  for (const ref of Object.keys(sheet?.cells ?? {})) {
    const p = parseRef(ref);
    if (p) { maxRow = Math.max(maxRow, p.row); maxCol = Math.max(maxCol, p.col); }
  }
  for (const [key] of values) {
    if (!key.startsWith(`${sheet?.name}!`)) continue;
    const p = parseRef(key.slice(key.lastIndexOf("!") + 1));
    if (p) { maxRow = Math.max(maxRow, p.row); maxCol = Math.max(maxCol, p.col); }
  }
  // Do not render an unbounded DOM grid; export still includes all supported generated cells.
  maxRow = Math.min(maxRow, 100); maxCol = Math.min(maxCol, 26);
  if (!sheet) return null;
  const setCell = (ref: string, value: string) => {
    const model = structuredClone(doc.model);
    const sh = model.sheets[sheetIdx];
    if (value === "") delete sh.cells[ref];
    else if (value.startsWith("=")) sh.cells[ref] = { ref, raw: "", formula: value.slice(1) };
    else sh.cells[ref] = { ref, raw: value };
    setDoc({ ...doc, model });
  };
  return (
    <div className="max-h-96 overflow-auto" data-testid="office-grid">
      <p className="mb-1 text-[9px] text-slate-500">Viewport capped at 100 rows × 26 columns. Blue cells are generated and read-only.</p>
      <table className="border-collapse text-[10px]">
        <tbody>
          {Array.from({ length: maxRow }, (_, ri) => (
            <tr key={ri}>
              <th className="px-1 text-slate-500">{ri + 1}</th>
              {Array.from({ length: maxCol }, (_, ci) => {
                const ref = makeRef(ci + 1, ri + 1);
                const cell = sheet.cells[ref];
                const key = `${sheet.name}!${ref}`;
                const owner = calculation.owners.get(key);
                const child = !!owner && owner !== key;
                const computed = values.get(key);
                const shown = child ? String(computed ?? "") : cell?.formula ? `=${cell.formula}` : (cell?.raw ?? "");
                const effStyle = effectiveStyle(sheet, ref, values as Map<string, import("@/lib/office").CellValue>);
                return (
                  <td key={ref} className="border border-white/10 p-0.5" style={effStyle?.fill ? { background: effStyle.fill } : undefined} data-testid={`td-${ref}`}>
                    <input aria-label={`Cell ${ref}`} data-testid={`cell-${ref}`} value={shown} readOnly={child}
                      title={child ? `Generated by ${owner}; edit the anchor instead` : ref}
                      data-spill-owner={owner ?? ""} style={child ? { color: "#7dd3fc" } : undefined}
                      onChange={(e) => setCell(ref, e.target.value)}
                      className="w-20 bg-transparent px-1 py-0.5 outline-none" />
                    <div className="px-1 text-[9px] text-slate-500" data-testid={`computed-${ref}`}>{computed === null || computed === undefined ? "" : String(computed)}</div>
                  </td>
                );
              })}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

/* FF-09 chart from the sheet: column A = labels, column B = values (computed values, so formulas chart too). */
function ChartPanel({ doc, sheetIdx, values }: {
  doc: Extract<Doc, { kind: "xlsx" }>; sheetIdx: number; values: Map<string, CellValue>;
}) {
  const [kind, setKind] = useState<ChartKind>("bar");
  const sheet = doc.model.sheets[sheetIdx];
  if (!sheet) return null;
  let maxRow = 0;
  for (const ref of Object.keys(sheet.cells)) maxRow = Math.max(maxRow, parseRef(ref)?.row ?? 0);
  const labels: unknown[] = [];
  const nums: unknown[] = [];
  for (let r = 1; r <= maxRow; r++) {
    labels.push(values.get(`${sheet.name}!A${r}`) ?? "");
    nums.push(values.get(`${sheet.name}!B${r}`) ?? null);
  }
  const points = pointsFromColumns(labels, nums);
  let svg = "";
  let error = "";
  try {
    svg = points.length ? sanitizeSvg(buildChartSvg(kind, `${sheet.name}: A vs B`, points)).svg : "";
    if (!points.length) error = "Put labels in column A and numbers in column B to chart them.";
  } catch (e) { error = String(e instanceof Error ? e.message : e); }
  return (
    <Section title="Chart (column A labels, column B values)" right={
      <div className="flex gap-1">
        {(["bar", "line", "pie"] as const).map((k) => (
          <Btn key={k} small kind={kind === k ? "primary" : "ghost"} testId={`chart-${k}`} onClick={() => setKind(k)}>{k}</Btn>
        ))}
      </div>}>
      {error ? <p className="text-[11px] text-amber-300" data-testid="chart-error">{error}</p> : (
        <div data-testid="office-chart" className="max-w-full overflow-auto rounded border border-white/10 bg-slate-950 p-2"
          dangerouslySetInnerHTML={{ __html: svg }} />
      )}
      <p className="mt-1 text-[10px] text-slate-500">Rendered as SVG and passed through the same sanitiser as imported drawings. Log scales, series stacking and data-label number formats are not implemented.</p>
    </Section>
  );
}

/* Conditional formatting + data validation panel for Calc. */
function ConditionalPanel({ doc, setDoc, sheetIdx }: {
  doc: Extract<Doc, { kind: "xlsx" }>; setDoc: (d: Doc) => void; sheetIdx: number;
}) {
  const sheet = doc.model.sheets[sheetIdx];
  if (!sheet) return null;
  const rules = sheet.conditionalRules ?? [];
  const validations = sheet.validations ?? [];

  const addRule = () => {
    const model = structuredClone(doc.model);
    const sh = model.sheets[sheetIdx];
    sh.conditionalRules = [...(sh.conditionalRules ?? []), {
      type: "cellIs", op: "greaterThan", formula: ["0"], styleIndex: 0, range: "A1:B10",
    }];
    setDoc({ ...doc, model });
  };
  const addValidation = () => {
    const model = structuredClone(doc.model);
    const sh = model.sheets[sheetIdx];
    sh.validations = [...(sh.validations ?? []), {
      type: "whole", op: "greaterThanOrEqual", formula1: "0", allowBlank: true, range: "A1:B10", error: "Enter a non-negative whole number",
    }];
    setDoc({ ...doc, model });
  };
  const removeRule = (i: number) => {
    const model = structuredClone(doc.model);
    const sh = model.sheets[sheetIdx];
    sh.conditionalRules = (sh.conditionalRules ?? []).filter((_, idx) => idx !== i);
    setDoc({ ...doc, model });
  };
  const removeValidation = (i: number) => {
    const model = structuredClone(doc.model);
    const sh = model.sheets[sheetIdx];
    sh.validations = (sh.validations ?? []).filter((_, idx) => idx !== i);
    setDoc({ ...doc, model });
  };

  return (
    <Section title="Conditional formatting & validation" right={
      <div className="flex gap-1">
        <Btn small testId="add-cf-rule" onClick={addRule}>+ CF rule</Btn>
        <Btn small testId="add-validation" onClick={addValidation}>+ Validation</Btn>
      </div>}>
      <div className="text-[10px] text-slate-400" data-testid="cf-list">
        {rules.length === 0 && validations.length === 0 && <span>No rules. Add a conditional format or data validation.</span>}
        {rules.map((r, i) => (
          <div key={`cf-${i}`} className="flex items-center gap-1 py-0.5" data-testid={`cf-rule-${i}`}>
            <span className="font-mono">CF {r.range} {r.type} {r.op ?? ""} {r.formula.join(",")}</span>
            <Btn small kind="danger" onClick={() => removeRule(i)}>✕</Btn>
          </div>
        ))}
        {validations.map((v, i) => (
          <div key={`dv-${i}`} className="flex items-center gap-1 py-0.5" data-testid={`dv-rule-${i}`}>
            <span className="font-mono">DV {v.range} {v.type} {v.op ?? ""} {v.formula1 ?? ""}</span>
            <Btn small kind="danger" onClick={() => removeValidation(i)}>✕</Btn>
          </div>
        ))}
      </div>
      <Note>Basic cellIs highlighting is an approximate preview. Validation rules are metadata written into the .xlsx and re-read on open; cell-edit enforcement and full expression-rule evaluation are not implemented here.</Note>
    </Section>
  );
}
