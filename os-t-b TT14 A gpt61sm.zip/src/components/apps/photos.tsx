"use client";

// Implements: MD-03 Photos — a gallery over image files in the VFS with non-destructive edits.
// The original file bytes are never rewritten: an edit produces a new file (or a recipe row) via
// the pure raster engine in lib/raster.ts, which is verified headlessly. Saving writes a NEW file
// named <original>.fusion.<ext>; the source stays byte-identical.

import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Btn, Note, Section, cls, fmtBytes, post, useJson, useShell } from "../ui";
import { applyRecipe, histogram, type EditRecipe, type Raster } from "@/lib/raster";

type FsNode = { id: number; parentId: number | null; name: string; kind: string; mime: string; content: string; size: number; updatedAt: string };
type Listing = { path: string; id: number | null; entries: FsNode[] };

export function PhotosApp() {
  const { toast } = useShell();
  const { data, reload } = useJson<Listing>("/api/fs?op=list&path=/Home");
  const [selected, setSelected] = useState<FsNode | null>(null);
  const [recipe, setRecipe] = useState<EditRecipe>({ adjust: { brightness: 1, contrast: 1, saturation: 1 } });
  const [raster, setRaster] = useState<Raster | null>(null);
  const [busy, setBusy] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Gather images recursively by walking folders (shallow: Home + one level, like the gallery scope).
  const [images, setImages] = useState<FsNode[]>([]);
  useEffect(() => {
    (async () => {
      const found: FsNode[] = [];
      const walk = async (path: string) => {
        const r = await fetch(`/api/fs?op=list&path=${encodeURIComponent(path)}`);
        if (!r.ok) return;
        const j = (await r.json()) as Listing;
        for (const e of j.entries) {
          if (e.kind === "dir" && !e.name.startsWith(".")) await walk(`${path === "/" ? "" : path}/${e.name}`);
          else if (/^image\//.test(e.mime) || /\.(png|jpe?g|webp|gif|avif)$/i.test(e.name)) found.push(e);
        }
      };
      await walk("/Home");
      setImages(found.slice(0, 60));
    })();
  }, [data]);

  const load = useCallback(async (node: FsNode) => {
    setSelected(node);
    setRecipe({ adjust: { brightness: 1, contrast: 1, saturation: 1 } });
    setBusy(true);
    try {
      const full = (await (await fetch(`/api/fs?op=read&id=${node.id}`)).json()) as { node: FsNode };
      const content = full.node.content;
      const src = content.startsWith("data:") ? content : null;
      if (!src) throw new Error("image content is not stored as a data URL");
      const img = new Image();
      img.onload = () => {
        const off = document.createElement("canvas");
        off.width = img.naturalWidth; off.height = img.naturalHeight;
        const ctx = off.getContext("2d", { willReadFrequently: true });
        if (!ctx) { setBusy(false); return; }
        ctx.drawImage(img, 0, 0);
        const d = ctx.getImageData(0, 0, off.width, off.height);
        setRaster({ width: d.width, height: d.height, data: d.data });
        setBusy(false);
      };
      img.onerror = () => { setBusy(false); toast("Could not decode image", "error"); };
      img.src = src;
    } catch (e) { setBusy(false); toast(String(e), "error"); }
  }, [toast]);

  useEffect(() => {
    if (!raster || !canvasRef.current) return;
    const out = applyRecipe(raster, recipe);
    const cv = canvasRef.current;
    cv.width = out.width; cv.height = out.height;
    const ctx = cv.getContext("2d");
    if (!ctx) return;
    const framed = new Uint8ClampedArray(out.width * out.height * 4);
    framed.set(out.data);
    ctx.putImageData(new ImageData(framed, out.width, out.height), 0, 0);
  }, [raster, recipe]);

  const stats = useMemo(() => (raster ? { w: raster.width, h: raster.height, peak: histogram(applyRecipe(raster, recipe)).indexOf(Math.max(...histogram(applyRecipe(raster, recipe)))) } : null), [raster, recipe]);

  const saveEdited = async () => {
    const cv = canvasRef.current;
    if (!cv || !selected) return;
    const base = selected.name.replace(/\.[^.]+$/, "");
    cv.toBlob(async (blob) => {
      if (!blob) return toast("PNG encoding unsupported", "warn");
      const b64 = await new Promise<string>((res) => {
        const r = new FileReader();
        r.onload = () => res(String(r.result));
        r.readAsDataURL(blob);
      });
      const parent = await (await fetch(`/api/fs?op=list&path=/Home/Downloads`)).json();
      await post("/api/fs", { op: "create", parentId: parent.id, name: `${base}.fusion.png`, kind: "file", mime: "image/png", content: b64 });
      window.dispatchEvent(new Event("fusion:fs"));
      toast(`Saved edited copy to /Home/Downloads/${base}.fusion.png — original untouched (MD-03)`);
    }, "image/png");
  };

  const patch = (k: keyof EditRecipe, v: unknown) => setRecipe((r) => ({ ...r, [k]: v }));

  return (
    <div className="flex h-full min-h-0" data-testid="photos-app">
      <div className="w-48 shrink-0 overflow-auto border-r border-white/10 p-1">
        <span className="text-[10px] uppercase text-slate-500">{images.length} image(s) under /Home</span>
        <div className="mt-1 grid grid-cols-2 gap-1">
          {images.map((n) => (
            <button key={n.id} onClick={() => void load(n)} data-testid={`photo-thumb-${n.id}`}
              className={cls("truncate rounded px-1 py-1 text-[10px]", selected?.id === n.id ? "bg-[var(--accent)]/25" : "hover:bg-white/5")}>
              🖼 {n.name}
            </button>
          ))}
        </div>
        {images.length === 0 && <p className="mt-2 text-[10px] text-slate-500">No images found under /Home.</p>}
      </div>
      <div className="flex min-w-0 flex-1 flex-col">
        {selected && raster ? (
          <>
            <div className="flex items-center gap-2 border-b border-white/10 px-2 py-1 text-[11px]">
              <span className="truncate">{selected.name}</span>
              <span className="text-slate-500">{stats?.w}×{stats?.h}px</span>
              <div className="flex-1" />
              <Btn small kind="primary" onClick={saveEdited}>Save edited copy</Btn>
              <Btn small onClick={() => setRecipe({ adjust: { brightness: 1, contrast: 1, saturation: 1 } })}>Reset</Btn>
            </div>
            <div className="flex min-h-0 flex-1">
              <div className="flex min-w-0 flex-1 items-center justify-center bg-slate-950/60 p-2">
                <canvas ref={canvasRef} data-testid="photo-canvas" className="max-h-full max-w-full rounded border border-white/10" />
              </div>
              <aside className="w-56 shrink-0 overflow-auto border-l border-white/10 bg-black/20 p-2">
                <Section title="Non-destructive edits">
                  {([["brightness", "Brightness"], ["contrast", "Contrast"], ["saturation", "Saturation"]] as const).map(([k, label]) => (
                    <label key={k} className="mb-1 block text-[10px]">{label} {(recipe.adjust?.[k] ?? 1).toFixed(2)}
                      <input type="range" min={0} max={2} step={0.05} aria-label={label} value={recipe.adjust?.[k] ?? 1}
                        onChange={(e) => setRecipe((r) => ({ ...r, adjust: { ...r.adjust, [k]: Number(e.target.value) } }))} className="w-full" />
                    </label>
                  ))}
                  <label className="mb-1 block text-[10px]">Blur {recipe.blur ?? 0}
                    <input type="range" min={0} max={8} aria-label="Blur" value={recipe.blur ?? 0} onChange={(e) => patch("blur", Number(e.target.value))} className="w-full" />
                  </label>
                  <label className="mb-1 block text-[10px]">Sharpen {recipe.sharpen ?? 0}
                    <input type="range" min={0} max={3} step={0.1} aria-label="Sharpen" value={recipe.sharpen ?? 0} onChange={(e) => patch("sharpen", Number(e.target.value))} className="w-full" />
                  </label>
                  <div className="flex flex-wrap gap-1">
                    {([["equalize", "Equalize"], ["sepia", "Sepia"], ["edges", "Edges"]] as const).map(([k, label]) => (
                      <Btn key={k} small kind={recipe[k as keyof EditRecipe] ? "primary" : "ghost"} onClick={() => patch(k as keyof EditRecipe, !recipe[k as keyof EditRecipe])}>{label}</Btn>
                    ))}
                  </div>
                  <label className="mt-1 block text-[10px]">Posterize {recipe.posterize ?? "off"}
                    <input type="range" min={2} max={8} aria-label="Posterize" value={recipe.posterize ?? 4}
                      onChange={(e) => patch("posterize", recipe.posterize ? null : Number(e.target.value))} className="w-full" />
                  </label>
                  <Btn small kind="ghost" onClick={() => patch("posterize", recipe.posterize ? null : 4)}>{recipe.posterize ? "Posterize off" : "Posterize on"}</Btn>
                </Section>
                <Note>The source file is never modified. “Save edited copy” writes a new PNG to /Home/Downloads.</Note>
              </aside>
            </div>
          </>
        ) : (
          <div className="flex flex-1 items-center justify-center text-xs text-slate-500">
            {busy ? "decoding…" : "Select an image to edit it non-destructively"}
          </div>
        )}
      </div>
    </div>
  );
}
