"use client";

import React, { useCallback, useEffect, useState } from "react";
import { Btn, Note, Section, StateDot, Wall, useShell } from "../ui";
import { kvGet, kvPut, useKvWatch } from "./productivity";
import { liveClips, mailtoUrl, makeClip, normaliseContact, type ClipItem, type Contact } from "@/lib/integration";

export function ContactsApp() {
  const { toast } = useShell();
  const [contacts, setContacts] = useState<Contact[]>([]);
  const [name, setName] = useState(""), [email, setEmail] = useState(""), [tel, setTel] = useState("");
  const reload = useCallback(() => kvGet<Contact[]>("app.contacts", []).then(setContacts), []);
  useEffect(() => { void reload(); }, [reload]); useKvWatch("app.contacts", reload);
  const save = async (next: Contact[]) => { await kvPut("app.contacts", next.slice(0, 1000)); setContacts(next.slice(0, 1000)); };
  const add = async (raw: Partial<Contact>) => {
    const clean = normaliseContact(raw); if (!clean) return toast("Name plus a valid email or phone is required", "warn");
    await save([{ ...clean, id: `p${Date.now()}${Math.random().toString(36).slice(2, 6)}`, createdAt: new Date().toISOString() }, ...contacts]);
    setName(""); setEmail(""); setTel("");
  };
  const picker = (navigator as Navigator & { contacts?: { select: (fields: string[], opts: { multiple: boolean }) => Promise<{ name?: string[]; email?: string[]; tel?: string[] }[]> } }).contacts;
  return <div data-testid="contacts-app" className="h-full overflow-auto p-3">
    <Section title="Add contact (PR-05)"><div className="flex flex-wrap gap-1">
      <input aria-label="Contact name" value={name} onChange={e => setName(e.target.value)} placeholder="Name" className="rounded border border-white/10 bg-black/30 px-2 py-1 text-[11px]" />
      <input aria-label="Contact email" value={email} onChange={e => setEmail(e.target.value)} placeholder="Email" className="rounded border border-white/10 bg-black/30 px-2 py-1 text-[11px]" />
      <input aria-label="Contact phone" value={tel} onChange={e => setTel(e.target.value)} placeholder="Phone" className="rounded border border-white/10 bg-black/30 px-2 py-1 text-[11px]" />
      <Btn small kind="primary" onClick={() => void add({ name, email, tel, source: "manual" })}>Add</Btn>
      <Btn small disabled={!picker} onClick={async () => {
        if (!picker) return;
        try {
          const rows = await picker.select(["name", "email", "tel"], { multiple: true });
          const now = Date.now();
          const picked = rows.map((row, i) => normaliseContact({ name: row.name?.[0], email: row.email?.[0], tel: row.tel?.[0], source: "picker" }))
            .filter((x): x is NonNullable<typeof x> => !!x)
            .map((x, i) => ({ ...x, id: `p${now}-${i}`, createdAt: new Date(now).toISOString() }));
          if (picked.length) await save([...picked, ...contacts]);
        } catch { toast("Contact picker cancelled"); }
      }}>Pick from device…</Btn>
    </div><p data-testid="contact-picker-state" className="mt-1 text-[10px] text-slate-500">Contact Picker API: {picker ? "available after a user gesture" : "unavailable; manual entry remains"}</p></Section>
    <Section title={`Stored contacts (${contacts.length})`} right={<Btn small onClick={() => { const blob = new Blob([JSON.stringify({ kind: "fusion-contacts", version: 1, contacts }, null, 2)], { type: "application/json" }); const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = "fusion-contacts.json"; a.click(); }}>Export JSON</Btn>}>
      <ul data-testid="contact-list" className="space-y-1">{contacts.map(c => <li key={c.id} className="flex items-center gap-2 rounded bg-white/5 p-2 text-[11px]"><span className="min-w-0 flex-1"><b>{c.name}</b><span className="ml-2 text-slate-400">{c.email || c.tel}</span></span><span className="text-[9px] uppercase text-slate-500">{c.source}</span><Btn small kind="danger" onClick={() => void save(contacts.filter(x => x.id !== c.id))}>Delete</Btn></li>)}</ul>
      <Note>Picked rows are shown before they are saved by this explicit action. No background address-book access exists.</Note>
    </Section>
  </div>;
}

export function ClipboardApp() {
  const { toast } = useShell();
  const [items, setItems] = useState<ClipItem[]>([]), [text, setText] = useState(""), [sensitive, setSensitive] = useState(false);
  const reload = useCallback(async () => { const all = await kvGet<ClipItem[]>("app.clipboard", []); const live = liveClips(all); setItems(live); if (live.length !== all.length) await kvPut("app.clipboard", live); }, []);
  useEffect(() => { void reload(); const id = setInterval(reload, 5000); return () => clearInterval(id); }, [reload]); useKvWatch("app.clipboard", reload);
  const add = async (source: ClipItem["source"], value = text) => { const item = makeClip(value, sensitive, source); if (!item) return toast("Clipboard item is empty", "warn"); const next = liveClips([item, ...items]); await kvPut("app.clipboard", next); setItems(next); setText(""); };
  return <div data-testid="clipboard-app" className="h-full overflow-auto p-3">
    <Section title="Explicit clipboard history (PR-12)"><textarea aria-label="Clipboard draft" value={text} onChange={e => setText(e.target.value)} placeholder="Type text or press Read clipboard…" className="h-20 w-full rounded border border-white/10 bg-black/30 p-2 text-[11px]" />
      <div className="mt-1 flex flex-wrap items-center gap-1"><label className="flex items-center gap-1"><input type="checkbox" checked={sensitive} onChange={e => setSensitive(e.target.checked)} /> Sensitive (expires after 60 s)</label>
        <Btn small kind="primary" onClick={async () => {
          const value = text;
          await add("own-copy", value);
          try { await navigator.clipboard.writeText(value); } catch { toast("Saved to history, but browser denied clipboard write", "warn"); }
        }}>Add &amp; copy</Btn>
        <Btn small onClick={async () => { try { const v = await navigator.clipboard.readText(); setText(v); await add("explicit-paste", v); } catch { toast("Clipboard read denied or unavailable", "warn"); } }}>Read clipboard…</Btn>
        <Btn small kind="danger" onClick={() => { void kvPut("app.clipboard", []); setItems([]); }}>Clear</Btn></div>
      <Note>Only text copied here or read after this explicit user gesture is recorded. Other apps and tabs are never monitored.</Note></Section>
    <Section title={`History (${items.length})`}><ul data-testid="clipboard-list" className="space-y-1">{items.map(x => <li key={x.id} className="flex items-center gap-2 rounded bg-white/5 p-2 text-[11px]"><span className="min-w-0 flex-1 truncate">{x.sensitive ? "•••• sensitive item" : x.text}</span><span className="text-[9px] text-slate-500">{x.source}{x.expiresAt ? ` · expires ${new Date(x.expiresAt).toLocaleTimeString()}` : ""}</span><Btn small onClick={async () => { try { await navigator.clipboard.writeText(x.text); toast("Copied by explicit gesture"); } catch { toast("Clipboard write denied", "warn"); } }}>Copy</Btn><Btn small kind="danger" onClick={() => { const next = items.filter(i => i.id !== x.id); void kvPut("app.clipboard", next); setItems(next); }}>Delete</Btn></li>)}</ul></Section>
  </div>;
}

export function MailApp() {
  const { toast } = useShell();
  const [to, setTo] = useState(""), [subject, setSubject] = useState(""), [body, setBody] = useState("");
  const url = mailtoUrl(to, subject, body);
  return <div data-testid="mail-app" className="h-full overflow-auto p-3"><Section title="Mail handoff (PR-06)">
    <input aria-label="Mail recipient" value={to} onChange={e => setTo(e.target.value)} placeholder="person@example.com" className="mb-1 w-full rounded border border-white/10 bg-black/30 px-2 py-1 text-[11px]" />
    <input aria-label="Mail subject" value={subject} onChange={e => setSubject(e.target.value)} placeholder="Subject" className="mb-1 w-full rounded border border-white/10 bg-black/30 px-2 py-1 text-[11px]" />
    <textarea aria-label="Mail body" value={body} onChange={e => setBody(e.target.value)} placeholder="Message" className="h-40 w-full rounded border border-white/10 bg-black/30 p-2 text-[11px]" />
    <div className="mt-1"><a data-testid="mailto-link" href={url || undefined} onClick={e => { if (!url) { e.preventDefault(); toast("Enter a valid email address", "warn"); } }} className="inline-flex rounded border border-[var(--accent)] bg-[var(--accent)]/10 px-3 py-1.5 text-[var(--accent)]">Open default mail app</a></div>
    <Note>No mail credentials, IMAP state or message content are sent to this server. The operating system handles the mailto URL.</Note>
  </Section></div>;
}

export function HandlersApp() {
  const { toast } = useShell();
  const [manifest, setManifest] = useState<Record<string, unknown> | null>(null);
  useEffect(() => { fetch("/manifest.webmanifest").then(r => r.json()).then(setManifest).catch(() => setManifest(null)); }, []);
  const canProtocol = "registerProtocolHandler" in navigator;
  const fileHandlers = Array.isArray(manifest?.file_handlers) ? manifest?.file_handlers as unknown[] : [];
  return <div data-testid="handlers-app" className="h-full overflow-auto p-3"><Section title="Handlers & install guide (ST-03)">
    <ul className="space-y-1 text-[11px]"><li className="flex gap-2"><StateDot state={fileHandlers.length ? "available" : "unavailable"} />Manifest file handlers: {fileHandlers.length}</li><li className="flex gap-2"><StateDot state={(manifest?.share_target) ? "available" : "unavailable"} />Web Share Target: {manifest?.share_target ? "declared" : "missing"}</li><li className="flex gap-2"><StateDot state={canProtocol ? "needs-permission" : "unavailable"} />Custom protocol handler: {canProtocol ? "browser supports prompting" : "unavailable"}</li><li>Installed mode: {matchMedia("(display-mode: standalone)").matches ? "standalone" : "browser tab"}</li></ul>
    <div className="mt-2"><Btn small disabled={!canProtocol} onClick={() => { try { navigator.registerProtocolHandler("web+fusion", `${location.origin}/?open=find&q=%s`); toast("Browser accepted the handler request; final approval is browser-controlled"); } catch (e) { toast(String(e), "warn"); } }}>Register web+fusion handler…</Btn></div>
    <Wall>File-handler and share-target declarations become active only after a supporting browser installs the PWA. A page cannot make itself the default without browser/user confirmation.</Wall>
    <pre data-testid="manifest-summary" className="mt-2 overflow-auto rounded bg-black/30 p-2 text-[10px]">{JSON.stringify({ file_handlers: manifest?.file_handlers ?? null, share_target: manifest?.share_target ?? null, display: manifest?.display ?? null }, null, 2)}</pre>
  </Section></div>;
}
