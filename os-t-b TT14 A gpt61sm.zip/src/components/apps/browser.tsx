"use client";

import React, { useEffect, useMemo, useReducer, useRef, useState } from "react";
import { Btn, Note, Section, Wall, cls, useInterval, useShell } from "../ui";
import { browserInitial, browserNormalize, browserReduce, safeBrowserUrl, type BrowserSession, type BrowserTab } from "@/lib/browserState";
import { kvGet, kvPut } from "./productivity";
import { policyFor, KNOWN_FEATURES } from "@/lib/sandboxPolicy";

// PR-07o browser profiles. Honest scope: a web page cannot create separate browser partitions, so a
// profile scopes *our* per-site policy grants and *our* history only — never cookies, storage or
// renderer isolation. That boundary is stated in the UI, not hidden.
export type BrowserProfile = { name: string; color: string; allow: string[] };
type ProfileStore = { active: string; list: BrowserProfile[] };
type HistEntry = { url: string; title: string; at: number };

// PR-07a/b/c/d/e/f/g/q/r: each frame is *one keyed React node*; changing tabs or split geometry only
// changes CSS placement. The old Browser recreated the Frame component on every render, reloading pages.
// Cross-origin iframe limitations remain: no forced UA, content filter, site permission interception or DOM find.
type Saved = { id: string; name: string; savedAt: string; state: BrowserSession };
type ProbeState = "unknown" | "allowed" | "denied";

function BrowserFrame({ tab, rect, probe, wake, sandbox, allow }: {
  tab: BrowserTab; rect: React.CSSProperties | null; probe: ProbeState; wake: () => void; sandbox: string; allow: string;
}) {
  const shown = rect !== null;
  return (
    <div data-testid={`browser-frame-${tab.id}`} aria-hidden={!shown} style={{ position: "absolute", overflow: "hidden", ...rect, display: shown ? "block" : "none" }}>
      {tab.asleep ? (
        <div className="flex h-full flex-col items-center justify-center gap-2 bg-slate-950 text-xs text-slate-300">
          <span>Sleeping tab — URL preserved: {tab.url}</span><Btn small onClick={wake}>Wake</Btn>
        </div>
      ) : (
        <>
          <iframe title={`Browser tab: ${tab.title}`} src={tab.url} sandbox={sandbox} allow={allow}
            referrerPolicy="no-referrer" className="h-full w-full bg-white" data-sandbox={sandbox} />
          {probe === "denied" && (
            <div role="status" className="absolute inset-x-2 bottom-2 rounded border border-rose-400/40 bg-slate-950/95 p-2 text-[11px] text-rose-100">
              Embed refused by this site (or unavailable from the safe public probe). The page is not a browser engine.
              <a href={tab.url} target="_blank" rel="noopener noreferrer" className="ml-2 underline">Open in a real browser tab ↗</a>
            </div>
          )}
        </>
      )}
    </div>
  );
}

export function BrowserApp({ windowId }: { windowId: string }) {
  const { toast, settings } = useShell();
  const [s, act] = useReducer(browserReduce, undefined, () => browserInitial(0));
  const [ready, setReady] = useState(false);
  const [address, setAddress] = useState("https://example.com/");
  const [groupName, setGroupName] = useState("");
  const [groupColor, setGroupColor] = useState("#38bdf8");
  const [sessionName, setSessionName] = useState("");
  const [saved, setSaved] = useState<Saved[]>([]);
  const [probe, setProbe] = useState<Record<number, ProbeState>>({});
  const [batch, setBatch] = useState<"duplicates" | "others" | "toRight">("duplicates");
  const [profiles, setProfiles] = useState<ProfileStore>({ active: "Default", list: [{ name: "Default", color: "#38bdf8", allow: [] }] });
  const [history, setHistory] = useState<HistEntry[]>([]);
  const [showHistory, setShowHistory] = useState(false);
  const [newProfile, setNewProfile] = useState("");
  const content = useRef<HTMLDivElement>(null);
  const dragging = useRef(false);
  const storageKey = `fusion.browser.${windowId}`;
  const active = s.tabs.find(t => t.id === s.activeId);
  const sleepMs = settings["runtime.lowMemoryMode"] ? 20_000 : 120_000;

  useEffect(() => {
    try {
      const raw = localStorage.getItem(storageKey);
      if (raw) act({ type: "hydrate", session: browserNormalize(JSON.parse(raw) as BrowserSession) });
      else act({ type: "hydrate", session: browserInitial(Date.now()) });
    } catch { act({ type: "hydrate", session: browserInitial(Date.now()) }); }
    kvGet<Saved[]>("app.browserSessions", []).then(setSaved);
    kvGet<ProfileStore>("app.browserProfiles", { active: "Default", list: [{ name: "Default", color: "#38bdf8", allow: [] }] }).then(setProfiles);
    setReady(true);
  }, [storageKey]);
  // History is per profile (PR-07o scope): keyed by profile name, capped at 200 entries.
  useEffect(() => {
    kvGet<HistEntry[]>(`app.browserHistory.${profiles.active}`, []).then(setHistory);
  }, [profiles.active]);
  useEffect(() => { if (ready) localStorage.setItem(storageKey, JSON.stringify(s)); }, [s, ready, storageKey]);
  useEffect(() => { setAddress(active?.url ?? "about:blank"); }, [active?.url, active?.id]);

  useInterval(() => {
    const now = Date.now();
    for (const t of s.tabs) {
      if (!t.pinned && !t.asleep && now - t.lastActive > sleepMs && t.id !== s.activeId && (s.split === "off" || t.id !== s.secondId)) {
        act({ type: "sleep", id: t.id });
      }
    }
  }, 5000);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (!e.ctrlKey || !e.altKey || e.metaKey) return;
      if (e.key.toLowerCase() === "t") { e.preventDefault(); act({ type: "add", now: Date.now() }); }
      if (e.key === "PageDown" || e.key === "PageUp") {
        e.preventDefault();
        const i = s.tabs.findIndex(t => t.id === s.activeId);
        const next = (i + (e.key === "PageDown" ? 1 : s.tabs.length - 1)) % s.tabs.length;
        act({ type: "activate", id: s.tabs[next].id, now: Date.now() });
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [s.activeId, s.tabs]);

  const navigate = (id: number, text: string) => {
    const url = safeBrowserUrl(text);
    if (!url) return toast("Only http(s) and about:blank are allowed. Credentials in URLs are refused.", "warn");
    act({ type: "navigate", id, url, now: Date.now() });
    if (url === "about:blank") return;
    // PR-07o: record into the active profile's history (capped).
    kvGet<HistEntry[]>(`app.browserHistory.${profiles.active}`, []).then((h) => {
      const next = [{ url, title: new URL(url).hostname, at: Date.now() }, ...h.filter(x => x.url !== url)].slice(0, 200);
      void kvPut(`app.browserHistory.${profiles.active}`, next);
      setHistory(next);
    });
    // WM-06: the server *only* probes a fixed set of public hosts. Other sites show a real-browser fallback.
    fetch(`/api/embed?url=${encodeURIComponent(url)}`).then(r => r.json()).then((r: { embeddable: boolean | null }) => {
      setProbe(p => ({ ...p, [id]: r.embeddable === false ? "denied" : r.embeddable === true ? "allowed" : "unknown" }));
    }).catch(() => setProbe(p => ({ ...p, [id]: "unknown" })));
  };
  const createGroup = () => {
    if (!groupName.trim()) return toast("Name the group", "warn");
    act({ type: "createGroup", id: `g${Date.now()}`, name: groupName, color: groupColor, tabId: s.activeId });
    setGroupName("");
  };
  const persistSessions = async (next: Saved[]) => {
    await kvPut("app.browserSessions", next);
    setSaved(next);
  };
  const saveSession = () => {
    if (!sessionName.trim()) return toast("Name the session before saving", "warn");
    const next = [...saved.filter(x => x.name !== sessionName.trim()), { id: `s${Date.now()}`, name: sessionName.trim(), savedAt: new Date().toISOString(), state: s }];
    void persistSessions(next);
    toast(`Saved ${s.tabs.length} tabs, ${s.groups.length} group(s), and split layout`);
  };

  const tabsForGroup = (id: string | null) => s.tabs.filter(t => !t.pinned && t.groupId === id);
  const tabButton = (t: BrowserTab) => (
    <div key={t.id} data-testid={`browser-tab-${t.id}`} className={cls("flex items-center gap-1 rounded text-[11px]", s.activeId === t.id ? "bg-[var(--accent)]/20" : "bg-white/5 hover:bg-white/10")}>
      <button title={`Activate ${t.title}`} onClick={() => act({ type: "activate", id: t.id, now: Date.now() })}
        className="min-w-0 flex-1 truncate px-2 py-1 text-left">{t.pinned ? "📌 " : ""}{t.asleep ? "💤 " : ""}{t.title}</button>
      <button title={`Close ${t.title}`} aria-label={`Close tab ${t.title}`} className="px-1 text-slate-500 hover:text-rose-300" onClick={() => act({ type: "close", id: t.id })}>×</button>
    </div>
  );
  const tabRail = (
    <div data-testid="browser-tab-rail" className={cls("flex gap-1 overflow-auto border-white/10 p-1", s.verticalTabs ? "w-44 shrink-0 flex-col border-r" : "shrink-0 flex-row border-b")}>
      {s.tabs.filter(t => t.pinned).map(tabButton)}
      {tabsForGroup(null).map(tabButton)}
      {s.groups.map(g => (
        <div key={g.id} className={cls("min-w-0", s.verticalTabs ? "" : "flex items-center gap-1")}>
          <button data-testid={`browser-group-${g.id}`} onClick={() => act({ type: "collapseGroup", id: g.id })}
            className="shrink-0 rounded border border-white/10 px-1 text-[10px]" style={{ color: g.color }} title={`${g.collapsed ? "Expand" : "Collapse"} ${g.name}`}>
            {g.collapsed ? "▸" : "▾"} {g.name} ({tabsForGroup(g.id).length})
          </button>
          {!g.collapsed && tabsForGroup(g.id).map(tabButton)}
        </div>
      ))}
    </div>
  );

  const rectFor = (id: number): React.CSSProperties | null => {
    if (id === s.activeId) return s.split === "off" ? { inset: 0 } : s.split === "horizontal"
      ? { top: 0, left: 0, width: `${s.divider}%`, height: "100%" } : { top: 0, left: 0, width: "100%", height: `${s.divider}%` };
    if (s.split !== "off" && id === s.secondId) return s.split === "horizontal"
      ? { top: 0, left: `${s.divider}%`, width: `${100 - s.divider}%`, height: "100%" }
      : { top: `${s.divider}%`, left: 0, width: "100%", height: `${100 - s.divider}%` };
    return null;
  };
  const dividerProps = s.split === "horizontal" ? { left: `calc(${s.divider}% - 3px)`, top: 0, height: "100%", width: 6, cursor: "col-resize" }
    : { top: `calc(${s.divider}% - 3px)`, left: 0, width: "100%", height: 6, cursor: "row-resize" };

  return (
    <div className="flex h-full min-h-0 flex-col" data-testid="browser-app">
      <div className="flex flex-wrap items-center gap-1 border-b border-white/10 p-1">
        <Btn small onClick={() => act({ type: "verticalTabs", on: !s.verticalTabs })}>{s.verticalTabs ? "Horizontal tabs" : "Vertical tabs"}</Btn>
        <Btn small onClick={() => act({ type: "split", split: s.split === "off" ? "horizontal" : s.split === "horizontal" ? "vertical" : "off" })}>Split: {s.split}</Btn>
        <Btn small onClick={() => act({ type: "add", now: Date.now() })}>+ Tab</Btn>
        <form className="min-w-40 flex-1" onSubmit={e => { e.preventDefault(); navigate(s.activeId, address); }}>
          <input aria-label="Address" value={address} onChange={e => setAddress(e.target.value)}
            className="w-full rounded border border-white/10 bg-black/30 px-2 py-1 text-[11px]" />
        </form>
        <Btn small onClick={() => active && act({ type: "pin", id: active.id })} title="Pinned tabs do not sleep or close in batch actions">
          <span data-testid="browser-pin">{active?.pinned ? "Unpin" : "Pin"}</span>
        </Btn>
        <a href={active?.url || "about:blank"} target="_blank" rel="noopener noreferrer" className="rounded border border-white/10 px-2 py-1 text-[11px]" title="The external page opens in a real browser tab">↗</a>
      </div>
      <div className="flex min-h-0 flex-1 flex-col">
        <div className={cls("flex min-h-0 flex-1", s.verticalTabs ? "flex-row" : "flex-col")}>
          {tabRail}
          <div ref={content} className="relative min-h-0 min-w-0 flex-1 overflow-hidden bg-slate-900" data-testid="browser-content">
            {s.tabs.map(t => {
              // WM-06 + PR-07o: per-site sandbox policy, plus whatever the active profile grants.
              const profile = profiles.list.find(x => x.name === profiles.active);
              const pol = policyFor(t.url, profile?.allow ?? []);
              const allow = pol.allow;
              return <BrowserFrame key={t.id} tab={t} rect={rectFor(t.id)} probe={probe[t.id] || "unknown"}
                sandbox={pol.sandbox ?? "allow-scripts"} allow={allow}
                wake={() => act({ type: "wake", id: t.id, now: Date.now() })} />;
            })}
            {s.split !== "off" && s.secondId && (
              <div role="separator" aria-label="Split divider" aria-orientation={s.split === "horizontal" ? "vertical" : "horizontal"}
                aria-valuemin={20} aria-valuemax={80} aria-valuenow={s.divider} tabIndex={0} data-testid="browser-divider"
                onPointerDown={e => { dragging.current = true; e.currentTarget.setPointerCapture(e.pointerId); }}
                onPointerMove={e => {
                  if (!dragging.current || !content.current) return;
                  const r = content.current.getBoundingClientRect();
                  act({ type: "divider", value: s.split === "horizontal" ? ((e.clientX - r.left) / r.width) * 100 : ((e.clientY - r.top) / r.height) * 100 });
                }}
                onPointerUp={e => { dragging.current = false; e.currentTarget.releasePointerCapture(e.pointerId); }}
                onKeyDown={e => {
                  if (e.key === "ArrowLeft" || e.key === "ArrowUp" || e.key === "ArrowRight" || e.key === "ArrowDown") {
                    e.preventDefault(); act({ type: "divider", value: s.divider + (e.key === "ArrowLeft" || e.key === "ArrowUp" ? -5 : 5) });
                  }
                }}
                className="absolute z-20 bg-[var(--accent)]/50 hover:bg-[var(--accent)]" style={dividerProps} />
            )}
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-1 border-t border-white/10 bg-black/20 p-1 text-[10px]">
          {/* PR-07o profile switcher: scopes our per-site policy grants and history only. */}
          <select aria-label="Browser profile" data-testid="profile-select" value={profiles.active}
            className="rounded bg-slate-900 px-1 py-1" title="Profiles scope this browser's per-site policy grants and history — not cookies or storage"
            onChange={async (e) => {
              const next = { ...profiles, active: e.target.value };
              await kvPut("app.browserProfiles", next);
              setProfiles(next);
            }}>
            {profiles.list.map((pr) => <option key={pr.name} value={pr.name}>{pr.name}</option>)}
          </select>
          <input aria-label="New profile name" data-testid="profile-name" placeholder="New profile…" value={newProfile}
            onChange={(e) => setNewProfile(e.target.value)}
            className="w-24 rounded border border-white/10 bg-black/30 px-1 py-1 text-slate-100" />
          <Btn small testId="add-profile-btn" onClick={async () => {
            const name = newProfile.trim();
            if (!name || profiles.list.some(x => x.name === name)) return toast("Pick a unique profile name", "warn");
            const next = { active: name, list: [...profiles.list, { name, color: "#34d399", allow: [] }] };
            await kvPut("app.browserProfiles", next);
            setProfiles(next);
            setNewProfile("");
          }}>+ Profile</Btn>
          <Btn small onClick={() => setShowHistory(v => !v)} data-testid="history-toggle">History ({history.length})</Btn>
          {showHistory && (
            <div className="max-h-24 w-64 overflow-auto rounded border border-white/10 bg-black/40 p-1" data-testid="profile-history">
              {history.slice(0, 12).map((h, i) => <div key={i} className="truncate text-slate-400">{h.title}</div>)}
              {history.length === 0 && <div className="text-slate-600">No history in this profile yet.</div>}
            </div>
          )}
          {s.split !== "off" && <label>Second tab <select aria-label="Second tab" value={s.secondId || ""}
            onChange={e => act({ type: "second", id: Number(e.target.value) })} className="rounded bg-slate-900 px-1">
            {s.tabs.filter(t => t.id !== s.activeId).map(t => <option value={t.id} key={t.id}>{t.title}</option>)}
          </select></label>}
          <span>{s.tabs.length} tab(s) · {s.groups.length} group(s) · divider {s.divider}%</span>
          <span className="ml-auto text-slate-500">Ctrl+Alt+T: tab · Ctrl+Alt+PgUp/PgDn: switch (browser-safe)</span>
        </div>
      </div>
      <div className="flex max-h-40 shrink-0 flex-wrap items-start gap-2 overflow-auto border-t border-white/10 p-2 text-[10px]">
        <div className="flex flex-wrap items-center gap-1">
          <input aria-label="New group name" placeholder="New group" value={groupName} onChange={e => setGroupName(e.target.value)}
            className="w-24 rounded border border-white/10 bg-black/30 px-1 py-1" />
          <input aria-label="Group colour" type="color" value={groupColor} onChange={e => setGroupColor(e.target.value)} className="h-6 w-7" />
          <Btn small onClick={createGroup}>Group active</Btn>
          <select aria-label="Move active to group" value={active?.groupId ?? ""} className="rounded bg-slate-900 px-1 py-1"
            onChange={e => act({ type: "group", id: s.activeId, groupId: e.target.value || null })}>
            <option value="">Ungrouped</option>{s.groups.map(g => <option key={g.id} value={g.id}>{g.name}</option>)}
          </select>
        </div>
        <div className="flex flex-wrap items-center gap-1">
          <select aria-label="Batch action" value={batch} onChange={e => setBatch(e.target.value as typeof batch)} className="rounded bg-slate-900 px-1 py-1">
            <option value="duplicates">Close duplicates (to right)</option><option value="others">Close other tabs</option><option value="toRight">Close to the right</option>
          </select>
          <Btn small onClick={() => act({ type: "batch", target: batch, id: s.activeId })}>Apply batch</Btn>
        </div>
        <div className="flex flex-wrap items-center gap-1">
          <input aria-label="Session name" placeholder="Session name" value={sessionName} onChange={e => setSessionName(e.target.value)}
            className="w-24 rounded border border-white/10 bg-black/30 px-1 py-1" />
          <Btn small onClick={saveSession}>Save session</Btn>
          <select aria-label="Restore session" value="" className="rounded bg-slate-900 px-1 py-1" onChange={e => {
            const chosen = saved.find(x => x.id === e.target.value);
            if (chosen) { act({ type: "hydrate", session: chosen.state }); toast(`Restored “${chosen.name}”`); }
          }}>
            <option value="">Restore…</option>{saved.map(x => <option value={x.id} key={x.id}>{x.name}</option>)}
          </select>
        </div>
        <Wall>PR-07h: an iframe cannot change a cross-origin UA or expose its DOM to this page. Sites may refuse embedding. Use ↗ to open the real browser.</Wall>
      </div>
    </div>
  );
}
