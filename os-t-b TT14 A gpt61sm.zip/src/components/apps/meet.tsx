"use client";

// Implements: LN-20 Fusion Meet — a two-party WebRTC call. Signalling through /api/signal (append-only log).
// Negotiation rule: when two peers meet, the one whose random id sorts first offers; the other answers.
// Scope nuance: iceServers is empty (no STUN/TURN configured), so only host candidates are used. Peers on
// different networks (NAT) will not connect; that is a declared limit, not a silent failure.
// Media nuance: the camera/mic stream is sent as-is. Lens processing is not yet piped into Meet.

import React, { useEffect, useRef, useState } from "react";
import { Btn, Note, Section, post, useShell } from "../ui";

type Msg = { id: number; from: string; kind: string; payload: Record<string, unknown>; createdAt: string };
type Sess = {
  id: string;
  room: string;
  pc: RTCPeerConnection;
  stream: MediaStream;
  lastId: number;
  timer: number;
  peer: string | null;
  offered: boolean;
  remoteSet: boolean;
  pendingIce: RTCIceCandidateInit[];
};

export function MeetApp() {
  const { toast } = useShell();
  const [room, setRoom] = useState("fusion-demo");
  const [status, setStatus] = useState("idle");
  const [peerState, setPeerState] = useState("—");
  const [joined, setJoined] = useState(false);
  const localRef = useRef<HTMLVideoElement>(null);
  const remoteRef = useRef<HTMLVideoElement>(null);
  const sess = useRef<Sess | null>(null);

  const send = async (s: Sess, kind: string, payload: Record<string, unknown> = {}) => {
    await post("/api/signal", { room: s.room, from: s.id, kind, payload });
  };

  const flush = async (s: Sess) => {
    for (const c of s.pendingIce) await s.pc.addIceCandidate(c).catch(() => undefined);
    s.pendingIce = [];
  };

  const handle = async (s: Sess, m: Msg) => {
    if (m.from === s.id) return;
    const pc = s.pc;
    if (m.kind === "hello") {
      if (s.peer) return;
      if (s.id < m.from) {
        s.peer = m.from;
        s.offered = true;
        const offer = await pc.createOffer();
        await pc.setLocalDescription(offer);
        await send(s, "offer", { sdp: offer.sdp });
      } else {
        await send(s, "hello"); // acknowledge so the smaller id learns we exist
      }
    } else if (m.kind === "offer" && !s.peer) {
      s.peer = m.from;
      await pc.setRemoteDescription({ type: "offer", sdp: String(m.payload.sdp) });
      s.remoteSet = true;
      await flush(s);
      const answer = await pc.createAnswer();
      await pc.setLocalDescription(answer);
      await send(s, "answer", { sdp: answer.sdp });
    } else if (m.kind === "answer" && s.offered && s.peer === m.from) {
      await pc.setRemoteDescription({ type: "answer", sdp: String(m.payload.sdp) });
      s.remoteSet = true;
      await flush(s);
    } else if (m.kind === "ice" && s.peer === m.from) {
      const c = m.payload.c as RTCIceCandidateInit;
      if (s.remoteSet) await pc.addIceCandidate(c).catch(() => undefined);
      else s.pendingIce.push(c);
    } else if (m.kind === "bye" && s.peer === m.from) {
      setPeerState("peer left");
    }
  };

  const poll = async (s: Sess) => {
    const r = (await fetch(`/api/signal?room=${encodeURIComponent(s.room)}&after=${s.lastId}`).then((x) => x.json())) as { messages: Msg[] };
    for (const m of r.messages) {
      s.lastId = Math.max(s.lastId, m.id);
      await handle(s, m).catch((e: unknown) => setStatus(`negotiation error: ${String(e)}`));
    }
  };

  const join = async () => {
    try {
      setStatus("requesting camera and microphone");
      const stream = await navigator.mediaDevices.getUserMedia({ video: { width: 640, height: 360 }, audio: true });
      if (localRef.current) {
        localRef.current.srcObject = stream;
        localRef.current.muted = true;
        void localRef.current.play().catch(() => undefined);
      }
      const pc = new RTCPeerConnection({ iceServers: [] });
      const id = `p${Math.random().toString(36).slice(2, 10)}`;
      const s: Sess = { id, room, pc, stream, lastId: 0, timer: 0, peer: null, offered: false, remoteSet: false, pendingIce: [] };
      stream.getTracks().forEach((t) => pc.addTrack(t, stream));
      pc.ontrack = (e) => {
        if (remoteRef.current) {
          remoteRef.current.srcObject = e.streams[0] ?? new MediaStream([e.track]);
          void remoteRef.current.play().catch(() => undefined);
        }
      };
      pc.onicecandidate = (e) => { if (e.candidate) void send(s, "ice", { c: e.candidate.toJSON() }); };
      pc.onconnectionstatechange = () => {
        setPeerState(pc.connectionState);
        if (pc.connectionState === "connected") setStatus("connected");
        if (pc.connectionState === "failed") setStatus("failed: no route between peers (host candidates only)");
      };
      // Skip history: begin after the newest message already in the room.
      const init = (await fetch(`/api/signal?room=${encodeURIComponent(room)}&after=0`).then((x) => x.json())) as { maxId: number };
      s.lastId = init.maxId ?? 0;
      sess.current = s;
      setJoined(true);
      setStatus("joined — waiting for a peer");
      await send(s, "hello");
      let lastHello = Date.now();
      s.timer = window.setInterval(() => {
        poll(s).catch((e: unknown) => setStatus(`signal error: ${String(e)}`));
        if (!s.peer && Date.now() - lastHello > 3000) {
          lastHello = Date.now();
          void send(s, "hello");
        }
      }, 700);
    } catch (e) {
      setStatus(`failed: ${String(e)}`);
      toast("Camera or microphone unavailable", "warn");
    }
  };

  const leave = async () => {
    const s = sess.current;
    if (!s) return;
    clearInterval(s.timer);
    await send(s, "bye").catch(() => undefined);
    s.pc.close();
    s.stream.getTracks().forEach((t) => t.stop());
    sess.current = null;
    setJoined(false);
    setStatus("left");
    setPeerState("—");
  };

  useEffect(() => () => {
    const s = sess.current;
    if (s) {
      clearInterval(s.timer);
      s.pc.close();
      s.stream.getTracks().forEach((t) => t.stop());
    }
  }, []);

  return (
    <div className="flex h-full min-h-0 flex-col p-3" data-testid="meet-app">
      <div className="mb-2 flex items-center gap-2 text-[11px]">
        <input aria-label="Room code" value={room} onChange={(e) => setRoom(e.target.value)} disabled={joined}
          className="rounded border border-white/10 bg-black/30 px-2 py-1 disabled:opacity-40" />
        {!joined ? <Btn small kind="primary" onClick={join}>Join</Btn> : <Btn small kind="danger" onClick={leave}>Leave</Btn>}
        <span data-testid="meet-status" className="text-slate-300">{status}</span>
        <span className="text-slate-500">· peer: <span data-testid="meet-peer">{peerState}</span></span>
      </div>
      <div className="grid min-h-0 flex-1 grid-cols-2 gap-2">
        <Section title="You">
          <video ref={localRef} data-testid="local-video" autoPlay playsInline className="h-full w-full rounded bg-black object-contain" />
        </Section>
        <Section title="Remote">
          <video ref={remoteRef} data-testid="remote-video" autoPlay playsInline className="h-full w-full rounded bg-black object-contain" />
        </Section>
      </div>
      <Note>LN-20: two browsers in the same room negotiate a direct WebRTC connection. Without STUN/TURN, only peers that can reach each other directly (same LAN or same host) connect.</Note>
    </div>
  );
}
