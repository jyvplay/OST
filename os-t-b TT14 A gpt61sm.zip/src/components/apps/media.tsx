"use client";

// CA-01/CA-02/CA-05/CA-08/CA-11, LN-01/04/13/15/23, MD-01/04/06/07.
// PR-07 browser implementation lives in apps/browser.tsx; no duplicate iframe engine here.
import React, { useCallback, useEffect, useRef, useState } from "react";
import { Btn, Note, Section, StateDot, Wall, cls, post, useInterval, useJson, useShell } from "../ui";

/* ───────────── CA Beam ───────────── */
export function BeamApp() {
  const { toast } = useShell();
  const videoRef = useRef<HTMLVideoElement>(null);
  const { data } = useJson<{ targets: { id: number; name: string; protocol: string; trusted: boolean }[]; protocolMatrix: Record<string, string>; impossible: Record<string, string> }>("/api/beam");
  const [remoteAvailable, setRemoteAvailable] = useState<boolean | null>(null);
  const [presentationAvailable, setPresentationAvailable] = useState<boolean | null>(null);
  const [session, setSession] = useState<string | null>(null);

  useEffect(() => {
    const v = videoRef.current as (HTMLVideoElement & { remote?: { watchAvailability?: (cb: (a: boolean) => void) => Promise<number> } }) | null;
    if (v?.remote?.watchAvailability) v.remote.watchAvailability((a) => setRemoteAvailable(a)).catch(() => setRemoteAvailable(null));
    type PR = new (urls: string[]) => { getAvailability: () => Promise<{ value: boolean }> };
    const Ctor = (window as unknown as { PresentationRequest?: PR }).PresentationRequest;
    if (Ctor) new Ctor([`${location.origin}/receiver`]).getAvailability().then((a) => setPresentationAvailable(a.value)).catch(() => setPresentationAvailable(null));
  }, []);

  const startPresentation = async () => {
    type PR = new (urls: string[]) => { start: () => Promise<{ id: string }> };
    const Ctor = (window as unknown as { PresentationRequest?: PR }).PresentationRequest;
    if (!Ctor) return toast("Presentation API unavailable in this browser", "warn");
    try {
      const s = await new Ctor([`${location.origin}/receiver`]).start();
      setSession(s.id);
      await post("/api/beam", { name: "Presentation receiver", protocol: "presentation", trusted: true });
      toast("Presentation session started; the receiver page runs on this origin");
    } catch (e) { toast(`Cast cancelled: ${String(e)}`, "warn"); }
  };

  return (
    <div className="h-full overflow-auto p-3" data-testid="beam-app">
      <Section title="Sources" right={session ? <span className="rounded bg-rose-500/20 px-2 py-0.5 text-[10px] text-rose-200">● casting</span> : null}>
        <video ref={videoRef} controls playsInline className="mb-2 h-40 w-full rounded bg-black" src="/api/sample-media" />
        <div className="flex flex-wrap gap-1">
          <Btn small onClick={() => videoRef.current?.play()}>Play local</Btn>
          <Btn small kind="primary" onClick={() => {
            const remote = (videoRef.current as (HTMLVideoElement & { remote?: { prompt?: () => Promise<void> } }) | null)?.remote;
            if (!remote?.prompt) return toast("Remote Playback unavailable: this browser shows no cast picker for this element", "warn");
            remote.prompt().catch(() => toast("Picker dismissed"));
          }}>Cast (OS picker)</Btn>
          <Btn small onClick={startPresentation}>Present to second screen</Btn>
          <Btn small onClick={() => videoRef.current?.requestPictureInPicture?.().catch(() => toast("PiP refused"))}>PiP</Btn>
        </div>
        <Note>On the web, AirPlay and Cast live in the browser’s own picker. We hand it the element rather than reimplement RAOP or castv2, which a page cannot open sockets for.</Note>
      </Section>
      <Section title="Discovery">
        <ul className="space-y-1 text-[11px]">
          <li className="flex items-center gap-2"><StateDot state={remoteAvailable ? "available" : remoteAvailable === false ? "unavailable" : "impossible"} /> Remote Playback devices: {remoteAvailable === null ? "API absent for this element" : remoteAvailable ? "at least one found" : "none visible"}</li>
          <li className="flex items-center gap-2"><StateDot state={presentationAvailable ? "available" : presentationAvailable === false ? "unavailable" : "impossible"} /> Presentation displays: {presentationAvailable === null ? "API absent" : presentationAvailable ? "available" : "none"}</li>
          {(data?.targets ?? []).map((t) => (
            <li key={t.id} className="flex items-center gap-2"><StateDot state={t.trusted ? "available" : "needs-permission"} /> {t.name} <span className="text-slate-500">({t.protocol})</span></li>
          ))}
        </ul>
      </Section>
      <Section title="Declared walls">
        {Object.entries(data?.impossible ?? {}).map(([k, v]) => <Wall key={k}>{k}: {v}</Wall>)}
      </Section>
    </div>
  );
}

/* ───────────── LN Lens ───────────── */
export function LensApp() {
  const { toast } = useShell();
  const camRef = useRef<HTMLVideoElement | null>(null);
  const screenRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const rafRef = useRef<number>(0);
  const bgRef = useRef<ImageData | null>(null);
  const [fx, setFx] = useState({ key: true, lowlight: 0, presenter: false, mirror: true });
  const [stats, setStats] = useState({ fps: 0, costMs: 0, rung: "full" });
  const [recording, setRecording] = useState(false);
  const recRef = useRef<MediaRecorder | null>(null);
  const fxRef = useRef(fx);
  fxRef.current = fx;

  const start = async (kind: "camera" | "screen") => {
    try {
      const stream = kind === "camera"
        ? await navigator.mediaDevices.getUserMedia({ video: { width: 1280, height: 720 }, audio: false })
        : await navigator.mediaDevices.getDisplayMedia({ video: true });
      const v = document.createElement("video");
      v.srcObject = stream; v.muted = true; v.playsInline = true;
      await v.play();
      if (kind === "camera") camRef.current = v;
      else { screenRef.current = v; setFx((f) => ({ ...f, presenter: true })); }
      toast(`${kind} started. Frames stay on this device.`);
    } catch (e) { toast(`${kind} unavailable: ${String(e)}`, "warn"); }
  };

  const loop = useCallback(() => {
    const cv = canvasRef.current;
    const cam = camRef.current;
    if (!cv) return;
    const ctx = cv.getContext("2d", { willReadFrequently: true });
    if (!ctx) return;
    const f = fxRef.current;
    const t0 = performance.now();
    ctx.clearRect(0, 0, cv.width, cv.height);
    if (f.presenter && screenRef.current) ctx.drawImage(screenRef.current, 0, 0, cv.width, cv.height);
    else { ctx.fillStyle = "#0b1120"; ctx.fillRect(0, 0, cv.width, cv.height); }

    if (cam && cam.videoWidth) {
      const small = f.presenter;
      const w = small ? cv.width * 0.28 : cv.width;
      const h = small ? cv.height * 0.28 : cv.height;
      const x = small ? cv.width - w - 12 : 0;
      const y = small ? cv.height - h - 12 : 0;
      ctx.save();
      if (f.mirror) { ctx.translate(x + w, y); ctx.scale(-1, 1); ctx.translate(-x, -y); }
      ctx.filter = f.lowlight ? `brightness(${1 + f.lowlight / 100}) contrast(${1 + f.lowlight / 200}) saturate(1.1)` : "none";
      ctx.drawImage(cam, x, y, w, h);
      ctx.restore();
      ctx.filter = "none";

      // LN-01 keyer: running background estimate + per-pixel difference. No ML model, no licence exposure.
      if (f.key && !f.presenter && cv.width <= 640) {
        const frame = ctx.getImageData(0, 0, cv.width, cv.height);
        const bg = bgRef.current;
        if (bg && bg.width === frame.width) {
          const d = frame.data, b = bg.data;
          for (let i = 0; i < d.length; i += 4) {
            const diff = Math.abs(d[i] - b[i]) + Math.abs(d[i + 1] - b[i + 1]) + Math.abs(d[i + 2] - b[i + 2]);
            if (diff < 48) d[i + 3] = 40;
            b[i] = b[i] * 0.96 + d[i] * 0.04;
            b[i + 1] = b[i + 1] * 0.96 + d[i + 1] * 0.04;
            b[i + 2] = b[i + 2] * 0.96 + d[i + 2] * 0.04;
          }
          ctx.putImageData(frame, 0, 0);
        } else {
          bgRef.current = ctx.getImageData(0, 0, cv.width, cv.height);
        }
      }
    }
    const cost = performance.now() - t0;
    setStats({
      fps: Math.round(1000 / Math.max(1, cost + 8)),
      costMs: Math.round(cost * 10) / 10,
      rung: cost > 24 ? "effects-off" : cost > 14 ? "reduced" : "full", // LN-15: measured, not assumed
    });
    rafRef.current = requestAnimationFrame(loop);
  }, []);

  useEffect(() => { rafRef.current = requestAnimationFrame(loop); return () => cancelAnimationFrame(rafRef.current); }, [loop]);

  return (
    <div className="flex h-full min-h-0" data-testid="lens-app">
      <div className="flex min-w-0 flex-1 flex-col items-center justify-center bg-black/40 p-2">
        <canvas ref={canvasRef} width={640} height={360} className="w-full max-w-xl rounded border border-white/10" aria-label="Lens composite output" data-testid="lens-canvas" />
        <p className="mt-1 text-[10px] text-slate-400">{stats.fps} fps · {stats.costMs} ms/frame · ladder rung: {stats.rung}</p>
      </div>
      <aside className="w-72 shrink-0 overflow-auto border-l border-white/10 bg-black/20 p-2">
        <Section title="Sources">
          <div className="flex flex-wrap gap-1">
            <Btn small onClick={() => start("camera")}>Camera</Btn>
            <Btn small onClick={() => start("screen")}>Screen (presenter)</Btn>
            <Btn small kind={recording ? "danger" : "primary"} onClick={() => {
              const cv = canvasRef.current;
              if (!cv) return;
              if (recording) { recRef.current?.stop(); setRecording(false); return; }
              const stream = cv.captureStream(30);
              const mime = MediaRecorder.isTypeSupported("video/webm;codecs=vp9") ? "video/webm;codecs=vp9" : "video/webm";
              const rec = new MediaRecorder(stream, { mimeType: mime });
              const chunks: BlobPart[] = [];
              rec.ondataavailable = (e) => chunks.push(e.data);
              rec.onstop = () => {
                const blob = new Blob(chunks, { type: "video/webm" });
                const a = document.createElement("a");
                a.href = URL.createObjectURL(blob);
                a.download = `fusion-lens-${Date.now()}.webm`;
                a.click();
                toast(`Recorded ${Math.round(blob.size / 1024)} KB. Saved by the browser (LN-23).`);
              };
              rec.start();
              recRef.current = rec;
              setRecording(true);
            }}>{recording ? "Stop recording" : "Record"}</Btn>
          </div>
        </Section>
        <Section title="Effects">
          <label className="mb-1 flex items-center gap-2 text-[11px]"><input type="checkbox" checked={fx.key} onChange={(e) => setFx({ ...fx, key: e.target.checked })} /> Background keyer (temporal, model-free)</label>
          <label className="mb-1 flex items-center gap-2 text-[11px]"><input type="checkbox" checked={fx.presenter} onChange={(e) => setFx({ ...fx, presenter: e.target.checked })} /> Presenter mode (person over screen)</label>
          <label className="mb-1 flex items-center gap-2 text-[11px]"><input type="checkbox" checked={fx.mirror} onChange={(e) => setFx({ ...fx, mirror: e.target.checked })} /> Mirror camera</label>
          <label className="mb-1 block text-[11px]">Low-light lift
            <input type="range" min={0} max={80} value={fx.lowlight} onChange={(e) => setFx({ ...fx, lowlight: Number(e.target.value) })} className="w-full" />
          </label>
        </Section>
        <Section title="Where this output can go">
          <ul className="space-y-1 text-[11px]">
            <li className="flex items-center gap-2"><StateDot state="available" /> Record to a file (LN-23)</li>
            <li className="flex items-center gap-2"><StateDot state="partial" /> Fusion Meet: camera only, Lens not piped in yet (LN-20)</li>
            <li className="flex items-center gap-2"><StateDot state="impossible" /> Other sites’ video calls (LN-21)</li>
            <li className="flex items-center gap-2"><StateDot state="impossible" /> Native apps as a webcam (LN-22)</li>
          </ul>
          <Wall>A web page cannot register a camera for other origins or native applications. That is the web analogue of Android’s system-only VirtualDeviceManager. The honest routes stay; the fake one is removed.</Wall>
        </Section>
      </aside>
    </div>
  );
}

/* ───────────── CA-11 Together ───────────── */
export function TogetherApp() {
  const [code, setCode] = useState("fusion");
  const [room, setRoom] = useState<{ playing: boolean; projectedMs: number; title: string } | null>(null);
  const [drift, setDrift] = useState<number | null>(null);
  const vRef = useRef<HTMLVideoElement>(null);

  useInterval(async () => {
    const r = await fetch(`/api/together?code=${encodeURIComponent(code)}`).then((x) => x.json());
    setRoom(r.room);
    const v = vRef.current;
    if (r.room && v && !v.paused) {
      const target = r.room.projectedMs / 1000;
      const d = (v.currentTime - target) * 1000;
      setDrift(Math.round(d));
      if (Math.abs(d) > 400) v.currentTime = target;
      else v.playbackRate = Math.min(1.05, Math.max(0.95, 1 - d / 4000));
    }
  }, 1000);

  const push = async (playing: boolean) => {
    await fetch("/api/together", {
      method: "PUT", headers: { "content-type": "application/json" },
      body: JSON.stringify({ code, playing, positionMs: Math.round((vRef.current?.currentTime ?? 0) * 1000), title: "local copy" }),
    });
  };

  return (
    <div className="h-full overflow-auto p-3" data-testid="together-app">
      <Section title="Room">
        <div className="flex items-center gap-2">
          <input value={code} onChange={(e) => setCode(e.target.value)} aria-label="Room code" className="rounded border border-white/10 bg-black/30 px-2 py-1 text-[11px]" />
          <Btn small onClick={() => push(true)}>Play for everyone</Btn>
          <Btn small onClick={() => push(false)}>Pause for everyone</Btn>
        </div>
        <p className="mt-2 text-[11px] text-slate-400">
          {room ? `${room.playing ? "playing" : "paused"} at ${(room.projectedMs / 1000).toFixed(1)} s` : "room not created yet"}
          {drift !== null && ` · your drift ${drift} ms (${Math.abs(drift) > 400 ? "hard seek" : "rate-nudged"})`}
        </p>
      </Section>
      <Section title="Your own copy of the media">
        <video ref={vRef} controls className="h-48 w-full rounded bg-black" onPlay={() => push(true)} onPause={() => push(false)} />
        <input type="file" accept="video/*,audio/*" aria-label="Pick local media"
          onChange={(e) => { const f = e.target.files?.[0]; if (f && vRef.current) vRef.current.src = URL.createObjectURL(f); }}
          className="mt-2 text-[11px]" />
        <Note>The server stores only a clock and a play/pause intent. Media is never uploaded or relayed.</Note>
      </Section>
    </div>
  );
}

/* ───────────── MD-01 / MD-04 / MD-06 / MD-07 Capture ───────────── */
export function CaptureApp() {
  const { toast } = useShell();
  const [shots, setShots] = useState<string[]>([]);
  const [recState, setRecState] = useState<"idle" | "recording" | "stopped">("idle");
  const [level, setLevel] = useState(0);
  const [clipUrl, setClipUrl] = useState<string | null>(null);
  const [devices, setDevices] = useState<string[]>([]);
  const [picked, setPicked] = useState<string | null>(null);
  const mrRef = useRef<MediaRecorder | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const ctxRef = useRef<AudioContext | null>(null);
  const rafRef = useRef(0);

  const listDevices = useCallback(async () => {
    if (!navigator.mediaDevices?.enumerateDevices) return;
    const all = await navigator.mediaDevices.enumerateDevices();
    setDevices(all.filter((d) => d.kind === "audiooutput").map((d) => d.label || `output ${d.deviceId.slice(0, 6)}`));
  }, []);
  useEffect(() => { void listDevices(); }, [listDevices]);

  const stopRec = () => {
    mrRef.current?.stop();
    cancelAnimationFrame(rafRef.current);
    streamRef.current?.getTracks().forEach((t) => t.stop());
    void ctxRef.current?.close();
    setLevel(0);
  };
  useEffect(() => () => stopRec(), []); // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <div className="h-full overflow-auto p-3" data-testid="capture-app">
      <Section title="Screen capture (MD-01)">
        <Btn small kind="primary" onClick={async () => {
          try {
            const stream = await navigator.mediaDevices.getDisplayMedia({ video: true });
            const track = stream.getVideoTracks()[0];
            const v = document.createElement("video");
            v.srcObject = stream;
            await v.play();
            await new Promise((r) => setTimeout(r, 180));
            const c = document.createElement("canvas");
            c.width = v.videoWidth;
            c.height = v.videoHeight;
            c.getContext("2d")!.drawImage(v, 0, 0);
            track.stop();
            setShots([c.toDataURL("image/png"), ...shots].slice(0, 6));
            toast("Captured");
          } catch { toast("Capture cancelled", "warn"); }
        }}>Take screenshot</Btn>
        <div className="mt-2 grid grid-cols-3 gap-2">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          {shots.map((s, i) => <img key={i} src={s} alt={`capture ${i + 1}`} className="rounded border border-white/10" />)}
        </div>
        <Note>Annotate, blur and redact are not built. The screenshot is kept in memory only.</Note>
      </Section>

      <Section title="Voice recorder (MD-04)">
        <div className="flex items-center gap-2">
          <Btn small kind={recState === "recording" ? "danger" : "primary"} onClick={async () => {
            if (recState === "recording") { stopRec(); setRecState("stopped"); return; }
            try {
              const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
              streamRef.current = stream;
              const ctx = new AudioContext();
              ctxRef.current = ctx;
              const analyser = ctx.createAnalyser();
              ctx.createMediaStreamSource(stream).connect(analyser);
              const buf = new Uint8Array(analyser.fftSize);
              const meter = () => {
                analyser.getByteTimeDomainData(buf);
                let peak = 0;
                for (const v of buf) peak = Math.max(peak, Math.abs(v - 128));
                setLevel(peak / 128);
                rafRef.current = requestAnimationFrame(meter);
              };
              meter();
              const mr = new MediaRecorder(stream);
              const chunks: BlobPart[] = [];
              mr.ondataavailable = (e) => chunks.push(e.data);
              mr.onstop = () => {
                const blob = new Blob(chunks, { type: mr.mimeType || "audio/webm" });
                setClipUrl(URL.createObjectURL(blob));
              };
              mr.start();
              mrRef.current = mr;
              setRecState("recording");
            } catch (e) {
              toast(`Microphone unavailable: ${String(e)}`, "warn");
            }
          }}>{recState === "recording" ? "Stop" : "Record voice"}</Btn>
          <span data-testid="capture-state" className="text-[11px] text-slate-300">{recState}</span>
          <div className="h-2 w-40 overflow-hidden rounded bg-white/10" aria-label="input level" role="meter" aria-valuenow={Math.round(level * 100)} aria-valuemin={0} aria-valuemax={100}>
            <div className="h-full bg-[var(--accent)]" style={{ width: `${Math.round(level * 100)}%` }} />
          </div>
        </div>
        {clipUrl && <audio controls src={clipUrl} data-testid="voice-clip" className="mt-2 w-full" />}
        <Note>Recorded in memory until you save. Nothing is uploaded.</Note>
      </Section>

      <Section title="Audio output devices (MD-06)" right={<Btn small onClick={() => void listDevices()}>Refresh</Btn>}>
        <ul className="text-[11px]" data-testid="audio-devices">
          {devices.length === 0 && <li className="text-slate-500">No output devices listed (labels appear after a permission grant).</li>}
          {devices.map((d) => <li key={d}>{d}</li>)}
        </ul>
        <p className="mt-1 text-[11px]">Routing: {"setSinkId" in HTMLMediaElement.prototype ? `available (${picked ?? "default"})` : "not available in this browser"}</p>
      </Section>

      <Section title="Colour picker (MD-07)">
        <Btn small onClick={async () => {
          type ED = new () => { open: () => Promise<{ sRGBHex: string }> };
          const Ctor = (window as unknown as { EyeDropper?: ED }).EyeDropper;
          if (!Ctor) return toast("EyeDropper is not available in this browser", "warn");
          try { const r = await new Ctor().open(); setPicked(r.sRGBHex); } catch { toast("Picker cancelled"); }
        }}>Pick a colour</Btn>
        {picked && <span className="ml-2 inline-flex items-center gap-1 text-[11px]"><span className="inline-block h-4 w-4 rounded border border-white/20" style={{ background: picked }} />{picked}</span>}
      </Section>
    </div>
  );
}
