"use client";

import React, { useCallback, useEffect, useMemo, useReducer, useRef, useState } from "react";
import { MIN_SIZE, SHELL_TOP, initialState, normalize, reduce, tileRect, type Density, type DesktopState, type TileZone, type WindowCommand, type WindowState } from "@/lib/windowEngine";
import { runProbe, type Probe } from "@/lib/capabilities";
import { applyAppearance } from "@/lib/prefs";
import { bindingCombo, matchCombo, type Preset } from "@/lib/shortcuts";
import { describeAction, intervalDue, matchesEvent, planFor, type Action, type Routine, type RoutineEvent } from "@/lib/routines";
import { Btn, Shell, StateDot, cls, post, type GovernorState, type ShellApi } from "./ui";
import { EditorApp, FilesApp, FindApp, ForgeApp, TerminalApp, TrashApp } from "./apps/files";
import { BeamApp, CaptureApp, LensApp, TogetherApp } from "./apps/media";
import { BrowserApp } from "./apps/browser";
import { LedgerApp } from "./apps/ledger";
import { ClipboardApp, ContactsApp, HandlersApp, MailApp } from "./apps/integration";
import { OfficeApp } from "./apps/office";
import { ImageApp, VectorApp } from "./apps/studio";
import { LayersApp } from "./apps/layers";
import { AboutApp, AlertsApp, BackupApp, CalculatorApp, CapabilitiesApp, MessagesApp, MonitorApp, NotesApp, RegistryApp, SettingsApp, VaultApp, VerifyApp, evaluate } from "./apps/misc";
import { CalendarApp, PresetsApp, PrivacyApp, RoutinesApp, TasksApp, TouchpadApp, checkDueTasks, kvGet, kvPut, useKvWatch } from "./apps/productivity";
import { MeetApp } from "./apps/meet";
import { BridgeApp } from "./apps/bridge";
import { PhotosApp } from "./apps/photos";
import { Widgets } from "./Widgets";

// SH-01/02/03/04/05/06/08/09/11/12 shell; WM-01/02/03/04/05/09/10/11 compositor;
// SR-01 palette; NC-02 do-not-disturb; ST-05/06/07/09 preferences; AU-01 routines.
type AppDef = { id: string; name: string; icon: string; render: (w: WindowState) => React.ReactNode; rect?: { w: number; h: number } };
const APPS: AppDef[] = [
  { id: "files", name: "Files", icon: "🗂", render: () => <FilesApp />, rect: { w: 980, h: 600 } },
  { id: "trash", name: "Trash", icon: "🗑", render: () => <TrashApp /> },
  { id: "editor", name: "Editor", icon: "📝", render: w => <EditorApp docId={w.docId} /> },
  { id: "find", name: "Find", icon: "🔍", render: () => <FindApp /> },
  { id: "terminal", name: "Terminal", icon: "▶", render: () => <TerminalApp />, rect: { w: 760, h: 420 } },
  { id: "notes", name: "Notes", icon: "🗒", render: () => <NotesApp /> },
  { id: "tasks", name: "Tasks & timers", icon: "✔", render: () => <TasksApp />, rect: { w: 620, h: 460 } },
  { id: "calendar", name: "Calendar", icon: "📅", render: () => <CalendarApp /> },
  { id: "routines", name: "Routines", icon: "🔁", render: () => <RoutinesApp />, rect: { w: 720, h: 560 } },
  { id: "presets", name: "Presets", icon: "🗺", render: () => <PresetsApp /> },
  { id: "touchpad", name: "Touchpad", icon: "🖲", render: () => <TouchpadApp />, rect: { w: 360, h: 300 } },
  { id: "browser", name: "Browser", icon: "🌐", render: w => <BrowserApp windowId={w.id} />, rect: { w: 1040, h: 660 } },
  { id: "ledger", name: "Build ledger", icon: "📊", render: () => <LedgerApp />, rect: { w: 1060, h: 650 } },
  { id: "forge", name: "Forge", icon: "⚙", render: () => <ForgeApp /> },
  { id: "office", name: "Office", icon: "🗎", render: () => <OfficeApp />, rect: { w: 980, h: 640 } },
  { id: "image", name: "Image editor", icon: "🖼", render: () => <ImageApp />, rect: { w: 900, h: 620 } },
  { id: "layers", name: "Layers", icon: "▱", render: () => <LayersApp />, rect: { w: 1000, h: 660 } },
  { id: "vector", name: "Vector", icon: "✒", render: () => <VectorApp />, rect: { w: 940, h: 600 } },
  { id: "beam", name: "Beam", icon: "📡", render: () => <BeamApp /> },
  { id: "lens", name: "Lens", icon: "🎥", render: () => <LensApp />, rect: { w: 980, h: 560 } },
  { id: "meet", name: "Meet", icon: "👥", render: () => <MeetApp />, rect: { w: 940, h: 560 } },
  { id: "bridge", name: "Bridge", icon: "🔗", render: () => <BridgeApp />, rect: { w: 760, h: 560 } },
  { id: "photos", name: "Photos", icon: "🖼", render: () => <PhotosApp />, rect: { w: 980, h: 620 } },
  { id: "capture", name: "Capture", icon: "📸", render: () => <CaptureApp /> },
  { id: "together", name: "Together", icon: "🎬", render: () => <TogetherApp /> },
  { id: "alerts", name: "Alerts", icon: "🔔", render: () => <AlertsApp /> },
  { id: "calc", name: "Calculator", icon: "🧮", render: () => <CalculatorApp />, rect: { w: 420, h: 320 } },
  { id: "vault", name: "Vault", icon: "🔐", render: () => <VaultApp /> },
  { id: "privacy", name: "Privacy", icon: "🛡", render: () => <PrivacyApp /> },
  { id: "backup", name: "Backup", icon: "💾", render: () => <BackupApp /> },
  { id: "messages", name: "Messages", icon: "💬", render: () => <MessagesApp /> },
  { id: "contacts", name: "Contacts", icon: "👤", render: () => <ContactsApp /> },
  { id: "clipboard", name: "Clipboard", icon: "📋", render: () => <ClipboardApp /> },
  { id: "mail", name: "Mail handoff", icon: "✉️", render: () => <MailApp /> },
  { id: "handlers", name: "Handlers", icon: "🔗", render: () => <HandlersApp /> },
  { id: "monitor", name: "Monitor", icon: "📈", render: () => <MonitorApp /> },
  { id: "capabilities", name: "Capabilities", icon: "🧪", render: () => <CapabilitiesApp /> },
  { id: "verify", name: "Verify", icon: "✅", render: () => <VerifyApp /> },
  { id: "registry", name: "Feature register", icon: "📋", render: () => <RegistryApp />, rect: { w: 1080, h: 640 } },
  { id: "settings", name: "Settings", icon: "⚙️", render: () => <SettingsApp /> },
  { id: "about", name: "About", icon: "ℹ️", render: () => <AboutApp /> },
];
const appOf = (id: string) => APPS.find(a => a.id === id);
const rectStyle = (r: { x: number; y: number; w: number; h: number }) => ({ left: r.x, top: r.y, width: r.w, height: r.h });

export default function Desktop() {
  const [state, rawDispatch] = useReducer(reduce, undefined, () => initialState());
  const [probe, setProbe] = useState<Probe | null>(null);
  const [settings, setSettings] = useState<Record<string, unknown>>({});
  const [locked, setLocked] = useState<Record<string, unknown>>({});
  const [launcher, setLauncher] = useState(false);
  const [palette, setPalette] = useState(false);
  const [overview, setOverview] = useState(false);
  const [quick, setQuick] = useState(false);
  const [focusMode, setFocusMode] = useState(false);
  const [heldCount, setHeldCount] = useState(0);
  const [widgetIds, setWidgetIdsState] = useState<string[]>(["clock", "governor"]);
  const [entitlement, setEntitlement] = useState<ShellApi["entitlement"]>(null);
  const [governor, setGovernor] = useState({ state: "COOL" as GovernorState, evidence: "measuring…", frameMs: 0 });
  const [bgPaused, setBgPaused] = useState(false);
  const [pauseReason, setPauseReason] = useState("");
  const [profileBanner, setProfileBanner] = useState<{ to: string; prev: string } | null>(null);
  const [toasts, setToasts] = useState<{ id: number; msg: string; kind: string }[]>([]);
  const [snapHint, setSnapHint] = useState<TileZone | null>(null);
  const [routines, setRoutines] = useState<Routine[]>([]);
  const hydrated = useRef(false);
  const stateRef = useRef(state); stateRef.current = state;
  const settingsRef = useRef(settings); settingsRef.current = settings;
  const routinesRef = useRef(routines); routinesRef.current = routines;
  const bgRef = useRef(bgPaused); bgRef.current = bgPaused;
  const openRef = useRef<(module: string, title?: string, docId?: string) => void>(() => {});
  const lastIntervals = useRef<Record<string, number>>({});
  const lastWidth = useRef<number | null>(null);
  const hotTimer = useRef<number | null>(null);
  const hotCorner = useRef<string | null>(null);
  const live = useRef<HTMLDivElement>(null);
  const dispatch = useCallback((c: WindowCommand) => rawDispatch(c), []);
  const announce = useCallback((message: string) => { if (live.current) live.current.textContent = message; }, []);
  const toast = useCallback((msg: string, kind: "info" | "warn" | "error" = "info") => {
    if (settingsRef.current["focus.dnd"]) {
      setHeldCount(n => n + 1);
      void post("/api/alerts", { app: "Held (DND)", title: msg, priority: kind });
      return;
    }
    const id = Date.now() + Math.random();
    setToasts(prev => [...prev, { id, msg, kind }]);
    setTimeout(() => setToasts(prev => prev.filter(t => t.id !== id)), 5200);
  }, []);
  const setSetting = useCallback(async (key: string, value: unknown) => {
    const result = await post<{ settings?: Record<string, unknown>; error?: string }>("/api/settings", { key, value }, "PATCH");
    if (result.settings) setSettings(result.settings);
    else toast(result.error ?? "Setting refused", "warn");
  }, [toast]);
  const setDnd = useCallback((on: boolean) => { void setSetting("focus.dnd", on); }, [setSetting]);
  const runRoutine = useCallback((r: Routine, source: string) => {
    void post("/api/audit", { action: r.mode === "dry-run" ? "routine.dry-run" : "routine.run", detail: { routine: r.id, name: r.name, source, step: describeAction(r.action) } });
    if (r.mode === "dry-run") { toast(`[dry-run] ${planFor(r)}`); return; }
    const a: Action = r.action;
    if (a.type === "notify") toast(a.text);
    if (a.type === "note") { void post("/api/notes", { title: a.title, body: a.body }); toast(`Note created: ${a.title}`); }
    if (a.type === "tile" && stateRef.current.focus) dispatch({ t: "tile", id: stateRef.current.focus, zone: a.zone });
    if (a.type === "focusMode") setFocusMode(a.on);
    if (a.type === "open") openRef.current(a.module);
  }, [dispatch, toast]);
  const fireRoutines = useCallback((ev: RoutineEvent) => {
    for (const r of routinesRef.current) if (matchesEvent(r, ev)) runRoutine(r, ev.type);
  }, [runRoutine]);
  const open = useCallback((module: string, title?: string, docId?: string) => {
    const def = appOf(module);
    dispatch({ t: "open", module, title: title ?? def?.name ?? module, docId, rect: def?.rect });
    setLauncher(false); setPalette(false); setOverview(false); setQuick(false);
    fireRoutines({ type: "app-open", module });
  }, [dispatch, fireRoutines]);
  openRef.current = open;
  const refreshEntitlement = useCallback(() => { fetch("/api/entitlement").then(r => r.json()).then(setEntitlement); }, []);
  const reloadRoutines = useCallback(() => { void kvGet<Routine[]>("app.routines", []).then(setRoutines); }, []);
  useKvWatch("app.routines", reloadRoutines);
  useKvWatch("app.widgets", () => { void kvGet<string[]>("app.widgets", ["clock", "governor"]).then(setWidgetIdsState); });

  // SH-08 session restore (server state is canonical; viewport is clamped on hydration).
  useEffect(() => {
    runProbe().then(setProbe);
    fetch("/api/settings").then(r => r.json()).then((j: { settings: Record<string, unknown>; locked: Record<string, unknown> }) => { setSettings(j.settings); setLocked(j.locked ?? {}); });
    refreshEntitlement(); void reloadRoutines();
    void kvGet<string[]>("app.widgets", ["clock", "governor"]).then(setWidgetIdsState);
    const sp = new URLSearchParams(location.search);
    const wantOpen = sp.get("open"), shareTitle = sp.get("title"), shareText = sp.get("text"), shareUrl = sp.get("url");
    if (location.search) history.replaceState(null, "", "/");
    fetch("/api/state").then(r => r.json()).then((j: { state: DesktopState | null }) => {
      const viewport = { w: innerWidth, h: innerHeight };
      if (j.state?.windows.length) dispatch({ t: "hydrate", state: normalize({ ...j.state, viewport }) });
      else { dispatch({ t: "viewport", ...viewport }); dispatch({ t: "open", module: "files", title: "Files", rect: appOf("files")?.rect }); dispatch({ t: "open", module: "ledger", title: "Build ledger", rect: appOf("ledger")?.rect }); }
      hydrated.current = true;
      if (shareTitle || shareText || shareUrl) void post("/api/notes", { title: `Shared: ${shareTitle || shareUrl || "text"}`, body: [shareText, shareUrl].filter(Boolean).join("\n\n") }).then(() => openRef.current("notes"));
      else if (wantOpen && appOf(wantOpen)) openRef.current(wantOpen);
    });
    // FM-10 share/file handlers work only for supported installed PWA text files; binary is not silently garbled.
    type LQ = { setConsumer: (fn: (p: { files: FileSystemFileHandle[] }) => Promise<void>) => void };
    (window as unknown as { launchQueue?: LQ }).launchQueue?.setConsumer(async params => {
      for (const h of params.files) {
        const f = await h.getFile();
        if (f.size > 2_000_000 || !(f.type.startsWith("text/") || /\.(txt|md|csv|json)$/i.test(f.name))) { toast(`Cannot import ${f.name}: text up to 2 MB only`, "warn"); continue; }
        const dir = await post<{ node: { id: number } }>("/api/fs", { op: "ensureDir", path: "/Home/Inbox" });
        const r = await post<{ node: { id: number } }>("/api/fs", { op: "create", parentId: dir.node.id, name: f.name, kind: "file", mime: f.type || "text/plain", content: await f.text() });
        openRef.current("editor", f.name, String(r.node.id));
      }
    });
    if ("serviceWorker" in navigator) navigator.serviceWorker.register("/sw.js").catch(() => {});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [dispatch]);
  useEffect(() => { if (!hydrated.current) return; const id = setTimeout(() => { void post("/api/state", { state }, "PUT"); }, 500); return () => clearTimeout(id); }, [state]);
  useEffect(() => { applyAppearance(settings); if (Object.keys(settings).length) dispatch({ t: "density", density: String(settings["appearance.density"] ?? "balanced") as Density }); }, [settings, dispatch]);
  // ST-09 display profile switch is a *viewport heuristic*, not hardware detection.
  useEffect(() => {
    const resize = () => {
      const width = innerWidth;
      dispatch({ t: "viewport", w: width, h: innerHeight });
      if (lastWidth.current !== null && (lastWidth.current >= 1600) !== (width >= 1600) && settingsRef.current["profiles.auto"] !== false) {
        const prev = String(settingsRef.current["appearance.density"] ?? "balanced");
        setProfileBanner({ to: width >= 1600 ? "desk" : "laptop", prev });
        void setSetting("appearance.density", width >= 1600 ? "compact" : "balanced");
        fireRoutines({ type: "display-change" });
      }
      lastWidth.current = width;
    };
    resize(); addEventListener("resize", resize); return () => removeEventListener("resize", resize);
  }, [dispatch, fireRoutines, setSetting]);
  // RG-01 measured frame time; not a temperature measurement.
  useEffect(() => {
    let n = 0, slow = 0, sum = 0, last = performance.now(), id = 0;
    const tick = (t: number) => {
      const dt = t - last; last = t; n++; sum += dt; if (dt > 50) slow++;
      if (n >= 60) {
        const avg = sum / n;
        const grade: GovernorState = avg > 48 ? "CRITICAL" : avg > 32 ? "THROTTLED" : avg > 20 ? "HOT" : avg > 13 ? "WARM" : "COOL";
        setGovernor({ state: grade, frameMs: avg, evidence: `mean frame ${avg.toFixed(1)} ms over 60 frames, ${slow} frames >50 ms, ${document.hidden ? "tab hidden" : "tab visible"}` });
        n = 0; slow = 0; sum = 0;
      }
      id = requestAnimationFrame(tick);
    };
    id = requestAnimationFrame(tick); return () => cancelAnimationFrame(id);
  }, []);
  useEffect(() => {
    const check = async () => {
      const n = navigator as Navigator & { getBattery?: () => Promise<{ level: number; charging: boolean }>; connection?: { saveData?: boolean } };
      let why = n.connection?.saveData ? "Data saver is on" : "";
      try { const b = await n.getBattery?.(); if (b && !b.charging && b.level < 0.2) why = `Battery ${Math.round(b.level * 100)}% and not charging`; } catch { /* no Battery API */ }
      setBgPaused(!!why); setPauseReason(why);
    };
    void check(); const id = setInterval(check, 30_000); return () => clearInterval(id);
  }, []);
  useEffect(() => {
    const id = setInterval(() => {
      const now = Date.now();
      for (const r of routinesRef.current) {
        if (!r.enabled || r.trigger.type !== "interval") continue;
        if (lastIntervals.current[r.id] === undefined) { lastIntervals.current[r.id] = now; continue; }
        if (!bgRef.current && intervalDue(r, now, lastIntervals.current[r.id])) { lastIntervals.current[r.id] = now; runRoutine(r, "interval"); }
      }
    }, 1000); return () => clearInterval(id);
  }, [runRoutine]);
  useEffect(() => {
    const id = setInterval(async () => {
      const due = await checkDueTasks();
      for (const t of due) { toast(`⏰ ${t.title}`, "warn"); if (typeof Notification !== "undefined" && Notification.permission === "granted") new Notification("Fusion Shell", { body: t.title }); }
    }, 2000); return () => clearInterval(id);
  }, [toast]);
  // ST-06 only shortcuts the browser reliably sends are bound. Workspace shortcuts use Alt+1..9.
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement | null;
      const typing = !!target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA" || target.isContentEditable);
      const preset = String(settingsRef.current["shell.shortcutPreset"] ?? "hybrid") as Preset;
      const is = (action: string) => matchCombo(e, bindingCombo(preset, action));
      if (e.key === "Escape") { setPalette(false); setLauncher(false); setOverview(false); setQuick(false); return; }
      if (is("palette")) { e.preventDefault(); setPalette(p => !p); return; }
      if (typing && !e.ctrlKey && !e.metaKey) return;
      if (is("overview")) { e.preventDefault(); setOverview(p => !p); return; }
      if (is("focus")) { e.preventDefault(); setFocusMode(p => !p); return; }
      if (e.altKey && !e.ctrlKey && !e.metaKey && /^[1-9]$/.test(e.key)) { e.preventDefault(); dispatch({ t: "switchWorkspace", workspace: Number(e.key) }); return; }
      if (is("cycle")) { e.preventDefault(); dispatch({ t: "cycle", dir: e.shiftKey ? -1 : 1 }); return; }
      const id = stateRef.current.focus;
      if (!id) return;
      if (is("close")) { e.preventDefault(); dispatch({ t: "close", id }); return; }
      const tiles: [string, TileZone][] = [["tileLeft", "left"], ["tileRight", "right"], ["tileFull", "full"], ["tileCenter", "center"]];
      for (const [key, zone] of tiles) if (is(key)) { e.preventDefault(); dispatch({ t: "tile", id, zone }); announce(`Window tiled ${zone}`); return; }
      if (e.ctrlKey && e.altKey && e.key.startsWith("Arrow")) {
        e.preventDefault(); const w = stateRef.current.windows.find(x => x.id === id); if (!w) return;
        const step = e.shiftKey ? 50 : 10;
        const delta: Record<string, [number, number]> = { ArrowLeft: [-step, 0], ArrowRight: [step, 0], ArrowUp: [0, -step], ArrowDown: [0, step] };
        const [dx, dy] = delta[e.key]; dispatch({ t: "move", id, x: w.rect.x + dx, y: w.rect.y + dy });
        announce(`Window moved to ${w.rect.x + dx}, ${w.rect.y + dy}`);
      }
    };
    addEventListener("keydown", onKey); return () => removeEventListener("keydown", onKey);
  }, [dispatch, announce]);
  const snapshot = useCallback(() => stateRef.current, []);
  const loadState = useCallback((s: DesktopState) => dispatch({ t: "hydrate", state: normalize({ ...s, viewport: stateRef.current.viewport }) }), [dispatch]);
  const persistWidgetIds = useCallback((ids: string[]) => { setWidgetIdsState(ids); void kvPut("app.widgets", ids); }, []);
  const api: ShellApi = useMemo(() => ({
    state, dispatch, open, close: id => dispatch({ t: "close", id }), probe, settings, setSetting, toast, governor,
    entitlement, refreshEntitlement, locked, focusMode, setFocusMode, dnd: settings["focus.dnd"] === true, setDnd,
    heldCount, bgPaused, pauseReason, snapshot, loadState, runRoutine, widgetIds, setWidgetIds: persistWidgetIds,
  }), [state, dispatch, open, probe, settings, setSetting, toast, governor, entitlement, refreshEntitlement, locked, focusMode, setDnd, heldCount, bgPaused, pauseReason, snapshot, loadState, runRoutine, widgetIds, persistWidgetIds]);
  const dnd = settings["focus.dnd"] === true;
  return (
    <Shell.Provider value={api}>
      <div className="relative h-dvh w-full overflow-hidden bg-[radial-gradient(120%_120%_at_20%_-10%,#1e293b_0%,#0b1120_55%,#060910_100%)] text-slate-100 select-none"
        onContextMenu={e => { if ((e.target as HTMLElement).closest(".fusion-window-content")) return; e.preventDefault(); setLauncher(true); }}
        onPointerDown={e => { if (e.button === 3 || e.button === 4) { e.preventDefault(); window.dispatchEvent(new CustomEvent("fusion:nav", { detail: { dir: e.button === 3 ? -1 : 1 } })); } }}
        onPointerMove={e => {
          if (settingsRef.current["shell.hotCorners"] === false) return;
          const m = 4, w = innerWidth, h = innerHeight;
          const corner = e.clientX <= m && e.clientY <= m ? "tl" : e.clientX >= w - m && e.clientY <= m ? "tr" : e.clientX <= m && e.clientY >= h - m ? "bl" : e.clientX >= w - m && e.clientY >= h - m ? "br" : null;
          if (corner === hotCorner.current) return;
          hotCorner.current = corner;
          if (hotTimer.current !== null) clearTimeout(hotTimer.current);
          if (corner) hotTimer.current = window.setTimeout(() => setOverview(true), 350);
        }}>
        <TopBar state={state} governor={governor} entitlement={entitlement} dnd={dnd} heldCount={heldCount} focusMode={focusMode}
          onLauncher={() => setLauncher(v => !v)} onOverview={() => setOverview(v => !v)} onQuick={() => setQuick(v => !v)} onLedger={() => open("ledger")} />
        <div className="absolute left-3 top-12 flex w-24 flex-col gap-2">
          {["files", "browser", "ledger", "terminal", "meet"].map(id => {
            const a = appOf(id)!;
            return <button key={id} onDoubleClick={() => open(id)} className="flex flex-col items-center gap-1 rounded p-1 text-[10px] text-slate-300 hover:bg-white/10 focus-visible:outline focus-visible:outline-1 focus-visible:outline-[var(--accent)]"><span className="text-2xl" aria-hidden>{a.icon}</span>{a.name}</button>;
          })}
        </div>
        {!!widgetIds.length && <Widgets ids={widgetIds} governor={governor} />}
        {state.windows.filter(w => w.workspace === state.workspace).map(w => <Window key={w.id} w={w} state={state} dispatch={dispatch} onSnapHint={setSnapHint} announce={announce} dim={focusMode && w.id !== state.focus} />)}
        {snapHint && <div className="pointer-events-none absolute rounded border-2 border-[var(--accent)] bg-[var(--accent)]/10" style={rectStyle(tileRect(state, snapHint))} />}
        {profileBanner && <div data-testid="profile-banner" className="absolute bottom-16 left-3 z-[9800] flex items-center gap-2 rounded border border-white/15 bg-slate-900/95 p-2 text-[11px]">Switched to the {profileBanner.to} profile.
          <Btn small onClick={() => { void setSetting("appearance.density", profileBanner.prev); setProfileBanner(null); }}>Revert</Btn><Btn small kind="flat" onClick={() => setProfileBanner(null)}>Dismiss</Btn>
        </div>}
        <Shelf state={state} dispatch={dispatch} onLauncher={() => setLauncher(v => !v)} />
        {launcher && <Launcher onPick={open} onClose={() => setLauncher(false)} />}
        {palette && <Palette state={state} open={open} dispatch={dispatch} toast={toast} onClose={() => setPalette(false)} focusMode={focusMode} setFocusMode={setFocusMode} dnd={dnd} setDnd={setDnd} />}
        {overview && <Overview state={state} dispatch={dispatch} onClose={() => setOverview(false)} />}
        {quick && <QuickPanel governor={governor} probe={probe} open={open} dnd={dnd} setDnd={setDnd} focusMode={focusMode} setFocusMode={setFocusMode} widgetIds={widgetIds} setWidgetIds={persistWidgetIds} bgPaused={bgPaused} pauseReason={pauseReason} onClose={() => setQuick(false)} />}
        <div className="pointer-events-none absolute bottom-16 right-3 z-[9999] flex w-80 flex-col gap-2">{toasts.map(t => <div key={t.id} data-testid="toast" className={cls("pointer-events-auto rounded border p-2 text-[11px] shadow-lg backdrop-blur", t.kind === "error" ? "border-rose-500/40 bg-rose-950/80" : t.kind === "warn" ? "border-amber-500/40 bg-amber-950/80" : "border-white/15 bg-slate-900/90")}>{t.msg}</div>)}</div>
        <div ref={live} aria-live="polite" className="sr-only" />
      </div>
    </Shell.Provider>
  );
}

function Window({ w, state, dispatch, onSnapHint, announce, dim }: {
  w: WindowState; state: DesktopState; dispatch: (c: WindowCommand) => void; onSnapHint: (z: TileZone | null) => void; announce: (s: string) => void; dim: boolean;
}) {
  const element = useRef<HTMLElement>(null);
  const drag = useRef<{ dx: number; dy: number; mode: "move" | "resize" } | null>(null);
  const move = (e: PointerEvent) => {
    const d = drag.current, el = element.current; if (!d || !el) return;
    if (d.mode === "move") {
      el.style.left = `${e.clientX - d.dx}px`; el.style.top = `${Math.max(SHELL_TOP, e.clientY - d.dy)}px`;
      onSnapHint(e.clientX < 24 ? "left" : e.clientX > innerWidth - 24 ? "right" : e.clientY < SHELL_TOP + 8 ? "full" : null);
    } else {
      const min = MIN_SIZE[state.density]; el.style.width = `${Math.max(min.w, e.clientX - w.rect.x)}px`; el.style.height = `${Math.max(min.h, e.clientY - w.rect.y)}px`;
    }
  };
  const end = (e: PointerEvent) => {
    const d = drag.current, el = element.current; drag.current = null;
    removeEventListener("pointermove", move); removeEventListener("pointerup", end);
    if (!d || !el) return;
    const zone = e.clientX < 24 ? "left" : e.clientX > innerWidth - 24 ? "right" : e.clientY < SHELL_TOP + 8 ? "full" : null;
    onSnapHint(null);
    if (d.mode === "move") { if (zone) { dispatch({ t: "tile", id: w.id, zone }); announce(`Window snapped ${zone}`); } else dispatch({ t: "move", id: w.id, x: parseInt(el.style.left), y: parseInt(el.style.top) }); }
    else dispatch({ t: "resize", id: w.id, w: parseInt(el.style.width), h: parseInt(el.style.height) });
  };
  const begin = (e: React.PointerEvent, mode: "move" | "resize") => {
    if (e.button !== 0) return;
    dispatch({ t: "focus", id: w.id }); drag.current = { dx: e.clientX - w.rect.x, dy: e.clientY - w.rect.y, mode };
    addEventListener("pointermove", move); addEventListener("pointerup", end);
  };
  if (w.minimized) return null;
  return <section ref={element} role="dialog" aria-label={`${w.title} window`} data-testid="window"
    onPointerDown={() => dispatch({ t: "focus", id: w.id })}
    className={cls("absolute flex flex-col overflow-hidden rounded-lg border bg-slate-950/90 shadow-2xl backdrop-blur-sm transition-opacity", state.focus === w.id ? "border-[var(--accent)]/60" : "border-white/10")}
    style={{ ...rectStyle(w.rect), zIndex: (w.alwaysOnTop ? 10000 : 0) + w.z, opacity: dim ? 0.55 : 1 }}>
    <header onPointerDown={e => begin(e, "move")} onDoubleClick={() => dispatch({ t: "maximize", id: w.id })} className="flex h-8 shrink-0 cursor-grab items-center gap-2 border-b border-white/10 bg-white/10 px-2 text-[11px]">
      <span aria-hidden>{appOf(w.module)?.icon}</span><span className="min-w-0 flex-1 truncate">{w.title}</span>
      <button aria-label="Tile left" className="rounded px-1 hover:bg-white/15" onClick={() => dispatch({ t: "tile", id: w.id, zone: "left" })}>◧</button>
      <button aria-label="Tile right" className="rounded px-1 hover:bg-white/15" onClick={() => dispatch({ t: "tile", id: w.id, zone: "right" })}>◨</button>
      <button aria-label={w.alwaysOnTop ? "Unpin from top" : "Keep on top"} className="rounded px-1 hover:bg-white/15" onClick={() => dispatch({ t: "toTop", id: w.id, on: !w.alwaysOnTop })}>{w.alwaysOnTop ? "📌" : "📍"}</button>
      <button aria-label="Minimize" className="rounded px-1 hover:bg-white/15" onClick={() => dispatch({ t: "minimize", id: w.id })}>—</button>
      <button aria-label={w.maximized ? "Restore" : "Maximize"} className="rounded px-1 hover:bg-white/15" onClick={() => dispatch({ t: "maximize", id: w.id })}>▢</button>
      <button aria-label="Close" className="rounded px-1 text-rose-300 hover:bg-rose-500/30" onClick={() => dispatch({ t: "close", id: w.id })}>✕</button>
    </header>
    <div className="fusion-window-content min-h-0 flex-1 overflow-hidden">{appOf(w.module)?.render(w) ?? <p className="p-3 text-xs">Module unavailable.</p>}</div>
    <div onPointerDown={e => begin(e, "resize")} className="absolute bottom-0 right-0 h-4 w-4 cursor-nwse-resize" aria-hidden />
  </section>;
}

function TopBar({ state, governor, entitlement, dnd, heldCount, focusMode, onLauncher, onOverview, onQuick, onLedger }: {
  state: DesktopState; governor: { state: GovernorState; frameMs: number }; entitlement: ShellApi["entitlement"]; dnd: boolean; heldCount: number; focusMode: boolean;
  onLauncher: () => void; onOverview: () => void; onQuick: () => void; onLedger: () => void;
}) {
  const [clock, setClock] = useState("");
  useEffect(() => { const t = setInterval(() => setClock(new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })), 1000); return () => clearInterval(t); }, []);
  return <header className="absolute inset-x-0 top-0 z-[9000] flex h-9 items-center gap-2 border-b border-white/10 bg-slate-950/80 px-2 text-[11px] backdrop-blur">
    <button onClick={onLauncher} className="rounded px-2 py-0.5 font-semibold text-[var(--accent)] hover:bg-white/10">Fusion</button>
    <button onClick={onOverview} className="rounded px-2 py-0.5 hover:bg-white/10">Overview</button>
    <button data-testid="open-ledger" onClick={onLedger} className="rounded px-2 py-0.5 text-[var(--accent)] hover:bg-white/10">Build ledger</button>
    <span className="hidden text-slate-500 md:inline">Ctrl+K palette · Meta+← → tile · Alt+1..9 space</span>
    <div className="flex-1" />
    {focusMode && <span data-testid="focus-indicator" className="rounded bg-sky-500/20 px-1.5 py-0.5 text-sky-200">Focus</span>}
    {dnd && <span data-testid="dnd-indicator" className="rounded bg-amber-500/20 px-1.5 py-0.5 text-amber-200">DND · {heldCount} held</span>}
    <span className="flex items-center gap-1 text-slate-400"><StateDot state={governor.state === "COOL" ? "available" : governor.state === "CRITICAL" ? "blocked" : "needs-permission"} />{governor.state} {governor.frameMs.toFixed(0)}ms</span>
    {entitlement && <span className="rounded bg-white/10 px-1.5 py-0.5">{entitlement.state === "trial" ? `trial ${entitlement.daysLeft}d` : entitlement.state}</span>}
    <span className="text-slate-400">{state.workspaces.find(k => k.id === state.workspace)?.name}</span>
    <button onClick={onQuick} aria-label="Quick panel" className="rounded px-2 py-0.5 hover:bg-white/10">⚡</button>
    <span data-testid="clock" className="tabular-nums">{clock}</span>
  </header>;
}
function Shelf({ state, dispatch, onLauncher }: { state: DesktopState; dispatch: (c: WindowCommand) => void; onLauncher: () => void }) {
  return <footer className="absolute inset-x-0 bottom-0 z-[9000] flex h-[52px] items-center gap-2 border-t border-white/10 bg-slate-950/80 px-2 py-1.5 backdrop-blur">
    <button onClick={onLauncher} aria-label="Open launcher" className="rounded bg-white/10 px-2 py-1 text-xs hover:bg-white/20">▦</button>
    <div data-testid="shelf" className="flex min-w-0 flex-1 gap-1 overflow-x-auto">{state.windows.filter(w => w.workspace === state.workspace).map(w =>
      <button key={w.id} onClick={() => dispatch(w.minimized ? { t: "restore", id: w.id } : { t: "focus", id: w.id })}
        className={cls("flex max-w-44 items-center gap-1 truncate rounded px-2 py-1 text-[11px]", state.focus === w.id ? "bg-[var(--accent)]/25 text-white" : "bg-white/5 text-slate-300 hover:bg-white/10", w.minimized && "opacity-50")}>{appOf(w.module)?.icon} <span className="truncate">{w.title}</span></button>)}</div>
    <div className="flex gap-1">{state.workspaces.map(k => <button key={k.id} onClick={() => dispatch({ t: "switchWorkspace", workspace: k.id })} className={cls("rounded px-2 py-1 text-[10px]", state.workspace === k.id ? "bg-[var(--accent)]/25" : "bg-white/5 hover:bg-white/10")}>{k.name}</button>)}
      <button onClick={() => dispatch({ t: "addWorkspace" })} className="rounded bg-white/5 px-2 py-1 text-[10px] hover:bg-white/10">+</button></div>
  </footer>;
}
function Launcher({ onPick, onClose }: { onPick: (id: string) => void; onClose: () => void }) {
  const [q, setQ] = useState("");
  return <div data-testid="launcher" className="absolute inset-0 z-[9500] bg-black/50 backdrop-blur-sm" onClick={onClose}>
    <div className="absolute inset-x-0 bottom-14 mx-auto w-[min(860px,94vw)] rounded-xl border border-white/10 bg-slate-950/95 p-3" onClick={e => e.stopPropagation()}>
      <input autoFocus value={q} onChange={e => setQ(e.target.value)} placeholder="Search applications" aria-label="Search applications" className="mb-3 w-full rounded border border-white/15 bg-black/40 px-3 py-2 text-sm outline-none" />
      <div className="grid grid-cols-[repeat(auto-fill,minmax(96px,1fr))] gap-2">{APPS.filter(a => a.name.toLowerCase().includes(q.toLowerCase())).map(a => <button key={a.id} onClick={() => onPick(a.id)} className="flex flex-col items-center gap-1 rounded-lg p-3 text-[11px] hover:bg-white/10"><span className="text-2xl" aria-hidden>{a.icon}</span>{a.name}</button>)}</div>
    </div>
  </div>;
}
function Palette({ onClose, open, dispatch, state, toast, setDnd, setFocusMode, focusMode, dnd }: {
  onClose: () => void; open: (id: string, title?: string, doc?: string) => void; dispatch: (c: WindowCommand) => void; state: DesktopState;
  toast: (m: string, k?: "info" | "warn" | "error") => void; setDnd: (on: boolean) => void; setFocusMode: (on: boolean) => void; focusMode: boolean; dnd: boolean;
}) {
  const [q, setQ] = useState("");
  const [remote, setRemote] = useState<{ source: string; id: string; title: string; subtitle: string }[]>([]);
  useEffect(() => { if (!q) { setRemote([]); return; } const t = setTimeout(() => { fetch(`/api/search?q=${encodeURIComponent(q)}`).then(r => r.json()).then(j => setRemote(j.results.slice(0, 12))); }, 90); return () => clearTimeout(t); }, [q]);
  const commands = [
    ...APPS.map(a => ({ group: "app", label: `Open ${a.name}`, run: () => open(a.id) })),
    { group: "window", label: "Tile focused window left", run: () => state.focus && dispatch({ t: "tile", id: state.focus, zone: "left" }) },
    { group: "window", label: "Tile focused window right", run: () => state.focus && dispatch({ t: "tile", id: state.focus, zone: "right" }) },
    { group: "window", label: "Close all windows", run: () => dispatch({ t: "closeAll" }) },
    { group: "window", label: "New workspace", run: () => dispatch({ t: "addWorkspace" }) },
    { group: "shell", label: `${focusMode ? "Leave" : "Enter"} focus mode`, run: () => setFocusMode(!focusMode) },
    { group: "shell", label: `${dnd ? "Turn off" : "Turn on"} do-not-disturb`, run: () => setDnd(!dnd) },
    { group: "shell", label: "Run verification self-test", run: () => open("verify") },
    { group: "shell", label: "Share this desktop", run: () => { navigator.share?.({ title: "Fusion Shell", url: location.href }).catch(() => toast("Share cancelled")); } },
  ];
  const calc = /^[\d\s().+\-*/%^]+$/.test(q.trim()) && q.trim().length > 2 ? evaluate(q) : null;
  return <div data-testid="palette" className="absolute inset-0 z-[9600] bg-black/40" onClick={onClose}>
    <div className="mx-auto mt-24 w-[min(680px,92vw)] overflow-hidden rounded-xl border border-white/15 bg-slate-950/95 shadow-2xl" onClick={e => e.stopPropagation()}>
      <input autoFocus value={q} onChange={e => setQ(e.target.value)} placeholder="Type a command, a file, 12*(3+4)…" aria-label="Command palette" className="w-full border-b border-white/10 bg-transparent px-4 py-3 text-sm outline-none" />
      <div className="max-h-96 overflow-auto p-1">
        {calc !== null && Number.isFinite(calc) && <div className="px-3 py-2 text-sm">{q} = <b className="text-[var(--accent)]">{calc}</b></div>}
        {commands.filter(c => c.label.toLowerCase().includes(q.toLowerCase())).slice(0, 8).map((c, i) => <button key={i} onClick={() => { c.run(); onClose(); }} className="flex w-full items-center gap-2 rounded px-3 py-1.5 text-left text-xs hover:bg-white/10"><span className="rounded bg-white/10 px-1 text-[9px] uppercase text-slate-400">{c.group}</span>{c.label}</button>)}
        {remote.map((r, i) => <button key={i} onClick={() => { if (r.source === "file") open("editor", r.title, r.id); else open("find"); onClose(); }} className="flex w-full items-center gap-2 rounded px-3 py-1.5 text-left text-xs hover:bg-white/10"><span className="rounded bg-sky-500/15 px-1 text-[9px] uppercase text-sky-300">{r.source}</span><span className="min-w-0 flex-1 truncate">{r.title}</span></button>)}
      </div>
      <p className="border-t border-white/10 px-3 py-1 text-[10px] text-slate-500">Local results are shown with provenance; web results live in Find and are off by default.</p>
    </div>
  </div>;
}
function Overview({ state, dispatch, onClose }: { state: DesktopState; dispatch: (c: WindowCommand) => void; onClose: () => void }) {
  return <div data-testid="overview" className="absolute inset-0 z-[9400] bg-black/70 p-8 backdrop-blur" onClick={onClose}>
    <div className="grid grid-cols-[repeat(auto-fill,minmax(220px,1fr))] gap-3" onClick={e => e.stopPropagation()}>{state.windows.map(w => <button key={w.id} onClick={() => { dispatch({ t: "focus", id: w.id }); onClose(); }} className="flex h-32 flex-col rounded-lg border border-white/15 bg-slate-900/80 p-2 text-left text-[11px] hover:border-[var(--accent)]"><span>{appOf(w.module)?.icon} {w.title}</span><span className="text-slate-500">{w.rect.w}×{w.rect.h} · space {w.workspace} · z{w.z}</span><span className="mt-auto flex gap-1">{state.workspaces.map(k => <span key={k.id} role="button" tabIndex={0} onClick={e => { e.stopPropagation(); dispatch({ t: "toWorkspace", id: w.id, workspace: k.id }); }} onKeyDown={e => { if (e.key === "Enter") dispatch({ t: "toWorkspace", id: w.id, workspace: k.id }); }} className="rounded bg-white/10 px-1 text-[9px]">→{k.name}</span>)}</span></button>)}</div>
    <p className="mt-4 text-center text-[11px] text-slate-400">Previews are metadata, not screenshots of cross-origin frames.</p>
  </div>;
}
function QuickPanel({ onClose, governor, probe, open, dnd, setDnd, focusMode, setFocusMode, widgetIds, setWidgetIds, bgPaused, pauseReason }: {
  onClose: () => void; governor: { state: GovernorState; evidence: string }; probe: Probe | null; open: (id: string) => void; dnd: boolean; setDnd: (on: boolean) => void; focusMode: boolean; setFocusMode: (on: boolean) => void; widgetIds: string[]; setWidgetIds: (ids: string[]) => void; bgPaused: boolean; pauseReason: string;
}) {
  const [screens, setScreens] = useState("not requested");
  const [wake, setWake] = useState(false);
  return <div className="absolute inset-0 z-[9500]" onClick={onClose}><div data-testid="quick-panel" className="absolute right-2 top-10 w-80 rounded-xl border border-white/15 bg-slate-950/95 p-3 text-[11px]" onClick={e => e.stopPropagation()}>
    <p className="mb-2 font-semibold">Quick panel</p>
    <div className="mb-2 flex flex-wrap gap-1">{["beam", "alerts", "monitor", "settings", "touchpad", "ledger"].map(id => <Btn key={id} small onClick={() => open(id)}>{appOf(id)?.name}</Btn>)}</div>
    <div className="mb-2 flex flex-wrap gap-2"><label className="flex items-center gap-1"><input type="checkbox" checked={dnd} onChange={e => setDnd(e.target.checked)} data-testid="dnd-toggle" /> Do not disturb</label><label className="flex items-center gap-1"><input type="checkbox" checked={focusMode} onChange={e => setFocusMode(e.target.checked)} /> Focus mode</label></div>
    <div className="mb-2 flex flex-wrap gap-1">{["clock", "governor", "nextTask", "fault"].map(id => <button key={id} onClick={() => setWidgetIds(widgetIds.includes(id) ? widgetIds.filter(x => x !== id) : [...widgetIds, id])} className={cls("rounded px-2 py-0.5 text-[10px]", widgetIds.includes(id) ? "bg-[var(--accent)]/25" : "bg-white/5")}>{widgetIds.includes(id) ? "✓ " : ""}{id === "fault" ? "fault (test)" : id}</button>)}</div>
    <div className="mb-2 flex gap-1"><Btn small onClick={async () => { const fn = (window as unknown as { getScreenDetails?: () => Promise<{ screens: { label: string; width: number; height: number }[] }> }).getScreenDetails; if (!fn) return setScreens("Window Management API unavailable"); try { const d = await fn(); setScreens(d.screens.map(s => `${s.label} ${s.width}×${s.height}`).join(" · ")); } catch { setScreens("permission denied"); } }}>Detect displays</Btn>
      <Btn small onClick={async () => { try { const n = navigator as Navigator & { wakeLock?: { request: (t: string) => Promise<unknown> } }; setWake(!!(await n.wakeLock?.request("screen"))); } catch { setWake(false); } }}>{wake ? "Wake lock held" : "Hold wake lock"}</Btn>
      <Btn small onClick={() => document.documentElement.requestFullscreen?.()}>Fullscreen</Btn></div>
    <p className="text-slate-400">Displays: {screens}</p><p className="text-slate-400">Governor: {governor.state} — {governor.evidence}</p>
    <p className="text-slate-400">Background work: {bgPaused ? `paused — ${pauseReason}` : "running"}</p>
    <p className="text-slate-500">System volume and brightness cannot be controlled by a web page.{probe ? "" : ""}</p>
  </div></div>;
}
