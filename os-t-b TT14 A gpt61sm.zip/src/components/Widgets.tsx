"use client";

// Implements: SH-05 widget host with per-widget error boundaries (a crashing widget cannot take down the shell).
// The "fault" widget is a deliberate fault injector used by the e2e suite to prove crash isolation.
import React, { useEffect, useState } from "react";
import { kvGet } from "./apps/productivity";
import type { Task } from "./apps/productivity";
import type { GovernorState } from "./ui";

export const WIDGET_LABELS: Record<string, string> = {
  clock: "Clock",
  governor: "Governor",
  nextTask: "Next task",
  fault: "Fault injector (test)",
};

class Boundary extends React.Component<{ name: string; children: React.ReactNode }, { err: string | null }> {
  state = { err: null as string | null };
  static getDerivedStateFromError(e: Error) {
    return { err: e.message || String(e) };
  }
  render() {
    if (this.state.err) {
      return (
        <div data-testid={`widget-crashed-${this.props.name}`} role="alert" className="text-[11px] text-rose-100">
          Widget “{WIDGET_LABELS[this.props.name] ?? this.props.name}” crashed: {this.state.err}. The shell and other windows are unaffected.
          <div className="mt-1">
            <button className="underline" onClick={() => this.setState({ err: null })}>Retry</button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

function Fault(): React.ReactElement {
  throw new Error("intentional fault injected by the Widgets test");
}

function Clock() {
  // Hydration-safe: the server renders a placeholder; the real time is set after mount.
  // (Rendering new Date() during SSR caused React error #418 in the browser suite.)
  const [now, setNow] = useState<Date | null>(null);
  useEffect(() => {
    setNow(new Date());
    const t = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(t);
  }, []);
  return (
    <p className="text-lg tabular-nums" data-testid="widget-clock">
      {now ? now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" }) : "--:--:--"}
    </p>
  );
}

function NextTask() {
  const [t, setT] = useState<Task | null>(null);
  useEffect(() => {
    const load = () =>
      kvGet<Task[]>("app.tasks", []).then((list) => {
        const open = list.filter((x) => !x.done && x.due).sort((a, b) => (a.due! < b.due! ? -1 : 1));
        setT(open[0] ?? null);
      });
    void load();
    const i = setInterval(load, 10_000);
    return () => clearInterval(i);
  }, []);
  return t ? <p>{t.title} <span className="text-slate-500">· {new Date(t.due!).toLocaleTimeString()}</span></p> : <p className="text-slate-500">No timed items.</p>;
}

function renderWidget(id: string, governor: { state: GovernorState; frameMs: number }) {
  switch (id) {
    case "clock": return <Clock />;
    case "governor": return <p>{governor.state} · {governor.frameMs.toFixed(1)} ms/frame</p>;
    case "nextTask": return <NextTask />;
    case "fault": return <Fault />;
    default: return <p>Unknown widget “{id}”.</p>;
  }
}

export function Widgets({ ids, governor }: { ids: string[]; governor: { state: GovernorState; frameMs: number } }) {
  return (
    <div data-testid="widgets" className="pointer-events-none absolute right-3 top-12 z-[8000] flex w-52 flex-col gap-2">
      {ids.map((id) => (
        <div key={id} className="pointer-events-auto rounded-lg border border-white/10 bg-slate-950/80 p-2 text-[11px] text-slate-200 backdrop-blur">
          <div className="mb-1 text-[9px] uppercase tracking-wider text-slate-500">{WIDGET_LABELS[id] ?? id}</div>
          <Boundary name={id}>{renderWidget(id, governor)}</Boundary>
        </div>
      ))}
    </div>
  );
}
