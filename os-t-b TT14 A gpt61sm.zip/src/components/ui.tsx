"use client";

import React, { createContext, useCallback, useContext, useEffect, useRef, useState } from "react";
import type { DesktopState, WindowCommand } from "@/lib/windowEngine";
import type { Probe } from "@/lib/capabilities";
import type { Routine } from "@/lib/routines";

export type GovernorState = "COOL" | "WARM" | "HOT" | "THROTTLED" | "CRITICAL";

export type ShellApi = {
  state: DesktopState;
  dispatch: (c: WindowCommand) => void;
  open: (module: string, title?: string, docId?: string) => void;
  close: (id: string) => void;
  probe: Probe | null;
  settings: Record<string, unknown>;
  setSetting: (key: string, value: unknown) => Promise<void>;
  toast: (msg: string, kind?: "info" | "warn" | "error") => void;
  governor: { state: GovernorState; evidence: string; frameMs: number };
  entitlement: { state: string; daysLeft: number; plan: string } | null;
  refreshEntitlement: () => void;
  locked: Record<string, unknown>;
  focusMode: boolean;
  setFocusMode: (on: boolean) => void;
  dnd: boolean;
  setDnd: (on: boolean) => void;
  heldCount: number;
  bgPaused: boolean;
  pauseReason: string;
  snapshot: () => DesktopState;
  loadState: (s: DesktopState) => void;
  runRoutine: (r: Routine, source: string) => void;
  widgetIds: string[];
  setWidgetIds: (ids: string[]) => void;
};

export const Shell = createContext<ShellApi | null>(null);
export const useShell = () => {
  const v = useContext(Shell);
  if (!v) throw new Error("useShell outside provider");
  return v;
};

export const cls = (...a: (string | false | undefined | null)[]) => a.filter(Boolean).join(" ");

export function useJson<T>(url: string | null, deps: unknown[] = []) {
  const [data, setData] = useState<T | null>(null);
  const [loading, setLoading] = useState(!!url);
  const [error, setError] = useState<string | null>(null);
  const reload = useCallback(() => {
    if (!url) return;
    setLoading(true);
    fetch(url)
      .then((r) => r.json())
      .then((j) => { setData(j as T); setError(null); })
      .catch((e) => setError(String(e)))
      .finally(() => setLoading(false));
  }, [url]);
  useEffect(reload, [reload, ...deps]); // eslint-disable-line react-hooks/exhaustive-deps
  return { data, loading, error, reload, setData };
}

export async function post<T>(url: string, body: unknown, method = "POST"): Promise<T> {
  const r = await fetch(url, { method, headers: { "content-type": "application/json" }, body: JSON.stringify(body) });
  return (await r.json()) as T;
}

export function Btn({
  children, onClick, kind = "ghost", small, disabled, title, type = "button", testId, "data-testid": dataTestId,
}: {
  children: React.ReactNode; onClick?: (e: React.MouseEvent) => void; kind?: "ghost" | "primary" | "danger" | "flat";
  small?: boolean; disabled?: boolean; title?: string; type?: "button" | "submit";
  /** Forwarded as data-testid. Accepts both testId and data-testid for ergonomics. */
  testId?: string;
  "data-testid"?: string;
}) {
  const base = "inline-flex items-center gap-1.5 rounded-md border transition-colors focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-1 focus-visible:outline-[var(--accent)] disabled:opacity-40";
  const size = small ? "px-2 py-1 text-[11px]" : "px-2.5 py-1.5 text-xs";
  const look =
    kind === "primary" ? "border-[var(--accent)] bg-[var(--accent)]/15 text-[var(--accent)] hover:bg-[var(--accent)]/25"
    : kind === "danger" ? "border-rose-500/50 text-rose-300 hover:bg-rose-500/15"
    : kind === "flat" ? "border-transparent text-slate-300 hover:bg-white/10"
    : "border-white/15 bg-white/5 text-slate-200 hover:bg-white/10";
  const tid = testId || dataTestId;
  return (
    <button type={type} title={title} disabled={disabled} onClick={onClick} data-testid={tid} className={cls(base, size, look)}>
      {children}
    </button>
  );
}

export const Badge = ({ children, tone = "slate" }: { children: React.ReactNode; tone?: string }) => (
  <span className={`rounded px-1.5 py-0.5 text-[10px] font-medium uppercase tracking-wide bg-${tone}-500/15 text-${tone}-300 border border-${tone}-500/25`}>
    {children}
  </span>
);

export const StateDot = ({ state }: { state: string }) => {
  const color =
    state === "available" || state === "implemented" || state === "COMPLETE" ? "bg-emerald-400"
    : state === "needs-permission" || state === "skeleton" || state === "partial" ? "bg-amber-400"
    : state === "impossible" || state === "blocked" || state === "not-applicable" ? "bg-rose-400"
    : "bg-slate-500";
  return <span className={`inline-block h-2 w-2 shrink-0 rounded-full ${color}`} aria-hidden />;
};

export const Section = ({ title, children, right }: { title: string; children: React.ReactNode; right?: React.ReactNode }) => (
  <section className="mb-3 rounded-lg border border-white/10 bg-black/20">
    <header className="flex items-center justify-between border-b border-white/10 px-3 py-1.5">
      <h3 className="text-[11px] font-semibold uppercase tracking-wider text-slate-400">{title}</h3>
      {right}
    </header>
    <div className="p-3 text-xs text-slate-200">{children}</div>
  </section>
);

export const Note = ({ children }: { children: React.ReactNode }) => (
  <p className="mt-2 rounded border border-sky-400/20 bg-sky-400/5 p-2 text-[11px] leading-relaxed text-sky-200/90">{children}</p>
);

export const Wall = ({ children }: { children: React.ReactNode }) => (
  <p className="mt-2 rounded border border-rose-400/25 bg-rose-500/5 p-2 text-[11px] leading-relaxed text-rose-200/90">
    <strong className="font-semibold">Platform wall.</strong> {children}
  </p>
);

export function useInterval(fn: () => void, ms: number | null) {
  const ref = useRef(fn);
  ref.current = fn;
  useEffect(() => {
    if (ms === null) return;
    const id = setInterval(() => ref.current(), ms);
    return () => clearInterval(id);
  }, [ms]);
}

export const fmtBytes = (b: number) =>
  b < 1024 ? `${b} B` : b < 1048576 ? `${(b / 1024).toFixed(1)} KB` : `${(b / 1048576).toFixed(2)} MB`;
