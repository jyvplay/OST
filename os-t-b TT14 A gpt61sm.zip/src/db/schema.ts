import {
  pgTable,
  serial,
  text,
  integer,
  boolean,
  timestamp,
  jsonb,
  bigint,
  index,
} from "drizzle-orm/pg-core";

/** FM-01/FM-11: virtual file system nodes (DB-backed VFS). */
export const fsNodes = pgTable(
  "fs_nodes",
  {
    id: serial("id").primaryKey(),
    parentId: integer("parent_id"),
    name: text("name").notNull(),
    kind: text("kind").notNull().default("file"), // 'dir' | 'file'
    mime: text("mime").notNull().default("text/plain"),
    content: text("content").notNull().default(""),
    size: integer("size").notNull().default(0),
    trashed: boolean("trashed").notNull().default(false),
    trashedFrom: text("trashed_from"),
    tags: text("tags").notNull().default(""),
    version: integer("version").notNull().default(1),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("fs_nodes_parent_idx").on(t.parentId), index("fs_nodes_name_idx").on(t.name)],
);

/** FM-03 / §5.7: durable journal for the file-operation state machine. */
export const fileOps = pgTable("file_ops", {
  id: serial("id").primaryKey(),
  kind: text("kind").notNull(), // copy | move | delete | restore | batch_rename
  state: text("state").notNull(), // REQUESTED..COMPLETE | FAILED
  srcIds: text("src_ids").notNull().default(""),
  destParentId: integer("dest_parent_id"),
  journal: jsonb("journal").notNull().default([]),
  undoable: boolean("undoable").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

/** BK-01: timeline versions for every write. */
export const fsVersions = pgTable("fs_versions", {
  id: serial("id").primaryKey(),
  nodeId: integer("node_id").notNull(),
  path: text("path").notNull().default(""),
  content: text("content").notNull().default(""),
  version: integer("version").notNull().default(1),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

/** ST-01 settings graph + desktop state + profiles + entitlement cache. */
export const kv = pgTable("kv", {
  key: text("key").primaryKey(),
  value: jsonb("value").notNull(),
  scope: text("scope").notNull().default("settings"),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const notes = pgTable("notes", {
  id: serial("id").primaryKey(),
  title: text("title").notNull().default("Untitled"),
  body: text("body").notNull().default(""),
  tags: text("tags").notNull().default(""),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

/** NC-01 alert store (7-day TTL enforced on read). */
export const alerts = pgTable("alerts", {
  id: serial("id").primaryKey(),
  app: text("app").notNull(),
  title: text("title").notNull(),
  body: text("body").notNull().default(""),
  priority: text("priority").notNull().default("normal"),
  read: boolean("read").notNull().default(false),
  pinned: boolean("pinned").notNull().default(false),
  snoozedUntil: timestamp("snoozed_until", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

/** MS-01/05/06: messages module (SMS/Matrix/local only; no iMessage without a Mac). */
export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  thread: text("thread").notNull(),
  author: text("author").notNull().default("me"),
  body: text("body").notNull().default(""),
  channel: text("channel").notNull().default("local"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

/** SC-01: vault stores ciphertext only; keys never leave the browser. */
export const vaultItems = pgTable("vault_items", {
  id: serial("id").primaryKey(),
  label: text("label").notNull(),
  kind: text("kind").notNull().default("password"),
  ciphertext: text("ciphertext").notNull(),
  iv: text("iv").notNull(),
  salt: text("salt").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

/** CA-*: Beam target trust memory (A-11 rogue receiver control). */
export const castTargets = pgTable("cast_targets", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  protocol: text("protocol").notNull(), // remote-playback | presentation | webrtc-together | audio-sink
  fingerprint: text("fingerprint").notNull().default(""),
  trusted: boolean("trusted").notNull().default(false),
  lastSeen: timestamp("last_seen", { withTimezone: true }).notNull().defaultNow(),
});

/** Feature register (§7) — the source of truth, browsable in-app. */
export const features = pgTable("features", {
  id: text("id").primaryKey(),
  area: text("area").notNull(),
  title: text("title").notNull(),
  tier: text("tier").notNull(),
  phase: text("phase").notNull(),
  route: text("route").notNull().default(""),
  status: text("status").notNull().default("spec"), // spec | skeleton | implemented | blocked | not-applicable
  webNuance: text("web_nuance").notNull().default(""),
});

export const auditLog = pgTable("audit_log", {
  id: serial("id").primaryKey(),
  actor: text("actor").notNull().default("user"),
  action: text("action").notNull(),
  detail: jsonb("detail").notNull().default({}),
  at: timestamp("at", { withTimezone: true }).notNull().defaultNow(),
});

/** LN-20 Fusion Meet signalling: append-only log (no read-modify-write races between peers). */
export const signals = pgTable(
  "signals",
  {
    id: serial("id").primaryKey(),
    room: text("room").notNull(),
    fromPeer: text("from_peer").notNull(),
    kind: text("kind").notNull(),
    payload: jsonb("payload").notNull().default({}),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("signals_room_idx").on(t.room, t.id)],
);

/** CA-11 Together rooms (server-held sync clock, no cloud relay beyond this origin). */
export const togetherRooms = pgTable("together_rooms", {
  code: text("code").primaryKey(),
  state: jsonb("state").notNull(),
  epochMs: bigint("epoch_ms", { mode: "number" }).notNull().default(0),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});
